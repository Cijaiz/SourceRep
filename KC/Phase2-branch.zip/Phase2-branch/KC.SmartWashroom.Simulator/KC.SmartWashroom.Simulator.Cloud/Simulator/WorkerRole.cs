using System;
using System.Diagnostics;
using System.Net;
using System.Threading;
using Microsoft.WindowsAzure.ServiceRuntime;
using KC.SmartWashroom.Business.Simulator;
using KC.SmartWashroom.Core.Helper;
using System.Collections.Generic;
using KC.SmartWashroom.Core.Log;

namespace Simulator
{
    public class WorkerRole : RoleEntryPoint
    {
        private int simulatorRunTime;
        private const string SimulatorIntervalKey = "SimulatorRunTimeIntervalInSecs";

        public override void Run()
        {
            while (true)
            {
                try
                {
                    Logger.Debug("Device Data Simulator running...");
                    GatewayFeedManager gfMgr = new GatewayFeedManager();
                    gfMgr.GatewayFeeder();
                    Thread.Sleep(simulatorRunTime * 1000);
                    Trace.TraceInformation("Working");
                }
                catch (Exception exp)
                {
                    Logger.Error(exp.ToString());
                }
            }
        }

        public override bool OnStart()
        {
            //Get the value from cloud configuration
            Logger.Debug("Device Data Simulator Started");
            simulatorRunTime = Convert.ToInt32(CommonHelper.GetConfigSetting(SimulatorIntervalKey));
            return base.OnStart();
        }
    }
}
