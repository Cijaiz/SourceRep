﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.Core.Constants
{
    public class DeviceHubConstants
    {
        public const string DEVICE_HUB_AUTH_TOKEN = "DeviceHubAuthToken";
    }
}
