﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.Core.Constants
{
    public class TrafficChartConstants
    {
        // chart constants for building view traffic chart weekwise 
        // chart constants for floor view traffic chart weekwise
        // chart constants for floor view product usage weekwise
        public const string XAxisWeek = "UsageDayOfWeek";
        public const string XAxisLabel = "Date";
        public const string XAxisLabelWeek = "Days";
        public const string SecondaryAxisWeek = "Week";
        public const string YAxisTraffic = "CountOfTraffic";
        public const string YAxisLabel = "Visits";
        public const string UsageYAxisLabel = "Units Consumed";

        //Different Charts
        public const string ChartTraffic = "Traffic";
        public const string ChartUsage = "SupplyUsage";

        // chart constants for building view traffic chart monthwise 
        // chart constants for floor view traffic chart monthwise
        // chart constants for floor view product usage monthwise
        public const string XAxisMonth = "UsageDay";
        public const string SecondaryAxisMonth = "Month";

        // chart constants for floor view product usage weekwise        
        public const string SecondaryAxisSupplyWeekAndMonth = "ProductType";
        public const string YAxisProductUsage = "CountOfUsage";

        //Titles and Chart Ids
        public const string TrafficTitle = "Traffic Chart";
        public const string TrafficChartId = "TrafficChart_Id";      

        public const string SupplyUsageChartTitle = "Supply Usage Chart";
        public const string SupplyUsageChartId = "SupplyUsageChart_Id";

        //Business Hub API Controllers
        public const string ControllerUsageMart = "UsageMart";        

        //Business Hub API Action Methods
        public const string API_TrafficDataWeek = "GetTrafficDataWeekwise";
        public const string API_TrafficDataMonth = "GetTrafficDataMonthWise";
        public const string API_SupplyUsageWeek = "GetProductUsageWeekwise";
        public const string API_SupplyUsageMonth = "GetProductUsageMonthwise";
        public const string API_SupplyUsageSummary = "GetProductSummaryData";
        public const string API_GetRefillBeforeThreshold = "GetRefillBeforeThreshold";

        //Last n months
        public const int Last_N_Months = 6;

        //String separator for Month dropdown list
        public const string MonthYearSeparator = "_";

        //String for this or last month
        public const string This = "This ";
        public const string Last = "Last ";

        //devicetypes
        public const string eHRT = "2";
        public const string JRT = "1";
        public const string eSoap = "3";
        public const string SRB = "4";
        public const string Batteries = "Batteries Replaced";

        public const string eHRTName = "Paper Towels";
        public const string JRTName = "Tissue (Large)";
        public const string SRBName = "Tissue (Small)";
        public const string eSoapName = "Soap";

        public const string Rolls = "(in Rolls)";
        public const string Bottles = "(in Bottles)";
        public const string Numbers = "(in Numbers)";

        //storyboard chart constants
        public const string ControllerStoryboard = "AlertMart";
        public const string API_Storyboard = "GetStoryBoardData";
        public const string NoData = "<div> No data found for the selected filters </div>";
        public const string ErrorMessage = "<div> Error while loading the chart. Please contact the Administrator </div>";

        //Refill chart constant
        public const string Times = "Times";
        public const string Time = "Time";
    }
}
