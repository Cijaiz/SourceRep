﻿namespace KC.SmartWashroom.Core.Constants
{
    public class AlertEngineConstants
    {
        public static string[] UNIVERSAL_FORMATS = {"M/d/yyyy h:mm:ss tt", "M/d/yyyy h:mm tt", "MM/dd/yyyy hh:mm:ss", 
                                                      "M/d/yyyy h:mm:ss", "M/d/yyyy hh:mm tt", "M/d/yyyy hh tt", 
                                                      "M/d/yyyy h:mm", "M/d/yyyy h:mm", "MM/dd/yyyy hh:mm", "M/dd/yyyy hh:mm"};

        public static int INTERNALQUEUE_TASK_COUNT = 2;
        public static int CACHE_TASK_COUNT = 1;

        public static string LASTDEVICEERRORS_BLOB_CONTAINER = "alertenginetemplates";
        public static string LASTDEVICEERRORS_BLOB_TEXT_NAME = "lastdevicetraceerrors";

        public const int MAINTHREAD_SLEEPTIME = 5000;
        public const string DATE_FORMAT = "dd'-'MM'-'yyyy  HH:mm:ss:fff tt";
        public const string BUSINESS_HUB_URL = "BusinessHubUrl";

        public const string GET_USER_DETAILS_ACTION = "GetUsersDetails";
        public const string GET_ERROR_ADMIN_DETAILS_ACTION = "GetErrorAdminDetails";
        public const string GET_USER_DETAILS_CONTROLLER = "Tenants";

        public const string DEVICE_TENANTS_CONTROLLER = "DeviceTenant";
        public const string GET_ALL_PROPERTIES_ACTION = "GetAllProperties";
        public const string GET_ALL_PROPERTIES_CONTROLLER = "Property";
        public const string GET_CUSTOMER_NAME_BYID = "GetCustomerNameByID";

        public const string GET_ALL_BUILDINGS_BY_PROPERTYID_ACTION = "GetBuildingByPropertyId";
        public const string GET_ALERTDETAILS_BY_ALERT_GROUP = "GetAlertDetailsByAlertGroup";
        public const string GET_FLOORSETS_BY_BUILDINGID = "GetFloorSetsByBuildingId";
        public const string GET_ALL_BUILDINGS_BY_CUSTID_ACTION = "GetAllBuildings";
        public const string GET_DEVICE_PARAMETERS = "GetDeviceParameters";
        public const string UPSET_RETURN_PARAMETERS = "UpsetReturnParameters";
        public const string DELETE_DEVICE_PARAMETER_VALUE = "RemoveReturnParameterValues";

        public const string CLEAR_ALL_DEVICE_OVERRIDES = "ClearAllDeviceOverrides";
        public const string GET_ALL_BUILDINGS_CONTROLLER = "Building";
        public const string RECENTUPDATES_CONTROLLER = "RecentUpdates";

        public const string GET_FLOOR_ALERTS_CONTROLLER = "Floor";
        public const string GET_FLOOR_ALERTS_ACTION = "GetFloorAlerts";

        public const string GET_FLOOR_ALERTS_BY_GENDERID = "GetFloorAlertsbyGenderId";
        public const string GET_FLOORS_BY_BUILDINGID = "GetFloors";
        public const string GET_WASHROOM_CONTROLLER = "Washroom";
        public const string GET_WASHROOMS_BY_FLOORID = "GetWashroomsByFloorId";
        public const string GET_DEVICE_STATUS_IN_WASHROOMS = "GetDeviceStatusInWashrooms";
        public const string GET_UNRESPONSIVE_DEVICES = "GetUnresponsiveDevices";

        public const string GET_FLOOR_ALERTS_BY_WASHROOMID = "GetFloorAlertsbyWashroomId";
        public const string GET_FLOOR_ALERTS_WASHROOM_DETAILS_BY_GENDERID = "GetFloorAlertsWashroomDetailsbyGenderId";

        public const string DEVICES_CONTROLLER = "Devices";
        public const string CUSTOMER_CONTROLLER = "Customer";
        public const string GETDEVICEALERTSTATUS = "GetDeviceAlertStatus";
        public const string ACTIVITY_CONTROLLER = "Activity";

        public const string CACHE_CONTROLLER = "Cache";
        public const string CACHE_ACTION = "SaveDeviceDetailToCache";
        public const string GETDEVICELASTDISPENSEDVALUE_ACTION = "GetDeviceLastDispensedValue";

        public const string GET_DEVICEALERTSFORBUILDING_WITHRESOLUTION_ACTION = "GetDeviceAlertsForBuildingWithResolution";
        public const string GET_DEVICEREFILLS_WITHRESOLUTION_ACTION = "GetDeviceRefillsForBuildingWithResolution";
        public const string GET_CUSTOMER_CONTACTS_ACTION = "GetContactsForCustomer";
        public const string GET_ACTIVITIESCUSTOMER_ACTION = "GetActivitiesForCustomer";
        public const string GET_ACTIVITIESCUSTOMERFILTER_ACTION = "GetActivitiesForCustomerWithFilter";
        public const string GET_ACTIVITIESLASTDAY_ACTION = "FetchActivitiesLastDay";
        public const string GET_ALERTTYPES_BY_DEVICETYPE_ACTION = "GetAlertTypesForDeviceType";
        public const string GET_ALLDEVICETYPES_ACTION = "GetAllDeviceTypes";
        public const string GET_ALLROOMTYPES_ACTION = "GetAllRoomTypes";
        public const string GET_ALLPROPERTIES_ACTION = "GetAllProperties";
        public const string GET_ALLBUILDINGS_ACTION = "GetAllBuildings";
        public const string GET_ALLFLOORS_ACTION = "GetAllFloors";
        public const string COUNT_OUTSTANDINGDEVICEALERTS_ACTION = "CountOutstandingDeviceAlerts";
        public const string COUNT_DISPENSESHRTDEVICE_ACTION = "CountDispenseseHRTDevices";
        public const string ESOAP_SHOTSIZE = "eSoapShotSize";
        public const string GET_ACTIVITIES_ACTION = "GetActivities";
        public const string GET_RECENT_ACTIVITIES_ACTION = "GetRecentActivities";
        #region Alert Engine
        public const int MAXIMUM_MESSAGE_RETRY_COUNT = 2;
        public const string FROM_EMAIL_ADDRESS = "FromEmailAddress";
        public const string FROM_MOBILE_NUMBER = "FromMobileNumber";

        public const string TWILIO_ACCOUNT_SID = "TwilioAccountSid";
        public const string TWILIO_AUTH_TOKEN = "TwilioAuthToken";

        public const string TASKS_THRESHOLD_LIMIT = "TasksThresholdLimit";
        public const string MESSAGES_FOR_TASK_ALLOCATION = "MessagesForTaskAllocation";
        public const string TEMPLATES_CONFIGURATION_FILEPATH = "TemplatesConfigurationFilePath";

        public const string HIGH_PRIORITY_QUEUE_NAME = "highpriorityqueue";
        public const string LOW_PRIORITY_QUEUE_NAME = "lowpriorityqueue";

        public const string ENGINE_ALERT_AUDIT_LOG_TABLE = "AlertAuditLog";
        public const string ENGINE_ALERT_LOG_TABLE = "AlertLog";
        public const string ENGINE_ALERT_STATUS_TABLE = "AlertStatus";

        public const string SMTP_SERVER_CONFIGURATION = "SmtpServerConfiguration";
        public const string SMS_CONFIGURATION = "SmsConfiguration";

        public const string ERRORCODE = "E01";
        public const string SUCCESSCODE = "S01";
        public const string WASHROOM_TEMPLATECODE = "W01";

        public const string JRT_LOW_BATTERY_ALERT_TEMPLATECODE = "J1";
        public const string JRT_PAPER_TRANSFER_ALERT_TEMPLATECODE = "J2";
        public const string JRT_LOW_PAPER_ALERT_TEMPLATECODE = "J3";

        public const string ESOAP_LOW_SOAP_ALERT_TEMPLATECODE = "S1";
        public const string ESOAP_LOW_BATTERY_ALERT_TEMPLATECODE = "S2";
        public const string ESOAP_MOTOR_OVERCURRENT_ALERT_TEMPLATECODE = "S3";

        public const string ESOAP_VERY_LOW_SOAP_ALERT_TEMPLATECODE = "S4";
        public const string EHRT_PAPER_TRANSFER_ALERT_TEMPLATECODE = "H1";
        public const string EHRT_LOW_BATTERY_ALERT_TEMPLATECODE = "H2";

        public const string EHRT_PAPER_JAM_ALERT_TEMPLATECODE = "H3";
        public const string EHRT_LOW_PAPER_ALERT_TEMPLATECODE = "H4";
        public const string EHRT_TRASH_FULL_ALERT_TEMPLATECODE = "H5";

        public const string SRB_LOW_BATTERY_ALERT_TEMPLATECODE = "SR1";
        public const string SRB_PAPER_TRANSFER_ALERT_TEMPLATECODE = "SR2";
        public const string SRB_LOW_PAPER_ALERT_TEMPLATECODE = "SR3";
        public const string USER_CREATION_TEMPLATECODE = "UC";
        public const string USER_FORGOTPASSWORD_TEMPLATECODE = "FP";

        public const string API_CACHE_REFRESH = "CA";
        public const string API_CACHE_CUSTOMER_OVERRIDE_REFRESH = "CAC";
        public const string API_DATABASE_UPDATE = "CADB";

        public const string KEYS_FORMATTER = "{0}_{1}";
        public const string KEYS_FORMATTER_WITHPROPERTY = "{0}_{1}_{2}";
        public const string ROW_KEYS_FORMATTER = "{0}_{1}_{2}";
        #endregion

        #region API Constants
        public const string MESSAGE_SUCCESS = "MESSAGE_SUCCESS";
        public const string MESSAGE_REMOVE_SUCCESS = "MESSAGE_REMOVE_SUCCESS";
        public const string MESSAGE_FAIL = "MESSAGE_FAIL";

        public const string STATUS_SUCCESS = "STATUS_SUCCESS";
        public const string STATUS_FAIL = "STATUS_FAIL";

        public const string JRT_DEVICE_NAME = "Tissue(Large)";
        public const string EHRT_DEVICE_NAME = "Towel";
        public const string ESOAP_DEVICE_NAME = "Soap";
        public const string SRB_DEVICE_NAME = "Tissue(Small)";

        public const string PUSH_DEVICE_ALERT_CONTROLLER = "devices";
        public const string PUSH_DEVICE_ALERT_ACTION = "PostDeviceAlert";
        public const string REMOVE_DEVICE_ALERT_ACTION = "RemoveDeviceAlert";

        public const string POST_DEVICE_ALERT_MESSAGE_ACTION = "PostAlertMessage";
        public const string API_USER_NAME = "APIUserName";
        public const string API_PASSWORD = "APIPassword";

        public const string THRESHOLD_VALUES = "ThresholdValues";
        #endregion

        #region TenantUI Constants
        public const string CREATE_SUCCESS = "CREATE_SUCCESS";
        public const string CREATE_FAIL = "CREATE_FAIL";
        public const string INVALID_FLOOR_RANGE = "INVALID_FLOOR_RANGE";
        public const string UPDATE_SUCCESS = "UPDATE_SUCCESS";
        public const string UPDATE_FAIL = "UPDATE_FAIL";
        public const string RETURN_PARAMETER_UPDATE_FAIL = "RETURN_PARAMETER_UPDATE_FAIL";
        public const string DELETE_SUCCESS = "DELETE_SUCCESS";
        public const string DELETE_FAIL = "DELETE_FAIL";
        public const string DEVICE_INVALID = "DEVICE_INVALID";
        public const string DEVICETYPE_INVALID = "DEVICETYPE_INVALID";

        public const string AUTHORIZE_DELETION = "AUTHORIZE_DELETION";
        public const string AUTHORIZE_EDIT = "AUTHORIZE_EDIT";
        public const string LOGGEDIN_DELETION = "LOGGEDIN_DELETION";
        //public const string REACTIVATED = "";
        #endregion

        #region Device Status Refill Thresholds
        public const string DeviceStatusRefillThresholdHIGH = "High";
        public const string DeviceStatusRefillThresholdMIDDLE = "Middle";
        public const string DeviceStatusRefillThresholdLOWMIDDLE = "LowMiddle";
        public const string DeviceStatusRefillThresholdLOW = "Low";
        #endregion

        #region Authentication
        public const string AUTHENTICATION_CONTROLLER = "Membership";
        public const string AUTHENTICATE_USER = "LoginUser";
        public const string RESET_USER_CREDENTIALS = "ResetUserCredentials";

        public const string GENERATE_USER_CREDENTIALS = "GenerateUserCredentials";
        public const string GETUSER_PERMISSIONS = "GetUserPermissions";
        public const string FORGOT_USER_CREDENTIALS = "ForgotPassword";

        public const string CREATE_USERAUTHORIZATION_FEATURE = "CreateFeature";
        public const string GET_AUTHORIZATION_FEATURES = "GetAuthorizationFeatureList";
        public const string GETUSER_ACCOUNTINFORMATION = "GetUserAccountInformation";

        public const string REFRESH_USERASSERTS = "RefreshUserAssets";
        #endregion
    }
}
