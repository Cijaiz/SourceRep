﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.Core.Constants
{
    public class AggregationConstants
    {
        //azure scheduler constants
        public const string SubscriptionId = "SubscriptionId";
        public const string CertificateThumbprint = "CertificateThumbprint";
        public const string SchedulerCloudService = "SchedulerCloudService";
        public const string SchedulerQueue = "SchedulerQueue";
        public const string SchedulerJobCollection = "SchedulerJobCollection";
        public const string StorageAccount = "StorageAccount";
        public const string StorageConnectionString = "Microsoft.WindowsAzure.Plugins.Diagnostics.ConnectionString";
                                
    }
}
