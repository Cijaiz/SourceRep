﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.Core.Constants
{
    public class CommonConstants
    {
        public const int SQLAZURE_MAX_RETRIES = 5;
        public const int SQL_EXCEPTION_RETRY = 3;
        public const int SQLAZURE_CONNECTION_RETRYINTERVAL = 2;

        public const string HUB_USERNAME = "HubUserName";
        public const string HUB_USERPASSWORD = "HubUserPassword";

        public const string AUTHENTICATIONCREDENTIALS = "AuthenticationCredentials";
        public const string AUTHENTIACATION_COOKIE_PREFIX = "_UserName";

        public const string AUTH_TICKET_EXPIRATION_INTERVAL_IN_MINS = "AuthTicketExpirationIntervalInMins";
        public const string PASSWORD_RESET_CODE = "na000555";
        public const int PASSWORD_LENGTH = 8;

        public const string eHRT = "EHRT";
        public const string JRT = "JRT";
        public const string eSoap = "ESOAP";
        public const string SRB = "SRB";

        public const string JRTREFILL_SIZE = "S";
        public const string SRBREFILL_SIZE = "S";

        public const int DEFAULT_VALUE = 0;
        public const int RECENTUPDATES_ALERTS_COUNT = 5;
        public const char SEPERATOR = '_';

        //Constants for filter values in Chart
        public const string FilterPropertyId = "propertyId";
        public const string FilterBuildingId = "buildingId";
        public const string FilterPeriodId = "periodId";
        public const string FilterFloorId = "floorId";
        public const string FilterRoomId = "roomId";
        public const string FilterMonth = "month";
        public const string FilterYear = "year";
        public const string FilterNoSelection = "0";
        public const string FilterThisWeek = "1";
        public const string FilterLastWeek = "2";
        public const string FilterThisMonth = "3";
        public const string FilterLastMonth = "4";
        public const string ChartType = "chartType";
        public const string Month = "Month";
        public const string Year = "Year";


        public const string DEVICE_LOG_PARTITION_KEY_FORMAT = "{0}_{1}";
        public const string DEVICE_LOG_PARTITION_KEY_FORMAT_WITHPROPERTY = "{0}_{1}_{2}";
        public const string DEVICE_LOG_ROW_KEY_FORMAT = "{0}_{1}_{2}";
        public const string PARTITION_DATE_FORMAT = "yyyyMMdd";
        public const string PROPERTY_JOB_INTERVAL_LIMIT = "JobIntervalLimit";

        public const string LONG_DATE_TIME_FORMAT = "yyyy/MM/dd HH:mm:ss.fffffff";
        public const string SHORT_DATE_TIME_PREVIOUS_FORMAT = "MM/dd/yyyy HH:mm:ss";

        public const string SHORT_DATE_TIME_FORMAT = "yyyy/MM/dd HH:mm:ss";
        public const string SHORT_DATE_TIME_FORMAT_WITH_MERIDIAN = "MM/dd/yyyy hh:mm:ss tt";

        public const string VALID_DATA = "VALID";
        public const string INVALID_DATA = "INVALID";

        public const string SRB_DEVICE = "000011";
        public const string JRT_DEVICE = "000008";
        public const string ESOAP_DEVICE = "000007";
        public const string EHRT_DEVICE = "000000";

        public const string PASSWORD_RESET_INVALID = "PASSWORD_RESET_INVALID";
        public const string DATE_FORMAT_MONTH_IN_WORDS = "MMM dd, yyyy, hh:mm tt";

        public const string LOW_BATTERY = "Low Battery";
        public const string PAPER_TRANSFER="Paper Transfer";
        public const string LOW_PAPER = "Low Paper";
        public const string LOW_SOAP="Low Soap";
        public const string MOTOR_OVERCURRENT = "Motor Overcurrent";
        public const string VERY_LOW_SOAP="Very Low Soap";
        public const string PAPER_JAM = "Paper Jam";
        public const string TRASH_FULL="Trash Full";

        public const string DEFAULT_IMAGE="http://kcdevelopment.blob.core.windows.net/mediastore/no_image.png";

        //Used to fetch the resource file for  Men_s/Women_s = Men's/Women's
        public const string PREFIX_UNDERSCORE_S = "_s";

        public const int LAST_STATS_DURATION = -24;
        public const int DEFAULT_SEARCH_DURATION_DAYS = -30;
    }
}
