﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.Core.Constants
{
    public class AlertChartConstants
    {
        //for building trends alert chart weekwise
        //for floor trends alert chart weekwise
        public const string XAxisWeek = "AlertDayOfWeek";
        public const string XAxisLabel = "Date";
        public const string XAxisLabelWeek = "Days";
        public const string SecondaryAxis = "AlertType";
        public const string YAxis = "CountOfAlerts";
        public const string YAxisLabel = "Alerts";

        //for building trends alert chart monthwise
        //for floor trends alert chart monthwise
        public const string XAxisMonth = "AlertDay";
        public const string ProductSummaryMonth = "Month";

        //Titles and Chart Ids
        public const string AlertTitle = "Alert Chart";
        public const string AlertChartId = "AlertChart_Id";

        //Business Hub API Controllers
        public const string ControllerAlertMart = "AlertMart";

        //Business Hub API Action Methods
        public const string API_AlertWeek = "GetAlertDataWeekwise";
        public const string API_AlertMonth = "GetAlertDataMonthwise";
        public const string API_AlertSummaryData = "GetAlertSummaryData";

        //Alerttype to alter mapping constants
        public const string JRTLowBatteryCode = "J1";
        public const string LowBattery = "Low Battery";
        public const string eHRTLowBatteryCode = "H2";
        public const string eSoapLowBatteryCode = "S2";
        public const string JRTLowPaperCode = "J3";
        public const string LowPaper = "Low Paper";
        public const string eHRTLowPaperCode = "H4";
        public const string eHRTPaperJamCode = "H3";
        public const string PaperJam = "Paper Jam";
        public const string SRBLowBatteryCode = "SR1";
        public const string SRBPaperTransferCode = "SR2";
        public const string SRBLowPaperCode = "SR3";
        public const string eSoapLowSoapCode = "S1";
        public const string LowSoap = "Low Soap";

        public const string Others = "Others";
        public const string DATABASE_CONNECTION = "SmartWashroomEntities";
    }
}
