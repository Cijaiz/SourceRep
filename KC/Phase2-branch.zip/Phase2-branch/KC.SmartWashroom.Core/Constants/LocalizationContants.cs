﻿
namespace KC.SmartWashroom.Constants
{
    public class LocalizationContants
    {
        public const string DEFAULT_CULTURE = "en-US";
        public const string HINDI_CULTURE = "hi";
        public const string IMPLEMENTED_CULTURE = "implementedCulture";
        public const char HYPHEN = '-';
        public const string RESOURCEKEY_HOLDER = "[[{0}]]";
        public const string REQUIRED = "required";
        public const string REGEX = "regex";
        public const string STRINGLENGTHMESSAGE = "StringLengthMessage";
        public const string STRINGLENGTH = "stringlength";

        //en-US
        public const char RESOLUTIONTIME_DAYS_EN = 'd';
        public const char RESOLUTIONTIME_HOURS_EN = 'h';
        public const string RESOLUTIONTIME_MINS_EN = "mins";

        //de-DE
        public const char RESOLUTIONTIME_DAYS_DE = 't';
        public const char RESOLUTIONTIME_HOURS_DE = 's';
        public const string RESOLUTIONTIME_MINS_DE = "min";
    }

    /// <summary>
    /// List of supported culture codes by Microsoft Commerce Server 
    /// </summary>
    public class CultureCodes
    {
        public const string ENGLISH_UNITED_STATES = "en-US";
        public const string ENGLISH_UNITED_KINGDOM = "en-GB";
        public const string HINDI_INDIA = "hi-IN";
        public const string FRENCH_FRANCE = "fr-FR";
        public const string GERMAN_GERMANY = "de-DE";
        public const string RUSSIAN_RUSSIA = "ru-RU";
    }
}
