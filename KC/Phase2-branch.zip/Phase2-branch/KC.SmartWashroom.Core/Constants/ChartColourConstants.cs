﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.Core.Constants
{
    public class ChartColourConstants
    {
        public const string eHRT = "#00718e";
        public const string JRT = "#33cc33";
        public const string eSoap = "#f07803";
        public const string SRB = "#ff0066";
        public const string Batteries = "#8628bb";
        public const string LowPaper = "#b91717";
        public const string LowBattery = "#56b1c7";
        public const string PaperJam = "#611616";
        public const string LowSoap = "#c06002";
        public const string Others = "#f0c518";
    }
}
