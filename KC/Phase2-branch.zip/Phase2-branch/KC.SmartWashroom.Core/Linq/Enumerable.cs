﻿

namespace KC.SmartWashroom.Core.Linq
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    /// <summary>
    /// Utility LINQ extenions for IEnumerable
    /// </summary>
    public static class EnumerableExtensions
    {
        /// <summary>
        /// Iterates the given enumerable using eager execution.
        /// This behavior is specific to LINQ to objects; no way the compiler
        /// will translate it in to LINQ to SQL or LINQ to Entities
        /// </summary>
        /// <typeparam name="T">The data type</typeparam>
        /// <param name="enumerable">The enumerable</param>
        /// <param name="action">The action to be performed</param>
        /// <returns>The same enumerable itself</returns>
        public static IEnumerable<T> ForEach<T>(this IEnumerable<T> enumerable, Action<T> action)
        {
            if (enumerable != null && action != null)
            {
                foreach (var item in enumerable)
                {
                    action.Invoke(item);
                }
            }

            return enumerable ?? Enumerable.Empty<T>();
        }

        /// <summary>
        /// Combines the enumerables
        /// </summary>
        /// <typeparam name="T">The data type of the item in each enumeration</typeparam>
        /// <param name="enumerables">The enumerables of the enumerables</param>
        /// <returns>A combined enumerable</returns>
        public static IEnumerable<T> Combine<T>(this IEnumerable<IEnumerable<T>> enumerables)
        {
            if (enumerables != null)
            {
                foreach (var enumerable in enumerables)
                {
                    if (enumerable != null)
                    {
                        foreach (var item in enumerable)
                        {
                            if (item != null)
                            {
                                yield return item;
                            }                            
                        }
                    }                    
                }
            }

            yield break;
        }
    }
}
