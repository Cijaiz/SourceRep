﻿

namespace KC.SmartWashroom.Core
{
    using System;
    using System.Collections.Generic;
    public class PropertyBag : IPropertyBag
    {
        private object syncLock;
        private IDictionary<string, object> buffer;

        // true lazy loading
        protected IDictionary<string, object> Buffer
        {
            get
            {
                // thread safety
                if (this.buffer == null)
                {
                    lock (this.syncLock)
                    {
                        if (this.buffer == null)
                        {
                            this.buffer = new Dictionary<string, object>();
                        }
                    }
                }

                return this.buffer;
            }
        }


        public IEnumerable<KeyValuePair<string, object>> Parameters
        {
            get { return this.Buffer; }
        }

        public PropertyBag()
        {
            this.syncLock = new object();
        }

        public T Get<T>(string key = null)
        {
            var value = default(T);

            var cacheKey = this.GenerateCacheKey<T>(key);

            if (this.Buffer.ContainsKey(cacheKey))
            {
                var instance = this.Buffer[cacheKey];
                if (instance is T)
                {
                    value = (T)instance;
                }
            }

            return value;
        }

        public bool Set<T>(T instance, string key = null, bool updateExisting = true)
        {
            bool isModified = false;

            var cacheKey = this.GenerateCacheKey<T>(key);

            lock (this.syncLock)
            {
                if (!this.Buffer.ContainsKey(cacheKey))
                {
                    this.Buffer.Add(cacheKey, instance);
                    isModified = true;
                }
                else if (updateExisting)
                {
                    if (!EqualityComparer<T>.Default.Equals(instance, default(T)))
                    {
                        this.Buffer[cacheKey] = instance;
                    }
                    else
                    {
                        this.Buffer.Remove(cacheKey);
                    }
                    isModified = true;
                }
            }


            return isModified;
        }

        protected string GenerateCacheKey<T>(string key)
        {
            var cacheKey = typeof(T).AssemblyQualifiedName;

            if (!string.IsNullOrWhiteSpace(key))
            {
                cacheKey = string.Format("{0}_{1}", cacheKey, key);
            }

            return cacheKey;
        }

        /* Not required for now; the idea is to write maximum managed code
        private void Dispose()
        {
            var cache = this.Buffer;

            foreach (var item in cache)
            {
                var disposable = item.Value as IDisposable;
                if (disposable != null)
                {
                    disposable.Dispose();
                }
            }

            cache.Clear();
            this.Dispose(true);

        }

        protected virtual void Dispose(bool disposing)
        {

        }


        void System.IDisposable.Dispose()
        {
            this.Dispose();
        }
        */
    }
}
