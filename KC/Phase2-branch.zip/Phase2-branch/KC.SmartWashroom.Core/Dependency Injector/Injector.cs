﻿using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.Configuration;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.Core.DependencyInjector
{
    public class Injector
    {
        private static IUnityContainer injectionContainer;

        static Injector()
        {
            injectionContainer = new UnityContainer();
            var injectorSection = (UnityConfigurationSection)ConfigurationManager.GetSection("UnityDependency");
            injectorSection.Configure(injectionContainer);
        }

        public static T Resolve<T>()
        {
            T instanceType = default(T);
            instanceType = injectionContainer.Resolve<T>();
            return instanceType;
        }
    }
}
