﻿namespace KC.SmartWashroom.Core
{
    using System;
    using System.Collections.Generic;

    public interface IPropertyBag // : IDisposable // Not doing it now; let me not write old interop stuffs!
    {
        T Get<T>(string key = null);
        IEnumerable<KeyValuePair<string, object>> Parameters { get; }
        bool Set<T>(T instance, string key = null, bool updateExisting = true);
    }
}
