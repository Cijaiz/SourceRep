﻿using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Security;

namespace KC.SmartWashroom.Core.Security.Authorization.Structure
{
    public sealed class FormsAuthenticationProvider
    {
        /// <summary>
        /// This method is to set forms authentication cookie.
        /// </summary>
        /// <param name="userName">Logged in user's name</param>
        /// <param name="userContext">Extra data UserContext that needs to persists in authentication token.</param>
        /// <param name="createPersistentCookie">Whether to persists forms authentication cookie </param>
        public static void SetAuthCookie(string userName, UserContext userContext, bool createPersistentCookie)
        {
            string userData = string.Empty;

            // serialize the UserContext to persists in session cookies
            if (userContext != null)
                userData = Helper.SerializationHelper.JsonSerialize(userContext);

            HttpContext context = HttpContext.Current;
            var ticket = new FormsAuthenticationTicket(
                version: 1,
                name: userName,
                issueDate: DateTime.UtcNow,
                expiration: DateTime.UtcNow.AddMinutes(SetAuthTicketExpirationInterval()),
                isPersistent: createPersistentCookie,
                userData: userData);

            string encryptedTicket = FormsAuthentication.Encrypt(ticket);
            var formsCookie = new HttpCookie(FormsAuthentication.FormsCookieName, encryptedTicket);
            context.Response.Cookies.Add(formsCookie);
        }

        /// <summary>
        /// Refreshes the User Asserts into the Auth Cookie...
        /// </summary>
        /// <param name="userContext"></param>
        public static void RefreshUserassertsInAuthCookie(UserContext userContext)
        {
            Guard.IsNotNull(userContext, "User Contexxt");

            //Get the Native Form's Authentication Cookie to Load User Data... This is done to reuse the Form's Authentication Cookie to store user data..
            HttpCookie formsAuthenticationCookie = HttpContext.Current.Request.Cookies[FormsAuthentication.FormsCookieName];

            //If unable to find the cookie then dont issue the ticket.
            if (formsAuthenticationCookie == null)
                return;

            // Get the authentication ticket and rebuild the principal 
            // & identity
            FormsAuthenticationTicket authTicket =
              FormsAuthentication.Decrypt(formsAuthenticationCookie.Value);

            if (authTicket == null)
                throw new InvalidOperationException("Unable to Decrypt the Authentication Token from the Authentication Cookie..");

            // De-Serialize the UserContext
            UserContext originalUserContext = Helper.SerializationHelper.JsonDeserialize<UserContext>(authTicket.UserData);

            if (userContext.PropertyAccessAsserts != null && originalUserContext.PropertyAccessAsserts != null)
            {
                //Refresh the PropertyAccessAsserts..
                originalUserContext.PropertyAccessAsserts.Clear();
                originalUserContext.PropertyAccessAsserts = userContext.PropertyAccessAsserts;
            }

            if (userContext.BuildingAccessAsserts != null && originalUserContext.BuildingAccessAsserts != null)
            {
                //Refresh the BUildAccessAsserts..
                originalUserContext.BuildingAccessAsserts.Clear();
                originalUserContext.BuildingAccessAsserts = userContext.BuildingAccessAsserts;
            }

            // Serialize the UserContext back with refreshed values..
            string newUserData = string.Empty;
            if (userContext != null)
            {
                newUserData = Helper.SerializationHelper.JsonSerialize(originalUserContext);

                HttpContext context = HttpContext.Current;
                var ticket = new FormsAuthenticationTicket(
                    version: authTicket.Version,
                    name: authTicket.Name,
                    issueDate: authTicket.IssueDate,
                    expiration: authTicket.Expiration,
                    isPersistent: authTicket.IsPersistent,
                    userData: newUserData);

                string encryptedTicket = FormsAuthentication.Encrypt(ticket);
                formsAuthenticationCookie.Value = encryptedTicket;

                //Set the Correct Cookie Just Refresh dont add...
                context.Response.Cookies.Set(formsAuthenticationCookie);
            }
        }

        /// <summary>
        /// Removes the Authentication Cookie enabling for safe logout...
        /// </summary>
        public static void RemoveAuthCookie()
        {
            //Get the Native Form's Authentication Cookie to Load User Data... This is done to reuse the Form's Authentication Cookie to store user data..
            HttpCookie formsAuthenticationCookie = HttpContext.Current.Request.Cookies[FormsAuthentication.FormsCookieName];

            //Remove the Authentication COokie to enable smooth Logout Expereicne.....
            if (formsAuthenticationCookie != null)
            {
                formsAuthenticationCookie.Expires = DateTime.UtcNow.AddDays(-1d);
                HttpContext.Current.Response.Cookies.Add(formsAuthenticationCookie);
            }
        }

        /// <summary>
        /// To set current user principal to CustomPrincipal with added information from Authentication cookie.
        /// </summary>
        public static void SetCurrentPrinciple()
        {
            //Get the Native Form's Authentication Cookie to Load User Data... This is done to reuse the Form's Authentication Cookie to store user data..
            HttpCookie formsAuthenticationCookie = HttpContext.Current.Request.Cookies[FormsAuthentication.FormsCookieName];

            //If unable to find the cookie then dont issue the ticket.
            if (formsAuthenticationCookie == null)
                return;

            // Get the authentication ticket and rebuild the principal 
            // & identity
            FormsAuthenticationTicket authTicket =
              FormsAuthentication.Decrypt(formsAuthenticationCookie.Value);

            CustomPrincipal userPrincipal = new CustomPrincipal(authTicket);
            HttpContext.Current.User = userPrincipal;
        }

        public static void RememberMeInCookie(string userName)
        {

            HttpContext context = HttpContext.Current;
            var formsUserCookie = new HttpCookie(FormsAuthentication.FormsCookieName + "_UserName", userName);
            formsUserCookie.Expires = DateTime.UtcNow.AddDays(2);

            context.Response.Cookies.Add(formsUserCookie);
        }

        public static string RetrivedRememberdUserNameFromCookie()
        {
            string userName = string.Empty;
            HttpCookie rememberMeUserCookie = HttpContext.Current.Request.Cookies[FormsAuthentication.FormsCookieName + CommonConstants.AUTHENTIACATION_COOKIE_PREFIX];

            //If unable to find the cookie then dont issue the ticket.
            if (rememberMeUserCookie == null)
                return userName;

            userName = rememberMeUserCookie.Value;
            return userName;
        }

        private static int SetAuthTicketExpirationInterval()
        {
            int AuthCookieExpirationInterval = 20;
            AuthCookieExpirationInterval = Int32.TryParse(CommonHelper.GetConfigSetting(CommonConstants.AUTH_TICKET_EXPIRATION_INTERVAL_IN_MINS),
                                                       out AuthCookieExpirationInterval).Equals(true) ?
                                                        AuthCookieExpirationInterval : AuthCookieExpirationInterval;
            return AuthCookieExpirationInterval;
        }
    }
}
