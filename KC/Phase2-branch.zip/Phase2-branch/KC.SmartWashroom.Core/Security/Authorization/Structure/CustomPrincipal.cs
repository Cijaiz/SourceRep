﻿using KC.SmartWashroom.Core.Security.Authorization.Skeleton;
using KC.SmartWashroom.Core.Security.Authorization.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Web.Security;
using KC.SmartWashroom.Core.Enumerations;

namespace KC.SmartWashroom.Core.Security.Authorization.Structure
{
    public class CustomPrincipal : ICustomPrincipal
    {
        public CustomPrincipal(FormsAuthenticationTicket authTicket)
        {
            this.Identity = new UserIdentity(authTicket);

            var userIdentity = this.Identity.ToUserIdentity();

            //Extract the information..
            this.UserId = userIdentity.Context.UserId;
            this.FirstName = userIdentity.Context.FirstName;
            this.LastName = userIdentity.Context.LastName;

            this.PhotoPath = userIdentity.Context.PhotoPath;
            this.LastLogon = userIdentity.Context.LastLogon;

            this.BuildingPermissions = userIdentity.Context.BuildingAccessAsserts;
            this.PropertyPermissions = userIdentity.Context.PropertyAccessAsserts;
            this.Permissions = userIdentity.Context.FeaturePermissions;

            this.RoleLevel = (Enums.RoleLevelType)userIdentity.Context.RoleLevel;
            this.CustomerId = userIdentity.Context.CustomerId;
            this.CustomerName = userIdentity.Context.CustomerName;
        }

        /// <summary>
        /// Gets First name
        /// </summary>
        public string FirstName { get; private set; }

        /// <summary>
        /// Gets Identity
        /// </summary>
        public IIdentity Identity { get; private set; }

        /// <summary>
        /// Gets Last Logon
        /// </summary>
        public DateTime? LastLogon { get; private set; }

        /// <summary>
        /// Gets Last name
        /// </summary>
        public string LastName { get; private set; }

        /// <summary>
        /// Gets Photo Path
        /// </summary>
        public string PhotoPath { get; private set; }

        /// <summary>
        /// Gets User Id
        /// </summary>
        public int UserId { get; private set; }

        /// <summary>
        /// Gets or sets Permissions
        /// </summary>
        public List<int> Permissions { get; set; }

        /// <summary>
        /// Get or Sets Building Permissions
        /// </summary>
        public List<int> BuildingPermissions { get; set; }

        /// <summary>
        /// Get or Sets Property Permissions
        /// </summary>
        public List<int> PropertyPermissions { get; set; }

        /// <summary>
        /// Returns whether user has permission.
        /// </summary>
        /// <param name="appPermission">The application permission checked against user's permission.</param>
        /// <returns>True if user has permission otherwise false.</returns>
        public bool HasPermission(Enumerations.Enums.ApplicationPermission appPermission)
        {
            return this.Permissions != null ? Permissions.Exists(permission => permission == (int)appPermission) : false;
        }

        public bool IsInRole(string role)
        {
            return false;
        }

        /// <summary>
        /// Checks whether the building access is enabled for the logged in user.
        /// </summary>
        /// <param name="buildingId"></param>
        /// <returns></returns>
        public bool HasBuildingAccess(int buildingId)
        {
            return this.BuildingPermissions != null ? BuildingPermissions.Exists(permission => permission == buildingId) : false;
        }

        /// <summary>
        /// Checks whether the building access is enabled for the logged in user.
        /// </summary>
        /// <param name="buildingId"></param>
        /// <returns></returns>
        public bool HasPropertyAccess(int propertyId)
        {
            return this.PropertyPermissions != null ? PropertyPermissions.Exists(permission => permission == propertyId) : false;
        }

        public Enums.RoleLevelType RoleLevel { get; private set; }

        public int CustomerId { get; set; }

        public string CustomerName { get; set; }
    }
}
