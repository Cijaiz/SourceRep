﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KC.SmartWashroom.Core.Security.Authorization.Structure
{
    /// <summary>
    /// UserContext class is to hold user's context information which can be Serialized
    /// </summary>
    public class UserContext
    {
        /// <summary>
        /// Gets or sets First name
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// Gets or sets Last logon
        /// </summary>
        public DateTime? LastLogon { get; set; }

        /// <summary>
        /// Gets or sets Last name
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        /// Gets or sets Permissions
        /// </summary>
        public List<int> FeaturePermissions { get; set; }

        /// <summary>
        /// Gets or sets Photo Path
        /// </summary>
        public string PhotoPath { get; set; }

        /// <summary>
        /// Gets or sets User Id
        /// </summary>
        public int UserId { get; set; }

        /// <summary>
        /// Get or sets the Role ID for the logged in user..
        /// </summary>
        public int RoleId { get; set; }

        /// <summary>
        /// Get or sets the Role Level for the logged in user..
        /// </summary>
        public int RoleLevel { get; set; }

        /// <summary>
        /// Gets or sets CustomerId
        /// </summary>
        public int CustomerId { get; set; }

        /// <summary>
        /// Gets or sets User Name
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// Gets or sets CustomerName
        /// </summary>
        public string CustomerName { get; set; }

        /// <summary>
        /// Gets or sets IsFirstLogin For Better user Expenericen..
        /// </summary>
        public bool IsFirstLogin { get; set; }

        /// <summary>
        /// Get or Sets the SaltedPassword for additional security during password resets..
        /// </summary>
        public string SaltedPassword { get; set; }

        /// <summary>
        /// Access List of buildings for logged in user
        /// </summary>
        public List<int> BuildingAccessAsserts { get; set; }

        /// <summary>
        /// Access List of properties for logged in user
        /// </summary>
        public List<int> PropertyAccessAsserts { get; set; }
    }
}
