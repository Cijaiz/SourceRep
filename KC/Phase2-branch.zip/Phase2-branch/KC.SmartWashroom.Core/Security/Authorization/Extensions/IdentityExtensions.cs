﻿using KC.SmartWashroom.Core.Security.Authorization.Structure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Web.Security;

namespace KC.SmartWashroom.Core.Security.Authorization.Extensions
{
    /// <summary>
    /// Identity Extensions
    /// </summary>
    public static class IdentityExtensions
    {
        /// <summary>
        /// Extension method to convert IIdentity to UserIdentity
        /// </summary>
        /// <param name="identity">Logged in user's IIdentity</param>
        /// <returns>User Identity</returns>
        public static UserIdentity ToUserIdentity(this IIdentity identity)
        {
            var formsIdentity = (FormsIdentity)identity;
            return new UserIdentity(formsIdentity.Ticket);
        }
    }
}
