﻿using KC.SmartWashroom.Core.Enumerations;
using System;
using System.Collections.Generic;
using System.Security.Principal;

namespace KC.SmartWashroom.Core.Security.Authorization.Skeleton
{
    /// <summary>
    /// This interface implements IPrincipal along with custom properties and method.
    /// </summary>
    public interface ICustomPrincipal : IPrincipal
    {
        /// <summary>
        /// Gets First name
        /// </summary>
        string FirstName { get; }

        /// <summary>
        /// Gets Last Logon
        /// </summary>
        DateTime? LastLogon { get; }

        /// <summary>
        /// Gets Last Name
        /// </summary>
        string LastName { get; }

        /// <summary>
        /// Gets Photo Path
        /// </summary>
        string PhotoPath { get; }

        /// <summary>
        /// Gets User Id
        /// </summary>
        int UserId { get; }

        /// <summary>
        /// Gets the Permissions for the current User Role..
        /// </summary>
        List<int> Permissions { get; set; }

        /// <summary>
        /// Returns whether user has permission.
        /// </summary>
        /// <param name="appPermission">The application permission checked against user's permission.</param>
        /// <returns>True if user has permission otherwise false.</returns>
        bool HasPermission(Enums.ApplicationPermission appPermission);
    }
}
