﻿using KC.SmartWashroom.Core.Helper;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace KC.SmartWashroom.Core.Security
{
    public class AuthenticationMessageHandler : DelegatingHandler
    {
        //Note .net 4.0
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            Exception authenticationException = null;
            bool isAuthenticated = Validator.TrafficAuthenticator.IncommingMessageValidator(out authenticationException);

            if (!isAuthenticated)
            {
                HttpResponseMessage responseMessage = null;
                string serializedErrorResponse = string.Empty;
                if (authenticationException is KeyNotFoundException)
                {
                    //Serialize the Error Response..
                    serializedErrorResponse = SerializationHelper.JsonSerialize<ProcessResponseForGateway>
                                                            (new ProcessResponseForGateway()
                                                            {
                                                                message = "Unable to Authenticate user.. No Valid Authentication Credentials Found at Server..",
                                                                status = "authenticationfailure"
                                                            });

                    responseMessage = new HttpResponseMessage(HttpStatusCode.OK)
                    {
                        Content = new StringContent(serializedErrorResponse),
                        ReasonPhrase = "Please check the Service Credentials.. Unable to authenticate the authorization token..".Replace('/', '#').Replace("\n", string.Empty).Replace("\r", string.Empty)
                    };
                }
                if (authenticationException is UnauthorizedAccessException)
                {
                    //Serialize the Error Response..
                    serializedErrorResponse = SerializationHelper.JsonSerialize<ProcessResponseForGateway>
                                                            (new ProcessResponseForGateway()
                                                            {
                                                                message = "Unable to Authenticate user.. Please check Service Credentials",
                                                                status = "authenticationfailure"
                                                            });

                    responseMessage = new HttpResponseMessage(HttpStatusCode.OK)
                    {
                        Content = new StringContent(serializedErrorResponse),
                        ReasonPhrase = "Please check the Service Credentials.. Unable to Authorize..".Replace('/', '#').Replace("\n", string.Empty).Replace("\r", string.Empty)
                    };
                }
                else if (authenticationException is ApplicationException)
                {
                    //Serialize the Error Response..
                    serializedErrorResponse = SerializationHelper.JsonSerialize<ProcessResponseForGateway>
                                                            (new ProcessResponseForGateway()
                                                            {
                                                                message = string.Format("Unable to serve the requests .. Service.. Server unavailable.. Details below /n {0}",
                                                                authenticationException.Message + authenticationException.StackTrace),
                                                                status = "generalfailure with Authorization TOken: " + KC.SmartWashroom.Core.Security.Validator.TrafficAuthenticator.IncommingAuthorizationToken
                                                            });

                    responseMessage = new HttpResponseMessage(HttpStatusCode.OK)
                    {
                        Content = new StringContent(serializedErrorResponse),
                        ReasonPhrase = "Application Error Occured...",
                    };
                }
                else if (authenticationException is Exception)
                {
                    //Serialize the Error Response..
                    serializedErrorResponse = SerializationHelper.JsonSerialize<ProcessResponseForGateway>
                                                            (new ProcessResponseForGateway()
                                                            {
                                                                message = string.Format("Unable to serve the requests .. Service.. Server unavailable.. Details below /n {0}",
                                                                authenticationException.Message.Replace('/', '#') + authenticationException.StackTrace.Replace('/', '#')),
                                                                status = "generalfailure In Authentication Token: " + KC.SmartWashroom.Core.Security.Validator.TrafficAuthenticator.IncommingAuthorizationToken
                                                            });

                    responseMessage = new HttpResponseMessage(HttpStatusCode.OK)
                    {
                        Content = new StringContent(serializedErrorResponse),
                        ReasonPhrase = (authenticationException.Message).Replace('/', '#').Replace("\n", string.Empty).Replace("\r", string.Empty),
                    };
                }
                else
                {
                    //Serialize the Error Response..
                    serializedErrorResponse = SerializationHelper.JsonSerialize<ProcessResponseForGateway>
                                                            (new ProcessResponseForGateway()
                                                            {
                                                                message = "Authentication Failure..",
                                                                status = "Authentication Token sent: " + KC.SmartWashroom.Core.Security.Validator.TrafficAuthenticator.IncommingAuthorizationToken
                                                            });

                    responseMessage = new HttpResponseMessage(HttpStatusCode.OK)
                    {
                        Content = new StringContent(serializedErrorResponse),
                        ReasonPhrase = "Authentication Failure..",
                    };
                }

                var task = new TaskCompletionSource<HttpResponseMessage>();
                task.SetResult(responseMessage);
                return task.Task;
            }
            else
                // Call the inner handler.
                return base.SendAsync(request, cancellationToken);
        }

        //Note .net4.5 and above.
        //protected internal async override Task<HttpResponseMessage> SendAsync(
        //    HttpRequestMessage request, CancellationToken cancellationToken)
        //{
        //    ACSAuthenticationHelper.ACSHostNameSettingKey = Constants.ACS_HOSTNAME;
        //    ACSAuthenticationHelper.ACSNameSpaceSettingKey = Constants.ACS_NAMESPACE;
        //    ACSAuthenticationHelper.ACSTokenKeySettingKey = Constants.ACS_TOKEN_KEY;
        //    ACSAuthenticationHelper.ACSRealmSettingKey = Constants.ACS_REALM;

        //    ACSAuthenticationHelper.ValidateSWTTokenRequest();

        //    // Call the inner handler.
        //    var response = await base.SendAsync(request, cancellationToken);
        //    return response;
        //}
    }
}
