﻿using KC.SmartWashroom.Core.Helper;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace KC.SmartWashroom.Core.Security
{
    public class AuthenticationDeviceHandler : DelegatingHandler
    {
        //Note .net 4.0
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            Exception authenticationException = null;
            bool isAuthenticated = Validator.TrafficAuthenticator.IncommingDeviceMessageValidator(out authenticationException);

            if (!isAuthenticated)
            {
                HttpResponseMessage responseMessage = new HttpResponseMessage(HttpStatusCode.Unauthorized);

                var task = new TaskCompletionSource<HttpResponseMessage>();
                task.SetResult(responseMessage);
                return task.Task;
            }
            else
                // Call the inner handler.
                return base.SendAsync(request, cancellationToken);
        }

        //Note .net4.5 and above.
        //protected internal async override Task<HttpResponseMessage> SendAsync(
        //    HttpRequestMessage request, CancellationToken cancellationToken)
        //{
        //    ACSAuthenticationHelper.ACSHostNameSettingKey = Constants.ACS_HOSTNAME;
        //    ACSAuthenticationHelper.ACSNameSpaceSettingKey = Constants.ACS_NAMESPACE;
        //    ACSAuthenticationHelper.ACSTokenKeySettingKey = Constants.ACS_TOKEN_KEY;
        //    ACSAuthenticationHelper.ACSRealmSettingKey = Constants.ACS_REALM;

        //    ACSAuthenticationHelper.ValidateSWTTokenRequest();

        //    // Call the inner handler.
        //    var response = await base.SendAsync(request, cancellationToken);
        //    return response;
        //}
    }
}
