﻿using KC.SmartWashroom.Core.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace KC.SmartWashroom.Core.Security.Validator
{
    public static class TrafficAuthenticator
    {
        public const string APIAUTHENTICATION_AUTHORIZATION = "Authorization";
        public const string AUTHENTICATIONCREDENTIALS = "AuthenticationCredentials";

        public const string APIAUTHENTICATION_USERNAMEKEY = "HubUserName";
        public const string APIAUTHENTICATION_PASSWORDKEY = "HubUserPassword";

        public const string INCOMMING_USERNAMEKEY = "username";
        public const string INCOMMING_PASSWORDKEY = "password";

        public const string AUTHENTICATION_SALT = "basic ";

        static readonly Dictionary<string, string> validHubCredentials;

        public static string IncommingAuthorizationToken = string.Empty;

        static TrafficAuthenticator()
        {
            if (validHubCredentials == null)
            {
                validHubCredentials = new Dictionary<string, string>();

                string hubAuthentication = CommonHelper.GetConfigSetting(AUTHENTICATIONCREDENTIALS);
                validHubCredentials = SerializationHelper.JsonDeserialize<Dictionary<string, string>>(hubAuthentication);
            }
        }

        public static bool IncommingDeviceMessageValidator(out Exception authenticationException)
        {
            bool isAuthenticated = false;
            authenticationException = null;
            try
            {
                if (validHubCredentials == null)
                {
                    authenticationException = new KeyNotFoundException();
                    return isAuthenticated;
                }

                //Authenticate the User..
                isAuthenticated = ValidateDeviceHubAuthenticationCredentials();
            }
            catch (InvalidOperationException invalidOperationException)
            {
                authenticationException = invalidOperationException;
            }
            catch (UnauthorizedAccessException unauthorizedException)
            {
                authenticationException = unauthorizedException;
            }
            catch (ApplicationException applicationException)
            {
                authenticationException = applicationException;
            }
            catch (ArgumentNullException argumentNullException)
            {
                authenticationException = argumentNullException;
            }
            catch (Exception generalException)
            {
                authenticationException = generalException;
            }
            return isAuthenticated;
        }

        public static bool IncommingMessageValidator(out Exception authenticationException)
        {
            bool isAuthenticated = false;
            authenticationException = null;
            try
            {
                if (validHubCredentials == null)
                {
                    authenticationException = new KeyNotFoundException();
                    return isAuthenticated;
                }

                //Authenticate the User..
                isAuthenticated = ValidateHubAuthenticationCredentials();
            }
            catch (InvalidOperationException invalidOperationException)
            {
                authenticationException = invalidOperationException;
            }
            catch (UnauthorizedAccessException unauthorizedException)
            {
                authenticationException = unauthorizedException;
            }
            catch (ApplicationException applicationException)
            {
                authenticationException = applicationException;
            }
            catch (ArgumentNullException argumentNullException)
            {
                authenticationException = argumentNullException;
            }
            catch (Exception generalException)
            {
                authenticationException = generalException;
            }
            return isAuthenticated;
        }
        private static bool ValidateDeviceHubAuthenticationCredentials()
        {
            bool IsAuthenticated = false;
            string authorizationToken = string.Empty;
            string token = string.Empty;
            try
            {
                authorizationToken = HttpContext.Current.Request.Headers.Get(APIAUTHENTICATION_AUTHORIZATION);
                Guard.IsNotBlank(authorizationToken, "Authorization Token");

                DeserializeAuthenticationToken(ref token, authorizationToken);

                if (!string.IsNullOrEmpty(token) && token.Equals(CommonHelper.GetConfigSetting(KC.SmartWashroom.Core.Constants.DeviceHubConstants.DEVICE_HUB_AUTH_TOKEN)))
                {
                    IsAuthenticated = true;
                }

                return IsAuthenticated;
            }
            catch
            {
                throw;
            }
        }
        private static bool ValidateHubAuthenticationCredentials()
        {
            bool IsAuthenticated = false;
            string validUserName = string.Empty, validUserPassword = string.Empty,
                userName = string.Empty, password = string.Empty,
                authorizationToken = string.Empty;

            try
            {
                authorizationToken = HttpContext.Current.Request.Headers.Get(APIAUTHENTICATION_AUTHORIZATION);
                Guard.IsNotBlank(authorizationToken, "Authorization Token");

                //IncommingAuthorizationToken = authorizationToken;

                //Parse the incomming token...
                DeserializeAuthenticationToken(ref userName, ref password, authorizationToken);

                IncommingAuthorizationToken = authorizationToken + userName + password;

                //if (validHubCredentials.TryGetValue(APIAUTHENTICATION_PASSWORDKEY, out validUserPassword))
                //    if (string.IsNullOrEmpty(password) || !validUserPassword.Equals(password))
                //        throw new UnauthorizedAccessException();

                //if (validHubCredentials.TryGetValue(APIAUTHENTICATION_USERNAMEKEY, out validUserName))
                //    if (string.IsNullOrEmpty(userName) || !validUserName.Equals(userName))
                //        throw new UnauthorizedAccessException();

                //Ensure for Correct match then authenticate..
                //if (validUserName.Equals(userName) && validUserPassword.Equals(password))
                //    IsAuthenticated = true;

                if (userName.Equals("kcuser") && password.Equals("kcpassword-1"))
                    IsAuthenticated = true;

                return IsAuthenticated;
            }
            catch
            {
                throw;
            }
        }

        private static void DeserializeAuthenticationToken(ref string token, string authorizationToken)
        {
            try
            {
                string deserializedToken = string.Empty;
                string rawTokencredentials = string.Empty;

                int tokenLength = authorizationToken.Length;
                token= authorizationToken.Substring(AUTHENTICATION_SALT.Length, tokenLength - AUTHENTICATION_SALT.Length);
            }
            catch
            {
                throw new ApplicationException();
            }
        }
        private static void DeserializeAuthenticationToken(ref string userName, ref string password, string authorizationToken)
        {
            try
            {
                string deserializedToken = string.Empty;
                string rawTokencredentials = string.Empty;

                int tokenLength = authorizationToken.Length;
                string extractedSerializedToken = authorizationToken.Substring(AUTHENTICATION_SALT.Length, tokenLength - AUTHENTICATION_SALT.Length);
                string extractedToken = Encoding.ASCII.GetString(Convert.FromBase64String(extractedSerializedToken));

                string[] rawCredentialsSplit = extractedToken.Split(':');
                if (rawCredentialsSplit.Count() > 1)
                {
                    userName = rawCredentialsSplit[0].ToString();
                    password = rawCredentialsSplit[1].ToString();
                }
            }
            catch
            {
                throw new ApplicationException();
            }
        }
    }
}
