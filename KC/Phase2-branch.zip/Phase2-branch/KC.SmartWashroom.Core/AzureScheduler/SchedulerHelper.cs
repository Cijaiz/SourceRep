﻿using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.Helper;
using Microsoft.Azure;
using Microsoft.WindowsAzure.Management.Scheduler;
using Microsoft.WindowsAzure.Scheduler;
using Microsoft.WindowsAzure.Scheduler.Models;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Auth;
using Microsoft.WindowsAzure.Storage.Queue;
using Microsoft.WindowsAzure.Storage.Queue.Protocol;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.Core.AzureScheduler
{
    public class SchedulerHelper
    {
        private static string SubscriptionId;
        private static string CertificateThumbprint;
        private static string SchedulerCloudService;
        private static string SchedulerQueue;
        private static string SchedulerJobCollection;
        private static string StorageAccount;
        private static string StorageConnectionString;

        public SchedulerHelper()
        {
            SubscriptionId = CommonHelper.GetConfigSetting(AggregationConstants.SubscriptionId);
            CertificateThumbprint = CommonHelper.GetConfigSetting(AggregationConstants.CertificateThumbprint);
            SchedulerCloudService = CommonHelper.GetConfigSetting(AggregationConstants.SchedulerCloudService);
            SchedulerQueue = CommonHelper.GetConfigSetting(AggregationConstants.SchedulerQueue);
            SchedulerJobCollection = CommonHelper.GetConfigSetting(AggregationConstants.SchedulerJobCollection);
            StorageAccount = CommonHelper.GetConfigSetting(AggregationConstants.StorageAccount);
            StorageConnectionString = CommonHelper.GetConfigSetting(AggregationConstants.StorageConnectionString);
        }

        private static X509Certificate2 GetStoreCertificate(string thumbprint)
        {
            List<StoreLocation> locations = new List<StoreLocation> 
            { 
                StoreLocation.CurrentUser, 
                StoreLocation.LocalMachine 
            };

            foreach (var location in locations)
            {
                X509Store store = new X509Store("My", location);
                try
                {
                    store.Open(OpenFlags.ReadOnly | OpenFlags.OpenExistingOnly);
                    X509Certificate2Collection certificates = store.Certificates.Find(
                        X509FindType.FindByThumbprint, thumbprint, false);
                    if (certificates.Count == 1)
                    {
                        return certificates[0];
                    }
                }
                finally
                {
                    store.Close();
                }
            }

            throw new ArgumentException(string.Format(
                "A Certificate with thumbprint '{0}' could not be located.",
                thumbprint));
        }

        public string CreateSchedulerJob(string PropertyId, int jobInterval)
        {
            try
            {
                CloudStorageAccount storageAccount = CloudStorageAccount.Parse(StorageConnectionString);
                CloudQueueClient queueClient = storageAccount.CreateCloudQueueClient();
                CloudQueue queue = queueClient.GetQueueReference(SchedulerQueue);

                X509Certificate2 certificate = GetStoreCertificate(CertificateThumbprint);
                string JobId = string.Empty;

                // create management credencials and cloud service management client
                var credentials = new CertificateCloudCredentials(SubscriptionId, certificate);
                var cloudServiceMgmCli = new CloudServiceManagementClient(credentials);

                queue.CreateIfNotExists();

                var perm = new QueuePermissions();
                var policy = new SharedAccessQueuePolicy { SharedAccessExpiryTime = DateTimeOffset.MaxValue, Permissions = SharedAccessQueuePermissions.Add };
                perm.SharedAccessPolicies.Add("jobcoll001policy", policy);

                queue.SetPermissions(perm);
                var sas = queue.GetSharedAccessSignature(new SharedAccessQueuePolicy(), "jobcoll001policy");


                var schedulerClient = new SchedulerClient(SchedulerCloudService, SchedulerJobCollection, credentials);

                var result = schedulerClient.Jobs.Create(new JobCreateParameters()
                {
                    Action = new JobAction()
                    {
                        Type = JobActionType.StorageQueue,
                        QueueMessage = new JobQueueMessage()
                        {
                            Message = PropertyId,
                            QueueName = SchedulerQueue,
                            SasToken = sas,
                            StorageAccountName = StorageAccount
                        }
                    },
                    StartTime = DateTime.UtcNow.AddDays(-1),
                    Recurrence = new JobRecurrence()
                    {
                        Frequency = JobRecurrenceFrequency.Hour,
                        Interval = jobInterval
                    }
                });
                JobId = result.Job.Id;

                return JobId;
            }
            catch (Exception ex)
            {
                Log.Logger.Error("Scheduler Job creation Failed for property id: " + PropertyId + " with exception: " + ex.Message);
                return string.Empty;
            }
        }

        public string UpdateSchedulerJob(int PropertyId, string JobId, int jobInterval)
        {
            try
            {
                CloudStorageAccount storageAccount = CloudStorageAccount.Parse(StorageConnectionString);
                CloudQueueClient queueClient = storageAccount.CreateCloudQueueClient();
                CloudQueue queue = queueClient.GetQueueReference(SchedulerQueue);

                X509Certificate2 certificate = GetStoreCertificate(CertificateThumbprint);

                // create management credencials and cloud service management client
                var credentials = new CertificateCloudCredentials(SubscriptionId, certificate);
                var cloudServiceMgmCli = new CloudServiceManagementClient(credentials);

                var schedulerClient = new SchedulerClient(SchedulerCloudService, SchedulerJobCollection, credentials);

                var perm = new QueuePermissions();
                var policy = new SharedAccessQueuePolicy { SharedAccessExpiryTime = DateTimeOffset.MaxValue, Permissions = SharedAccessQueuePermissions.Add };
                perm.SharedAccessPolicies.Add("jobcoll001policy", policy);

                queue.SetPermissions(perm);
                var sas = queue.GetSharedAccessSignature(new SharedAccessQueuePolicy(), "jobcoll001policy");
                JobGetResponse response = schedulerClient.Jobs.Get(JobId);
                if (response != null && response.Job != null && response.Job.Action != null)
                {
                    var result = schedulerClient.Jobs.CreateOrUpdate(JobId, new JobCreateOrUpdateParameters
                    {
                        Action = response.Job.Action,
                        StartTime = response.Job.StartTime,
                        Recurrence = new JobRecurrence
                        {
                            Frequency = JobRecurrenceFrequency.Hour,
                            Interval = jobInterval
                        }
                    });
                    return result.Job.Id;
                }
                else
                {
                    var result = schedulerClient.Jobs.Create(new JobCreateParameters()
                    {
                        Action = new JobAction()
                        {
                            Type = JobActionType.StorageQueue,
                            QueueMessage = new JobQueueMessage()
                            {
                                Message = PropertyId.ToString(),
                                QueueName = SchedulerQueue,
                                SasToken = sas,
                                StorageAccountName = StorageAccount
                            }
                        },
                        StartTime = DateTime.UtcNow.AddDays(-1),
                        Recurrence = new JobRecurrence()
                        {
                            Frequency = JobRecurrenceFrequency.Hour,
                            Interval = jobInterval
                        }
                    });
                    return result.Job.Id;
                }

            }
            catch (Exception ex)
            {
                Log.Logger.Error("Scheduler Job updation Failed for property id: " + PropertyId + " with exception: " + ex.Message);
                Log.Logger.Debug("Creating a new job for property id: " + PropertyId);
                return CreateSchedulerJob(PropertyId.ToString(), jobInterval);
            }
        }

        public string DeleteSchedulerJob(string JobId)
        {
            try
            {
                CloudStorageAccount storageAccount = CloudStorageAccount.Parse(StorageConnectionString);

                X509Certificate2 certificate = GetStoreCertificate(CertificateThumbprint);

                // create management credencials and cloud service management client
                var credentials = new CertificateCloudCredentials(SubscriptionId, certificate);
                var cloudServiceMgmCli = new CloudServiceManagementClient(credentials);

                var schedulerClient = new SchedulerClient(SchedulerCloudService, SchedulerJobCollection, credentials);

                var result = schedulerClient.Jobs.Delete(JobId);

                return result.RequestId;
            }
            catch (Exception ex)
            {
                Log.Logger.Error("Scheduler Job deletion Failed for job id: " + JobId + " with exception: " + ex.Message);
                return string.Empty;
            }
        }
    }
}
