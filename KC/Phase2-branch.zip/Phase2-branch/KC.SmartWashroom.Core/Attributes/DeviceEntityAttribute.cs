﻿using KC.SmartWashroom.Core.Enumerations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.Core.Attributes
{
    public class DeviceEntityAttribute: Attribute
    {
        private Enums.DeviceEntityType _deviceEntityType;
        public DeviceEntityAttribute(Enums.DeviceEntityType deviceEntityType)
        {
            _deviceEntityType = deviceEntityType;
        }
        public Enums.DeviceEntityType DeviceEntityType
        {
            get
            {
                return _deviceEntityType;
            }
        }
    }
}
