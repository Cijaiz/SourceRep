﻿
using System.Collections.Generic;
namespace KC.SmartWashroom.Core.Helper
{
    public class SmsConfig
    {
        public string FromMobileNumber { get; set; }
        public string AccountUserId { get; set; }
        public string AuthuenticationToken { get; set; }

        public List<string> ErrorAdminMobileNos { get; set; }
    }
}
