﻿using KC.SmartWashroom.Core.Constants;
using Microsoft.WindowsAzure;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Reflection;

namespace KC.SmartWashroom.Core.Helper
{
    /// <summary>
    /// Common helper
    /// </summary>
    public static class CommonHelper
    {
        /// <summary>
        /// This function is used to get the configuration value.
        /// </summary>
        /// <example>
        /// string value = CommonHelper.GetConfigSetting("key");
        /// </example>
        /// <remarks>
        ///  It will check for the key in cloud configuration if its not available then it will app/web config file.
        /// </remarks>
        /// <exception cref="">Key is not found in the config file.</exception>
        /// <param name="key">key name</param>
        /// <returns>Config value as string</returns>
        public static string GetConfigSetting(string key)
        {
            return CloudConfigurationManager.GetSetting(key);
        }

        public static string UploadMediaFile(string folderPathToUpload, System.Web.HttpPostedFileBase fileTOUpload, bool persistThumbNails = false)
        {
            return FileManagement.StorageManager.UploadMediaFile(folderPathToUpload, fileTOUpload, persistThumbNails);
        }

        public static string GetMediaFilePath(string relativeFilePath)
        {
            return FileManagement.StorageManager.GetPublicMediaPath(relativeFilePath);
        }

        public static int GetRandomNumber(int lowRandomNumber, int highRandomNumber)
        {
            Random random = new Random();
            int number = random.Next(lowRandomNumber, highRandomNumber);
            return number;
        }

        public static string GetRandomAlphaNumericPassword()
        {
            var masterCharacters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

            var random = new Random();
            var result = new string(
                Enumerable.Repeat(masterCharacters, CommonConstants.PASSWORD_LENGTH)
                          .Select(s => s[random.Next(s.Length)])
                          .ToArray());

            return result;
        }

        public static KeyValuePair<string, string> GetDeviceAlertType(string alertCode)
        {
            KeyValuePair<string, string> Keyvalue;
            List<KeyValuePair<string, KeyValuePair<string, string>>> DeviceAlertTypeKeys = new List<KeyValuePair<string, KeyValuePair<string, string>>>();

            DeviceAlertTypeKeys = CreateAlertTypes();

            KeyValuePair<string, KeyValuePair<string, string>> item = DeviceAlertTypeKeys.Find((lItem) => lItem.Key.Equals(alertCode));
            Keyvalue = item.Value;

            return Keyvalue;

        }

        public static string GetDeviceAlertTypeCode(string alertTypeName)
        {
            string key;
            List<KeyValuePair<string, KeyValuePair<string, string>>> DeviceAlertTypeKeys = new List<KeyValuePair<string, KeyValuePair<string, string>>>();

            DeviceAlertTypeKeys = CreateAlertTypes();

            KeyValuePair<string, KeyValuePair<string, string>> item = DeviceAlertTypeKeys.Find((lItem) => lItem.Value.Value.Equals(alertTypeName));
            key = item.Key;

            return key;
        }

        public static List<KeyValuePair<string, KeyValuePair<string, string>>> CreateAlertTypes()
        {
            List<KeyValuePair<string, KeyValuePair<string, string>>> DeviceAlertTypeKeys = new List<KeyValuePair<string, KeyValuePair<string, string>>>();

            Hashtable DeviceKeyValues = new Hashtable();
            DeviceKeyValues.Add("JRT", AlertEngineConstants.JRT_DEVICE_NAME);
            DeviceKeyValues.Add("eHRT", AlertEngineConstants.EHRT_DEVICE_NAME);
            DeviceKeyValues.Add("eSoap", AlertEngineConstants.ESOAP_DEVICE_NAME);
            DeviceKeyValues.Add("SRB", AlertEngineConstants.SRB_DEVICE_NAME);

            KeyValuePair<string, string> J1 = new KeyValuePair<string, string>(DeviceKeyValues["JRT"].ToString(), CommonConstants.LOW_BATTERY);
            KeyValuePair<string, string> J2 = new KeyValuePair<string, string>(DeviceKeyValues["JRT"].ToString(), CommonConstants.PAPER_TRANSFER);
            KeyValuePair<string, string> J3 = new KeyValuePair<string, string>(DeviceKeyValues["JRT"].ToString(), CommonConstants.LOW_PAPER);

            KeyValuePair<string, string> S1 = new KeyValuePair<string, string>(DeviceKeyValues["eSoap"].ToString(), CommonConstants.LOW_SOAP);
            KeyValuePair<string, string> S2 = new KeyValuePair<string, string>(DeviceKeyValues["eSoap"].ToString(), CommonConstants.LOW_BATTERY);
            KeyValuePair<string, string> S3 = new KeyValuePair<string, string>(DeviceKeyValues["eSoap"].ToString(), CommonConstants.MOTOR_OVERCURRENT);
            KeyValuePair<string, string> S4 = new KeyValuePair<string, string>(DeviceKeyValues["eSoap"].ToString(), CommonConstants.VERY_LOW_SOAP);

            KeyValuePair<string, string> H1 = new KeyValuePair<string, string>(DeviceKeyValues["eHRT"].ToString(), CommonConstants.PAPER_TRANSFER);
            KeyValuePair<string, string> H2 = new KeyValuePair<string, string>(DeviceKeyValues["eHRT"].ToString(), CommonConstants.LOW_BATTERY);
            KeyValuePair<string, string> H3 = new KeyValuePair<string, string>(DeviceKeyValues["eHRT"].ToString(), CommonConstants.PAPER_JAM);
            KeyValuePair<string, string> H4 = new KeyValuePair<string, string>(DeviceKeyValues["eHRT"].ToString(), CommonConstants.LOW_PAPER);
            KeyValuePair<string, string> H5 = new KeyValuePair<string, string>(DeviceKeyValues["eHRT"].ToString(), CommonConstants.TRASH_FULL);

            KeyValuePair<string, string> SR1 = new KeyValuePair<string, string>(DeviceKeyValues["SRB"].ToString(), CommonConstants.LOW_BATTERY);
            KeyValuePair<string, string> SR2 = new KeyValuePair<string, string>(DeviceKeyValues["SRB"].ToString(), CommonConstants.PAPER_TRANSFER);
            KeyValuePair<string, string> SR3 = new KeyValuePair<string, string>(DeviceKeyValues["SRB"].ToString(), CommonConstants.LOW_PAPER);

            DeviceAlertTypeKeys.Add(new KeyValuePair<string, KeyValuePair<string, string>>("J1", J1));
            DeviceAlertTypeKeys.Add(new KeyValuePair<string, KeyValuePair<string, string>>("J2", J2));
            DeviceAlertTypeKeys.Add(new KeyValuePair<string, KeyValuePair<string, string>>("J3", J3));

            DeviceAlertTypeKeys.Add(new KeyValuePair<string, KeyValuePair<string, string>>("S1", S1));
            DeviceAlertTypeKeys.Add(new KeyValuePair<string, KeyValuePair<string, string>>("S2", S2));
            DeviceAlertTypeKeys.Add(new KeyValuePair<string, KeyValuePair<string, string>>("S3", S3));
            DeviceAlertTypeKeys.Add(new KeyValuePair<string, KeyValuePair<string, string>>("S4", S4));

            DeviceAlertTypeKeys.Add(new KeyValuePair<string, KeyValuePair<string, string>>("H1", H1));
            DeviceAlertTypeKeys.Add(new KeyValuePair<string, KeyValuePair<string, string>>("H2", H2));
            DeviceAlertTypeKeys.Add(new KeyValuePair<string, KeyValuePair<string, string>>("H3", H3));
            DeviceAlertTypeKeys.Add(new KeyValuePair<string, KeyValuePair<string, string>>("H4", H4));
            DeviceAlertTypeKeys.Add(new KeyValuePair<string, KeyValuePair<string, string>>("H5", H5));

            DeviceAlertTypeKeys.Add(new KeyValuePair<string, KeyValuePair<string, string>>("SR1", SR1));
            DeviceAlertTypeKeys.Add(new KeyValuePair<string, KeyValuePair<string, string>>("SR2", SR2));
            DeviceAlertTypeKeys.Add(new KeyValuePair<string, KeyValuePair<string, string>>("SR3", SR3));


            return DeviceAlertTypeKeys;
        }

        public static decimal CalculateDevicePercentageLevel(string DeviceType,
                                                            decimal DeviceLastDispensed,
                                                            decimal DeviceRefillValue,
                                                            decimal ProductRefillValue,
                                                            byte productUsageBuffer)
        {
            decimal PercentageLevel = 0;
            decimal soapBufferDefault = 0;
            decimal eSoapUsageBuffer = decimal.TryParse(productUsageBuffer.ToString(), out soapBufferDefault)
                                                                    ? soapBufferDefault : soapBufferDefault;

            decimal ProductThresholdValue = Convert.ToDecimal(ProductRefillValue.ToString());
            switch (DeviceType.ToUpper())
            {
                case CommonConstants.JRT:
                case CommonConstants.SRB:
                    PercentageLevel = DeviceLastDispensed;
                    break;
                case CommonConstants.eHRT:
                    if (DeviceRefillValue != 0)
                    {
                        PercentageLevel = ((DeviceRefillValue - DeviceLastDispensed) / DeviceRefillValue) * 100;
                    }
                    break;
                case CommonConstants.eSoap:
                    //Used Formula
                    //((Refill Size -Buffer)-(Shot Size ×Number of Dispenses))/((Refill Size -Buffer) )
                    if (DeviceRefillValue != 0)
                    {
                        PercentageLevel = (((DeviceRefillValue - eSoapUsageBuffer) - (ProductThresholdValue * DeviceLastDispensed))
                                                                                    / (DeviceRefillValue - eSoapUsageBuffer)) * 100;
                    }
                    break;
                default:
                    break;
            }
            PercentageLevel = PercentageLevel < 0 ? 0 : PercentageLevel;// Lower than lower limit check safe check..
            PercentageLevel = PercentageLevel > 100 ? 100 : PercentageLevel; //Greater Upper LImit check safe check..

            return PercentageLevel;
        }

        public static DateTime ConvertRowKeyToDateTime(string rowKey)
        {
            string DATE_FORMAT = "dd'-'MM'-'yyyy  HH:mm:ss:fff tt";
            DateTime result = DateTime.UtcNow;
            var rowKeyVals = rowKey.Split(':');
            var ticksMeridian = rowKeyVals[3].Split(' ');
            var dateAndHourMins = rowKeyVals[0] + ":" + rowKeyVals[1] + ":" + rowKeyVals[2];
            var meridian = ticksMeridian[1];


            string dateValue = dateAndHourMins + " " + meridian;

            //result = Convert.ToDateTime(dateValue);
            result = DateTime.ParseExact(rowKey, DATE_FORMAT, CultureInfo.InvariantCulture);

            return result;
        }
        //public static Dictionary<string, string> GetHeader(Consumer consumer)
        //{
        //    Dictionary<string, string> header = new Dictionary<string, string>();
        //    AuthenticationTokenBuilder authenticationBuilder = new AuthenticationTokenBuilder();

        //    switch (consumer)
        //    {
        //        case Consumer.Hub:
        //            authenticationBuilder.ACSRealmSettingKey = Key.HUB_REALM;
        //            break;
        //        case Consumer.MailingService:
        //            authenticationBuilder.ACSRealmSettingKey = Key.MAILINGSERVICE_REALM;
        //            break;
        //        case Consumer.Orchard:
        //            authenticationBuilder.ACSRealmSettingKey = Key.ORCHARD_REALM;
        //            break;
        //        default:
        //            break;
        //    }

        //    authenticationBuilder.ACSNameSpaceSettingKey = Key.ACS_NAMESPACE;
        //    authenticationBuilder.ACSUserIdSettingKey = Key.SERVICEIDENTITY_USERNAME;
        //    authenticationBuilder.ACSPasswordSettingKey = Key.SERVICEIDENTITY_PASSWORD;
        //    string token = string.Format("WRAP access_token=\"{0}\"", authenticationBuilder.BuildACSToken());
        //    header.Add(DefaultValue.TOKEN_HEADER, token);

        //    return header;
        //}

        public static DateTime GetLocalTime(DateTime inputDate, string locationTimeZone)
        {
            DateTime localTime = inputDate;
            ReadOnlyCollection<TimeZoneInfo> timeZones = TimeZoneInfo.GetSystemTimeZones();
            TimeZoneInfo localTimeZone = timeZones.Where(x => x.Id.Equals(locationTimeZone)).FirstOrDefault();

            localTime = TimeZoneInfo.ConvertTimeFromUtc(inputDate, localTimeZone ?? timeZones.Where(x => x.Id.Equals("UTC")).FirstOrDefault());
            return localTime;
        }

        /// <summary>
        /// Return the current utc time ticks in inversal
        /// </summary>
        /// <returns>timestamp as 19 digits</returns>
        public static string GetInverseTimestamp()
        {
            return string.Format("{0:D19}", DateTime.MaxValue.Ticks - DateTime.UtcNow.Ticks);
        }

        /// <summary>
        /// Gets the ticks remining from the given date time to the maximum date time value
        /// </summary>
        /// <param name="dateTime">The instance of the date time</param>
        /// <returns>The ticks remaining from the given date time to the maximum date time</returns>
        /// <remarks>Uses the UTC convensions by default</remarks>
        public static long InverseTicks(this DateTime dateTime)
        {
            return dateTime.Inverse().Ticks;
        }

        /// <summary>
        /// Gets the ticks remining from the given date time offset to the maximum date time value
        /// </summary>
        /// <param name="dateTimeOffset">The instance of the date time offset</param>
        /// <returns>The ticks remaining from the given date time offset to the maximum date time offset</returns>
        /// <remarks>Uses the UTC convensions by default</remarks>
        public static long InverseTicks(this DateTimeOffset dateTimeOffset)
        {
            return dateTimeOffset.Inverse().Ticks;
        }

        /// <summary>
        /// Gets the time remining from the given date time to the maximum date time value
        /// </summary>
        /// <param name="dateTime">The instane of the date time</param>
        /// <returns>The time remaining from the given date time to the maximum date time value</returns>
        /// <remarks>Uses the UTC convensions by default</remarks>
        public static TimeSpan Inverse(this DateTime dateTime)
        {
            return DateTime.MaxValue.ToUniversalTime() - dateTime.ToUniversalTime();
        }

        /// <summary>
        /// Gets the time remining from the given date time to the maximum date time value
        /// </summary>
        /// <param name="dateTimeOffset">The instane of the date time with offset</param>
        /// <returns>The time remaining from the given date time to the maximum date time value</returns>
        /// <remarks>Uses the UTC convensions by default</remarks>
        public static TimeSpan Inverse(this DateTimeOffset dateTimeOffset)
        {
            return DateTimeOffset.MaxValue.ToUniversalTime() - dateTimeOffset.ToUniversalTime();
        }

        /// <summary>
        /// Gets the number of complete days left from the given date time offset to the maximum date time offset value
        /// </summary>
        /// <param name="dateTimeOffset">The instane of the date time with offset</param>
        /// <returns>The number of complete days left to the maximum date from the given date </returns>
        public static int InverseDays(this DateTimeOffset dateTimeOffset)
        {
            return dateTimeOffset.Inverse().Days;
        }

        /// <summary>
        /// Gets the number of complete days left from the given date time offset to the maximum date time value
        /// </summary>
        /// <param name="dateTimeOffset">The instane of the date time</param>
        /// <returns>The number of complete days left to the maximum date from the given date </returns>
        /// <remarks>Uses the UTC convensions by default</remarks>
        public static int InverseDays(this DateTime dateTime)
        {
            return dateTime.Inverse().Days;
        }

        public static List<string> GetDaysForWeek(DateTime StartDate, DateTime EndDate)
        {
            List<string> Days = new List<string>();
            int days = (int)((EndDate - StartDate).TotalDays);
            for (int i = 0; i <= days; i++)
            {
                string day = string.Empty;
                day = GetDay((int)(StartDate.AddDays(i).DayOfWeek));
                Days.Add(day);
            }
            return Days;
        }

        private static string GetDay(int day)
        {
            string dayChars = string.Empty;
            switch (day)
            {
                case (int)DayOfWeek.Monday:
                    dayChars = DayOfWeek.Monday.ToString();
                    break;
                case (int)DayOfWeek.Tuesday:
                    dayChars = DayOfWeek.Tuesday.ToString();
                    break;
                case (int)DayOfWeek.Wednesday:
                    dayChars = DayOfWeek.Wednesday.ToString();
                    break;
                case (int)DayOfWeek.Thursday:
                    dayChars = DayOfWeek.Thursday.ToString();
                    break;
                case (int)DayOfWeek.Friday:
                    dayChars = DayOfWeek.Friday.ToString();
                    break;
                case (int)DayOfWeek.Saturday:
                    dayChars = DayOfWeek.Saturday.ToString();
                    break;
                case (int)DayOfWeek.Sunday:
                    dayChars = DayOfWeek.Sunday.ToString();
                    break;
                default:
                    break;
            }
            if (!string.IsNullOrEmpty(dayChars))
            {
                return dayChars.Substring(0, 3);
            }
            else
            {
                return dayChars;
            }
        }

        public static List<string> GetDatesThisMonth(TimeZoneInfo tmz)
        {
            DateTime date = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, tmz);
            List<string> Dates = new List<string>();
            for (int i = 1; i <= (int)date.Day; i++)
            {
                Dates.Add(i.ToString());
            }
            return Dates;
        }

        public static List<string> GetDatesLastMonth(TimeZoneInfo tmz)
        {
            DateTime date = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, tmz);
            return GetDatesForAnyMonthYear(date.AddMonths(-1).Year, date.AddMonths(-1).Month);
        }

        public static List<string> GetDatesForMonth(string month, int year, TimeZoneInfo tmz)
        {
            int monthNumber = 0;
            DateTime date = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, tmz);
            //Check if it is current month
            if (year == date.Year && string.Equals(date.ToString("MMM"), month))
            {
                return GetDatesThisMonth(tmz);
            }
            else
            {
                monthNumber = GetMonth(month);
                return GetDatesForAnyMonthYear(year, monthNumber);
            }
        }

        private static int GetMonth(string month)
        {
            string[] AllMonthsAbbr = new string[12];
            int monthIndex = 0;
            AllMonthsAbbr = DateTimeFormatInfo.CurrentInfo.AbbreviatedMonthNames;
            for (int i = 0; i <= 12; i++)
            {
                if (AllMonthsAbbr[i] == month)
                {
                    monthIndex = i;
                    break;
                }
            }
            return monthIndex + 1;
        }

        private static List<string> GetDatesForAnyMonthYear(int year, int month)
        {
            List<string> Dates = new List<string>();
            for (int i = 1; i <= DateTime.DaysInMonth(year, month); i++)
            {
                Dates.Add(i.ToString());
            }
            return Dates;
        }

        public static DateTime TryParseDateTime(string dateTimeString, params string[] formatCodes)
        {
            var dateTime = default(DateTime);

            if (!string.IsNullOrWhiteSpace(dateTimeString))
            {
                if (formatCodes != null
                    && formatCodes.Length > 0)
                {
                    DateTime.TryParseExact(dateTimeString, formatCodes, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out dateTime);
                }
                if (dateTime == default(DateTime))
                {
                    DateTime.TryParse(dateTimeString, out dateTime);
                }
            }

            return dateTime;

        }

        public static void ShallowCopy(Object dest, Object src)
        {
            BindingFlags flags = BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic;
            FieldInfo[] destFields = dest.GetType().GetFields(flags);
            FieldInfo[] srcFields = src.GetType().GetFields(flags);

            foreach (FieldInfo srcField in srcFields)
            {
                FieldInfo destField = destFields.FirstOrDefault(field => field.Name == srcField.Name);

                if (destField != null && !destField.IsLiteral)
                {
                    if (srcField.FieldType == destField.FieldType)
                        destField.SetValue(dest, srcField.GetValue(src));
                }
            }
        }


    }
}
