﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.Core.Helper
{
    public class ProcessResponse
    {
        public int RefId { get; set; }
        public string Message { get; set; }
        public ResponseStatus Status { get; set; }
    }

    public class ProcessResponse<T>
    {
        public T Object { get; set; }
        public string Message { get; set; }
        public ResponseStatus Status { get; set; }
    }

    public enum ResponseStatus
    {
        Success = 1,
        Failed = 2,
        Error = 3
    }

    public class ProcessResponseForGateway
    {
        public string status { get; set; }
        public string message { get; set; }
    }
}
