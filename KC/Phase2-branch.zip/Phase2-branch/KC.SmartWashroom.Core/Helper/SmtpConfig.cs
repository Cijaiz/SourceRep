﻿
using System.Collections.Generic;
namespace KC.SmartWashroom.Core.Helper
{
    public  class SmtpConfig
    {
        public  int SmtpPort { get;  set; }
        public  string SmtpUserName { get;  set; }
        public  string SmtpPassword { get;  set; }

        public  bool SmtpEnableSsl { get;  set; }
        public  string SmtpHost { get;  set; }
        public string FromEmailAddress { get; set; }
        
        public List<string> ErrorAdminsEmails { get; set; }
    }
}
