﻿using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.Core.Helper.CloudHelper
{
    public class CacheHelper
    {
        private Dictionary<string, ConnectionMultiplexer> connections = new Dictionary<string, ConnectionMultiplexer>();
        private static CacheHelper instance = null;

        /// <summary>
        /// Gets an instance of Cache helper.
        /// </summary>
        /// <returns>Azure REDIS Cache helper without any connections</returns>
        public static CacheHelper GetInstance()
        {
            if (instance == null)
                instance = new CacheHelper();

            return instance;
            //return GetInstance(CommonHelper.GetConfigSetting("CacheName") + ",ssl=" + CommonHelper.GetConfigSetting("CacheUseSSL") + ",password=" + CommonHelper.GetConfigSetting("CachePassword") + ",SyncTimeout=5000,ConnectTimeout=5000");
        }

        private CacheHelper()
        {
            this.connections = new Dictionary<string, ConnectionMultiplexer>();
        }

        /// <summary>
        /// Gets an instance of default Connection, if it is already configured beforehand. If not configured, throws an exception
        /// </summary>
        /// <returns>StackExchange.Redis.StrongName ConnectionMultiplexer instance</returns>
        public ConnectionMultiplexer GetConnection()
        {
            if (connections.Keys.Count > 0)
            {
                string key = null;
                foreach (string item in connections.Keys)
                {
                    key = item;
                    break;
                }
                return connections[key];
            }
            else
                throw new ApplicationException("No REDIS cache connection configured");
        }

        /// <summary>
        /// Returns a Connection with connection the specified redis cache
        /// </summary>
        /// <param name="connectionString">Connection string to connect to the REDIS cache</param>
        /// <returns>StackExchange.Redis.StrongName ConnectionMultiplexer instance</returns>
        public ConnectionMultiplexer GetConnection(string connectionString)
        {
            if (connections.ContainsKey(connectionString))
                return connections[connectionString];
            else
            {
                ConnectionMultiplexer con = ConnectionMultiplexer.Connect(connectionString);
                this.connections.Add(connectionString, con);
                return con;
            }
        }

        /// <summary>
        /// Returns a Connection with connection the default connection generated from the following configuration parameters
        /// CacheName (entire name with redis.cache.windows.net)
        /// CacheUseSSL
        /// CachePassword
        /// Default sync timeout and connect timeout are set to 5 sec
        /// If the parameters cannot be found, throws an exception
        /// </summary>
        /// <returns>StackExchange.Redis.StrongName ConnectionMultiplexer instance</returns>
        public ConnectionMultiplexer GetDefaultConnection()
        {
            string connectionString = null;
            try
            {
                connectionString = CommonHelper.GetConfigSetting("CacheName") + ",ssl=" + CommonHelper.GetConfigSetting("CacheUseSSL") + ",password=" + CommonHelper.GetConfigSetting("CachePassword") + ",SyncTimeout=5000,ConnectTimeout=5000";
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Could not find one or more parameters to construct default connection string", ex);
            }

            if (connections.ContainsKey(connectionString))
                return connections[connectionString];
            else
            {
                ConnectionMultiplexer con = ConnectionMultiplexer.Connect(connectionString);
                this.connections.Add(connectionString, con);
                return con;
            }
        }
    }
}