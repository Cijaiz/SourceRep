﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Queue;
using Microsoft.WindowsAzure.Storage.RetryPolicies;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.Core.Helper.CloudHelper
{
    public sealed class Queue
    {
        private CloudQueueClient cloudQueueClient = null;
        private CloudStorageAccount cloudStorageAccount = null;

        private Queue(string storageConnectionString)
        {
            cloudStorageAccount = CloudStorageAccount.Parse(storageConnectionString);
            cloudQueueClient = cloudStorageAccount.CreateCloudQueueClient();
            IRetryPolicy exponentialRetryPolicy = new ExponentialRetry(TimeSpan.FromSeconds(2), 5);
            cloudQueueClient.RetryPolicy = exponentialRetryPolicy;
        }

        public static Queue GetInstance(string storageConnectionString)
        {
            return new Queue(storageConnectionString);
        }

        public bool Create(string queueName)
        {
            try
            {
                CloudQueue queue = cloudQueueClient.GetQueueReference(queueName);
                queue.CreateIfNotExists();
                return true;
            }
            catch (StorageException ex)
            {
                if (ex.RequestInformation.HttpStatusCode == (int)HttpStatusCode.Conflict)
                {
                    return false;
                }
                throw;
            }
        }

        public void Push(string queueName, CloudQueueMessage message)
        {
            CloudQueue cloudQueue = cloudQueueClient.GetQueueReference(queueName);
            //if (cloudQueue.Exists()) As Queue is already created lets skip this check.
            //{
                try
                {
                    string id = Guid.NewGuid().ToString();
                    new Logger.Structure.AzureLogger().WriteInformation("Push: {0}-Adding message to string: {1}", id, message.AsString);
                    CloudQueue queue = cloudQueueClient.GetQueueReference(queueName);
                    queue.AddMessage(message);
                    new Logger.Structure.AzureLogger().WriteInformation("Push: {0}-Added message to string: {1}", id, message.AsString);
                }
                catch
                {
                    throw;
                }
            //}
        }

        public void Push(string queueName, bool createQueueIfNotExists, CloudQueueMessage message)
        {
            CloudQueue queue = cloudQueueClient.GetQueueReference(queueName);
            if (!queue.Exists())
            {
                queue.CreateIfNotExists();
            }

            queue.AddMessage(message);

        }

        public int? GetMessageCount(string queueName)
        {
            CloudQueue queue = cloudQueueClient.GetQueueReference(queueName);
            int? count = null;
            if(queue.Exists())
            {
                queue.FetchAttributes();
                count = queue.ApproximateMessageCount;
            }
            return count;
        }

        public CloudQueueMessage GetMessage(string queueName)
        {
            CloudQueue queue = cloudQueueClient.GetQueueReference(queueName);
            CloudQueueMessage retrievedMessage = null;
           
            if (queue.Exists())
            {
                 retrievedMessage = queue.GetMessage();
               
            }
            return retrievedMessage;
        }

        public void DeleteMessage(string queueName, CloudQueueMessage Message)
        {
            CloudQueue queue = cloudQueueClient.GetQueueReference(queueName);
            if (queue.Exists())
            {
                queue.DeleteMessage(Message);

            }
        }
    }
}
