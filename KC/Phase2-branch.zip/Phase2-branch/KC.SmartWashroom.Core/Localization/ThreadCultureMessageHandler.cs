﻿using KC.SmartWashroom.Core.Constants;
using System.Collections.Generic;
using System.Globalization;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;


namespace KC.SmartWashroom.Core.Localization
{
    public class ThreadCultureMessageHandler : DelegatingHandler
    {
        List<string> ImplementedCulture;

        #region Protected Methods
        /// <summary>
        ///  Sets the Current Thread Culture
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,
            CancellationToken cancellationToken)
        {
            string cultureName = null;
            if (request.Headers.AcceptLanguage != null)
            {
                // then check the Accept-Language header.
                cultureName = request.Headers.AcceptLanguage.ToString();

                List<string> implementedCulture = new List<string> {
                LocalizationContants.DEFAULT_CULTURE, 
                LocalizationContants.HINDI_CULTURE  
            };

                cultureName = CultureHelper.GetImplementedCulture(cultureName, ImplementedCulture);
                Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo(cultureName);
                Thread.CurrentThread.CurrentUICulture = Thread.CurrentThread.CurrentCulture;
                CultureInfo.DefaultThreadCurrentCulture = new System.Globalization.CultureInfo(cultureName);
                CultureInfo.DefaultThreadCurrentUICulture = Thread.CurrentThread.CurrentCulture;
            }
            return base.SendAsync(request, cancellationToken);

        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Gets the Implemented Culture
        /// </summary>
        /// <param name="implementedCulture"></param>
        public ThreadCultureMessageHandler(List<string> implementedCulture)
        {
            if (implementedCulture.Count != 0 || implementedCulture != null)
                ImplementedCulture = implementedCulture;
            else
            {
                ImplementedCulture = new List<string> { LocalizationContants.DEFAULT_CULTURE };
            }
        } 
        #endregion

     
    }
}
