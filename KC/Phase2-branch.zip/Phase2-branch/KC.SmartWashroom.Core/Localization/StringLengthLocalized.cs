﻿using KC.SmartWashroom.Core.Constants;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Resources;
using System.Web.Mvc;

namespace KC.SmartWashroom.Core.Localization
{
    public class StringLengthLocalizedAttribute : StringLengthAttribute, IClientValidatable
    {
        #region Constructor
        //public StringLengthLocalizedAttribute()
        //    : this(20)
        //{
        //}

        /// <summary>
        /// Initializes a new instance of the System.ComponentModel.DataAnnotations.StringLengthAttribute
        ///    class by using a specified maximum length.
        /// </summary>
        /// <param name="maximumLength"></param>
        public StringLengthLocalizedAttribute(int maximumLength)
            : base(maximumLength)
        {
            this.ErrorMessageResourceType = typeof(Resource.Resource);
        }

        /// <summary>
        /// Initializes a new instance of the System.ComponentModel.DataAnnotations.StringLengthAttribute
        ///  class by using a specified maximum length and Error Message.
        /// </summary>
        /// <param name="maximumLength"></param>
        public StringLengthLocalizedAttribute(int maximumLength, string errorMessage)
            : base(maximumLength)
        {
            this.ErrorMessageResourceType = typeof(Resource.Resource);
            this.ErrorMessageResourceName = errorMessage;
        }

        /// <summary>
        /// Initializes a new instance of the System.ComponentModel.DataAnnotations.StringLengthAttribute
        ///  class by using a specified maximum length,minimum length and Error Message.
        /// </summary>
        /// <param name="maximumLength"></param>
        /// <param name="minimumLength"></param>
        /// <param name="errorMessage"></param>
        public StringLengthLocalizedAttribute(int maximumLength, int minimumLength, string errorMessage)
            : base(maximumLength)
        {
            this.MinimumLength = minimumLength;
            this.ErrorMessageResourceType = typeof(Resource.Resource);
            this.ErrorMessageResourceName = errorMessage;
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// Returns the value of the specified string resource.
        /// </summary>
        /// <param name="localizedKey"></param>
        /// <returns></returns>
        private static string GetString(string localizedKey)
        {
            ResourceManager resourceManager = new ResourceManager(typeof(KC.SmartWashroom.Resource.Resource));
            return resourceManager.GetString(localizedKey);
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Returns client validation rules for that class.
        /// </summary>
        /// <param name="metadata"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public IEnumerable<ModelClientValidationRule> GetClientValidationRules(ModelMetadata metadata, ControllerContext context)
        {
            yield return new ModelClientValidationRule
            {
                ErrorMessage = this.ErrorMessage,
                ValidationType = LocalizationContants.STRINGLENGTH,
            };
        }
        #endregion


    }
}
