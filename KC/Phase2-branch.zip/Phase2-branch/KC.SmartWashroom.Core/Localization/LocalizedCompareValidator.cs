﻿using KC.SmartWashroom.Core.Constants;
using System.Collections.Generic;
using System.Resources;
using System.Threading;

using System.Web.UI.WebControls;
using System.Web.Mvc;

namespace KC.SmartWashroom.Core.Localization
{
    public class LocalizedCompareAttribute:System.ComponentModel.DataAnnotations.CompareAttribute,IClientValidatable
    {
        public LocalizedCompareAttribute(string otherProperty,string localizedKey)
            : base(otherProperty)
        {
            this.ErrorMessageResourceType = typeof(KC.SmartWashroom.Resource.Resource);
            this.ErrorMessageResourceName = localizedKey;

        }
        #region Private Methods
        /// <summary>
        /// Returns the value of the specified string resource.
        /// </summary>
        /// <param name="localizedKey"></param>
        /// <returns></returns>
        //private static string GetString(string localizedKey)
        //{
        //    ResourceManager resourceManager = new ResourceManager(typeof(KC.SmartWashroom.Resource.Resource));
        //    return resourceManager.GetString(localizedKey, Thread.CurrentThread.CurrentUICulture);
        //}

        /// <summary>
        /// Returns client validation rules for that class.
        /// </summary>
        /// <param name="metadata"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public IEnumerable<ModelClientValidationRule> GetClientValidationRules(ModelMetadata metadata, ControllerContext context)
        {
            yield return new ModelClientValidationRule
            {
                ErrorMessage = this.ErrorMessage,
                ValidationType = LocalizationContants.COMPARE

            };
        } 
        #endregion
    }
}
