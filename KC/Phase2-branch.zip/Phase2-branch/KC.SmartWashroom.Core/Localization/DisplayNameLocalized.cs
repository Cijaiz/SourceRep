﻿using KC.SmartWashroom.Core.Constants;
using System.ComponentModel;

namespace KC.SmartWashroom.Core.Localization
{
    public class LocalizedDisplayNameAttribute : DisplayNameAttribute
    {
        #region Private Members
        private string ResourceKey { get; set; } 
        #endregion

        #region Properties
        /// <summary>
        ///    Gets the display name for a property, event, or public void method that takes
        //     no arguments stored in this attribute.
        /// </summary>
        public override string DisplayName
        {
            get
            {
                string displayName = Resource.Resource.ResourceManager.GetString(ResourceKey);
                return string.IsNullOrEmpty(displayName) ? string.Format(LocalizationContants.RESOURCEKEY_HOLDER, ResourceKey) : displayName;
            }
        } 
        #endregion

        #region Public Methods
        /// <summary>
        /// Constructor for Initialization
        /// </summary>
        /// <param name="resourceKey"></param>
        public LocalizedDisplayNameAttribute(string resourceKey)
        {
            ResourceKey = resourceKey;
        } 
        #endregion

       
        
    }

    
}
