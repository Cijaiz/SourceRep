﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Web.Mvc;
using KC.SmartWashroom.Core.Constants;

namespace KC.SmartWashroom.Core.Localization
{
    public class LocalizedRangeAttribute : System.ComponentModel.DataAnnotations.RangeAttribute, IClientValidatable
    {
        #region Constructor
        /// <summary>
        /// Validate the range and returns localized the error message if validation failed.
        /// </summary>
        /// <param name="minimum"></param>
        /// <param name="maximum"></param>
        /// <param name="resourceKey"></param>
        public LocalizedRangeAttribute(int minimum, int maximum, string resourceKey)
            : base(minimum, maximum)
        {
            this.ErrorMessageResourceType = typeof(Resource.Resource);
            this.ErrorMessageResourceName = resourceKey;
        } 

        #endregion

        #region Public Methods
        /// <summary>
        /// Returns client validation rules for that class.
        /// </summary>
        /// <param name="metadata"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public IEnumerable<ModelClientValidationRule> GetClientValidationRules(ModelMetadata metadata, ControllerContext context)
        {
            yield return new ModelClientValidationRule
            {
                ErrorMessage = this.ErrorMessage,
                ValidationType = LocalizationContants.RANGE

            };
        }  
        #endregion
    }
}
