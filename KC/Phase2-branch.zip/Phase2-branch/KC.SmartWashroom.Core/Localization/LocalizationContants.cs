﻿
namespace KC.SmartWashroom.Core.Constants
{
    public class LocalizationContants
    {
        public const string DEFAULT_CULTURE = "en-US";
        public const string HINDI_CULTURE = "hi";
        public const string IMPLEMENTED_CULTURE = "implementedCulture";
        public const char HYPHEN = '-';
        public const string RESOURCEKEY_HOLDER = "[[{0}]]";
        public const string REQUIRED = "required";
        public const string RANGE = "range";
        public const string REGEX = "regex";
        public const string STRINGLENGTHMESSAGE = "StringLengthMessage";
        public const string STRINGLENGTH = "stringlength";
        public const string COMPARE = "compare";
    }

    /// <summary>
    /// List of supported culture codes by Microsoft Commerce Server 
    /// </summary>
    public class CultureCodes
    {
        public const string ENGLISH_UNITED_STATES = "en-US";
        public const string ENGLISH_UNITED_KINGDOM = "en-GB";
        public const string HINDI_INDIA = "hi-IN";
        public const string FRENCH_FRANCE = "fr-FR";
        public const string GERMAN_GERMANY = "de-DE";
        public const string RUSSIAN_RUSSIA = "ru-RU";
    }
}
