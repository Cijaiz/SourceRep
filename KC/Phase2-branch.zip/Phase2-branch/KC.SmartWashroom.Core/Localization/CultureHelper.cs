﻿using KC.SmartWashroom.Core.Constants;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace KC.SmartWashroom.Core.Localization
{
    /// <summary>
    /// 
    /// </summary>
    public static class CultureHelper
    {

        #region Private Members
        /// <summary>
        /// List of supported culture codes by Microsoft Commerce Server 
        /// </summary>
        //private static readonly List<string> validCultures = new List<string> {"eu", "eu-ES", "br-FR", "en", "en-AU", "en-BZ", "en-CA",
        //    "en-029", "en-IN", "en-IE", "en-JM", "en-MY", "en-NZ", "en-PH", "en-SG", "en-ZA", "en-TT", "en-GB", "en-US", "en-ZW",
        //    "fr", "fr-BE", "fr-CA", "fr-FR", "fr-LU", "fr-MC", "fr-CH",
        //    "hi", "hi-IN",
        //    "es", "es-AR", "es-BO", "es-CL", "es-CO", "es-CR", "es-DO", "es-EC", "es-SV", "es-GT", "es-HN", "es-MX", "es-NI",
        //    "es-PA", "es-PY", "es-PE", "es-PR", "es-ES", "es-US", "es-UY", "es-VE",
        //    }; 

        /// <summary>
        /// List of valid culture codes
        /// </summary>
        private static readonly List<string> validCultures = new List<string> 
        { 
            CultureCodes.ENGLISH_UNITED_STATES,
            CultureCodes.ENGLISH_UNITED_KINGDOM,
            CultureCodes.FRENCH_FRANCE,
            CultureCodes.GERMAN_GERMANY,
            CultureCodes.RUSSIAN_RUSSIA,
            CultureCodes.HINDI_INDIA,
        };

        #endregion

        #region Private Methods
        /// <summary>
        /// Returns Neutral Culture 
        /// 
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        private static string GetNeutralCulture(string name)
        {
            if (!name.Contains(LocalizationContants.HYPHEN)) return name;
            return name.Split(LocalizationContants.HYPHEN)[0];
        } 
        #endregion

        #region Public Methods
        ///// <summary>
        ///// Gets the default Culture
        ///// </summary>
        ///// <param name="defaultCulture"></param>
        ///// <returns></returns>
        //public static string GetDefaultCulture(string defaultCulture)
        //{
        //    return defaultCulture;
        //}

        /// <summary>
        /// Gets Current Thread Culture
        /// </summary>
        /// <returns></returns>
        public static string GetCurrentCulture()
        {
            return Thread.CurrentThread.CurrentCulture.Name;
        }

        /// <summary>
        /// Gets Neutral culture of the Current Culture 
        /// </summary>
        /// <returns></returns>
        public static string GetCurrentNeutralCulture()
        {
            return GetNeutralCulture(Thread.CurrentThread.CurrentCulture.Name);
        }


        /// <summary>
        /// Returns a valid culture name based on "name" parameter. If "name" is not valid, it returns the default culture "en-US"
        /// </summary>
        /// <param name="name">Culture's name (e.g. en-US)</param>
        public static string GetImplementedCulture(string name, List<string> implementedCulture)
        {
            if (implementedCulture == null || implementedCulture.Count == 0)
            {
                implementedCulture.Insert(0, LocalizationContants.DEFAULT_CULTURE);
            }

            if (string.IsNullOrEmpty(name))
                return implementedCulture[0];

            if (validCultures.Where(validCulture => validCulture.Equals(name, StringComparison.InvariantCultureIgnoreCase)).Count() == 0)
                return implementedCulture[0];

            if (implementedCulture.Where(validCulture => validCulture.Equals(name, StringComparison.InvariantCultureIgnoreCase)).Count() > 0)
                return name;
            string neutralCultureName = GetNeutralCulture(name);
            foreach (var implCulture in implementedCulture)
                if (implCulture.StartsWith(neutralCultureName))
                    return implCulture;

            string defaultCulture = implementedCulture[0];
            return defaultCulture;
        } 
        #endregion
    }


}
