﻿using KC.SmartWashroom.Core.Constants;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Resources;
using System.Web.Mvc;

namespace KC.SmartWashroom.Core.Localization
{
    public class RequiredLocalizableAttribute : RequiredAttribute, IClientValidatable
    {
       


       /// <summary>
       /// Initializes a new instance of the System.ComponentModel.DataAnnotations.RequiredAttribute class.
       /// </summary>
       /// <param name="localizedKey"></param>
        public RequiredLocalizableAttribute(string localizedKey)
        {
            this.ErrorMessageResourceType = typeof(KC.SmartWashroom.Resource.Resource);
            this.ErrorMessageResourceName = localizedKey;
        }

        #region Interface Methods

        /// <summary>
        /// Returns client validation rules for that class.
        /// </summary>
        /// <param name="metadata"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public IEnumerable<ModelClientValidationRule> GetClientValidationRules(ModelMetadata metadata, ControllerContext context)
        {
            yield return new ModelClientValidationRule
            {
                ErrorMessage = this.ErrorMessage,
                ValidationType = LocalizationContants.REQUIRED
            };
        } 
        #endregion
    }
}
