﻿using System;
using System.Resources;
using System.Text.RegularExpressions;
using System.Globalization;
using KC.SmartWashroom.Constants;
using KC.SmartWashroom.Core.Helper;

namespace KC.SmartWashroom.Core.Localization
{
    public class ResourceLocalization
    {
        #region Public Method
        /// <summary>
        ///    The value of the resource localized for the caller's current UI culture,
        ///    or null if name cannot be found in a resource set.
        /// </summary>
        /// <param name="resourceKey"></param>
        /// <returns></returns>
        public static string LoadString(string resourceKey)
        {
            Guard.IsNotNull(resourceKey, "ResourceKey");
            string initalValue = resourceKey;

            //To do - need to do replace for other special chars.. 
            resourceKey = Regex.Replace(resourceKey, "[()]", "");
            resourceKey = resourceKey.Replace('.', ' ').Trim();
            resourceKey = resourceKey.Replace(' ', '_').Trim();

            ResourceManager resourceManager = new ResourceManager(typeof(Resource.Resource));
            resourceManager.IgnoreCase = true;
            return resourceManager.GetString(resourceKey) ?? initalValue;

        }

        /// <summary>
        /// Used to format the locallized sentence 
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="vals"></param>
        /// <returns></returns>
        public static string BuildResourceString(string msg, params string[] vals)
        {
            return string.Format(msg, vals);
        }


        public static string LocalizeWithFormatting(string key, params object[] formatParameters)
        {
            var formattedString = string.Empty;

            formattedString = ResourceLocalization.LoadString(key);

            if (!string.IsNullOrWhiteSpace(formattedString))
            {
                formattedString = string.Format(formattedString, formatParameters);
            }

            return formattedString;
        }

        /// <summary>
        /// Localize the resolution time.
        /// Example :  1d 2h 20mins will be localized as 1t 2s 20min in german.
        /// </summary>
        /// <param name="resolutionTime"></param>
        /// <returns></returns>
        public static string LocalizeResolutionTime(string resolutionTime)
        {
            CultureInfo currentCulture = CultureInfo.CurrentCulture;

            string formattedString = resolutionTime;

            if (currentCulture.Name.Equals(CultureCodes.GERMAN_GERMANY, StringComparison.OrdinalIgnoreCase))
            {
                formattedString = resolutionTime.Replace(LocalizationContants.RESOLUTIONTIME_DAYS_EN, LocalizationContants.RESOLUTIONTIME_DAYS_DE);
                formattedString = formattedString.Replace(LocalizationContants.RESOLUTIONTIME_HOURS_EN, LocalizationContants.RESOLUTIONTIME_HOURS_DE);
                formattedString = formattedString.Replace(LocalizationContants.RESOLUTIONTIME_MINS_EN, LocalizationContants.RESOLUTIONTIME_MINS_DE);
            }

            return formattedString;
        }
        #endregion

    }
}
