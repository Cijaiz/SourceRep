﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.Core.NotificationUtility
{
    public class CertificatedWebClient : WebClient
    {
        protected override WebRequest GetWebRequest(Uri address)
        {
            var request = base.GetWebRequest(address);

            X509Store store = new X509Store("My", StoreLocation.LocalMachine);
            store.Open(OpenFlags.ReadOnly);

            X509Certificate2Collection certificates = store.Certificates.Find(X509FindType.FindByThumbprint, "CERT_THUMBPRINT", false);
            if (certificates.Count > 0)
            {
                var cert = certificates[0];
                (request as HttpWebRequest).ClientCertificates.Add(cert);
            }
            return request;
        }
    }
}
