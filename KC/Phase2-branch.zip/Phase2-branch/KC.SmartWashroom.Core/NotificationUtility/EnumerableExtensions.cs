﻿using KC.SmartWashroom.Core.Helper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.Core.NotificationUtility
{
    using System.Security.Cryptography.X509Certificates;
    using KC.SmartWashroom.Core.Log;
    using System.Text.RegularExpressions;

    /// <summary>
    /// Extension methods for Notification Engine
    /// </summary>
    public static class EnumerableExtensions
    {
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="instance"></param>
        /// <param name="action"></param>
        public static void Each<T>(this IEnumerable<T> instance, Action<T> action)
        {
            if (instance == null)
                return;

            foreach (T item in instance)
            {
                action(item);
            }
        }

        /// <summary>
        /// Extension method for WebClient to download stream from specified URL.
        /// </summary>
        /// <param name="webClient">Web Client object </param>
        /// <param name="fetchUrl">Destination Url</param>
        /// <returns>Returns the downloaded string</returns>
        public static string SafeWebClientProcessing(this WebClient webClient, string fetchUrl)
        {
            String request = string.Empty;
            try
            {
                //Trust all certificates
                ServicePointManager.ServerCertificateValidationCallback += new RemoteCertificateValidationCallback(ValidateRemoteCertificate);

                System.IO.Stream stream = webClient.OpenRead(fetchUrl);
                System.IO.StreamReader reader = new System.IO.StreamReader(stream);
                request = reader.ReadToEnd();
            }
            catch (WebException webException)
            {
                throw webException;
            }

            catch (ArgumentException argException)
            {
                throw argException;
            }
            return request;
        }

        /// <summary>
        /// Sets the basic authentication header.... to the incoming webclietn.
        /// </summary>
        /// <param name="webClient"></param>
        /// <param name="userName"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public static bool SetAuthenticationHeaderToken(this WebClient webClient, string userName, string password)
        {
            bool isSuccess = false;

            //Prepare token..
            string formattedToken = string.Format("{0}:{1}", userName, password);
            string encodedToken = Convert.ToBase64String(Encoding.ASCII.GetBytes(formattedToken));
            string preparedAuthorizationToken = string.Format("{0} {1}", "Basic", encodedToken);

            //Login for Deserialization..
            string deserializedToken = string.Empty;
            string rawTokencredentials = string.Empty;

            int tokenLength = preparedAuthorizationToken.Length;
            string extractedSerializedToken = preparedAuthorizationToken.Substring("Basic ".Length, tokenLength - "Basic ".Length);
            string extractedToken = Encoding.ASCII.GetString(Convert.FromBase64String(extractedSerializedToken));

            string[] rawCredentialsSplit = extractedToken.Split(':');
            if (rawCredentialsSplit.Count() > 1)
            {
                string rawuserName = rawCredentialsSplit[0].ToString();
                string rawpassword = rawCredentialsSplit[1].ToString();
            }

            //The Credentials are embedded into Authorization Headers...
            if (preparedAuthorizationToken.Length > 0)
                webClient.Headers["Authorization"] = preparedAuthorizationToken;

            isSuccess = true;

            return isSuccess;
        }

        public static bool SetDeviceAuthenticationHeaderToken(this WebClient webClient, string token)
        {
            bool isSuccess = false;

            //Prepare token..
            //string formattedToken = string.Format("{0}", token);
            //string encodedToken = Convert.ToBase64String(Encoding.ASCII.GetBytes(formattedToken));
            //string preparedAuthorizationToken = string.Format("{0} {1}", "Basic", encodedToken);

            //The Credentials are embedded into Authorization Headers...
            if (token.Length > 0)
            {
                webClient.Headers["Authorization"] = token;
            }

            isSuccess = true;

            return isSuccess;
        }

        /// <summary>
        /// Extension Method for WebClient to call Post method
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="webClient">Web Client object</param>
        /// <param name="fetchUrl">Destination URL</param>
        /// <param name="postData">CHire data is the input to be passed to the post method</param>
        /// <returns>Returns the json response from the CHitr Import Controller</returns>
        public static string WebClientPostRequest<T>(this WebClient webClient, string fetchUrl, T postData)
        {
            string postMessage = string.Empty;

            if (postData.GetType().FullName.Equals("System.String"))
                postMessage = postData.ToString();
            else
                postMessage = SerializationHelper.JsonSerialize<T>(postData);

            webClient.Headers[HttpRequestHeader.ContentType] = "application/json";
            string response = webClient.UploadString(fetchUrl, postMessage);

            return response;
        }

        public static string WebClientPostRequest<T>(this WebClient webClient, string url, T postData, Dictionary<string, string> headers)
        {
            String response = string.Empty;
            try
            {
                //Trust all certificates
                ServicePointManager.ServerCertificateValidationCallback += new RemoteCertificateValidationCallback(ValidateRemoteCertificate);

                string postMessage = string.Empty;

                if (postData.GetType().FullName.Equals("System.String"))
                    postMessage = postData.ToString();
                else
                    postMessage = SerializationHelper.JsonSerialize<T>(postData);

                foreach (var item in headers)
                {
                    webClient.Headers.Add(item.Key, item.Value);
                }

                webClient.Headers[HttpRequestHeader.ContentType] = "application/json";
                response = webClient.UploadString(url, postMessage);
            }
            catch (Exception ex)
            {
                WebException webException = ex as WebException;
                if (webException.Response != null)
                {
                    HttpWebResponse webHttpResponse = webException.Response as HttpWebResponse;
                    if (webHttpResponse != null)
                    {
                        if (!(webHttpResponse.StatusCode == HttpStatusCode.OK))
                        {
                            Logger.Error(string.Format("Error : StatusCode {0}", webHttpResponse.StatusCode.ToString()));
                            Logger.Error(string.Format("Error Description : {0}", webHttpResponse.StatusDescription));
                        }
                    }
                }
                Logger.Error(string.Format("Exception Occured during Processing Client Call to Controller {0} \n Exception Details: {1}", url, ex.Message));
                throw new ApplicationException(string.Format("Exception Occured during Processing Client Call to Controller {0}", url));
            }
            return response;
        }

        private static System.Security.Cryptography.X509Certificates.X509Certificate2 getStoreCertificate(string thumbprint)
        {
            List<System.Security.Cryptography.X509Certificates.StoreLocation> locations = new List<StoreLocation>
            { 
                StoreLocation.CurrentUser, 
                StoreLocation.LocalMachine ,
            };

            foreach (var location in locations)
            {
                X509Store store = new System.Security.Cryptography.X509Certificates.X509Store("My", location);
                try
                {
                    store.Open(System.Security.Cryptography.X509Certificates.OpenFlags.ReadOnly | OpenFlags.OpenExistingOnly);
                    System.Security.Cryptography.X509Certificates.X509Certificate2Collection certificates = store.Certificates.Find(
                        X509FindType.FindByThumbprint, thumbprint, false);
                    if (certificates.Count == 1)
                    {
                        return certificates[0];
                    }
                }
                finally
                {
                    store.Close();
                }
            }

            throw new ArgumentException(string.Format(
                "A Certificate with thumbprint '{0}' could not be located.",
                thumbprint));
        }

        public static string WebPostRequest<T>(this HttpWebRequest webRequest, T requestData)
        {
            string responseFromServer = null;
            ServicePointManager.ServerCertificateValidationCallback += new RemoteCertificateValidationCallback(ValidateRemoteCertificate);
            try
            {
                webRequest.Method = "POST";

                byte[] messageInBytes = Encoding.UTF8.GetBytes(SerializationHelper.SerializeToXML<T>(requestData));


                // Set the ContentType property of the WebRequest.
                webRequest.ContentType = "application/xml";

                // Set the ContentLength property of the WebRequest.
                webRequest.ContentLength = messageInBytes.Length;

                //X509Certificate cert = new X509Certificate("OnTrees.cer");

                System.Security.Cryptography.X509Certificates.X509Certificate cert = getStoreCertificate("C7E2F410FA6830BA0380B1320E65EBF01E677E23");
                webRequest.ClientCertificates.Add(cert);

                // Get the request stream.
                Stream dataStream = webRequest.GetRequestStream();

                // Write the data to the request stream.
                dataStream.Write(messageInBytes, 0, messageInBytes.Length);
                // Close the Stream object.
                dataStream.Close();
                // Get the response.
                WebResponse response = webRequest.GetResponse();
                // Get the stream containing content returned by the server.
                dataStream = response.GetResponseStream();
                // Open the stream using a StreamReader for easy access.
                StreamReader reader = new StreamReader(dataStream);
                // Read the content.
                responseFromServer = reader.ReadToEnd();
            }
            catch
            {
                throw;
            }
            return responseFromServer;
        }

        public static bool ValidateRemoteCertificate(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }
    }
}
