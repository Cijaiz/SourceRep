﻿using KC.SmartWashroom.Core.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.Core
{
    public struct EngineConnectorWire
    {
        public static EngineConnectorWire EngineConnectorWireInstance()
        {
            EngineConnectorWire instance = new EngineConnectorWire();
            EngineConnectorWire.ValidHubCredentials = new Dictionary<string, string>();

            return instance;
        }

        public string StorageConnectionString { get; set; }
        public string FromEmailAddres { get; set; }
        public string FromMobileNumber { get; set; }

        public string BusinessHubUrl { get; set; }
        public string DataBaseConnectionString { get; set; }
        public string TemplatesConfigurationFilePath { get; set; }

        public SmtpConfig SmtpConfiguration { get; set; }
        public SmsConfig SmsConfiguration { get; set; }

        public static Dictionary<string, string> ValidHubCredentials { get; set; }
    }
}
