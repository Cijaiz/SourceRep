﻿
namespace KC.SmartWashroom.Core.Enumerations
{
    public static class Enums
    {
        public enum DeviceType
        {
            JRT = 1,
            eHRT = 2,
            eSoap = 3,
            SRB = 4
        }
        public enum SRBParams
        {
            DeviceId = 0,
            SoftwareVersion = 1,
            BatteryVoltage = 2,
            PaperRollRemainingPercent = 3,
            LowBatteryAlert = 4,
            LowPaperAlert = 5,
            TotalRollsDispensed = 6,
            UpdateIntervalInMinutes = 7,
            Reset = 8,
        }
        public enum JRTParams
        {
            DeviceId = 0,
            SoftwareVersion = 1,
            BatteryVoltage = 2,
            PaperRollRemainingPercent = 3,
            LowBatteryAlert = 4,
            PlaceHolder1=5,
            //PaperTransferAlert = 5,
            LowPaperAlert = 6,
            PlaceHolder2=7,
            //StubPaperInstalled = 7,
            TotalRollsDispensed = 8,
            UpdateIntervalInMinutes = 9,
            Reset = 10,
        }

        public enum eHRTParams
        {
            DeviceId = 0,
            SoftwareVersion = 1,
            Sensitivity = 2,
            DispenseLength = 3,
            DispenserDelay = 4,
            DispenseMode = 5,
            TotalDispenseCount = 6,
            DispensesWithLastBattery = 7,
            DispensesWithCurrentBattery = 8,
            NumberOfBatteryChanges = 9,
            VoltageLastBatteryChange = 10,
            CurrentBatteryVoltage = 11,
            LowPaperAlert = 12,
            LowBatteryAlert = 13,
            PaperJamAlert = 14,
            PaperDispensedSinceLastRefill = 15,
            Reset = 16,
            PlaceHolder = 17,
            TrashEmptyPercent = 18,
            TrashFullAlert = 19,
            UpdateInterval = 20,
            TotalRollsDispensed = 21,
            DelayEnabled=22,
            DelayValue=23
        }

        public enum eSOAPParams
        {
            DeviceId = 0,
            SoftwareVersion = 1,
            Shot = 2,
            Range = 3,
            RefillSize = 4,
            CleanModeSinceBatteryChange = 5,
            TotalDispenseSinceConstruction = 6,
            DispenseDuringLastBattery = 7,
            DispenseSinceLastBatteryChange = 8,
            NumberOfBatteryChanges = 9,
            VoltageAtLastBatteryChange = 10,
            CurrentBatteryVoltage = 11,
            LowSoapAlert = 12,
            LowBatteryAlert = 13,
            MotorOverCurrentAlert = 14,
            TotalRefillsSinceConstruction = 15,
            RefillsduringLastBattery = 16,
            RefillsSinceBatteryChange = 17,
            NoOfDispensesSinceLastRefill = 18,
            //VeryLowSoapAlert = 19
            UpdateInterval=19,
            Reset=20
        }

        public enum Alerts
        {
            LowBatteryAlert = 1,
            PaperTransferAlert = 2,
            LowPaperAlert = 3,
            LowSoapAlert = 4,
            MotorOvercurrentAlert = 5,
            VeryLowSoapAlert = 6,
            PaperJamAlert = 7,
            TrashFullAlert = 8
        }

        public enum AuditActivity
        {
            CreateUser = 1,
            EditUser = 2,
            DeleteUser = 3,
            ViewUser = 4,

            DashboardView = 5,
            BuildingView = 6,
            PropertyView = 7,
            WashroomView = 8,
            FloorView = 9,

            CreateCustomer = 10,
            EditCustomer = 11,
            DeleteCustomer = 12,
            ViewCustomer = 13,

            CreateProperty = 14,
            EditProperty = 15,
            DeleteProperty = 16,
            ViewProperty = 17,

            CreateBuilding = 18,
            EditBuilding = 19,
            DeleteBuilding = 20,
            ViewBuilding = 21,

            CreateFloor = 22,
            EditFloor = 23,
            DeleteFloor = 24,
            ViewFloor = 25,

            CreateWashroom = 26,
            EditWashroom = 27,
            DeleteWashroom = 28,
            ViewWashroom = 29,

            CreateDevice = 30,
            EditDevice = 31,
            DeleteDevice = 32,
            ViewDevice = 33,

            GetallCustomer = 34,
            ShareAlert = 35,

            GetAllActivities = 36,
            GetFilteredActivities = 37,
            ShowMoreActivities = 38,
            CountOutstandingAlerts = 39,
            CountDispenseseHRTDevices = 40
        }

        public enum ApplicationPermission
        {
            ViewProperties_Dashboard = 1,
            ViewBuildings_Dashboard = 2,
            ViewFloors_Dashboard = 3,

            ViewWashrooms_Dashboard = 4,
            ViewActivities_Dashboard = 5,
            ViewCustomers_Admin = 6,

            CreateCustomers_Admin = 7,
            EditCustomers_Admin = 8,
            DeleteCustomers_Admin = 9,

            ViewUsers_Admin = 10,
            CreateUsers_Admin = 11,
            EditUsers_Admin = 12,

            DeleteUsers_Admin = 13,
            ViewProperties_Admin = 14,
            CreateProperties_Admin = 15,

            EditProperties_Admin = 16,
            DeleteProperties_Admin = 17,
            ViewBuildings_Admin = 18,

            CreateBuildings_Admin = 19,
            EditBuildings_Admin = 20,
            DeleteBuildings_Admin = 21,

            ViewFloors_Admin = 22,
            CreateFloors_Admin = 23,
            EditFloors_Admin = 24,

            DeleteFloors_Admin = 25,
            ViewWashrooms_Admin = 26,
            CreateWashrooms_Admin = 27,

            EditWashrooms_Admin = 28,
            DeleteWashrooms_Admin = 29,
            ViewDevices_Admin = 30,

            CreateDevices_Admin = 31,
            EditDevices_Admin = 32,
            DeleteDevices_Admin = 33,

            Analytics = 34,
            GetAllCustomers = 35,
            GetAllBuildings = 36,

            ReturnParameters_Admin = 37,
            GetAllProperties = 38

        }

        public enum RoleLevelType
        {
            PortalAdmin = 1,
            PropertyAdmin = 10,
            BuildingAdmin = 20,
            CustomerAdmin = 5,
            Cleaner = 40
        }

        public enum ActivityLogNames
        {
            CustomerName = 1,
            PropertyName = 2,
            UserName = 3,
            BuildingName = 4,
            FloorLevel = 5,
            WashroomName = 6,
            DeviceName = 7,
            AllCustomers = 8,

            CustomerId = 9,
            PropertyId = 10,
            UserId = 11,
            BuildingId = 12,
            FloorId = 13,
            WashroomId = 14,
            DeviceId = 15
        }
        public enum DeviceEntityType
        {
            Base = 0,
            Specific = 1
        }
    }
}
