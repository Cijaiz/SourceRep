using KC.SmartWashroom.AlertEngine.EngineBase;
using KC.SmartWashroom.Core.Log;
using Microsoft.WindowsAzure.ServiceRuntime;
using System;
using System.Net;

namespace KC.AlertEngine.Worker
{
    public class WorkerRole : RoleEntryPoint
    {
        public override void Run()
        {
            //Create separate tasks for Engine and Scheduler
            //Parallel.Invoke(
            //                    () => { NotificationEngine(); },
            //                    () => { Scheduler(); }
            //                );
            try
            {
                NotificationEngine();
            }
            catch (Exception ex)
            {
                Logger.Error("An error occurred in Alert Engine Run method", ex);
                //throw;
            }
            
        }

        private static void NotificationEngine()
        {
            while (true)
            {
                NotificationManager.RunEngine();
            }
        }

        private void ProcessRefrabricatedMessages()
        {
            //Infinite loop
            while (true)
            {

            }
        }

        public override bool OnStart()
        {
            try
            {
                RoleEnvironment.Changed += new EventHandler<RoleEnvironmentChangedEventArgs>(RoleEnvironment_Changed);

                Logger.Debug(string.Format("Starting Processor WorkerRole.. {0}", RoleEnvironment.CurrentRoleInstance.Id));

                // Set the maximum number of concurrent connections 
                //Connection optimisation for http and webclient call.
                ServicePointManager.UseNagleAlgorithm = true;
                ServicePointManager.Expect100Continue = true;
                //ServicePointManager.CheckCertificateRevocationList = true;
                ServicePointManager.DefaultConnectionLimit = 12;

                //Start the Engine and setup all the Warmup tasks..
                NotificationManager.StorageConnectionString = RoleEnvironment.GetConfigurationSettingValue("Microsoft.WindowsAzure.Plugins.Diagnostics.ConnectionString");
                NotificationManager.StartEngine();

                Logger.Debug("Role Started at " + DateTime.UtcNow.ToString());

                return base.OnStart();
            }
            catch (Exception ex)
            {
                Logger.Error("An error occurred in Alert Engine OnStart Method", ex);
                return true;
                //throw;
            }

            
        }

        private void RoleEnvironment_Changed(object sender, RoleEnvironmentChangedEventArgs e)
        {
            Logger.Debug(string.Format("Re--Starting Processor WorkerRole.. {0} at {1}", RoleEnvironment.CurrentRoleInstance.Id, DateTime.UtcNow.ToShortDateString()));

            //Start the Engine and setup all the Warmup tasks..
            NotificationManager.StorageConnectionString = RoleEnvironment.GetConfigurationSettingValue("Microsoft.WindowsAzure.Plugins.Diagnostics.ConnectionString");
            NotificationManager.StartEngine();
        }

        /// <summary>
        /// Method for Role's OnStop event
        /// </summary>
        public override void OnStop()
        {
            NotificationManager.concurrentQueueListenerTokenSource.Cancel();
            base.OnStop();
        }
    }
}
