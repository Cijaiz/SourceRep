﻿using KC.SmartWashroom.BusinessEntities.Search;
using KC.SmartWashroom.Core.NotificationUtility;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.Core.Log;
using System;
using System.Diagnostics;
using System.Net;
using System.Net.Security;
using System.Threading;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.Business;
using KC.SmartWashroom.BusinessEntities.DeviceUpdate;

namespace KC.SmartWashroom.AlertEngine.EngineBase.EngineWorkers
{
    public class CacheManager : IDisposable
    {
        private string dbConnectionString = string.Empty;
        private Business.CacheManager _cacheBusinessManager = null;

        public CacheManager(string connectionString)
        {
            this.dbConnectionString = connectionString;
            _cacheBusinessManager = new Business.CacheManager(this.dbConnectionString);
        }

        public KC.SmartWashroom.Business.Contracts.IDeviceUpdateValueManager GetDeviceUpdateValueManager()
        {
            return _cacheBusinessManager.GetDeviceUpdateValueManager();
        }

        /// <summary>
        /// Schedules a refresh of cache with details of all the devices at the specified interval
        /// </summary>
        /// <param name="refreshInverval">Interval of refresh in minutes. Defaults to 240 minutes / 4 hours</param>
        public void ScheduleRecurringCacheRefresh(int refreshInverval = 240)
        {
            Stopwatch watchTimer = new Stopwatch();

            try
            {
                while (true)
                {
                    // This is a sample worker implementation. Replace with your logic.
                    Logger.Debug("KC.SmartWashroom.DeviceAPICacheWorker entry point called");

                    Logger.Warning("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<Start Device API Cache Refresh>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
                    watchTimer.Start();

                    Logger.Debug("Loading configuration values");

                    TimeSpan sleepTime = TimeSpan.FromMinutes(GetRefreshInterval());

                    Logger.Debug("Configuration loaded, starting processing");

                    Logger.Debug("Updating device type data-Commented");
                    RefreshDeviceType();
                    Logger.Debug("Updated device type data-Commented");

                    Logger.Debug("Updating device data");
                    RefreshCache();
                    Logger.Debug("Updated device data");

                    Logger.Warning("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<Cache refresh cycle completed>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
                    Logger.Debug(string.Format("Total Time For performing Device API Cache refresh {0} day(s), {1} hour(s), {2} minute(s), and {3} second(s)",
                        watchTimer.Elapsed.Days, watchTimer.Elapsed.Hours, watchTimer.Elapsed.Minutes, watchTimer.Elapsed.Seconds));
                    watchTimer.Stop();
                    watchTimer.Reset();

                    Logger.Warning("Main thread Sleeping for {0} day(s), {1} hour(s), {2} minute(s)", sleepTime.Days, sleepTime.Hours, sleepTime.Minutes);
                    Thread.Sleep(sleepTime);
                }
            }
            catch (Exception ex)
            {
                //Log the exception and don't throw it
                Logger.Error(ex.ToString());
                Thread.Sleep(TimeSpan.FromMinutes(GetRefreshInterval()));
                //throw;
            }

        }

        private int GetRefreshInterval()
        {
            int refreshInverval = 240;

            try
            {
                //Get interval from configuration
                string str = CommonHelper.GetConfigSetting("RunningIntervalMin");
                if (!int.TryParse(str, out refreshInverval))
                {
                    Logger.Error("RunningIntervalMin configuration not in number format, value is {0}. Defaulting to 240", str);
                    refreshInverval = 240;
                }
            }
            catch (Exception ex)
            {
                Logger.Error("Could not retreive RunningIntervalMin from configuration. Defaulting to 240", ex);
                refreshInverval = 240;
            }

            return refreshInverval;
        }

        public DeviceUpdateDetails GetFromCache(string deviceId)
        {
            return _cacheBusinessManager.GetFromCache(deviceId);
        }

        private void RefreshDeviceType()
        {
            try
            {
                DeviceTenantManager manager = new DeviceTenantManager();
                manager.SaveToDeviceTypesCache();
            }
            catch (Exception ex)
            {
                //Log the exception, don't throw it
                Logger.Error("An error occurred while putting Device Types in cache", ex);
            }
            
        }

        /// <summary>
        /// Fetches device details from database and updates it in cache
        /// </summary>
        /// <param name="deviceId">If specified, updates only that device. If not specified, updates all the devices</param>
        public void RefreshCache(string deviceId = null)
        {
            try
            {
                _cacheBusinessManager.RefreshCache(deviceId);
            }
            catch (Exception ex)
            {
                Logger.Error("An error occurred while refreshing device data in cache", ex);
                //throw;
            }
        }

        public void RefreshCacheForAutoReset(int customerId)
        {
            _cacheBusinessManager.RefreshCacheForAutoReset(customerId);
        }

        public DeviceUpdateDetails GetFromDatabase(string deviceId)
        {
            return _cacheBusinessManager.GetFromDatabase(deviceId);
        }

        public void Dispose()
        {
            if (_cacheBusinessManager != null)
            {
                _cacheBusinessManager.Dispose();
                _cacheBusinessManager = null;
            }
        }
    }
}
