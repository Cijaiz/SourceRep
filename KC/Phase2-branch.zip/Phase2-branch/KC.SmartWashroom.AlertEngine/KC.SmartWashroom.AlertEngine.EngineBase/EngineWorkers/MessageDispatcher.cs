﻿using KC.SmartWashroom.AlertEngine.Interfaces.EngineStructure;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.Core.Helper.CloudHelper;
using KC.SmartWashroom.Core.Log;
using Microsoft.WindowsAzure.Storage.Queue;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace KC.SmartWashroom.AlertEngine.EngineBase.EngineWorkers
{
    /// <summary>
    /// Methods for processing messages
    /// </summary>
    public class MessageDispatcher
    {
        private readonly List<INotificationEngine> engines;
        private static string LastErrorMessage;
        Stopwatch watchTimer = new Stopwatch();

        public MessageDispatcher(List<INotificationEngine> engines)
        {
            this.engines = engines;
        }

        /// <summary>
        /// Processes the message based on the Eventcode.
        /// </summary>
        /// <param name="message">processes the downloaded message</param>
        public bool ProcessMessage(CloudQueueMessage message)
        {
            watchTimer.Reset();
            watchTimer.Start();

            LastErrorMessage = string.Empty;
            bool isMessageProcessed = true;
            bool isMessagePrepared = false;

            DeviceDetail deviceDetail = new DeviceDetail();
            DeviceAlertInfo eventDetail = new DeviceAlertInfo();

            try
            {
                Guard.IsNotNull(message, "Queue Downloaded Message");

                #region Cloud Message Extraction
                //Deserialization logic goes here.. to pull the evenid and eventcode from message.
                eventDetail = SerializationHelper.JsonDeserialize<DeviceAlertInfo>(message.AsString);

                deviceDetail.DeviceID = eventDetail.DeviceID;
                deviceDetail.AlertType = eventDetail.AlertType;
                deviceDetail.IsAlert = eventDetail.IsAlert == 1 ? true : false;
                deviceDetail.IsAlertForCleaner = eventDetail.IsAlertForCleaner;

                //Pick up the Message insertion tmie from the QUQUe...
                eventDetail.AlertReceivedOn = message.InsertionTime.HasValue ?
                                              message.InsertionTime.Value.UtcDateTime.ToString(CommonConstants.SHORT_DATE_TIME_FORMAT)
                                                                            :
                                              eventDetail.AlertReceivedOn;
                #endregion

                //Check for resolved alerts i.e Is Alert is false then appened success template code with alert type
                if (!deviceDetail.IsAlert)
                    eventDetail.AlertType = AlertEngineConstants.SUCCESSCODE + "-" + eventDetail.AlertType;

                Logger.Debug(string.Format("Fresh Message Downlo aded with Template Code {0} and Event Id {1} and Message details As below \n {2}",
                                                                            eventDetail.AlertType,
                                                                            eventDetail.DeviceID,
                                                                            !string.IsNullOrEmpty(message.AsString) ? message.AsString : "Message details were Empty"));

                //Process messages using Both Engines.. (EMAIL AND SMS)
                foreach (INotificationEngine engine in engines)
                {
                    #region Push Incoming Alerts into SQL Azure & AlertStatus Storage..
                    //Skip this step for cleaners as we clone the message and manually cheat engine to prepare different email message.
                    //As per requirement for cleaners the customer wanted emails without portal URL embedded. so this step was implemented.
                    // Comments by Vijay as on April 9th 2015
                    if (!eventDetail.IsAlertForCleaner)
                    {
                        //Push the incomming Device Alerts into the Device Alert Table in SQL Azure so that it gets refreshed in the UI...
                        Logger.Debug(string.Format("Pushing Device Alert log..."));

                        string hubResponse = engine.PushDeviceAlertToRepository(deviceDetail, eventDetail);
                        if (!string.IsNullOrEmpty(hubResponse))
                        {
                            ProcessResponse<DeviceAlert> response = SerializationHelper.Deserialize<ProcessResponse<DeviceAlert>>(hubResponse);

                            #region Duplicate Check ...
                            //This is for checking if an alert already exists then skip this request for both the engines..  (Avoid Duplicates..)
                            if (response != null && response.Status.Equals(ResponseStatus.Failed))
                            {
                                isMessagePrepared = true;
                                isMessageProcessed = true;
                                break;
                            }
                            #endregion
                        }

                        //pushing device alerts only if we there is a message from Device  not from shared alerts.
                        engine.PushAlertStatusEntityToRepository(eventDetail);
                    }
                    #endregion

                    #region Prepare and Send Notifications
                    //Prepare the Notifications...
                    isMessagePrepared = engine.PrepareNotifications(eventDetail);

                    //Send Notification only on Successfull Message Preparation.
                    if (isMessagePrepared)
                        isMessageProcessed = engine.SendNotification(ref LastErrorMessage);
                    #endregion

                    //Identify the Engine which errord while pumping Messages...
                    if (!isMessageProcessed)
                        LastErrorMessage += "\nEngine Identifier: " + engine.GetType().Name;

                    #region Engine HeartBeat
                    // Push the logs finally indicating whether the message is sent or failed....
                    engine.PushAuditLogToRepository(eventDetail.DeviceID, isMessagePrepared ? isMessageProcessed : false);
                    #endregion

                    //CleanuAlertEngineConstantsp...
                    engine.CleanUpNotification(deviceDetail, eventDetail);
                }

                watchTimer.Stop();
                Logger.Debug(string.Format("Time taken to process message with DeviceID: {0} is {1} milliseconds",
                                        eventDetail.DeviceID,
                                        watchTimer.ElapsedMilliseconds.ToString()));
            }
            catch (Exception generalException)
            {
                //Catch it silently to avoid Aggregatesum exception from Application pool.
                isMessageProcessed = false;
                LastErrorMessage += generalException.Message;
                Logger.Error(string.Format("Error Processing message Id: {0} with message detail as below \n {1} \n Error Message: {2}",
                                        message.Id,
                                        message.AsString,
                                        generalException));

                TraceLastErrorInBlob(eventDetail, generalException);
            }
            return isMessageProcessed;
        }

        private static void TraceLastErrorInBlob(DeviceAlertInfo eventDetail, Exception generalException)
        {
            try
            {
                Blob blobClient;
                List<ExceptionTrace> faultDevices = null;
                GetLastError(out blobClient, out faultDevices);

                if (faultDevices == null)
                {
                    faultDevices = new List<ExceptionTrace> { new ExceptionTrace 
                    { 
                        DeviceID = eventDetail.DeviceID, 
                        ExceptionMessage = string.Format("\n Exception Message: {0} \n Exception stack: {1}", generalException.Message, generalException.StackTrace),
                        Time = DateTime.UtcNow.ToString()
                    }};
                }
                else
                {
                    var faultDevice = faultDevices.Where(error => error.DeviceID == eventDetail.DeviceID).FirstOrDefault();
                    if (faultDevice != null)
                    {
                        faultDevice.ExceptionMessage = string.Format("\n Exception Message: {0} \n Exception stack: {1}", generalException.Message, generalException.StackTrace);
                        faultDevice.Time = DateTime.UtcNow.ToString();

                        faultDevices.Remove(faultDevice);
                        faultDevices.Add(faultDevice);
                    }
                    else
                    {
                        faultDevice = new ExceptionTrace()
                        {
                            DeviceID = eventDetail.DeviceID,
                            ExceptionMessage = string.Format("\n Exception Message: {0} \n Exception stack: {1}", generalException.Message, generalException.StackTrace),
                            Time = DateTime.UtcNow.ToString()
                        };

                        faultDevices.Add(faultDevice);
                    }
                }

                string faultDevicesjson = SerializationHelper.JsonSerialize<List<ExceptionTrace>>(faultDevices);
                blobClient.UploadJsontoBlob(AlertEngineConstants.LASTDEVICEERRORS_BLOB_CONTAINER, AlertEngineConstants.LASTDEVICEERRORS_BLOB_TEXT_NAME, faultDevicesjson);
            }
            catch (Exception ex)
            {
                Logger.Error(ex.Message);
            } //Silent catch..
        }

        private static void GetLastError(out Blob blobClient, out List<ExceptionTrace> faultDevices)
        {
            faultDevices = null;

            blobClient = Blob.GetInstance(NotificationManager.StorageConnectionString);
            blobClient.CreateBlobContainer(AlertEngineConstants.LASTDEVICEERRORS_BLOB_CONTAINER, true);

            string lastErrorJson = blobClient.DownloadBlobasString(AlertEngineConstants.LASTDEVICEERRORS_BLOB_CONTAINER, AlertEngineConstants.LASTDEVICEERRORS_BLOB_TEXT_NAME);
            if (!string.IsNullOrEmpty(lastErrorJson))
                faultDevices = SerializationHelper.Deserialize<List<ExceptionTrace>>(lastErrorJson);
        }

        /// <summary>
        /// Processes Errors the message based on the Eventcode.
        /// </summary>
        /// <param name="message">processes the downloaded message</param>
        public void ProcessErrorMessage(CloudQueueMessage message)
        {
            try
            {
                //Deserialization logic goes here.. to pull the evenid and eventcode from message.
                var eventDetails = SerializationHelper.Deserialize<DeviceAlertInfo>(message.AsString);
                string deviceId = eventDetails.DeviceID;
                string templateCode = eventDetails.AlertType;

                Blob blobClient;
                List<ExceptionTrace> faultDevices = null;
                GetLastError(out blobClient, out faultDevices);

                if (faultDevices == null)
                    faultDevices = new List<ExceptionTrace>();

                //Filter last exception..
                ExceptionTrace faultDevice = faultDevices.Where(error => error.DeviceID == deviceId).FirstOrDefault();
                if (faultDevice == null)
                    faultDevice = new ExceptionTrace();

                //Send error email to admin.. 
                foreach (INotificationEngine engine in engines)
                {
                    engine.PrepareErrorNotification(deviceId, templateCode, AlertEngineConstants.ERRORCODE,
                        LastErrorMessage + " \n Detailed Errors: " + (!string.IsNullOrEmpty(faultDevice.ExceptionMessage) ? faultDevice.ExceptionMessage : "NA"));
                }
            }
            catch (Exception generalException)
            {

                Logger.Error(string.Format("Error Processing message Id: {0} and Error details {1}: Inner Exception would be {2}", message.Id,
                    generalException.Message,
                    generalException.InnerException != null ? generalException.InnerException.Message : "NA"));
                //Catch it silently to avoid Aggregatesum exception from Application pool. Just log it and remvoe message from queue..
            }

        }
    }
}
