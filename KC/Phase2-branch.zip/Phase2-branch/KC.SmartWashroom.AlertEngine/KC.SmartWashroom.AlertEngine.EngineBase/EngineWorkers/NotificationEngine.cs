﻿using KC.SmartWashroom.AlertEngine.Interfaces.TemplateStructure;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
using KC.SmartWashroom.BusinessEntities.BusinessHubEntities;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.Enumerations;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.Core.Helper.CloudHelper;
using KC.SmartWashroom.Core.Log;
using KC.SmartWashroom.Core.NotificationUtility;
using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Globalization;
using System.Net;
using System.Net.Security;

namespace KC.SmartWashroom.AlertEngine.EngineBase.EngineWorkers
{
    /// <summary>
    /// Methods for Loading templates into Concurrent Dictionary and Sending Emails
    /// </summary>
    public abstract class NotificationEngine
    {
        #region Variables & Constants
        private string communicationContent = string.Empty;
        public const string RESOLVED_SUCCESSFULLY = " resolved successfully";
        public Table tableStore = Table.GetInstance(NotificationManager.StorageConnectionString);
        #endregion

        #region Properties
        public string Subject { get; protected set; }
        public ICollection<string> ToAddresses { get; protected set; }
        public ICollection<string> ToMobileNumbers { get; protected set; }

        public bool IsNotificationPrepared { get; protected set; }
        #endregion

        #region Static Properties
        public static ConcurrentDictionary<string, ITemplate> EmailTemplatesDictionary { get; protected set; }
        public static ConcurrentDictionary<string, ITemplate> SMSTemplatesDictionary { get; protected set; }

        public static string BusinessHubUrl { get; protected set; }
        public static string DBConnectionString { get; protected set; }

        public string CommunicationContent
        {
            get
            {
                return communicationContent;
            }
            set
            {
                if (!string.IsNullOrEmpty(communicationContent))
                    communicationContent = string.Empty;

                communicationContent = value;
            }
        }
        public static DeviceDetail DeviceData { get; protected set; }
        public static EngineAuditLog EngineAuditLog { get; set; }

        public static Dictionary<string, string> ValidHubCredentials { get; set; }
        #endregion

        #region Protected Properties
        protected static string FromAddress { get; set; }
        protected static string FromMobileNumber { get; set; }

        protected static SmsConfig SmsConfiguration { get; set; }
        protected static SmtpConfig SmtpConfiguration { get; set; }

        protected ITemplate executionTemplate = null;
        #endregion

        #region Public Operations
        /// <summary>
        /// Loads all the Templates into the Concurrent Dictionary..
        /// </summary>
        /// <param name="templateLoader">The template loader.</param>
        public ConcurrentDictionary<string, ITemplate> LoadAllTemplates(ITemplateLoader templateLoader)
        {
            if (templateLoader.templatesDictionary == null)
                templateLoader.InitializeTemplateDictionary();

            return templateLoader.LoadAllTemplates();
        }

        public virtual bool PrepareNotifications(DeviceAlertInfo alertInfo)
        {
            IsNotificationPrepared = false;
            string alertType = string.Empty;

            string deviceID = alertInfo.DeviceID;
            string templateCode = alertInfo.AlertType;

            Guard.IsNotBlank(deviceID, "eventId in PrepareNotifications");
            Guard.IsNotBlank(templateCode, "templateCode in PrepareNotifications");

            //Populate the email content from the database using the event id and eventcode.
            Logger.Debug(string.Format("Fetching Notification content from datastore for message with Template Code {0} and Device Id {1}.", templateCode, deviceID));

            //Check for success template code with alert type
            ExtractAlertType(ref alertType, ref templateCode);

            //Fetch Model From BUSINESS HUB API....
            dynamic model = FetchContentDataFromDataStore(alertInfo, string.IsNullOrEmpty(alertType) ? templateCode : alertType);

            //Clear the Execution templates for fresh load..
            if (executionTemplate != null)
                executionTemplate = null;

            if (FetchExecutionTemplate(templateCode))
            {
                if (executionTemplate != null && executionTemplate.Notify)
                {
                    if (model != null)
                    {
                        CommunicationContent = PrepareMessageFromContent(model, executionTemplate);

                        //if template code matches success code then append resolved successfuly
                        if (templateCode.Equals(AlertEngineConstants.SUCCESSCODE))
                            Subject = string.IsNullOrEmpty(Subject) ? "Error Setting up Subject.."
                                                        : Subject.Contains(RESOLVED_SUCCESSFULLY)
                                                        ? Subject : Subject + RESOLVED_SUCCESSFULLY;
                    }
                    else
                    {
                        Logger.Error(string.Format("Unable to Prepare the HTML content.. Model or Executioin template may be empty.. for TemplateCode.. -{0} ", templateCode));
                    }

                    //Message Successfully Prepared..
                    Logger.Debug(string.Format("Message Content Prepared Successfully for Device ID {0} and Template Code {1}: \n Message Content below : {2}", deviceID, templateCode, CommunicationContent));
                    IsNotificationPrepared = true;
                }
                else if (executionTemplate != null && !executionTemplate.Notify) //Print for Non ALert Items..
                    Logger.Debug(string.Format("Non Alert - Processing for alertType {0}", templateCode));

                //Update HeartBeat for Internal Purpose..
                UpdateAuditLog(string.IsNullOrEmpty(alertType) ? templateCode : alertType, deviceID, alertInfo.IsAlert);
            }
            else
            {
                Logger.Error(string.Format("Unable to find the matching TemplateCode {0} in the Central Dictionary.", templateCode));
                throw new InvalidOperationException("Unable to find the matching TemplateCode in the Central Dictionary.");
            }

            //Successfully prepared Notification..
            return IsNotificationPrepared;
        }

        public virtual bool SendNotification(ref string errorMessage)
        {
            throw new InvalidOperationException("This is invalid to Send Notification from Base Please override on the actual Sender {Email} or {Text}");
        }

        public virtual void PushAuditLogToRepository(string deviceID, bool isOutForDelivery)
        {
            if (NotificationEngine.EngineAuditLog != null)
            {
                try
                {
                    DeviceAssociation DeviceAssociation = this.FetchDeviceInfo(deviceID);

                    //string emailAddress = EngineAuditLog.ToEmailAddresses.Each( o => o.ToString()).
                    tableStore.InsertRow<AlertAuditLogEntity>(new AlertAuditLogEntity(
                        string.Format("{0}_{1}", DateTime.UtcNow.ToString(CommonConstants.PARTITION_DATE_FORMAT), (DeviceAssociation != null ? DeviceAssociation.CustomerId.ToString() : "0")),
                        string.Format(AlertEngineConstants.ROW_KEYS_FORMATTER, CommonHelper.GetInverseTimestamp(), deviceID, Guid.NewGuid()))
                    {
                        AlertType = EngineAuditLog.AlertType,
                        EmailContent = EngineAuditLog.EmailContent,
                        IsAlert = EngineAuditLog.IsAlert,

                        isEmailOutForDelivery = EngineAuditLog.isEmailOutForDelivery,
                        isSMSOutForDelivery = EngineAuditLog.isSMSOutForDelivery,
                        SMSContent = EngineAuditLog.SMSContent,

                        ToEmailAddresses = (EngineAuditLog.ToEmailAddresses != null) ? string.Join(",", EngineAuditLog.ToEmailAddresses) : string.Empty,
                        ToPhoneNumbers = (EngineAuditLog.ToPhoneNumbers != null) ? string.Join(",", EngineAuditLog.ToPhoneNumbers) : string.Empty,

                        CreatedOn = DateTime.UtcNow.ToString(CommonConstants.LONG_DATE_TIME_FORMAT)
                    }, AlertEngineConstants.ENGINE_ALERT_AUDIT_LOG_TABLE);
                }
                catch (Exception exp)
                {
                    Logger.Error(exp.ToString());
                }
            }
        }

        public virtual void PushAlertStatusEntityToRepository(DeviceAlertInfo eventDetail)
        {
            Guard.IsNotNull(eventDetail, "Device Alert Info..");

            #region Avoid Injecting Device Alerts while Sharing Content from UI
            //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<Avoid Injecting aLERT lOG while Sharing Content from UI.......>>>>>>>>>>>>>>>>>>>>>>>>>>>
            if (eventDetail != null)
                if (eventDetail.SharedEmailAddresses != null
                    || eventDetail.SharedMobileNumbers != null
                    || eventDetail.AlertType.Equals(AlertEngineConstants.USER_CREATION_TEMPLATECODE)
                    || eventDetail.AlertType.Equals(AlertEngineConstants.USER_FORGOTPASSWORD_TEMPLATECODE)
                    || eventDetail.AlertType.Equals(AlertEngineConstants.API_CACHE_REFRESH)
                    || eventDetail.AlertType.Equals(AlertEngineConstants.API_DATABASE_UPDATE)
                    || eventDetail.AlertType.Equals(AlertEngineConstants.API_CACHE_CUSTOMER_OVERRIDE_REFRESH))
                    return;
            #endregion

            //Check for success template code with alert type
            string alertType = string.Empty;
            string templateCode = eventDetail.AlertType;

            ExtractAlertType(ref alertType, ref templateCode);

            // Insert Alert Status with Partitionkey : Customer ID and Row Key : DeviceID_AlertType..
            string alertStatusrowKey = string.Format(AlertEngineConstants.KEYS_FORMATTER, eventDetail.DeviceID.Trim(), string.IsNullOrEmpty(alertType) ? templateCode : alertType);

            //Perform Hub Call..
            DeviceInformation deviceStatus = RetriveDeviceDetail(eventDetail);

            //Pull the Calculated RefillPercentage for Devices..
            DeviceAlertsResolutionDetail deviceRefillDetail = RetriveDeviceRefillPercentage(deviceStatus, eventDetail.DeviceID);

            //Process Alert Status
            AlertStatusEntity alertStatus = ProcessAlertStatus(eventDetail, string.IsNullOrEmpty(alertType) ? templateCode : alertType,
                                                                    alertStatusrowKey,
                                                                    deviceStatus,
                                                                    deviceRefillDetail.RefillPercentage.ToString());

            //Process Alert Log..
            ProcessAlertLog(eventDetail, string.IsNullOrEmpty(alertType) ? templateCode : alertType,
                                        deviceStatus,
                                        alertStatus, deviceRefillDetail.RefillPercentage);
        }

        public static string BuildGetDeviceRefillPercentageUrl(string controllerName, string ActionName, int customerId, string DeviceId, string deviceType)
        {
            Guard.IsNotBlank(BusinessHubUrl, "Get Notification Users Details Publisher Url");
            return string.Format("{0}{1}/{2}?customerId={3}&deviceId={4}&deviceType={5}", BusinessHubUrl, controllerName, ActionName, customerId, DeviceId, deviceType);
        }

        public static string BuildGetUsersDetailsUrl(string controllerName, string ActionName, string deviceId)
        {
            Guard.IsNotBlank(BusinessHubUrl, "Get Notification Users Details Publisher Url");
            return string.Format("{0}{1}/{2}?deviceId={3}", BusinessHubUrl, controllerName, ActionName, deviceId);
        }

        public static string BuildGetUserContextUrl(string contollerName, string actionName, string userName)
        {
            Guard.IsNotBlank(BusinessHubUrl, "Get Notification Users Details Publisher Url");
            return string.Format("{0}{1}/{2}?userName={3}", BusinessHubUrl, contollerName, actionName, userName);
        }

        public static string BuildErrorAdminsUrl(string controllerName, string ActionName)
        {
            Guard.IsNotBlank(BusinessHubUrl, "Get Error Admins Url");
            // return string.Format("{0}{1}/{2}", "http://localhost:56853/api/",  controllerName, ActionName);
            return string.Format("{0}{1}/{2}", BusinessHubUrl, controllerName, ActionName);
        }

        public static string BuildPushDeviceAlertUrl(string controllerName, string ActionName)
        {
            Guard.IsNotBlank(BusinessHubUrl, "Push Device Alert Publisher Url");
            return string.Format("{0}{1}/{2}", BusinessHubUrl, controllerName, ActionName);
        }

        public static string GetNotificationUsersDetails(string deviceId)
        {
            string response = string.Empty;
            WebClient webClient = new WebClient();

            string fetchUrl = BuildGetUsersDetailsUrl(AlertEngineConstants.GET_USER_DETAILS_CONTROLLER, AlertEngineConstants.GET_USER_DETAILS_ACTION, deviceId);
            response = PerformHubRestCall(response, webClient, fetchUrl);

            #region Debugg
            Logger.Debug(string.Format("Response from Web API:{0}, Details: {1}", fetchUrl, response));
            #endregion

            return response;
        }

        public string GetUserContextFromDB(string userName)
        {
            string response = string.Empty;
            WebClient webClient = new WebClient();

            string fetchUrl = BuildGetUserContextUrl(AlertEngineConstants.AUTHENTICATION_CONTROLLER, AlertEngineConstants.GETUSER_ACCOUNTINFORMATION, userName);
            response = PerformHubRestCall(response, webClient, fetchUrl);

            #region Debugg
            Logger.Debug(string.Format("Response from Web API:{0}, Details: {1}", fetchUrl, response));
            #endregion

            return response;
        }

        public static string GetErrorNotificationUsersDetails()
        {
            string response = String.Empty;
            WebClient webClient = new WebClient();

            string fetchUrl = BuildErrorAdminsUrl(AlertEngineConstants.GET_USER_DETAILS_CONTROLLER, AlertEngineConstants.GET_ERROR_ADMIN_DETAILS_ACTION);

            #region Debugg
            Logger.Debug(string.Format("Fetching For Error Admins from {0}", fetchUrl));
            string username = "kcuser";
            string password = "kcpassword-1";
            Logger.Debug(string.Format("The hub URL {0}", fetchUrl));
            #endregion

            webClient.SetAuthenticationHeaderToken(username, password);
            response = webClient.SafeWebClientProcessing(fetchUrl);
            Logger.Debug(string.Format("Response from Web API:{0}", response));
            return response;
        }

        public virtual void PrepareErrorNotification(string deviceID, string templateCode, string errorEventCode, string LastErrorMessage)
        {
            IsNotificationPrepared = true;
            string errorMessage = string.Empty;

            Guard.IsNotBlank(deviceID, "eventId in PrepareNotifications");
            Guard.IsNotBlank(templateCode, "templateCode in PrepareNotifications");

            //Populate the email content from the database using the event id and eventcode.
            Logger.Debug(string.Format("Fetching Notification content from datastore for message with Alert Type {0} and Device Id {1}.", templateCode, deviceID));

            KeyValuePair<string, string> AlertDevice = GetAlertType(templateCode);
            string AlertName = AlertDevice.Value;

            //Set the Subject for Error Emails..
            if (!string.IsNullOrEmpty(Subject))
                Subject = string.Empty;

            Subject = string.Format("There was an Error Processing Message with Device Id: {0} and Alert Type: {1} at {2}.", deviceID, AlertName, DateTime.UtcNow.ToString());

            dynamic model = FetchErrorContentDataFromDataStore(errorEventCode, LastErrorMessage);

            if (FetchExecutionTemplate(errorEventCode))
            {
                if (executionTemplate.Notify)
                {
                    if (model != null && executionTemplate != null)
                    {
                        CommunicationContent = PrepareMessageFromContent(model, executionTemplate);
                    }
                    else
                    {
                        IsNotificationPrepared = false;
                        Logger.Error(string.Format("Unable to Prepare the HTML content.. Model or Executioin template may be empty.. for TemplateCode.. -{0} ", templateCode));
                    }

                    //Message Successfully Prepared..
                    Logger.Debug(string.Format("Message Content Prepared Successfully for Device ID {0} and Alert Type {1}: \n Message Content below : {2}", deviceID, templateCode, CommunicationContent));

                    if (IsNotificationPrepared)
                        IsNotificationPrepared = this.SendNotification(ref errorMessage);
                }
            }
            else
            {
                Logger.Error(string.Format("Unable to find the matching TemplateCode {0} in the Central Dictionary.", templateCode));
                throw new InvalidOperationException("Unable to find the matching TemplateCode in the Central Dictionary.");
            }

        }

        public virtual string PushDeviceAlertToRepository(DeviceDetail deviceDetail, DeviceAlertInfo eventDetail)
        {
            #region Avoid Injecting Device Alerts while Sharing Content from UI
            //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<Avoid Injecting Device Alerts while Sharing Content from UI, Also for Welcome emails.........>>>>>>>>>>>>>>>>>>>>>>>>>>>
            if (eventDetail != null)
                if (eventDetail.SharedEmailAddresses != null
                    || eventDetail.SharedMobileNumbers != null
                    || eventDetail.AlertType.Equals(AlertEngineConstants.USER_CREATION_TEMPLATECODE)
                    || eventDetail.AlertType.Equals(AlertEngineConstants.USER_FORGOTPASSWORD_TEMPLATECODE)
                    || eventDetail.AlertType.Equals(AlertEngineConstants.API_CACHE_REFRESH)
                    || eventDetail.AlertType.Equals(AlertEngineConstants.API_DATABASE_UPDATE)
                    || eventDetail.AlertType.Equals(AlertEngineConstants.API_CACHE_CUSTOMER_OVERRIDE_REFRESH))
                    return string.Empty;
            #endregion

            //Trust all certificates
            ServicePointManager.ServerCertificateValidationCallback += new RemoteCertificateValidationCallback(ValidateRemoteCertificate);

            string response = String.Empty;
            WebClient webClient = new WebClient();
            var inputData = SerializationHelper.JsonSerialize<DeviceDetail>(deviceDetail);

            //If IsAlert is TRUE then need to PUSH the alert details else REMOVE it.
            string pushUrl = BuildPushDeviceAlertUrl(AlertEngineConstants.GET_USER_DETAILS_CONTROLLER, (deviceDetail.IsAlert ? AlertEngineConstants.PUSH_DEVICE_ALERT_ACTION : AlertEngineConstants.REMOVE_DEVICE_ALERT_ACTION));
            string username = "kcuser";
            string password = "kcpassword-1";

            webClient.SetAuthenticationHeaderToken(username, password);
            webClient.Headers[HttpRequestHeader.ContentType] = "application/json";

            Logger.Debug(string.Format("URL:", pushUrl));
            response = webClient.UploadString(pushUrl, "POST", inputData);
            Logger.Debug(string.Format("Response from Web API:{0}", response));
            return response;
        }

        public virtual void CleanUpNotification(DeviceDetail deviceDetail, DeviceAlertInfo eventDetail)
        {
            //Skip..Implementation on the Children..
        }
        #endregion

        #region Protected Operations
        protected DateTime GetAlertReceivedOnforPropertyTimeZone(DeviceAlertInfo alertInfo)
        {
            DateTime defaultLocalTime = DateTime.UtcNow;
            DateTime alertReceivedOn = DateTime.TryParse((string.IsNullOrEmpty(alertInfo.AlertReceivedOn) ? defaultLocalTime.ToString()
                                                                                                    : alertInfo.AlertReceivedOn), out defaultLocalTime)
                                                                        ? defaultLocalTime : defaultLocalTime;

            var localTime = CommonHelper.GetLocalTime(defaultLocalTime, DeviceData.LocalTimeZone);
            return localTime;
        }

        protected KeyValuePair<string, string> GetAlertType(string alertCode)
        {
            Guard.IsNotNull(alertCode, "Alert Code");

            KeyValuePair<string, string> Keyvalue;

            KeyValuePair<string, KeyValuePair<string, string>> item = CommonHelper.CreateAlertTypes().Find((lItem) => lItem.Key.Equals(alertCode));
            Keyvalue = item.Value;

            return Keyvalue;
        }

        protected virtual bool FetchExecutionTemplate(string templateCode)
        {
            throw new InvalidOperationException("This is an invalid operation to fetch tempaltes from the base engine..");
        }

        protected virtual string PrepareMessageFromContent(dynamic model, ITemplate executionTemplate)
        {
            throw new InvalidOperationException("This should be handled in appropriate Engines.. {Email} or {Text}");
        }

        protected virtual dynamic FetchContentDataFromDataStore(DeviceAlertInfo alertInfo, string templateCode)
        {
            throw new InvalidOperationException("This should be handled from base engine");
        }

        protected virtual dynamic FetchErrorContentDataFromDataStore(string templateCode, string LastErrorMessage)
        {
            throw new InvalidOperationException("This should be handled from base engine");
        }

        /// <summary>
        /// To add the email details to the cloud table storage
        /// </summary>
        /// <param name="templateCode">Template Code</param>
        /// <param name="CommunicationContent">Mail Content which is loaded using the templates</param>
        protected virtual void UpdateAuditLog(string templateCode, string deviceID, int isAlert)
        {
            Guard.IsNotBlank(templateCode, "templateCode");
            Guard.IsNotBlank(deviceID, "deviceID");
            //  Guard.IsNotBlank(CommunicationContent, "CommunicationContent");

            ///initialising audit log entity 
            if (EngineAuditLog == null)
                EngineAuditLog = new EngineAuditLog();
        }
        #endregion

        #region Private Operations
        private static void ExtractAlertType(ref string alertType, ref string templateCode)
        {
            if (templateCode.IndexOf("-") != -1)
            {
                alertType = templateCode.Substring(templateCode.IndexOf("-") + 1);
                templateCode = templateCode.Substring(0, templateCode.IndexOf("-"));
            }
        }

        private AlertStatusEntity ProcessAlertStatus(DeviceAlertInfo eventDetail, string alertType,
                                        string alertStatusrowKey, DeviceInformation deviceDetail,
                                        string deviceRefillPercentage)
        {
            if (deviceDetail != null && deviceDetail.CustomerID.Equals(0))
                throw new Exception("Unable to fetch the Corresponding Customer ID to Push Alert Status..");

            // Create the table query.
            TableQuery<AlertStatusEntity> alertStatusRetriveQuery = new TableQuery<AlertStatusEntity>().Where(
                                                    TableQuery.CombineFilters(
                                                                            TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, deviceDetail.CustomerID.ToString()),
                                                                            TableOperators.And,
                                                                            TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.Equal, alertStatusrowKey)));

            //Load previous alerts for updation purpose..
            var alerts = tableStore.Query<AlertStatusEntity>(AlertEngineConstants.ENGINE_ALERT_STATUS_TABLE, alertStatusRetriveQuery);

            AlertStatusEntity alert = null;
            var alertEntity = new AlertStatusEntity();

            foreach (AlertStatusEntity item in alerts)
            {
                alert = item;
                break;
            }

            #region Logic for Settign Alert Issued On
            if (alert != null)
            {
                if (!string.IsNullOrEmpty(alert.AlertResolvedOn) && alert.IsAlert.Equals(0)
                                                                        && eventDetail.IsAlert.Equals(1)) //This is a new alert of Same Type after resolution..
                {
                    alertEntity.AlertIssuedOn = eventDetail.AlertReceivedOn;
                    alertEntity.RefillPercentage = deviceRefillPercentage;
                }
                else // Update the entity with previous issued time..
                {
                    alertEntity.AlertIssuedOn = alert.AlertIssuedOn;
                    alertEntity.RefillPercentage = alert.RefillPercentage; //Defect fix for not Updating the Latest REFill..
                }
            }
            else //This is a brand new  alert...
            {
                alertEntity.AlertIssuedOn = eventDetail.AlertReceivedOn;
                alertEntity.RefillPercentage = deviceRefillPercentage;
            }
            #endregion

            #region Logic : When Initial alert comes this column will be set to Empty.
            //When resolved alert comes (isalert=0) then this is set with latest time
            //Logic : when again an alert comes after resolution then this column will be reset to empty.. COnsidering as brand new alert. (Update ..)
            if (alert != null)
            {
                if (string.IsNullOrEmpty(alert.AlertResolvedOn) && eventDetail.IsAlert.Equals(1))//This is a new alert of Same Type before resolution..
                {
                    //Skip..
                }
                else if (!string.IsNullOrEmpty(alert.AlertResolvedOn) && eventDetail.IsAlert.Equals(1)) //This is a new alert post resolution for same type.
                    alertEntity.AlertResolvedOn = string.Empty;
                else if (eventDetail.IsAlert.Equals(0)) //REsolved Alert for same type after alert issued..
                    alertEntity.AlertResolvedOn = eventDetail.AlertReceivedOn;
            }
            else if (eventDetail.IsAlert.Equals(0))//REsolved Alert for same type..
                alertEntity.AlertResolvedOn = eventDetail.AlertReceivedOn;
            #endregion

            ExtractAndPushDeviceStatusToAlertStatusEntity(eventDetail, alertType, alertStatusrowKey, alertEntity, deviceDetail);

            return alertEntity;
        }

        private static DeviceInformation RetriveDeviceDetail(DeviceAlertInfo eventDetail)
        {
            //Pull More Information From Hub..
            WebClient client = new WebClient();
            string response = string.Empty;
            string hubUrl = BuildGetUsersDetailsUrl(AlertEngineConstants.DEVICES_CONTROLLER, AlertEngineConstants.GETDEVICEALERTSTATUS, eventDetail.DeviceID);

            //Do the Call to pull data from the hub.
            response = PerformHubRestCall(response, client, hubUrl);
            var deviceStatus = SerializationHelper.JsonDeserialize<DeviceInformation>(response);
            return deviceStatus;
        }

        private static DeviceAlertsResolutionDetail RetriveDeviceRefillPercentage(DeviceInformation deviceInformation, string deviceId)
        {
            //Pull More Information From Hub..
            WebClient client = new WebClient();
            string response = string.Empty;
            string hubUrl = BuildGetDeviceRefillPercentageUrl(AlertEngineConstants.GET_WASHROOM_CONTROLLER,
                                                                AlertEngineConstants.GETDEVICELASTDISPENSEDVALUE_ACTION,
                                                                deviceInformation.CustomerID, deviceId, deviceInformation.DeviceType);

            //Do the Call to pull data from the hub.
            response = PerformHubRestCall(response, client, hubUrl);
            var deviceStatus = SerializationHelper.JsonDeserialize<DeviceAlertsResolutionDetail>(response);
            return deviceStatus;
        }

        private void ProcessAlertLog(DeviceAlertInfo eventDetail, string alertType,
                                    DeviceInformation deviceDetail, AlertStatusEntity alertStatus, int refillPercentage)
        {
            Guard.IsNotNull(deviceDetail, "Device Status from DB STORE PROC>>");
            DateTime defaultTime = DateTime.MinValue;

            DateTime initialAlertTime = DateTime.TryParseExact(DateTime.Now.ToString(),
                                            AlertEngineConstants.UNIVERSAL_FORMATS, new CultureInfo("en-US"),
                                            DateTimeStyles.AdjustToUniversal, out defaultTime) ? defaultTime : defaultTime;

            string partitionKey = string.Format(AlertEngineConstants.KEYS_FORMATTER_WITHPROPERTY, initialAlertTime.InverseDays().ToString(), //initialAlertTime.ToString(CommonConstants.PARTITION_DATE_FORMAT),
                                                                                    deviceDetail.CustomerID.ToString(), deviceDetail.PropertyID.ToString());
            string rowKey = string.Format(AlertEngineConstants.ROW_KEYS_FORMATTER, CommonHelper.GetInverseTimestamp(), eventDetail.DeviceID, Guid.NewGuid().ToString());

            var alertLogEntity = new AlertStatusEntity();
            alertLogEntity.PartitionKey = partitionKey; //MMDDYYYY_Customer ID
            alertLogEntity.RowKey = rowKey; // DeviceID _ GUID

            alertLogEntity.AlertType = alertType;
            alertLogEntity.IsAlert = eventDetail.IsAlert;
            alertLogEntity.AlertIssuedOn = alertStatus.AlertIssuedOn;

            alertLogEntity.AlertResolvedOn = alertStatus.AlertResolvedOn;
            alertLogEntity.BuildingId = deviceDetail.BuildingId;
            alertLogEntity.CustomerID = deviceDetail.CustomerID;

            alertLogEntity.RefillPercentage = alertStatus.RefillPercentage;
            alertLogEntity.DeviceId = deviceDetail.DeviceId;

            //Populate the DeviceTypeID for the device TYpe ..
            GetDeviceTypeId(alertLogEntity, deviceDetail);

            alertLogEntity.FloorId = deviceDetail.FloorId;
            alertLogEntity.FloorLevel = deviceDetail.FloorLevel;
            alertLogEntity.PropertyID = deviceDetail.PropertyID;

            alertLogEntity.WashroomId = deviceDetail.WashroomId;

            //FInal push into Table..
            tableStore.InsertRow<AlertStatusEntity>(alertLogEntity, AlertEngineConstants.ENGINE_ALERT_LOG_TABLE);
        }

        private void ExtractAndPushDeviceStatusToAlertStatusEntity(DeviceAlertInfo eventDetail, string alertType, string alertStatusrowKey,
                                                                    AlertStatusEntity alertEntity, DeviceInformation deviceDetail)
        {
            Guard.IsNotNull(deviceDetail, "Device Status from DB STORE PROC>>");

            alertEntity.PartitionKey = deviceDetail.CustomerID.ToString(); //Customer ID
            alertEntity.RowKey = alertStatusrowKey;

            alertEntity.AlertType = alertType;
            alertEntity.IsAlert = eventDetail.IsAlert;

            alertEntity.BuildingId = deviceDetail.BuildingId;
            alertEntity.CustomerID = deviceDetail.CustomerID;

            alertEntity.DeviceId = deviceDetail.DeviceId;

            //Populate the DeviceTypeID for the device TYpe ..
            GetDeviceTypeId(alertEntity, deviceDetail);

            alertEntity.FloorId = deviceDetail.FloorId;
            alertEntity.FloorLevel = deviceDetail.FloorLevel;
            alertEntity.PropertyID = deviceDetail.PropertyID;

            alertEntity.WashroomId = deviceDetail.WashroomId;

            //FInal push into Table..
            tableStore.InsertRow<AlertStatusEntity>(alertEntity, AlertEngineConstants.ENGINE_ALERT_STATUS_TABLE);
        }

        private static void GetDeviceTypeId(AlertEntity alertEntity, DeviceInformation deviceDetail)
        {
            Enums.DeviceType deviceTypeEnumeration;
            if (Enum.TryParse(deviceDetail.DeviceType, true, out deviceTypeEnumeration))
                if (Enum.IsDefined(typeof(Enums.DeviceType), deviceTypeEnumeration))
                    alertEntity.DeviceType = deviceTypeEnumeration.ToString("d");
        }

        private static string PerformHubRestCall(string response, WebClient webClient, string fetchUrl)
        {
            if (ValidHubCredentials.Count.Equals(0) || !ValidHubCredentials.ContainsKey(CommonConstants.HUB_USERNAME)
                                                    || !ValidHubCredentials.ContainsKey(CommonConstants.HUB_USERPASSWORD))
                throw new ArgumentException("Hub Credentials invalid / Unable to load Hub Credentials for Successfull REST CALL");

            webClient.SetAuthenticationHeaderToken(ValidHubCredentials[CommonConstants.HUB_USERNAME], ValidHubCredentials[CommonConstants.HUB_USERPASSWORD]);
            return webClient.SafeWebClientProcessing(fetchUrl);
        }

        private bool ValidateRemoteCertificate(object sender, System.Security.Cryptography.X509Certificates.X509Certificate certificate, System.Security.Cryptography.X509Certificates.X509Chain chain, SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }

        private DeviceAssociation FetchDeviceInfo(string deviceId)
        {
            string response = string.Empty;
            WebClient webClient = new WebClient();

            string fetchUrl = BuildGetUsersDetailsUrl("Devices", "GetDeviceAssociation", deviceId);
            response = PerformHubRestCall(response, webClient, fetchUrl);

            return SerializationHelper.JsonDeserialize<DeviceAssociation>(response);
        }
        #endregion
    }
}
