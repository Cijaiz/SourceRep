﻿using KC.SmartWashroom.AlertEngine.EngineBase.Engines;
using KC.SmartWashroom.AlertEngine.Interfaces.EngineStructure;
using Microsoft.WindowsAzure.Storage.Queue;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace KC.SmartWashroom.AlertEngine.EngineBase.EngineWorkers
{
    public class InternalQueueListener
    {
        public static ConcurrentQueue<CloudQueueMessage> concurrentQueue = new ConcurrentQueue<CloudQueueMessage>();

        public InternalQueueListener()
        {
            // TODO: Complete member initialization
        }

        /// <summary>
        /// Method to listen for items in the Concurrent Queue.
        /// </summary>
        public void ListenInternalQueueMessages(CancellationToken ct, Core.EngineConnectorWire engineWire)
        {
            CloudQueueMessage clonedMessageWithCleanerUsers;
            List<INotificationEngine> engines = new List<INotificationEngine>();

            //Add Email Engine alone to process Cleaner Messages..
            INotificationEngine emailEngine = new EmailNotificationEngine();

            //Start the Engine to start the Communication workers and other initialization process..
            emailEngine.StartEngine(engineWire);
            engines.Add(emailEngine);

            MessageDispatcher dispatcher = new MessageDispatcher(engines);

            while (true)
            {
                if (ct.IsCancellationRequested)
                    break;

                if (InternalQueueListener.concurrentQueue.Count.Equals(0))
                {
                    //Sleep for 3 seconds..
                    Thread.Sleep(3000);
                    continue;
                }

                // Returns the object from the queue without removing it.            
                if (InternalQueueListener.concurrentQueue.TryDequeue(out clonedMessageWithCleanerUsers))
                {
                    if (!dispatcher.ProcessMessage(clonedMessageWithCleanerUsers))
                    {
                        dispatcher.ProcessErrorMessage(clonedMessageWithCleanerUsers);
                    }
                }
            }
        }
    }
}
