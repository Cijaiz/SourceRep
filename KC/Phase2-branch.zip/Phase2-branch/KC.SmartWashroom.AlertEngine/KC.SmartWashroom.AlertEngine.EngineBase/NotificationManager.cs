﻿using KC.SmartWashroom.AlertEngine.EngineBase.Engines;
using KC.SmartWashroom.AlertEngine.EngineBase.EngineWorkers;
using KC.SmartWashroom.AlertEngine.Interfaces.EngineStructure;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.Core.Log;
using KC.SmartWashroom.Core.NotificationUtility;
using Microsoft.WindowsAzure;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.Entity.Core.EntityClient;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;

namespace KC.SmartWashroom.AlertEngine.EngineBase
{
    public class NotificationManager
    {
        public static byte TasksThresholdLimit = 1; //Default is only one task being allocated.
        private static byte MessagesForTaskAllocation = 10; //Default is only 10 messages being processed.

        private static string HighPriorityQueueName = AlertEngineConstants.HIGH_PRIORITY_QUEUE_NAME;
        private static string LowPriorityQueueName = AlertEngineConstants.LOW_PRIORITY_QUEUE_NAME;

        public static string StorageConnectionString { get; set; }
        public static List<INotificationEngine> Engines { get; set; }

        //public static List<KeyValuePair<string, KeyValuePair<string, string>>> DeviceAlertTypeKeys = CommonHelper.CreateAlertTypes();
        public static Hashtable DeviceKeyValues = new Hashtable();

        public static CancellationTokenSource concurrentQueueListenerTokenSource = new CancellationTokenSource();

        /// <summary>
        /// Constructor for the Notification Manger.
        /// </summary>
        public NotificationManager() { }

        /// <summary>
        /// Incase we would want to access the instance methods this method is used.
        /// </summary>
        /// <returns>new Instance of Notification Manager</returns>
        public static NotificationManager ManagerInstance()
        {
            return new NotificationManager();
        }

        public static void StartEngine()
        {
            Guard.IsNotBlank(StorageConnectionString, "Storage Connection String.");

            AzureHelper.AzureConnectionString = StorageConnectionString;

            //Create Default Queues..
            AzureHelper.CreateQueueIfNotExists(HighPriorityQueueName);
            AzureHelper.CreateQueueIfNotExists(LowPriorityQueueName);

            //Set the Thresholdlimit from Role Configurtion.
            byte defaultTaskThresholdLimit = TasksThresholdLimit;
            byte defaultMessagesForTaskAllocation = MessagesForTaskAllocation;

            TasksThresholdLimit = byte.TryParse(CloudConfigurationManager.GetSetting(AlertEngineConstants.TASKS_THRESHOLD_LIMIT), out defaultTaskThresholdLimit) ? defaultTaskThresholdLimit : TasksThresholdLimit;
            MessagesForTaskAllocation = byte.TryParse(CloudConfigurationManager.GetSetting(AlertEngineConstants.MESSAGES_FOR_TASK_ALLOCATION), out defaultMessagesForTaskAllocation) ? defaultMessagesForTaskAllocation : MessagesForTaskAllocation;

            //Initializations of Engines and Connectors......
            Core.EngineConnectorWire engineWire = InitializeEnginesAndConnectors();

            #region Build Device Name And Alert Type Disctionary..
            //KeyValuePair<string, string> J1 = new KeyValuePair<string, string>("JRT", "Low Battery");
            //KeyValuePair<string, string> J2 = new KeyValuePair<string, string>("JRT", "Paper Transfer");
            //KeyValuePair<string, string> J3 = new KeyValuePair<string, string>("JRT", "Low Paper");

            //KeyValuePair<string, string> S1 = new KeyValuePair<string, string>("eSoap", "Low Soap");
            //KeyValuePair<string, string> S2 = new KeyValuePair<string, string>("eSoap", "Low Battery");
            //KeyValuePair<string, string> S3 = new KeyValuePair<string, string>("eSoap", "Motor Overcurrent");
            //KeyValuePair<string, string> S4 = new KeyValuePair<string, string>("eSoap", "Very Low Soap");

            //KeyValuePair<string, string> H1 = new KeyValuePair<string, string>("eHRT", "Paper Transfer");
            //KeyValuePair<string, string> H2 = new KeyValuePair<string, string>("eHRT", "Low Battery");
            //KeyValuePair<string, string> H3 = new KeyValuePair<string, string>("eHRT", "Paper Jam");
            //KeyValuePair<string, string> H4 = new KeyValuePair<string, string>("eHRT", "Low Paper");
            //KeyValuePair<string, string> H5 = new KeyValuePair<string, string>("eHRT", "Trash Full");

            //DeviceAlertTypeKeys.Add(new KeyValuePair<string, KeyValuePair<string, string>>("J1", J1));
            //DeviceAlertTypeKeys.Add(new KeyValuePair<string, KeyValuePair<string, string>>("J2", J2));
            //DeviceAlertTypeKeys.Add(new KeyValuePair<string, KeyValuePair<string, string>>("J3", J3));

            //DeviceAlertTypeKeys.Add(new KeyValuePair<string, KeyValuePair<string, string>>("S1", S1));
            //DeviceAlertTypeKeys.Add(new KeyValuePair<string, KeyValuePair<string, string>>("S2", S2));
            //DeviceAlertTypeKeys.Add(new KeyValuePair<string, KeyValuePair<string, string>>("S3", S3));
            //DeviceAlertTypeKeys.Add(new KeyValuePair<string, KeyValuePair<string, string>>("S4", S4));

            //DeviceAlertTypeKeys.Add(new KeyValuePair<string, KeyValuePair<string, string>>("H1", H1));
            //DeviceAlertTypeKeys.Add(new KeyValuePair<string, KeyValuePair<string, string>>("H2", H2));
            //DeviceAlertTypeKeys.Add(new KeyValuePair<string, KeyValuePair<string, string>>("H3", H3));
            //DeviceAlertTypeKeys.Add(new KeyValuePair<string, KeyValuePair<string, string>>("H4", H4));
            //DeviceAlertTypeKeys.Add(new KeyValuePair<string, KeyValuePair<string, string>>("H5", H5));

            //DeviceKeyValues.Add("JRT", AlertEngineConstants.JRT_DEVICE_NAME);
            //DeviceKeyValues.Add("eHRT", AlertEngineConstants.EHRT_DEVICE_NAME);
            //DeviceKeyValues.Add("eSoap", AlertEngineConstants.ESOAP_DEVICE_NAME); 
            #endregion

            //Iterative Start of All Engines....
            foreach (INotificationEngine engine in Engines)
                engine.StartEngine(engineWire);

            //Initialize the Cache Scheduler.. Default is every 4 hours it pushes messages into the Internal Queue..
            InitializeCacheScheduler(concurrentQueueListenerTokenSource, engineWire);

            //Initialize the Internal Queue System to manage sending role specific Emails..
            InitializeConcurrentQueueListener(concurrentQueueListenerTokenSource, engineWire);
        }

        private static Core.EngineConnectorWire InitializeEnginesAndConnectors()
        {
            //Engines Initializeations..
            Engines = new List<INotificationEngine>();
            Engines.Add(new EmailNotificationEngine());
            Engines.Add(new SMSNotificationEngine());

            //Connectors Initializeations..
            Core.EngineConnectorWire engineWire = Core.EngineConnectorWire.EngineConnectorWireInstance();

            engineWire.StorageConnectionString = StorageConnectionString;
            engineWire.BusinessHubUrl = CommonHelper.GetConfigSetting(AlertEngineConstants.BUSINESS_HUB_URL);
            string connString = CommonHelper.GetConfigSetting(AlertChartConstants.DATABASE_CONNECTION);

            //Handling both Entity framework connect into the Engine so that the underlying connection does not break..
            if (connString.StartsWith("metadata=", StringComparison.OrdinalIgnoreCase)
                || connString.IndexOf(".msl", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                connString = new EntityConnectionStringBuilder(connString).ProviderConnectionString;
            }

            engineWire.DataBaseConnectionString = connString;
            engineWire.TemplatesConfigurationFilePath = CloudConfigurationManager.GetSetting(AlertEngineConstants.TEMPLATES_CONFIGURATION_FILEPATH);

            engineWire.SmtpConfiguration = SerializationHelper.JsonDeserialize<SmtpConfig>(CommonHelper.GetConfigSetting(AlertEngineConstants.SMTP_SERVER_CONFIGURATION));
            engineWire.FromEmailAddres = engineWire.SmtpConfiguration.FromEmailAddress;
            engineWire.SmsConfiguration = SerializationHelper.JsonDeserialize<SmsConfig>(CommonHelper.GetConfigSetting(AlertEngineConstants.SMS_CONFIGURATION));
            engineWire.FromMobileNumber = engineWire.SmsConfiguration.FromMobileNumber;

            string hubAuthentication = CloudConfigurationManager.GetSetting(KC.SmartWashroom.Core.Constants.CommonConstants.AUTHENTICATIONCREDENTIALS);
            Core.EngineConnectorWire.ValidHubCredentials = !string.IsNullOrEmpty(hubAuthentication) ?
                                                            SerializationHelper.JsonDeserialize<Dictionary<string, string>>(hubAuthentication) : null;
            return engineWire;
        }

        /// <summary>
        /// Runs the Notification Engine to Start processing the messages from the queues.
        /// This is the decision maker for messages to be downloaded or processed. Here the Priority 1 queue messages are processed first 
        /// then the low priority messages are processed.
        /// </summary>
        public static void RunEngine()
        {
            Logger.Warning("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<Start the Engine Processing>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            var h = TimeZoneInfo.ConvertTimeFromUtc(System.DateTime.UtcNow, TimeZoneInfo.Local);

            Stopwatch watchTimer = new Stopwatch();
            watchTimer.Start();

            //Check the message count from the low priority queue and allocate the tasks based on the queue count..
            int currentLowPriorityMessageCount = AzureHelper.GetQueueMessagesCount(LowPriorityQueueName);
            int currenthighPriorityMessageCount = AzureHelper.GetQueueMessagesCount(HighPriorityQueueName);

            Logger.Warning(string.Format("\n Total messages available in the High priority queue : {0} \n Total messages available in the low priority queue : {1}",
                                currenthighPriorityMessageCount.ToString(), currentLowPriorityMessageCount.ToString()));

            //Process messages from high Priority Queue first then go to Low priority ones.
            NotificationManager.ManagerInstance().DynamicTaskCreation(currentLowPriorityMessageCount, currenthighPriorityMessageCount);

            Logger.Debug(string.Format("Total Time For processing highPriority messages is {0} \n and lowpriority messages in {1} is : {2} seconds",
                                                                                                                         currenthighPriorityMessageCount.ToString(),
                                                                                                                        currentLowPriorityMessageCount.ToString(),
                                                                                                                        watchTimer.Elapsed.Seconds.ToString()));
            watchTimer.Stop();
            watchTimer.Reset();

            Logger.Warning("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<Ends the Engine Processing>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Logger.Warning("Main thread sleeping for 5000 milliseconds..{5 Secs}");
            Thread.Sleep(KC.SmartWashroom.Core.Constants.AlertEngineConstants.MAINTHREAD_SLEEPTIME);
        }

        /// <summary>
        /// Here new tasks are created for allocation of the processing based on threshold.
        /// </summary>
        /// <param name="currentLowPriorityMessageCount">Total number of Low priority messages count</param>
        /// <param name="currenthighPriorityMessageCount">Total number of High priority messages count</param>
        private void DynamicTaskCreation(int currentLowPriorityMessageCount, int currenthighPriorityMessageCount)
        {
            //Tasks are created based on the message count taken dynamically considering one task being created for a set of 10 messages approx. not more 
            // than 4 total tasks currently.
            int numberOfTasksToCreate = 1;
            if (currentLowPriorityMessageCount >= MessagesForTaskAllocation)
                numberOfTasksToCreate = currentLowPriorityMessageCount / MessagesForTaskAllocation;

            int thresholdTasksCount = numberOfTasksToCreate <= TasksThresholdLimit ? numberOfTasksToCreate : TasksThresholdLimit;

            Logger.Debug("Tasks Threshold Limit is : " + TasksThresholdLimit.ToString());
            Logger.Debug(string.Format("{0} Tasks Created to process {1} low priority Messages & {2} high priority messages",
                                                                                            thresholdTasksCount.ToString(),
                                                                                            currentLowPriorityMessageCount.ToString(),
                                                                                            currenthighPriorityMessageCount.ToString()));

            //Create the tasks for faster processing..
            Task[] tasksArray = null;
            tasksArray = new Task[thresholdTasksCount];

            for (int i = 0; i < tasksArray.Length; i++)
            {
                tasksArray[i] = Task.Factory.StartNew((obj) =>
                {
                    MessageDispatcher dispatcher = new MessageDispatcher(Engines);

                    //Start Listening the queue..
                    QueueListener listener = (QueueListener)obj;
                    listener.StartListeningLowPriorityQueue(dispatcher.ProcessMessage, dispatcher.ProcessErrorMessage);
                }
                , new QueueListener(HighPriorityQueueName, 1, LowPriorityQueueName, 1)
                , TaskCreationOptions.AttachedToParent & (TaskCreationOptions.PreferFairness | TaskCreationOptions.LongRunning));
            }

            //Wait For all tasks to complete before proceeding to next....
            Task.WaitAll(tasksArray);
        }

        public static void InitializeCacheScheduler(CancellationTokenSource tokenSource, Core.EngineConnectorWire engineWire)
        {
            CancellationToken token = tokenSource.Token;

            //Create the tasks for faster processing..
            Task[] tasksArray = null;
            tasksArray = new Task[AlertEngineConstants.CACHE_TASK_COUNT];

            for (byte taskCount = 0; taskCount < tasksArray.Length; taskCount++)
            {
                tasksArray[taskCount] = Task.Factory.StartNew((obj) =>
                {
                    CancellationToken ct = token;
                    CacheManager scheduler = (CacheManager)obj;

                    // Were we already canceled?
                    ct.ThrowIfCancellationRequested();

                    //Start the Cache scheduler..
                    scheduler.ScheduleRecurringCacheRefresh();
                }
                , new CacheManager(engineWire.DataBaseConnectionString)
                , token
                , TaskCreationOptions.PreferFairness | TaskCreationOptions.LongRunning
                , TaskScheduler.Current);
            }

            //No Wait Required let the Main thread continue work..
        }

        /// <summary>
        ///Methods for ConcurrentQueueListener
        /// </summary>
        public static void InitializeConcurrentQueueListener(CancellationTokenSource tokenSource, Core.EngineConnectorWire engineWire)
        {
            CancellationToken token = tokenSource.Token;

            //Create the tasks for faster processing..
            Task[] tasksArray = null;
            tasksArray = new Task[AlertEngineConstants.INTERNALQUEUE_TASK_COUNT];

            for (byte taskCount = 0; taskCount < tasksArray.Length; taskCount++)
            {
                tasksArray[taskCount] = Task.Factory.StartNew((obj) =>
                {
                    CancellationToken ct = token;

                    InternalQueueListener listener = (InternalQueueListener)obj;

                    // Were we already canceled?
                    ct.ThrowIfCancellationRequested();

                    //Start the Queue Listener 
                    listener.ListenInternalQueueMessages(ct, engineWire);
                }
                , new InternalQueueListener()
                , token
                , TaskCreationOptions.PreferFairness | TaskCreationOptions.LongRunning
                , TaskScheduler.Current);
            }

            //No Wait Required let the Main thread continue work..
        }
    }
}
