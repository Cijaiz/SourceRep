﻿using KC.SmartWashroom.Core.Helper;
using System;
using System.Linq;

namespace KC.SmartWashroom.AlertEngine.EngineBase.Engines
{
    using KC.SmartWashroom.AlertEngine.EngineBase.CommunicationWorkers;
    using KC.SmartWashroom.AlertEngine.EngineBase.EngineWorkers;
    using KC.SmartWashroom.AlertEngine.EngineBase.TemplateLoaders;
    using KC.SmartWashroom.AlertEngine.Interfaces.CommunicationStructure;
    using KC.SmartWashroom.AlertEngine.Interfaces.EngineStructure;
    using KC.SmartWashroom.AlertEngine.Interfaces.TemplateStructure;
    using KC.SmartWashroom.BusinessEntities;
    using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
    using KC.SmartWashroom.BusinessEntities.DeviceUpdate;
    using KC.SmartWashroom.Core.Constants;
    using KC.SmartWashroom.Core.Enumerations;
    using KC.SmartWashroom.Core.Log;
    using KC.SmartWashroom.AlertEngine.EngineBase.Extensions;
    using Microsoft.WindowsAzure.Storage.Queue;
    using System.Collections.Generic;

    /// <summary>
    /// Emailnotification Engine.
    /// </summary>
    public class EmailNotificationEngine : NotificationEngine, INotificationEngine
    {
        private ISender<EmailMessage> sender = null;

        public void StartEngine(Core.EngineConnectorWire engineConnector)
        {
            //Initialize the Communication Worker..
            sender = new EmailWorker();

            //Dont call the Loader Component.if the Templates Dictionary is loaded already.
            if (EmailTemplatesDictionary != null)
                return;

            ITemplateLoader templateLoader = new EmailTemplateLoader();
            templateLoader.ConfigurationFilePath = engineConnector.TemplatesConfigurationFilePath;
            FromAddress = engineConnector.FromEmailAddres;

            BusinessHubUrl = engineConnector.BusinessHubUrl;
            DBConnectionString = engineConnector.DataBaseConnectionString;

            SmsConfiguration = engineConnector.SmsConfiguration;
            SmtpConfiguration = engineConnector.SmtpConfiguration;

            //Set the Hub Credentials..
            ValidHubCredentials = Core.EngineConnectorWire.ValidHubCredentials;

            //Build Templates Dictionary..
            EmailTemplatesDictionary = base.LoadAllTemplates(templateLoader);

            base.tableStore.Create(AlertEngineConstants.ENGINE_ALERT_AUDIT_LOG_TABLE);
            base.tableStore.Create(AlertEngineConstants.ENGINE_ALERT_LOG_TABLE);
            base.tableStore.Create(AlertEngineConstants.ENGINE_ALERT_STATUS_TABLE);
        }

        #region Protected Members

        protected override string PrepareMessageFromContent(dynamic model, ITemplate executionTemplate)
        {
            return executionTemplate.ParseTemplate(model);
        }

        protected override bool FetchExecutionTemplate(string templateCode)
        {
            Guard.IsNotNull(EmailTemplatesDictionary, "Email Templates Dictionary is dry..");

            //Clear off the previous cached or template created by other thread to get fresh message..
            if (executionTemplate != null)
                executionTemplate = null;

            return EmailTemplatesDictionary.TryGetValue(templateCode, out executionTemplate);
        }

        protected override dynamic FetchContentDataFromDataStore(DeviceAlertInfo alertInfo, string templateCode)
        {
            Guard.IsNotNull(alertInfo, "AlertInfo");
            Guard.IsNotBlank(alertInfo.DeviceID, "deviceID");
            Guard.IsNotBlank(templateCode, "templateCode");

            //Clear Static Device Data...
            if (DeviceData != null || base.ToAddresses != null
                                    || base.ToMobileNumbers != null)
            {
                DeviceData = null;

                base.ToAddresses = null;
                base.ToMobileNumbers = null;
                base.Subject = string.Empty;
            }

            dynamic result = string.Empty;

            //Key - Device Type & Value - AlertDescription {JRT(KEY) - Loww Battery(Value)}
            KeyValuePair<string, string> AlertDevice = base.GetAlertType(templateCode);
            //string DeviceName = ((!string.IsNullOrEmpty(AlertDevice.Key) &&
            //                        NotificationManager.DeviceKeyValues.Contains(AlertDevice.Key)) ? 
            //(string)NotificationManager.DeviceKeyValues[AlertDevice.Key] : string.Empty);

            switch (templateCode)
            {
                #region Alerts and Resolutions Section
                case AlertEngineConstants.JRT_LOW_BATTERY_ALERT_TEMPLATECODE:
                case AlertEngineConstants.JRT_PAPER_TRANSFER_ALERT_TEMPLATECODE:
                case AlertEngineConstants.JRT_LOW_PAPER_ALERT_TEMPLATECODE:
                case AlertEngineConstants.ESOAP_LOW_SOAP_ALERT_TEMPLATECODE:
                case AlertEngineConstants.ESOAP_LOW_BATTERY_ALERT_TEMPLATECODE:
                case AlertEngineConstants.ESOAP_MOTOR_OVERCURRENT_ALERT_TEMPLATECODE:
                case AlertEngineConstants.ESOAP_VERY_LOW_SOAP_ALERT_TEMPLATECODE:
                case AlertEngineConstants.EHRT_PAPER_TRANSFER_ALERT_TEMPLATECODE:
                case AlertEngineConstants.EHRT_LOW_BATTERY_ALERT_TEMPLATECODE:
                case AlertEngineConstants.EHRT_PAPER_JAM_ALERT_TEMPLATECODE:
                case AlertEngineConstants.EHRT_LOW_PAPER_ALERT_TEMPLATECODE:
                case AlertEngineConstants.EHRT_TRASH_FULL_ALERT_TEMPLATECODE:
                case AlertEngineConstants.SRB_LOW_BATTERY_ALERT_TEMPLATECODE:
                case AlertEngineConstants.SRB_PAPER_TRANSFER_ALERT_TEMPLATECODE:
                case AlertEngineConstants.SRB_LOW_PAPER_ALERT_TEMPLATECODE:
                    if (DeviceData == null)
                    {
                        //Do Api Call only first time.. And REtrive user details for whom EMails and SMS needs to be sent out at one shot...
                        DeviceData = new DeviceDetail();
                        string serializedDeviceLog = GetNotificationUsersDetails(alertInfo.DeviceID);

                        Logger.Debug(string.Format("Device Log Fetch Successfull.. Device Log Details below: {0}", serializedDeviceLog));

                        DeviceData = SerializationHelper.JsonDeserialize<DeviceDetail>(serializedDeviceLog);
                        DeviceData.AlertType = AlertDevice.Value;

                        //Push Share Comments to the Comments section in the Email/SMS..
                        DeviceData.Comments = alertInfo.MessageContent;

                        //var localTime = KC.SmartWashroom.Core.Helper.CommonHelper.GetLocalTime(
                        //    Convert.ToDateTime(string.IsNullOrEmpty(alertInfo.AlertReceivedOn) ? DateTime.UtcNow.ToString() : alertInfo.AlertReceivedOn,
                        //                        System.Globalization.CultureInfo.InvariantCulture)
                        //                        , DeviceData.LocalTimeZone);

                        var localTime = base.GetAlertReceivedOnforPropertyTimeZone(alertInfo);

                        DeviceData.IsAlertForCleaner = alertInfo.IsAlertForCleaner;
                        DeviceData.ReceivedOn = localTime.ToString();

                        if (DeviceData != null)
                        {
                            //Trim out Cleaners to Internal Queue for Seperate Processing and Email processing..
                            List<string> cleaners = FilterAndProcessCleanerUsers(DeviceData);

                            if (alertInfo.IsAlertForCleaner)
                            {
                                //Set email list for Cleaners..
                                base.ToAddresses = alertInfo.SharedEmailAddresses ?? cleaners;
                            }
                            else
                            {
                                //Override To Email Addresses if Queue message contains those...
                                if (alertInfo.SharedEmailAddresses != null)
                                    base.ToAddresses = alertInfo.SharedEmailAddresses;
                                else
                                    base.ToAddresses = alertInfo.SharedMobileNumbers == null ?
                                                        DeviceData.UserDetails.Where(user => user.IsEmailAlert == true)
                                                                              .Select(user => user.Email).ToList() : null;

                                #region Prepare and Push Cleaner Data..
                                //Push into Internal Queueing System only when Cleaners are available..
                                if (cleaners.Count > 0 && (alertInfo.SharedEmailAddresses == null && alertInfo.SharedMobileNumbers == null))
                                {
                                    DeviceAlertInfo cleanerData = new DeviceAlertInfo();
                                    cleanerData.DeviceID = DeviceData.DeviceID;
                                    cleanerData.AlertType = templateCode;
                                    cleanerData.IsAlert = alertInfo.IsAlert;

                                    cleanerData.AlertReceivedOn = alertInfo.AlertReceivedOn;
                                    cleanerData.IsAlertForCleaner = cleaners.Count > 0;

                                    PushClonedCleanerMessageintoInternalQueueSystem(cleanerData);
                                }
                                #endregion
                            }
                        }
                    }

                    //Set the Subject..... For Email Engine..
                    //base.Subject = string.Format("{0} Alert for {1}{2}", AlertDevice.Value, DeviceName, templateCode);
                    base.Subject = "Alert from Dispenser";

                    result = DeviceData;
                    break;
                #endregion

                #region User Creation
                case AlertEngineConstants.USER_CREATION_TEMPLATECODE:

                    //Set the SUbject for Email..
                    base.Subject = string.Format("User Account for {0} was created Successfully",
                        alertInfo.SharedEmailAddresses != null ?
                        alertInfo.SharedEmailAddresses.FirstOrDefault() : "NA");

                    //Override To Email Addresses {In this case we should have sharedemail addresses sent out. }
                    base.ToAddresses = alertInfo.SharedEmailAddresses != null ? alertInfo.SharedEmailAddresses : null;

                    result = new
                    {
                        //Deserialize...
                        UserAccountInformation = !string.IsNullOrEmpty(alertInfo.MessageContent)
                        ? SerializationHelper.JsonDeserialize<UserAccountInformation>(alertInfo.MessageContent)
                        : null,
                        UserName = alertInfo.SharedEmailAddresses.FirstOrDefault()
                    };
                    break;
                #endregion

                #region Forgot Password Section
                case AlertEngineConstants.USER_FORGOTPASSWORD_TEMPLATECODE:

                    //Set the SUbject for Email..
                    base.Subject = string.Format("Your Password for the User Account for {0} was reset Successfully", alertInfo.SharedEmailAddresses != null ? alertInfo.SharedEmailAddresses.FirstOrDefault() : "NA");

                    //Override To Email Addresses {In this case we should have sharedemail addresses sent out. }
                    base.ToAddresses = alertInfo.SharedEmailAddresses != null ? alertInfo.SharedEmailAddresses : null;
                    string serializedContent = base.GetUserContextFromDB(alertInfo.SharedEmailAddresses.FirstOrDefault());

                    result = new
                    {
                        //Deserialize...
                        UserAccountInformation = !string.IsNullOrEmpty(serializedContent)
                        ? SerializationHelper.JsonDeserialize<ProcessResponse<UserAccountInformation>>(serializedContent).Object
                        : null,
                        UserName = alertInfo.SharedEmailAddresses.FirstOrDefault()
                    };
                    break;
                #endregion

                #region API CacheRefresh Section
                case AlertEngineConstants.API_CACHE_REFRESH:
                    using (CacheManager cacheManager = new CacheManager(NotificationEngine.DBConnectionString))
                    {
                        //Cache refresh for single device
                        cacheManager.RefreshCache(alertInfo.DeviceID);
                    }
                    break;
                case AlertEngineConstants.API_CACHE_CUSTOMER_OVERRIDE_REFRESH:
                    using (CacheManager cacheManager = new CacheManager(NotificationEngine.DBConnectionString))
                    {
                        //Cutstomer auto reset through device type
                        int customerId = 0;
                        if (int.TryParse(alertInfo.DeviceID, out customerId))
                            cacheManager.RefreshCacheForAutoReset(customerId);
                        else
                            Logger.Error("Customer id not specified in correct format, value is {0}", alertInfo.MessageContent);
                    }
                    break;
                case AlertEngineConstants.API_DATABASE_UPDATE:
                    using (CacheManager cacheManager = new CacheManager(NotificationEngine.DBConnectionString))
                    {
                        DeviceUpdateDetails device = cacheManager.GetFromDatabase(alertInfo.DeviceID);
                        if (device != null)
                        {
                            //Update auto reset parameters
                            device.UpdateAutoResetParameters(cacheManager.GetDeviceUpdateValueManager());
                            //Refesh cache with updated values
                            cacheManager.RefreshCache(alertInfo.DeviceID);
                            Logger.Debug("Successfully updated auto reset parameters for device {0}", alertInfo.DeviceID);
                        }
                    }
                    break;
                #endregion

                default:
                    break;
            }
            return result;
        }

        protected override dynamic FetchErrorContentDataFromDataStore(string alertType, string LastErrorMessage)
        {
            Guard.IsNotBlank(alertType, "templateCode");
            dynamic result = null;

            if (alertType == "E01")
            {
                //DeviceData = new DeviceDetail();
                //string serializedDeviceLog = GetErrorNotificationUsersDetails();

                //Logger.Debug(string.Format("Device Log Fetch Successfull.. Device Log Details below: {0}", serializedDeviceLog));
                //DeviceData = SerializationHelper.JsonDeserialize<DeviceDetail>(serializedDeviceLog);

                //if (DeviceData != null)
                //    ToAddresses = DeviceData.UserDetails.Where(user => user.IsEmailAlert == true).Select(user => user.Email).ToList();

                //Fetch from Configuration..
                ToAddresses = NotificationEngine.SmtpConfiguration.ErrorAdminsEmails.ToList();

                result = new
                {
                    UserName = "Admin",
                    Subject = base.Subject,
                    LastError = LastErrorMessage
                };
            }
            return result;
        }

        protected override void UpdateAuditLog(string templateCode, string deviceID, int isAlert)
        {
            base.UpdateAuditLog(templateCode, deviceID, isAlert);

            //Now Update the Approariate engine specific details..
            if (EngineAuditLog != null)
            {
                EngineAuditLog.IsAlert = isAlert;
                EngineAuditLog.AlertType = templateCode;

                EngineAuditLog.ToEmailAddresses = ToAddresses;
                EngineAuditLog.EmailContent = CommunicationContent;
            }
        }
        #endregion

        public override void PushAuditLogToRepository(string deviceID, bool isOutForDelivery)
        {
            //Pushing to happen at the End only... And Only Once..... So Delegate this to SMS ENgine.....
            //Just update the Delivery...
            if (NotificationEngine.EngineAuditLog != null)
                NotificationEngine.EngineAuditLog.isEmailOutForDelivery = isOutForDelivery;
        }

        /// <summary>
        /// Sends the notification by using the WCF RESTFul service
        /// </summary>
        public override bool SendNotification(ref string errorMessage)
        {
            bool isSuccess = true;
            try
            {
                var emailMessage = new EmailMessage();
                emailMessage.From = FromAddress;
                emailMessage.To = ToAddresses;
                emailMessage.Subject = Subject;
                emailMessage.MessageBody = CommunicationContent;

                sender.SmtpConfiguration = SmtpConfiguration;
                sender.CommunicationContent = emailMessage;

                //Send email only when we have valid to addresses.. Else treat as sent...
                if (ToAddresses != null && ToAddresses.Count > 0)
                    isSuccess = sender.SendNotification(ref errorMessage);
            }
            catch (System.Net.Mail.SmtpException ex)
            {
                isSuccess = false;
                Logger.Error(ex.Message);
            }
            catch (Exception generalException)
            {
                isSuccess = false;
                Logger.Error(generalException.StackTrace);
            }
            return isSuccess;
        }

        private List<string> FilterAndProcessCleanerUsers(DeviceDetail deviceData)
        {
            //Filter the Users of Cleaner Role
            var filteredCleaners = (from user in deviceData.UserDetails
                                    where user.RoleLevel.Equals((int)Enums.RoleLevelType.Cleaner)
                                    select user.Email).ToList();

            //Remove the Filtered users from the fetched DeviceData..
            deviceData.UserDetails.RemoveAll(user => user.RoleLevel.Equals((int)Enums.RoleLevelType.Cleaner));

            return filteredCleaners;
        }

        private static void PushClonedCleanerMessageintoInternalQueueSystem(DeviceAlertInfo deviceData)
        {
            // Prepare Cloned Mesage for cleaners and push into Internal Queue System for Manually Triggering email engine..
            CloudQueueMessage clonedCleanerMessage = new CloudQueueMessage(SerializationHelper.JsonSerialize(deviceData));

            //Safely Enqueue into the Internal Queue which will be processed by DEDICated Thread started up during Engine Start..
            InternalQueueListener.concurrentQueue.Enqueue(clonedCleanerMessage);
        }
    }
}
