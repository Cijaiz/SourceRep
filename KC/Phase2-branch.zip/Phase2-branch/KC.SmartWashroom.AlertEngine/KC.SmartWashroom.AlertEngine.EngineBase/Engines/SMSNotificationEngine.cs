﻿using KC.SmartWashroom.Core.Helper;

using System.Linq;

namespace KC.SmartWashroom.AlertEngine.EngineBase.Engines
{
    using KC.SmartWashroom.AlertEngine.EngineBase.CommunicationWorkers;
    using KC.SmartWashroom.AlertEngine.EngineBase.EngineWorkers;
    using KC.SmartWashroom.AlertEngine.EngineBase.TemplateLoaders;
    using KC.SmartWashroom.AlertEngine.Interfaces.CommunicationStructure;
    using KC.SmartWashroom.AlertEngine.Interfaces.EngineStructure;
    using KC.SmartWashroom.AlertEngine.Interfaces.TemplateStructure;
    using KC.SmartWashroom.BusinessEntities;
    using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
    using KC.SmartWashroom.Core.Constants;
    using KC.SmartWashroom.Core.Log;
    using System;
    using System.Collections.Generic;

    public class SMSNotificationEngine : NotificationEngine, INotificationEngine
    {
        private ISender<string> sender = null;

        public void StartEngine(Core.EngineConnectorWire engineConnector)
        {
            //At this point the Templates Dictionary would be loaded already. So just continue and update the Text body Content alone...

            //Initialize the Communication Worker..
            sender = new TextMessageWorker();

            ITemplateLoader templateLoader = new SMSTemplateLoader();
            templateLoader.ConfigurationFilePath = engineConnector.TemplatesConfigurationFilePath;
            FromMobileNumber = engineConnector.FromMobileNumber;
            BusinessHubUrl = engineConnector.BusinessHubUrl;

            //Set the Hub Credentials..
            ValidHubCredentials = Core.EngineConnectorWire.ValidHubCredentials;

            //Build Templates Dictionary..
            SMSTemplatesDictionary = base.LoadAllTemplates(templateLoader);
        }

        #region Protected Members

        protected override bool FetchExecutionTemplate(string templateCode)
        {
            Guard.IsNotNull(SMSTemplatesDictionary, "SMS Templates Dictionary is dry..");

            //Clear off the previous cached or template created by other thread to get fresh message..
            if (executionTemplate != null)
                executionTemplate = null;

            return SMSTemplatesDictionary.TryGetValue(templateCode, out executionTemplate);
        }

        protected override dynamic FetchContentDataFromDataStore(DeviceAlertInfo alertInfo, string templateCode)
        {
            Guard.IsNotBlank(alertInfo.DeviceID, "deviceID");
            Guard.IsNotBlank(templateCode, "templateCode");
            dynamic result = null;

            switch (templateCode)
            {
                #region Alerts And REsolutions Section
                case AlertEngineConstants.JRT_LOW_BATTERY_ALERT_TEMPLATECODE:
                case AlertEngineConstants.JRT_PAPER_TRANSFER_ALERT_TEMPLATECODE:
                case AlertEngineConstants.JRT_LOW_PAPER_ALERT_TEMPLATECODE:
                case AlertEngineConstants.ESOAP_LOW_SOAP_ALERT_TEMPLATECODE:
                case AlertEngineConstants.ESOAP_LOW_BATTERY_ALERT_TEMPLATECODE:
                case AlertEngineConstants.ESOAP_MOTOR_OVERCURRENT_ALERT_TEMPLATECODE:
                case AlertEngineConstants.ESOAP_VERY_LOW_SOAP_ALERT_TEMPLATECODE:
                case AlertEngineConstants.EHRT_PAPER_TRANSFER_ALERT_TEMPLATECODE:
                case AlertEngineConstants.EHRT_LOW_BATTERY_ALERT_TEMPLATECODE:
                case AlertEngineConstants.EHRT_PAPER_JAM_ALERT_TEMPLATECODE:
                case AlertEngineConstants.EHRT_LOW_PAPER_ALERT_TEMPLATECODE:
                case AlertEngineConstants.EHRT_TRASH_FULL_ALERT_TEMPLATECODE:
                case AlertEngineConstants.SRB_LOW_BATTERY_ALERT_TEMPLATECODE:
                case AlertEngineConstants.SRB_PAPER_TRANSFER_ALERT_TEMPLATECODE:
                case AlertEngineConstants.SRB_LOW_PAPER_ALERT_TEMPLATECODE:
                    if (DeviceData == null)
                    {
                        //Key - Device Type & Value - AlertDescription {JRT(KEY) - Loww Battery(Value)}
                        KeyValuePair<string, string> AlertDevice = base.GetAlertType(templateCode);
                        //string DeviceName = (string)NotificationManager.DeviceKeyValues[AlertDevice.Key];

                        //Do Api Call only first time..
                        DeviceData = new DeviceDetail();
                        string serializedDeviceLog = GetNotificationUsersDetails(alertInfo.DeviceID);

                        Logger.Debug(string.Format("Device Log Fetch Successfull.. Device Log Details below: {0}", serializedDeviceLog));

                        DeviceData = SerializationHelper.JsonDeserialize<DeviceDetail>(serializedDeviceLog);
                        DeviceData.AlertType = AlertDevice.Value;

                        //Push Share Comments to the Comments section in the Email/SMS..
                        DeviceData.Comments = alertInfo.MessageContent;

                        if (DeviceData != null)
                        {
                            if (alertInfo.SharedEmailAddresses != null)
                            {
                                ToAddresses = alertInfo.SharedEmailAddresses;
                            }
                            else
                            {
                                ToAddresses = alertInfo.SharedMobileNumbers == null ? DeviceData.UserDetails.Where(user => user.IsEmailAlert == true).Select(user => user.Email).ToList() : null;
                            }
                        }

                    }

                    //var localTime = KC.SmartWashroom.Core.Helper.CommonHelper.GetLocalTime(
                    //    Convert.ToDateTime(string.IsNullOrEmpty(alertInfo.AlertReceivedOn) ? DateTime.UtcNow.ToString() : alertInfo.AlertReceivedOn,
                    //                        System.Globalization.CultureInfo.InvariantCulture),
                    //                        DeviceData.LocalTimeZone);
                    
                    var localTime = base.GetAlertReceivedOnforPropertyTimeZone(alertInfo);

                    DeviceData.ReceivedOn = localTime.ToString();
                    result = DeviceData;

                    //Assign Mobile Numbers.... For sending sms..
                    if (alertInfo.SharedMobileNumbers != null)
                    {
                        ToMobileNumbers = alertInfo.SharedMobileNumbers;
                    }
                    else
                    {
                        ToMobileNumbers = alertInfo.SharedEmailAddresses == null ? DeviceData.UserDetails.Where(user => user.IsMobileAlert == true).Select(user => user.MobileNo).ToList() : null;
                    }

                    break;
                #endregion
                #region User Creation Section
                case AlertEngineConstants.USER_CREATION_TEMPLATECODE:

                    //Override To Email Addresses {In this case we should have sharedemail addresses sent out. }
                    base.ToMobileNumbers = alertInfo.SharedMobileNumbers != null ? alertInfo.SharedMobileNumbers : null;

                    result = new
                    {
                        //Deserialize...
                        UserAccountInformation = !string.IsNullOrEmpty(alertInfo.MessageContent)
                        ? SerializationHelper.JsonDeserialize<UserAccountInformation>(alertInfo.MessageContent)
                        : null,
                        UserName = alertInfo.SharedEmailAddresses.FirstOrDefault()
                    };
                    break;
                #endregion
                #region FOrgot Password Section
                case AlertEngineConstants.USER_FORGOTPASSWORD_TEMPLATECODE:
                    string serializedContent = base.GetUserContextFromDB(alertInfo.SharedEmailAddresses.FirstOrDefault());
                    result = new
                    {
                        //Deserialize...
                        UserAccountInformation = !string.IsNullOrEmpty(serializedContent)
                        ? SerializationHelper.JsonDeserialize<ProcessResponse<UserAccountInformation>>(serializedContent).Object
                        : null,
                        UserName = alertInfo.SharedEmailAddresses.FirstOrDefault()
                    };

                    //Override To Email Addresses {In this case we should have sharedemail addresses sent out. }
                    base.ToMobileNumbers = alertInfo.SharedMobileNumbers != null ? alertInfo.SharedMobileNumbers : null;
                    break;
                #endregion
                default:
                    break;
            }
            return result;
        }

        protected override dynamic FetchErrorContentDataFromDataStore(string alertType, string LastErrorMessage)
        {
            Guard.IsNotBlank(alertType, "alertType");
            dynamic result = null;

            if (alertType == AlertEngineConstants.ERRORCODE)
            {
                //if (DeviceData != null)
                //    ToMobileNumbers = DeviceData.UserDetails.Where(user => user.IsMobileAlert == true).Select(user => user.MobileNo).ToList();

                //Fetch from Configuration..
                ToMobileNumbers = NotificationEngine.SmsConfiguration.ErrorAdminMobileNos.ToList();

                result = new
                {
                    UserName = "Admin",
                    Subject = base.Subject,
                    LastError = LastErrorMessage
                };
            }
            return result;
        }

        protected override string PrepareMessageFromContent(dynamic model, ITemplate executionTemplate)
        {
            return executionTemplate.ParseTemplate(model);
        }

        protected override void UpdateAuditLog(string templateCode, string deviceID, int isAlert)
        {
            base.UpdateAuditLog(templateCode, deviceID, isAlert);

            //Now Update the Approariate engine specific details..
            if (NotificationEngine.EngineAuditLog != null)
            {
                EngineAuditLog.ToPhoneNumbers = ToMobileNumbers;
                EngineAuditLog.SMSContent = CommunicationContent;
            }
        }
        #endregion

        public override void PushAuditLogToRepository(string deviceID, bool isOutForDelivery)
        {
            if (NotificationEngine.EngineAuditLog != null)
                NotificationEngine.EngineAuditLog.isSMSOutForDelivery = isOutForDelivery;

            //Perform the Push to Repository..
            base.PushAuditLogToRepository(deviceID, isOutForDelivery);
        }

        public override void PushAlertStatusEntityToRepository(DeviceAlertInfo eventDetail)
        {
            //Skip as it is already processed in Email Engine..
        }

        public override string PushDeviceAlertToRepository(DeviceDetail deviceData, DeviceAlertInfo eventDetail)
        {
            return string.Empty; //Do Processing of Device Alerts into Device Alert Table only during Emaiol Engine Execution to avoidDuplicated Entry......

            //This is done to avoid missing alerts during email engine failures..
            //return base.PushDeviceAlertToRepository(deviceData, eventDetail); //
        }

        public override bool SendNotification(ref string errorMessage)
        {
            bool isSuccess = true;
            try
            {
                sender.SmsConfiguration = SmsConfiguration;
                sender.CommunicationContent = CommunicationContent;
                sender.ToMobileNumbers = ToMobileNumbers;

                //Send email only when we have valid to addresses..
                if (ToMobileNumbers != null && ToMobileNumbers.Count > 0)
                    isSuccess = sender.SendNotification(ref errorMessage);
            }
            catch (System.Net.Mail.SmtpException ex)
            {
                Logger.Error(ex.Message);
                isSuccess = false;
            }
            return isSuccess;
        }

        public override void CleanUpNotification(DeviceDetail deviceDetail, DeviceAlertInfo eventDetail)
        {
            //Clear Static Device Data...
            if (DeviceData != null || base.ToAddresses != null
                                    || base.ToMobileNumbers != null)
            {
                DeviceData = null;

                base.ToAddresses = null;
                base.ToMobileNumbers = null;
                base.Subject = string.Empty;
            }
        }
    }
}
