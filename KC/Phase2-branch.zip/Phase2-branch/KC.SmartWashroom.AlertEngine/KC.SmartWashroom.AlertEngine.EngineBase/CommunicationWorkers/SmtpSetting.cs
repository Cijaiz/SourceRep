﻿using KC.SmartWashroom.Core.Helper;
using System.Net;
using System.Net.Mail;

namespace KC.SmartWashroom.AlertEngine.EngineBase.CommunicationWorkers
{
    public static class SmtpSetting
    {
        public static int Port { get; private set; }
        public static SmtpDeliveryMethod SmtpDeliveryMethod { get; private set; }
        public static bool EnableSsl { get; private set; }

        public static string Host { get; private set; }
        public static bool UseDefaultCredentials { get; private set; }
        public static NetworkCredential Credential { get; private set; }

        /// <summary>
        /// This method is used to update the SMTP setting property from the service configuration.
        /// </summary>
        public static void UpdateSetting(SmtpConfig SmtpConfiguration)
        {
            SmtpSetting.Host = SmtpConfiguration.SmtpHost;
            SmtpSetting.Port = SmtpConfiguration.SmtpPort;
            SmtpSetting.SmtpDeliveryMethod = SmtpDeliveryMethod.Network;

            SmtpSetting.UseDefaultCredentials = false;
            SmtpSetting.Credential = new NetworkCredential()
            {
                UserName = SmtpConfiguration.SmtpUserName,
                Password = SmtpConfiguration.SmtpPassword
            };

            SmtpSetting.EnableSsl = SmtpConfiguration.SmtpEnableSsl;
            //Logger.Debug("SMTP setting's update from cloud configuration. update on:{0}", DateTime.UtcNow);
        }
    }
}
