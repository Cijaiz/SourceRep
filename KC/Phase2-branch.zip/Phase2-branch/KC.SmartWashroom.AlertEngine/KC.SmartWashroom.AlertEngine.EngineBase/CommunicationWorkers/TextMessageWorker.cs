﻿using KC.SmartWashroom.AlertEngine.Interfaces.CommunicationStructure;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.Core.Log;
using System;
using System.Collections.Generic;
using Twilio;

namespace KC.SmartWashroom.AlertEngine.EngineBase.CommunicationWorkers
{
    public class TextMessageWorker : ISender<string>
    {
        public string CommunicationContent { get; set; }
        public ICollection<string> ToMobileNumbers { get; set; }

        public SmtpConfig SmtpConfiguration { get; set; }
        public SmsConfig SmsConfiguration { get; set; }

        public bool SendNotification(ref string errorMessage)
        {
            bool response = false;
            string textContent = CommunicationContent;
            string AccountUserId = SmsConfiguration.AccountUserId;

            string AuthuenticationToken = SmsConfiguration.AuthuenticationToken;
            string FromMobileNumber = SmsConfiguration.FromMobileNumber;
            var twilio = new TwilioRestClient(AccountUserId, AuthuenticationToken);

            if (String.IsNullOrEmpty(CommunicationContent))
            {
                Logger.Error("Communication content for sending message was invalid..");
                throw new ArgumentNullException(errorMessage);
            }

            foreach (string mobileNo in ToMobileNumbers)
            {
                try
                {
                    var message = new Message();
                    if (!String.IsNullOrEmpty(mobileNo))
                    {
                        message = twilio.SendMessage(FromMobileNumber, mobileNo, CommunicationContent, "");
                    }

                    response = true;
                    if (message.RestException != null)
                    {
                        response = false;
                        errorMessage = message.RestException.Message;
                        Logger.Error(message.RestException.Message);
                    }

                }
                catch (Exception smsException)
                {
                    response = false;
                    Logger.Error(smsException.Message);
                    throw smsException;
                }
            }
            return response;
        }
    }
}
