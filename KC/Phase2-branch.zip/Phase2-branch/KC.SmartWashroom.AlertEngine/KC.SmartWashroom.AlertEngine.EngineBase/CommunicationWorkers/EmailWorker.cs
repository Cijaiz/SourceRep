﻿using KC.SmartWashroom.AlertEngine.Interfaces.CommunicationStructure;
using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.Core.Log;
using KC.SmartWashroom.Core.NotificationUtility;
using SendGrid;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;

namespace KC.SmartWashroom.AlertEngine.EngineBase.CommunicationWorkers
{
    public class EmailWorker : ISender<EmailMessage>
    {
        public EmailMessage CommunicationContent { get; set; }
        public ICollection<string> ToEmailAddress { get; set; }
        public ICollection<string> ToMobileNumbers { get; set; }

        public SmtpConfig SmtpConfiguration { get; set; }
        public SmsConfig SmsConfiguration { get; set; }

        public bool SendNotification(ref string errorMessage)
        {
            bool response = false;
            SendGridMessage mailMessage = null;

            if (CommunicationContent == null)
            {
                Logger.Error("Communication content for sending message was invalid..");
                throw new ArgumentNullException(errorMessage);
            }
            mailMessage = ConstructMessage(CommunicationContent);

            try
            {
                var credentials = new NetworkCredential(SmtpConfiguration.SmtpUserName, SmtpConfiguration.SmtpPassword);

                // Create an Web transport for sending email.
                var transportWeb = new Web(credentials);

                // Send the email.
                transportWeb.Deliver(mailMessage);
                Logger.Debug("Email Successfully Sent..");
                response = true;
            }
            catch (Exception mailException)
            {
                response = false;
                Logger.Error(mailException.Message);
                errorMessage = mailException.Message;
                throw mailException;
            }
            return response;
        }

        private SmtpClient GetSmtpClientInstance(SmtpConfig SmtpConfiguration)
        {
            SmtpSetting.UpdateSetting(SmtpConfiguration);
            SmtpClient client = new SmtpClient()
            {
                DeliveryMethod = SmtpSetting.SmtpDeliveryMethod,
                Host = SmtpSetting.Host,
                Port = SmtpSetting.Port,
                UseDefaultCredentials = SmtpSetting.UseDefaultCredentials,
                Credentials = SmtpSetting.Credential,
                EnableSsl = SmtpSetting.EnableSsl
            };

            return client;
        }

        private SendGridMessage ConstructMessage(EmailMessage notificationMessage)
        {
            SendGridMessage message = new SendGridMessage();
            message.From = new MailAddress(notificationMessage.From);
            message.Subject = string.IsNullOrEmpty(notificationMessage.Subject) ? "No Subject Available" : notificationMessage.Subject;
            message.Html = notificationMessage.MessageBody;

            if (notificationMessage.To != null && notificationMessage.To.Count > 0)
                notificationMessage.To.ToList().ForEach(to => message.AddTo(to));

            //if (notificationMessage.Bcc != null && notificationMessage.Bcc.Count > 0)
            //    notificationMessage.Bcc.ToList().ForEach(bcc => message(bcc));

            if (notificationMessage.Headers != null && notificationMessage.Headers.Count > 0)
                notificationMessage.Headers.ToList().ForEach(header => message.Headers[header.Key] = header.Value);

            if (notificationMessage.Attachments != null && notificationMessage.Attachments.Count > 0)
            {
                string attachedFileName = string.Empty;
                string contentType = string.Empty;
                notificationMessage.Attachments.ToList().ForEach(
                    blobUrl =>
                    {
                        System.IO.Stream mailingContents = AzureHelper.DownloadContentsFromBlob(blobUrl);
                        if (mailingContents == null)
                            throw new Exception();
                        else
                        {
                            Attachment attachment = new Attachment(mailingContents,
                                                                    new ContentType(contentType)
                                                                   );
                            attachment.Name = attachedFileName;
                            using (var attachmentFileStream = mailingContents)
                            {
                                message.AddAttachment(attachmentFileStream, attachment.Name);
                            }
                        }
                    }
                );
            }
            return message;
        }
    }
}
