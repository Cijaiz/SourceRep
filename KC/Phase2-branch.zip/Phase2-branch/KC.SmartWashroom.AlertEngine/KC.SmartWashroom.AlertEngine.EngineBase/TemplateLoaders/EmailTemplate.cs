﻿using KC.SmartWashroom.AlertEngine.Interfaces.TemplateStructure;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.Core.Log;
using KC.SmartWashroom.Core.NotificationUtility;
using RazorEngine;
using System;
using System.IO;

namespace KC.SmartWashroom.AlertEngine.EngineBase.TemplateLoaders
{
    /// <summary>
    /// This downloads templates and parses the templates.
    /// </summary>
    public class EmailTemplate : ITemplate
    {
        public string EmailBodyContent { get; set; }
        public string TextBodyContent { get; set; }
        public bool Notify { get; set; }

        /// <summary>
        /// Downloads the cshtml template based on the URL.
        /// </summary>
        /// <param name="templateUri">Template URL</param>
        /// <returns>Returns bool</returns>
        public bool DownloadTemplate(string templateUri)
        {
            bool isDownloaded = false;
            Guard.IsNotBlank("templateUri", "Blob Template URI");
            try
            {
                //Downloads the blob's contents as stream
                Stream templateStream = AzureHelper.DownloadContentsFromBlob(templateUri);
                // convert stream to string
                StreamReader reader = new StreamReader(templateStream);
                this.EmailBodyContent = reader.ReadToEnd();
                isDownloaded = true;
            }
            catch (OutOfMemoryException outOfMemoryException)
            {
                Logger.Error("Out of Memory exception when reading the blob contents as stream");
                throw outOfMemoryException;
            }
            catch (IOException ioException)
            {
                Logger.Error("I/O error occured when reading blob contents");
                throw ioException;
            }
            catch (Exception generalException)
            {
                Logger.Error("Error while reading the contents of blob");
                throw generalException;
            }
            return isDownloaded;
        }

        public string ParseTemplate<T>(T modelData)
        {
            Guard.IsNotBlank("BodyContent", "BodyContent in ParseTemplate");
            Guard.IsNotNull(modelData, "Model Data in ParseTemplate");
            return Razor.Parse(EmailBodyContent, modelData);
        }
    }
}
