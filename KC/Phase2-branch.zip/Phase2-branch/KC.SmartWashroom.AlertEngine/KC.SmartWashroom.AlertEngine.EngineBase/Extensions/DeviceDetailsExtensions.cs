﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.AlertEngine.EngineBase.Extensions
{
    using KC.SmartWashroom.Business;
    using KC.SmartWashroom.Business.Contracts;
    using KC.SmartWashroom.BusinessEntities;
    using KC.SmartWashroom.BusinessEntities.DeviceUpdate;
    using KC.SmartWashroom.Core.Linq;
    using System.Collections.Generic;
    using System.Linq;
    /// <summary>
    /// Extension behaviors for the device data
    /// </summary>
    internal static class DeviceDetailsExtensions
    {
        /// <summary>
        /// Updates the auto reset parameters
        /// </summary>
        /// <param name="device">The device details</param>
        /// <param name="valueManager">The instance of the value manager, optional parameter</param>
        /// <returns>Returns the same collection modified</returns>
        internal static int UpdateAutoResetParameters(this DeviceUpdateDetails device
            , IDeviceUpdateValueManager valueManager = null)
        {
            var recordsAffected = -1;

            if (device != null)
            {
                recordsAffected = (new DeviceUpdateDetails[] { device }).UpdateAutoResetDeviceUpdateParameters(valueManager);
            }

            return recordsAffected;
        }



        /// <summary>
        /// Updates the auto reset parameters
        /// </summary>
        /// <param name="devices">The enumerable of device details</param>
        /// <param name="valueManager">The instance of the value manager, optional parameter</param>
        /// <returns>Returns the same collection modified</returns>
        internal static int UpdateAutoResetDeviceUpdateParameters(this IEnumerable<DeviceUpdateDetails> devices
            , IDeviceUpdateValueManager valueManager = null)
        {
            int recordsAffected = -1;
            if (devices != null)
            {
                recordsAffected = devices.Select(device => device.Parameters).Combine().UpdateAutoResetDeviceUpdateParameters(valueManager);
            }

            return recordsAffected;
        }

        /// <summary>
        /// Updates the auto reset parameters
        /// </summary>
        /// <param name="parameters">The enumerable of parameters</param>
        /// <param name="valueManager">The instance of the value manager, optional parameter</param>
        /// <returns>Returns the same collection modified</returns>
        internal static int UpdateAutoResetDeviceUpdateParameters(this IEnumerable<DeviceUpdateParameter> parameters
            , IDeviceUpdateValueManager valueManager = null)
        {
            int recordsAffected = -1;
            if (parameters != null)
            {
                if (valueManager == null)
                {
                    throw new ApplicationException("IDeviceUpdateValueManager not provided");
                }

                recordsAffected = valueManager.SetAutoResetParameterValues(parameters);
            }


            return recordsAffected;
        }


    }
}
