﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
using KC.SmartWashroom.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.AlertEngine.Interfaces.EngineStructure
{
    public interface INotificationEngine
    {
        string CommunicationContent { get; set; }
        void StartEngine(EngineConnectorWire engineConnector);
        bool PrepareNotifications(DeviceAlertInfo alertInfo);
        bool SendNotification(ref string errorMessage);

        void PushAuditLogToRepository(string deviceID, bool isOutForDelivery);
        void PushAlertStatusEntityToRepository(DeviceAlertInfo eventDetail);

        string PushDeviceAlertToRepository(DeviceDetail deviceDetail, DeviceAlertInfo eventDetail);
        void PrepareErrorNotification(string eventId, string templateCode, string errorTemplateCode, string lastError);

        void CleanUpNotification(DeviceDetail deviceDetail, DeviceAlertInfo eventDetail);
    }
}
