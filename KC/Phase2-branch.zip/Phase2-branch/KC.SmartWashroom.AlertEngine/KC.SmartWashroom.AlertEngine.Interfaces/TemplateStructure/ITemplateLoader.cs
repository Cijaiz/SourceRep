﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.AlertEngine.Interfaces.TemplateStructure
{
    /// <summary>
    /// Methods for Loading all the templates from Blob
    /// </summary>
    public interface ITemplateLoader
    {
        string ConfigurationFilePath { get; set; }
        ConcurrentDictionary<string, ITemplate> templatesDictionary { get; set; }

        void InitializeTemplateDictionary();
        ConcurrentDictionary<string, ITemplate> LoadAllTemplates();
    }
}
