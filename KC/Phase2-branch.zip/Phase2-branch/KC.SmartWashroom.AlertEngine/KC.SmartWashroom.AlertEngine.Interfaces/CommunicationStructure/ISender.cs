﻿using KC.SmartWashroom.Core.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.AlertEngine.Interfaces.CommunicationStructure
{
    public interface ISender<T>
    {
        T CommunicationContent { get; set; }
        ICollection<string> ToMobileNumbers {  get; set; }

          SmsConfig SmsConfiguration { get; set; }
          SmtpConfig SmtpConfiguration { get; set; }

        bool SendNotification(ref string errorMessage);
    }
}
