﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using KC.SmartWashroom.AlertEngine.EngineBase;
using KC.SmartWashroom.AlertEngine.EngineBase.Engines;
using KC.SmartWashroom.AlertEngine.Interfaces.EngineStructure;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.Core.Constants;
using System.Collections.Generic;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.ServiceRuntime;
using KC.AlertEngine.Worker;
using KC.SmartWashroom.AlertEngine.EngineBase.EngineWorkers;
using KC.SmartWashroom.AlertEngine.EngineBase.CommunicationWorkers;

namespace KC.SmartWashroom.AlertEngine.UnitTests
{
    [TestClass]
    public class AlertEngineTests
    {

        public static string StorageConnectionString { get; set; }
        public static List<INotificationEngine> Engines { get; set; }

        TextMessageWorker objTxtMsgWokrer = new TextMessageWorker();
        EmailWorker objEmailMsgWokrer = new EmailWorker();


        Core.EngineConnectorWire engineWire = Core.EngineConnectorWire.EngineConnectorWireInstance();

        string TemplatesConfigurationFilePath = CloudConfigurationManager.GetSetting(AlertEngineConstants.TEMPLATES_CONFIGURATION_FILEPATH);
        string BusinessHubUrl = CommonHelper.GetConfigSetting(AlertEngineConstants.BUSINESS_HUB_URL);
        public static SmtpConfig SmtpConfiguration = SerializationHelper.JsonDeserialize<SmtpConfig>(CommonHelper.GetConfigSetting(AlertEngineConstants.SMTP_SERVER_CONFIGURATION));
        public static string FromEmailAddres = SmtpConfiguration.FromEmailAddress;
        public static SmsConfig SmsConfiguration = SerializationHelper.JsonDeserialize<SmsConfig>(CommonHelper.GetConfigSetting(AlertEngineConstants.SMS_CONFIGURATION));
        public static string FromMobileNumber = SmsConfiguration.FromMobileNumber;
        string CommunicationContent = "This is a test method";

        [TestMethod]
        public void TestRunEngine()
        {
            //Engines = new List<INotificationEngine>();
            //Engines.Add(new EmailNotificationEngine());
            //Engines.Add(new SMSNotificationEngine());
            //StorageConnectionString = 
            ////Connectors Initializeations..



            NotificationManager.StartEngine();
        }

        private void Initialize()
        {


        }

        [TestMethod]
        public void TestEmailWorker()
        {

            objEmailMsgWokrer.SmtpConfiguration = SmtpConfiguration;
           // objEmailMsgWokrer.CommunicationContent = CommunicationContent;
            objEmailMsgWokrer.ToEmailAddress.Add("Neelamegam.s@cognizant.com");
            objTxtMsgWokrer.SendNotification();

        }


        [TestMethod]
        public void TestSmsWorker()
        {
            objTxtMsgWokrer.SmsConfiguration = SmsConfiguration;
            objTxtMsgWokrer.CommunicationContent = CommunicationContent;
            objTxtMsgWokrer.ToMobileNumbers.Add("+919597594515");
            objTxtMsgWokrer.SendNotification();
        }

    }
}
