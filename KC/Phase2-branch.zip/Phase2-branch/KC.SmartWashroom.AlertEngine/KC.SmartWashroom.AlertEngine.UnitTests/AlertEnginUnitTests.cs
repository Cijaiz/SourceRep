﻿using KC.SmartWashroom.AlertEngine.EngineBase;
using KC.SmartWashroom.AlertEngine.EngineBase.CommunicationWorkers;
using KC.SmartWashroom.AlertEngine.EngineBase.Engines;
using KC.SmartWashroom.AlertEngine.EngineBase.EngineWorkers;
using KC.SmartWashroom.AlertEngine.Interfaces.EngineStructure;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.Core.Helper.CloudHelper;
using KC.SmartWashroom.Core.NotificationUtility;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Queue;
using System.Collections.Generic;

namespace KC.SmartWashroom.AlertEngine.UnitTests
{
    /// <summary>
    /// Summary description for AlertEnginUnitTests
    /// </summary>
    [TestClass]
    public class AlertEnginUnitTests
    {
        Core.EngineConnectorWire engineWire = Core.EngineConnectorWire.EngineConnectorWireInstance();
        INotificationEngine EmailEngine = null;
        INotificationEngine SmsEngine = null;

        List<INotificationEngine> engines;
        private CloudQueueClient cloudQueueClient = null;
        private CloudStorageAccount cloudStorageAccount = null;

        string CommunicationContent = "This is a test method";
        public Table tableStore = null;

        public AlertEnginUnitTests()
        {
            var tt = new SmtpConfig();
            tt.ErrorAdminsEmails = new List<string>() { "Vijayananthan.jc@cognizant.com" };

            var tt1 = new SmsConfig();
            tt1.ErrorAdminMobileNos = new List<string>() { "+919597355973" };
            var ss1 = SerializationHelper.JsonSerialize<SmsConfig>(tt1);

            var ss = SerializationHelper.JsonSerialize<SmtpConfig>(tt);

            string StorageConnectionString = CloudConfigurationManager.GetSetting("Microsoft.WindowsAzure.Plugins.Diagnostics.ConnectionString");
            engineWire.StorageConnectionString = StorageConnectionString;
            NotificationManager.StorageConnectionString = StorageConnectionString;

            engineWire.TemplatesConfigurationFilePath = CloudConfigurationManager.GetSetting(AlertEngineConstants.TEMPLATES_CONFIGURATION_FILEPATH);
            engineWire.BusinessHubUrl = CloudConfigurationManager.GetSetting(AlertEngineConstants.BUSINESS_HUB_URL);
            engineWire.SmtpConfiguration = SerializationHelper.JsonDeserialize<SmtpConfig>(CloudConfigurationManager.GetSetting(AlertEngineConstants.SMTP_SERVER_CONFIGURATION));

            engineWire.FromEmailAddres = engineWire.SmtpConfiguration.FromEmailAddress;
            engineWire.SmsConfiguration = SerializationHelper.JsonDeserialize<SmsConfig>(CloudConfigurationManager.GetSetting(AlertEngineConstants.SMS_CONFIGURATION));
            engineWire.FromMobileNumber = engineWire.SmsConfiguration.FromMobileNumber;
            AzureHelper.AzureConnectionString = StorageConnectionString;

            EmailEngine = new EmailNotificationEngine();
            SmsEngine = new SMSNotificationEngine();
            engines = new List<INotificationEngine>();

            engines.Add(EmailEngine);
            engines.Add(SmsEngine);
            EmailEngine.StartEngine(this.engineWire);

            tableStore = Table.GetInstance(NotificationManager.StorageConnectionString);
        }

        [TestMethod]
        public void TestStartEngine()
        {
            DeviceAlertInfo ss = new DeviceAlertInfo();
            ss.AlertType = "UC";
            ss.SharedEmailAddresses = new List<string>() { "Vijayananthan.jc@cognizant.com" };
            ss.SharedMobileNumbers = new List<string>() { "+919597355973" };

            var saltedAccount = new UserAccountInformation() { Password = "OKJOKJ" };
            ss.MessageContent = SerializationHelper.JsonSerialize<UserAccountInformation>(saltedAccount);

            string serialized = SerializationHelper.JsonSerialize<DeviceAlertInfo>(ss);

            EmailEngine.StartEngine(this.engineWire);

            Assert.AreEqual(3, NotificationEngine.EmailTemplatesDictionary.Count);
        }

        [TestMethod]
        public void TestRunEngine()
        {
            NotificationManager.RunEngine();

            Assert.IsNotNull(NotificationManager.TasksThresholdLimit);
        }

        [TestMethod]
        public void TestProcessMessage()
        {
            MessageDispatcher dispatcher = new MessageDispatcher(engines);
            CloudQueueMessage msg = initializeMessageProcessing(dispatcher);

            dispatcher.ProcessMessage(msg);

            Assert.IsTrue(EmailNotificationEngine.EngineAuditLog.ToEmailAddresses != null);
        }

        [TestMethod]
        public void TestProcessErrorMessage()
        {
            MessageDispatcher dispatcher = new MessageDispatcher(engines);
            CloudQueueMessage msg = initializeMessageProcessing(dispatcher);

            dispatcher.ProcessErrorMessage(msg);

            Assert.IsTrue(EmailNotificationEngine.EngineAuditLog.ToEmailAddresses != null);
        }

        [TestMethod]
        public void TestPrepareNotifications()
        {
            MessageDispatcher dispatcher = new MessageDispatcher(engines);
            CloudQueueMessage msg = initializeMessageProcessing(dispatcher);

            dispatcher.ProcessErrorMessage(msg);
            var eventDetails = SerializationHelper.Deserialize<DeviceAlertInfo>(msg.AsString);
            string deviceId = eventDetails.DeviceID;
            string templateCode = eventDetails.AlertType;

            EmailEngine.PrepareNotifications(eventDetails);

            Assert.IsTrue(EmailEngine.CommunicationContent != null);
        }

        [TestMethod]
        public void TestPrepareErrorNotifications()
        {
            MessageDispatcher dispatcher = new MessageDispatcher(engines);
            CloudQueueMessage msg = initializeMessageProcessing(dispatcher);

            dispatcher.ProcessErrorMessage(msg);
            var eventDetails = SerializationHelper.Deserialize<DeviceAlertInfo>(msg.AsString);
            string deviceId = eventDetails.DeviceID;
            string templateCode = eventDetails.AlertType;
            string errorMessage = string.Empty;
            EmailEngine.PrepareErrorNotification(deviceId, templateCode, AlertEngineConstants.ERRORCODE, errorMessage);

            Assert.IsTrue(EmailEngine.CommunicationContent != null);
        }

        [TestMethod]
        public void TestEmailWorker()
        {
            string errorMessage = string.Empty;
            EmailWorker objEmailMsgWokrer = new EmailWorker();
            objEmailMsgWokrer.SmtpConfiguration = engineWire.SmtpConfiguration;
            EmailMessage TestMessage = new EmailMessage();

            TestMessage.From = objEmailMsgWokrer.SmtpConfiguration.FromEmailAddress;
            TestMessage.Subject = CommunicationContent;
            TestMessage.MessageBody = CommunicationContent;

            TestMessage.MessageType = "HTML";
            TestMessage.To.Add("Neelamegam.s@cognizant.com");
            objEmailMsgWokrer.CommunicationContent = TestMessage;

            Assert.IsTrue(objEmailMsgWokrer.SendNotification(ref errorMessage));

        }

        [TestMethod]
        public void TestSmsWorker()
        {
            string errorMessage = string.Empty;
            TextMessageWorker objTxtMsgWokrer = new TextMessageWorker();
            List<string> nos = new List<string>();

            nos.Add("+919597594515");
            objTxtMsgWokrer.SmsConfiguration = engineWire.SmsConfiguration;
            objTxtMsgWokrer.CommunicationContent = CommunicationContent;
            objTxtMsgWokrer.ToMobileNumbers = nos;

            Assert.IsTrue(objTxtMsgWokrer.SendNotification(ref errorMessage));
        }

        [TestMethod]
        public void TestAuditLog()
        {
            NotificationEngine.EngineAuditLog = new EngineAuditLog();
            SmsEngine.PushAuditLogToRepository(AlertEngineConstants.WASHROOM_TEMPLATECODE, false);

            Assert.IsFalse(NotificationEngine.EngineAuditLog.isSMSOutForDelivery);

        }

        public CloudQueueMessage initializeMessageProcessing(MessageDispatcher dispatcher)
        {
            CloudQueueMessage msg = new CloudQueueMessage("");
            cloudStorageAccount = CloudStorageAccount.Parse(engineWire.StorageConnectionString);
            cloudQueueClient = cloudStorageAccount.CreateCloudQueueClient();

            CloudQueue queue = cloudQueueClient.GetQueueReference("lowpriorityqueue");
            queue.CreateIfNotExists();

            msg.SetMessageContent("{\"DeviceID\":\"001\",\"TemplateCode\":\"B01\",\"NotificationContent\":\"Message1\",\"AlertType\":1}");
            queue.AddMessage(msg);

            return msg;
        }

    }
}

