/****** Object:  Table [dbo].[Property]    Script Date: 11/13/2014 4:46:37 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Property]') AND type in (N'U'))
ALTER TABLE [Property]
ALTER COLUMN [LocationTimeZone] varchar(60) NOT NULL
GO