IF Exists(select * from sys.columns where Name = N'Street' and Object_ID = Object_ID(N'Address'))
ALTER TABLE [Address] ALTER COLUMN [Street] varchar(100) NULL

IF Exists(select * from sys.columns where Name = N'BuildingAddress' and Object_ID = Object_ID(N'Address'))
ALTER TABLE [Address] ALTER COLUMN [BuildingAddress] varchar(100) NULL

IF Exists(select * from sys.columns where Name = N'City' and Object_ID = Object_ID(N'Address'))
ALTER TABLE [Address] ALTER COLUMN [City] varchar(50) NULL

IF Exists(select * from sys.columns where Name = N'State' and Object_ID = Object_ID(N'Address'))
ALTER TABLE [Address] ALTER COLUMN [State] varchar(50) NULL

IF Exists(select * from sys.columns where Name = N'Zip' and Object_ID = Object_ID(N'Address'))
ALTER TABLE [Address] ALTER COLUMN [Zip] varchar(20) NULL

IF Exists(select * from sys.columns where Name = N'Email' and Object_ID = Object_ID(N'User'))
ALTER TABLE [User] ALTER COLUMN [Email] varchar(60) NULL

IF Exists(select * from sys.columns where Name = N'MobileNo' and Object_ID = Object_ID(N'User'))
ALTER TABLE [User] ALTER COLUMN [MobileNo] varchar(25) NULL

IF Not Exists(select * from sys.columns where Name = N'RoleLevel' and Object_ID = Object_ID(N'Role'))
ALTER TABLE [Role] ADD [RoleLevel] int Not null Default 0

IF Not Exists(select * from sys.columns where Name = N'CreatedBy' and Object_ID = Object_ID(N'UserBuilding'))
ALTER TABLE [UserBuilding] ADD [CreatedBy] int Not Null

IF Not Exists(select * from sys.columns where Name = N'CreatedOn' and Object_ID = Object_ID(N'UserBuilding'))
ALTER TABLE [UserBuilding] ADD [CreatedOn] datetime not Null

IF Not Exists(select * from sys.columns where Name = N'ID' and Object_ID = Object_ID(N'UserBuilding'))
ALTER TABLE [UserBuilding] ADD [ID] int Identity(1,1) Primary key


