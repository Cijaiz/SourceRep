BEGIN 
Declare @ColumnName varchar(50) 
Declare @TableName varchar(10)
Select @ColumnName = 'PasswordSalt'
Select @TableName = 'User'

--PRINT @ColumnName
--PRINT @TableName

IF NOT EXISTS(SELECT * FROM information_schema.COLUMNS WHERE COLUMN_NAME=@ColumnName AND TABLE_NAME=@TableName AND TABLE_SCHEMA='dbo')
ALTER TABLE [User]
ADD [PasswordSalt] varchar(100)

Select @ColumnName = 'Password'

IF NOT EXISTS(SELECT * FROM information_schema.COLUMNS WHERE COLUMN_NAME=@ColumnName AND TABLE_NAME=@TableName AND TABLE_SCHEMA='dbo')
ALTER TABLE [User]
ADD [Password] varchar(100)

Select @ColumnName = 'IsAccountLocked'

IF NOT EXISTS(SELECT * FROM information_schema.COLUMNS WHERE COLUMN_NAME=@ColumnName AND TABLE_NAME=@TableName AND TABLE_SCHEMA='dbo')
ALTER TABLE [User]
ADD [IsAccountLocked] bit

Select @ColumnName = 'IsFirstLogin'

IF NOT EXISTS(SELECT * FROM information_schema.COLUMNS WHERE COLUMN_NAME=@ColumnName AND TABLE_NAME=@TableName AND TABLE_SCHEMA='dbo')
ALTER TABLE [User]
ADD [IsFirstLogin] bit

END
GO


GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_RolePermission_Role]') AND parent_object_id = OBJECT_ID(N'[dbo].[RolePermission]'))
ALTER TABLE [dbo].[RolePermission] DROP CONSTRAINT [FK_RolePermission_Role]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_RolePermission_Feature]') AND parent_object_id = OBJECT_ID(N'[dbo].[RolePermission]'))
ALTER TABLE [dbo].[RolePermission] DROP CONSTRAINT [FK_RolePermission_Feature]
GO

/****** Object:  Table [dbo].[RolePermission]    Script Date: 11/26/2014 12:18:58 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RolePermission]') AND type in (N'U'))
DROP TABLE [dbo].[RolePermission]
GO

/****** Object:  Table [dbo].[Feature]    Script Date: 11/26/2014 12:18:58 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Feature]') AND type in (N'U'))
DROP TABLE [dbo].[Feature]
GO

/****** Object:  Table [dbo].[Feature]    Script Date: 11/26/2014 12:18:58 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Feature]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Feature](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](70) NOT NULL,
 CONSTRAINT [PK_Feature] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO

SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[RolePermission]    Script Date: 11/26/2014 12:18:59 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RolePermission]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[RolePermission](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[FeatureId] [int] NOT NULL,
	[RoleId] [tinyint] NOT NULL,
 CONSTRAINT [PK_RolePermission] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END

GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_RolePermission_Feature]') AND parent_object_id = OBJECT_ID(N'[dbo].[RolePermission]'))
ALTER TABLE [dbo].[RolePermission]  WITH CHECK ADD  CONSTRAINT [FK_RolePermission_Feature] FOREIGN KEY([FeatureId])
REFERENCES [dbo].[Feature] ([ID])
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_RolePermission_Feature]') AND parent_object_id = OBJECT_ID(N'[dbo].[RolePermission]'))
ALTER TABLE [dbo].[RolePermission] CHECK CONSTRAINT [FK_RolePermission_Feature]
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_RolePermission_Role]') AND parent_object_id = OBJECT_ID(N'[dbo].[RolePermission]'))
ALTER TABLE [dbo].[RolePermission]  WITH CHECK ADD  CONSTRAINT [FK_RolePermission_Role] FOREIGN KEY([RoleId])
REFERENCES [dbo].[Role] ([ID])
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_RolePermission_Role]') AND parent_object_id = OBJECT_ID(N'[dbo].[RolePermission]'))
ALTER TABLE [dbo].[RolePermission] CHECK CONSTRAINT [FK_RolePermission_Role]
GO