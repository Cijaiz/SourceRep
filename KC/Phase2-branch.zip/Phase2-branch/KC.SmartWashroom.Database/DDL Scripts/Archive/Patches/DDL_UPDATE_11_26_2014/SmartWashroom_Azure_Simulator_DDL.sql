
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_SimulatorRaisedAlert_AlertType]') AND parent_object_id = OBJECT_ID(N'[dbo].[SimulatorRaisedAlert]'))
ALTER TABLE [dbo].[SimulatorRaisedAlert] DROP CONSTRAINT [FK_SimulatorRaisedAlert_AlertType]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_SimulatorRaisedAlert_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[SimulatorRaisedAlert]'))
ALTER TABLE [dbo].[SimulatorRaisedAlert] DROP CONSTRAINT [FK_SimulatorRaisedAlert_Device]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SimulatorRaisedAlert]') AND type in (N'U'))
DROP TABLE [dbo].[SimulatorRaisedAlert]
GO

/****** Object:  Table [dbo].[SimulatorRaisedAlert]    Script Date: 11/26/2014 9:14:53 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING OFF
GO

CREATE TABLE [dbo].[SimulatorRaisedAlert](
	[DeviceId] [varchar](30) NOT NULL,
	[AlertTypeId] [tinyint] NOT NULL,
	[LogTime] [datetime] NOT NULL,
 CONSTRAINT [PK_SimulatorRaisedAlert] PRIMARY KEY CLUSTERED 
(
	[DeviceId] ASC,
	[AlertTypeId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF)
) 

GO

SET ANSI_PADDING OFF
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_SimulatorRaisedAlert_AlertType]') AND parent_object_id = OBJECT_ID(N'[dbo].[SimulatorRaisedAlert]'))
ALTER TABLE [dbo].[SimulatorRaisedAlert]  WITH CHECK ADD  CONSTRAINT [FK_SimulatorRaisedAlert_AlertType] FOREIGN KEY([AlertTypeId])
REFERENCES [dbo].[AlertType] ([ID])
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_SimulatorRaisedAlert_AlertType]') AND parent_object_id = OBJECT_ID(N'[dbo].[SimulatorRaisedAlert]'))
ALTER TABLE [dbo].[SimulatorRaisedAlert] CHECK CONSTRAINT [FK_SimulatorRaisedAlert_AlertType]
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_SimulatorRaisedAlert_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[SimulatorRaisedAlert]'))
ALTER TABLE [dbo].[SimulatorRaisedAlert]  WITH CHECK ADD  CONSTRAINT [FK_SimulatorRaisedAlert_Device] FOREIGN KEY([DeviceId])
REFERENCES [dbo].[Device] ([ID])
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_SimulatorRaisedAlert_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[SimulatorRaisedAlert]'))
ALTER TABLE [dbo].[SimulatorRaisedAlert] CHECK CONSTRAINT [FK_SimulatorRaisedAlert_Device]
GO


