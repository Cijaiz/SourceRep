
IF NOT  EXISTS (SELECT TOP 1 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeviceAlertName]') AND type in (N'U'))
CREATE TABLE [dbo].[DeviceAlertName](
	[ID] int IDENTITY(1,1) primary key,
	[AlertName] [varchar](60) NOT NULL

 )

 GO

IF NOT  EXISTS (SELECT TOP 1 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeviceAlertMapping]') AND type in (N'U'))
CREATE TABLE [dbo].[DeviceAlertMapping](
	[ID] int IDENTITY(1,1),
	[DeviceTypeId] [tinyint] NOT NULL,
	[AlertTypeId] [tinyint] NOT NULL,
    [AlertNameId] [int] NULL,

 CONSTRAINT [pk_DeviceAlertMapping] PRIMARY KEY CLUSTERED 
(
	[DeviceTypeId] ASC,
	[AlertTypeId] ASC

))

GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[fk_devicetype]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceAlertMapping]'))
ALTER TABLE [dbo].[DeviceAlertMapping]  WITH CHECK ADD  CONSTRAINT [fk_devicetype] FOREIGN KEY([DeviceTypeId])
REFERENCES [dbo].[DeviceType] ([ID])
GO

GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[fk_devicealert]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceAlertMapping]'))
ALTER TABLE [dbo].[DeviceAlertMapping]  WITH CHECK ADD  CONSTRAINT [fk_devicealert] FOREIGN KEY([AlertTypeId])
REFERENCES [dbo].[AlertType] ([ID])
GO

GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[fk_alertName]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceAlertMapping]'))
ALTER TABLE [dbo].[DeviceAlertMapping]  WITH CHECK ADD  CONSTRAINT [fk_alertName] FOREIGN KEY([AlertNameId])
REFERENCES [dbo].[DeviceAlertName] ([ID])
GO



