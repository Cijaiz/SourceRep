IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Washroom_Wing]') AND parent_object_id = OBJECT_ID(N'[dbo].[Washroom]'))
ALTER TABLE [dbo].[Washroom] DROP CONSTRAINT [FK_Washroom_Wing]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Washroom_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Washroom]'))
ALTER TABLE [dbo].[Washroom] DROP CONSTRAINT [FK_Washroom_User1]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Washroom_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[Washroom]'))
ALTER TABLE [dbo].[Washroom] DROP CONSTRAINT [FK_Washroom_User]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Washroom_Gender]') AND parent_object_id = OBJECT_ID(N'[dbo].[Washroom]'))
ALTER TABLE [dbo].[Washroom] DROP CONSTRAINT [FK_Washroom_Gender]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Washroom_Floor]') AND parent_object_id = OBJECT_ID(N'[dbo].[Washroom]'))
ALTER TABLE [dbo].[Washroom] DROP CONSTRAINT [FK_Washroom_Floor]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserProperty_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserProperty]'))
ALTER TABLE [dbo].[UserProperty] DROP CONSTRAINT [FK_UserProperty_User]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserProperty_Property]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserProperty]'))
ALTER TABLE [dbo].[UserProperty] DROP CONSTRAINT [FK_UserProperty_Property]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserBuilding_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserBuilding]'))
ALTER TABLE [dbo].[UserBuilding] DROP CONSTRAINT [FK_UserBuilding_User]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserBuilding_Building]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserBuilding]'))
ALTER TABLE [dbo].[UserBuilding] DROP CONSTRAINT [FK_UserBuilding_Building]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_User_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[User]'))
ALTER TABLE [dbo].[User] DROP CONSTRAINT [FK_User_User1]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_User_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[User]'))
ALTER TABLE [dbo].[User] DROP CONSTRAINT [FK_User_User]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_User_Role]') AND parent_object_id = OBJECT_ID(N'[dbo].[User]'))
ALTER TABLE [dbo].[User] DROP CONSTRAINT [FK_User_Role]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_User_Customer]') AND parent_object_id = OBJECT_ID(N'[dbo].[User]'))
ALTER TABLE [dbo].[User] DROP CONSTRAINT [FK_User_Customer]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Property_User2]') AND parent_object_id = OBJECT_ID(N'[dbo].[Property]'))
ALTER TABLE [dbo].[Property] DROP CONSTRAINT [FK_Property_User2]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Property_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Property]'))
ALTER TABLE [dbo].[Property] DROP CONSTRAINT [FK_Property_User1]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Property_Customer]') AND parent_object_id = OBJECT_ID(N'[dbo].[Property]'))
ALTER TABLE [dbo].[Property] DROP CONSTRAINT [FK_Property_Customer]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Property_Address]') AND parent_object_id = OBJECT_ID(N'[dbo].[Property]'))
ALTER TABLE [dbo].[Property] DROP CONSTRAINT [FK_Property_Address]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Floor_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Floor]'))
ALTER TABLE [dbo].[Floor] DROP CONSTRAINT [FK_Floor_User1]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Floor_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[Floor]'))
ALTER TABLE [dbo].[Floor] DROP CONSTRAINT [FK_Floor_User]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Floor_Building]') AND parent_object_id = OBJECT_ID(N'[dbo].[Floor]'))
ALTER TABLE [dbo].[Floor] DROP CONSTRAINT [FK_Floor_Building]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_DeviceWashroom_Washroom]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceWashroom]'))
ALTER TABLE [dbo].[DeviceWashroom] DROP CONSTRAINT [FK_DeviceWashroom_Washroom]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_DeviceWashroom_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceWashroom]'))
ALTER TABLE [dbo].[DeviceWashroom] DROP CONSTRAINT [FK_DeviceWashroom_Device]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_DeviceAlert_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceAlert]'))
ALTER TABLE [dbo].[DeviceAlert] DROP CONSTRAINT [FK_DeviceAlert_Device]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_DeviceAlert_AlertType]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceAlert]'))
ALTER TABLE [dbo].[DeviceAlert] DROP CONSTRAINT [FK_DeviceAlert_AlertType]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Device_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Device]'))
ALTER TABLE [dbo].[Device] DROP CONSTRAINT [FK_Device_User1]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Device_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[Device]'))
ALTER TABLE [dbo].[Device] DROP CONSTRAINT [FK_Device_User]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Device_DeviceType]') AND parent_object_id = OBJECT_ID(N'[dbo].[Device]'))
ALTER TABLE [dbo].[Device] DROP CONSTRAINT [FK_Device_DeviceType]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Customer_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Customer]'))
ALTER TABLE [dbo].[Customer] DROP CONSTRAINT [FK_Customer_User1]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Customer_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[Customer]'))
ALTER TABLE [dbo].[Customer] DROP CONSTRAINT [FK_Customer_User]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Customer_Address]') AND parent_object_id = OBJECT_ID(N'[dbo].[Customer]'))
ALTER TABLE [dbo].[Customer] DROP CONSTRAINT [FK_Customer_Address]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Building_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Building]'))
ALTER TABLE [dbo].[Building] DROP CONSTRAINT [FK_Building_User1]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Building_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[Building]'))
ALTER TABLE [dbo].[Building] DROP CONSTRAINT [FK_Building_User]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Building_Property]') AND parent_object_id = OBJECT_ID(N'[dbo].[Building]'))
ALTER TABLE [dbo].[Building] DROP CONSTRAINT [FK_Building_Property]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Address_Country]') AND parent_object_id = OBJECT_ID(N'[dbo].[Address]'))
ALTER TABLE [dbo].[Address] DROP CONSTRAINT [FK_Address_Country]
GO
/****** Object:  Table [dbo].[Wing]    Script Date: 10/29/2014 7:50:31 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Wing]') AND type in (N'U'))
DROP TABLE [dbo].[Wing]
GO
/****** Object:  Table [dbo].[Washroom]    Script Date: 10/29/2014 7:50:31 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Washroom]') AND type in (N'U'))
DROP TABLE [dbo].[Washroom]
GO
/****** Object:  Table [dbo].[UserProperty]    Script Date: 10/29/2014 7:50:31 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserProperty]') AND type in (N'U'))
DROP TABLE [dbo].[UserProperty]
GO
/****** Object:  Table [dbo].[UserBuilding]    Script Date: 10/29/2014 7:50:31 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserBuilding]') AND type in (N'U'))
DROP TABLE [dbo].[UserBuilding]
GO
/****** Object:  Table [dbo].[User]    Script Date: 10/29/2014 7:50:31 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[User]') AND type in (N'U'))
DROP TABLE [dbo].[User]
GO
/****** Object:  Table [dbo].[Role]    Script Date: 10/29/2014 7:50:31 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Role]') AND type in (N'U'))
DROP TABLE [dbo].[Role]
GO
/****** Object:  Table [dbo].[Property]    Script Date: 10/29/2014 7:50:31 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Property]') AND type in (N'U'))
DROP TABLE [dbo].[Property]
GO
/****** Object:  Table [dbo].[Gender]    Script Date: 10/29/2014 7:50:31 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Gender]') AND type in (N'U'))
DROP TABLE [dbo].[Gender]
GO
/****** Object:  Table [dbo].[Floor]    Script Date: 10/29/2014 7:50:31 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Floor]') AND type in (N'U'))
DROP TABLE [dbo].[Floor]
GO
/****** Object:  Table [dbo].[DeviceWashroom]    Script Date: 10/29/2014 7:50:31 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeviceWashroom]') AND type in (N'U'))
DROP TABLE [dbo].[DeviceWashroom]
GO
/****** Object:  Table [dbo].[DeviceType]    Script Date: 10/29/2014 7:50:31 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeviceType]') AND type in (N'U'))
DROP TABLE [dbo].[DeviceType]
GO
/****** Object:  Table [dbo].[DeviceAlert]    Script Date: 10/29/2014 7:50:31 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeviceAlert]') AND type in (N'U'))
DROP TABLE [dbo].[DeviceAlert]
GO
/****** Object:  Table [dbo].[Device]    Script Date: 10/29/2014 7:50:31 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Device]') AND type in (N'U'))
DROP TABLE [dbo].[Device]
GO
/****** Object:  Table [dbo].[Customer]    Script Date: 10/29/2014 7:50:31 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Customer]') AND type in (N'U'))
DROP TABLE [dbo].[Customer]
GO
/****** Object:  Table [dbo].[Country]    Script Date: 10/29/2014 7:50:31 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Country]') AND type in (N'U'))
DROP TABLE [dbo].[Country]
GO
/****** Object:  Table [dbo].[Building]    Script Date: 10/29/2014 7:50:31 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Building]') AND type in (N'U'))
DROP TABLE [dbo].[Building]
GO
/****** Object:  Table [dbo].[AlertType]    Script Date: 10/29/2014 7:50:31 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AlertType]') AND type in (N'U'))
DROP TABLE [dbo].[AlertType]
GO
/****** Object:  Table [dbo].[Address]    Script Date: 10/29/2014 7:50:31 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Address]') AND type in (N'U'))
DROP TABLE [dbo].[Address]
GO
/****** Object:  Table [dbo].[Activity]    Script Date: 10/29/2014 7:50:31 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Activity]') AND type in (N'U'))
DROP TABLE [dbo].[Activity]
GO
/****** Object:  Table [dbo].[Activity]    Script Date: 10/29/2014 7:50:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Activity]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Activity](
	[ID] [tinyint] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](50) NOT NULL,
 CONSTRAINT [PK_Activity] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF)
)
END
GO
/****** Object:  Table [dbo].[Address]    Script Date: 10/29/2014 7:50:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Address]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Address](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Street] [varchar](100) NOT NULL,
	[BuildingAddress] [varchar](100) NOT NULL,
	[City] [varchar](50) NOT NULL,
	[State] [varchar](50) NOT NULL,
	[CountryId] [tinyint] NOT NULL,
	[Zip] [varchar](20) NOT NULL,
 CONSTRAINT [PK_Address] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF)
)
END
GO
/****** Object:  Table [dbo].[AlertType]    Script Date: 10/29/2014 7:50:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AlertType]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[AlertType](
	[ID] [tinyint] IDENTITY(1,1) NOT NULL,
	[Type] [varchar](10) NOT NULL,
 CONSTRAINT [PK_AlertType] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF)
)
END
GO
/****** Object:  Table [dbo].[Building]    Script Date: 10/29/2014 7:50:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Building]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Building](
	[ID] [tinyint] IDENTITY(1,1) NOT NULL,
	[PropertyId] [tinyint] NOT NULL,
	[Name] [varchar](150) NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedBy] [int] NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[LastUpdatedBy] [int] NULL,
	[LastUpdatedOn] [datetime] NULL,
 CONSTRAINT [PK_Building] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF)
)
END
GO
/****** Object:  Table [dbo].[Country]    Script Date: 10/29/2014 7:50:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Country]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Country](
	[ID] [tinyint] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](100) NOT NULL,
 CONSTRAINT [PK_Country] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF)
)
END
GO
/****** Object:  Table [dbo].[Customer]    Script Date: 10/29/2014 7:50:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Customer]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Customer](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](150) NOT NULL,
	[AddressId] [int] NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedBy] [int] NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[LastUpdatedBy] [int] NULL,
	[LastUpdatedOn] [datetime] NULL,
 CONSTRAINT [PK_Customer] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF)
)
END
GO
/****** Object:  Table [dbo].[Device]    Script Date: 10/29/2014 7:50:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Device]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Device](
	[ID] [varchar](30) NOT NULL,
	[Name] [varchar](50) NOT NULL,
	[ImageUrl] [varchar](1000) NOT NULL,
	[DeviceTypeId] [tinyint] NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedBy] [int] NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[LastUpdatedBy] [int] NULL,
	[LastUpdatedOn] [datetime] NULL,
 CONSTRAINT [PK_Device] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF)
)
END
GO
/****** Object:  Table [dbo].[DeviceAlert]    Script Date: 10/29/2014 7:50:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeviceAlert]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[DeviceAlert](
	[DeviceId] [varchar](30) NOT NULL,
	[AlertTypeId] [tinyint] NOT NULL,
	[ReceivedOn] [datetime] NOT NULL,
 CONSTRAINT [PK_DeviceAlert] PRIMARY KEY CLUSTERED 
(
	[DeviceId] ASC,
	[AlertTypeId] ASC,
	[ReceivedOn] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF)
)
END
GO
/****** Object:  Table [dbo].[DeviceType]    Script Date: 10/29/2014 7:50:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeviceType]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[DeviceType](
	[ID] [tinyint] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](10) NOT NULL,
 CONSTRAINT [PK_DeviceType] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF)
)
END
GO
/****** Object:  Table [dbo].[DeviceWashroom]    Script Date: 10/29/2014 7:50:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeviceWashroom]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[DeviceWashroom](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[DeviceId] [varchar](30) NOT NULL,
	[WashroomId] [tinyint] NOT NULL,
	[StartDate] [datetime] NOT NULL,
	[EndDate] [datetime] NOT NULL,
 CONSTRAINT [PK_DeviceWashroom] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF)
)
END
GO
/****** Object:  Table [dbo].[Floor]    Script Date: 10/29/2014 7:50:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Floor]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Floor](
	[ID] [tinyint] IDENTITY(1,1) NOT NULL,
	[BuildingId] [tinyint] NOT NULL,
	[FloorLevel] [tinyint] NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedBy] [int] NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[LastUpdatedBy] [int] NULL,
	[LastUpdatedOn] [datetime] NULL,
 CONSTRAINT [PK_Floor] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF)
)
END
GO
/****** Object:  Table [dbo].[Gender]    Script Date: 10/29/2014 7:50:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Gender]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Gender](
	[ID] [tinyint] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](10) NOT NULL,
 CONSTRAINT [PK_Gender] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF)
)
END
GO
/****** Object:  Table [dbo].[Property]    Script Date: 10/29/2014 7:50:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Property]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Property](
	[ID] [tinyint] IDENTITY(1,1) NOT NULL,
	[CustomerId] [int] NOT NULL,
	[PropertyName] [varchar](150) NOT NULL,
	[LocationTimeZone] [varchar](5) NOT NULL,
	[AddressId] [int] NOT NULL,
	[ImageUrl] [varchar](1000) NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedBy] [int] NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[LastUpdatedBy] [int] NULL,
	[LastUpdatedOn] [datetime] NULL,
 CONSTRAINT [PK_Property] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF)
)
END
GO
/****** Object:  Table [dbo].[Role]    Script Date: 10/29/2014 7:50:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Role]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Role](
	[ID] [tinyint] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](50) NOT NULL,
 CONSTRAINT [PK_Role] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF)
)
END
GO
/****** Object:  Table [dbo].[User]    Script Date: 10/29/2014 7:50:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[User]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[User](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[FirstName] [varchar](50) NOT NULL,
	[LastName] [varchar](50) NOT NULL,
	[Email] [varchar](60) NOT NULL,
	[MobileNo] [varchar](25) NOT NULL,
	[IsEmailAlert] [bit] NOT NULL,
	[IsMobileAlert] [bit] NOT NULL,
	[CustomerId] [int] NULL,
	[RoleId] [tinyint] NOT NULL,
	[IsDelete] [bit] NOT NULL,
	[CreatedBy] [int] NULL,
	[CreatedOn] [datetime] NOT NULL,
	[LastUpdatedBy] [int] NULL,
	[LastUpdatedOn] [datetime] NULL,
 CONSTRAINT [PK_User] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF)
)
END
GO
/****** Object:  Table [dbo].[UserBuilding]    Script Date: 10/29/2014 7:50:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserBuilding]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UserBuilding](
	[UserId] [int] NOT NULL,
	[BuildingId] [tinyint] NOT NULL
)
END
GO
/****** Object:  Table [dbo].[UserProperty]    Script Date: 10/29/2014 7:50:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserProperty]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UserProperty](
	[UserId] [int] NOT NULL,
	[PropertyId] [tinyint] NOT NULL
)
END
GO
/****** Object:  Table [dbo].[Washroom]    Script Date: 10/29/2014 7:50:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Washroom]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Washroom](
	[ID] [tinyint] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](50) NOT NULL,
	[KCIdentifier] [varchar](50) NOT NULL,
	[FloorId] [tinyint] NOT NULL,
	[GenderId] [tinyint] NOT NULL,
	[WingId] [tinyint] NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedBy] [int] NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[LastUpdatedBy] [int] NULL,
	[LastUpdatedOn] [datetime] NULL,
 CONSTRAINT [PK_Washroom] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF)
)
END
GO
/****** Object:  Table [dbo].[Wing]    Script Date: 10/29/2014 7:50:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Wing]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Wing](
	[ID] [tinyint] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](10) NOT NULL,
 CONSTRAINT [PK_Wing] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF)
)
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Address_Country]') AND parent_object_id = OBJECT_ID(N'[dbo].[Address]'))
ALTER TABLE [dbo].[Address]  WITH CHECK ADD  CONSTRAINT [FK_Address_Country] FOREIGN KEY([CountryId])
REFERENCES [dbo].[Country] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Address_Country]') AND parent_object_id = OBJECT_ID(N'[dbo].[Address]'))
ALTER TABLE [dbo].[Address] CHECK CONSTRAINT [FK_Address_Country]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Building_Property]') AND parent_object_id = OBJECT_ID(N'[dbo].[Building]'))
ALTER TABLE [dbo].[Building]  WITH CHECK ADD  CONSTRAINT [FK_Building_Property] FOREIGN KEY([PropertyId])
REFERENCES [dbo].[Property] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Building_Property]') AND parent_object_id = OBJECT_ID(N'[dbo].[Building]'))
ALTER TABLE [dbo].[Building] CHECK CONSTRAINT [FK_Building_Property]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Building_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[Building]'))
ALTER TABLE [dbo].[Building]  WITH CHECK ADD  CONSTRAINT [FK_Building_User] FOREIGN KEY([CreatedBy])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Building_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[Building]'))
ALTER TABLE [dbo].[Building] CHECK CONSTRAINT [FK_Building_User]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Building_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Building]'))
ALTER TABLE [dbo].[Building]  WITH CHECK ADD  CONSTRAINT [FK_Building_User1] FOREIGN KEY([LastUpdatedBy])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Building_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Building]'))
ALTER TABLE [dbo].[Building] CHECK CONSTRAINT [FK_Building_User1]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Customer_Address]') AND parent_object_id = OBJECT_ID(N'[dbo].[Customer]'))
ALTER TABLE [dbo].[Customer]  WITH CHECK ADD  CONSTRAINT [FK_Customer_Address] FOREIGN KEY([AddressId])
REFERENCES [dbo].[Address] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Customer_Address]') AND parent_object_id = OBJECT_ID(N'[dbo].[Customer]'))
ALTER TABLE [dbo].[Customer] CHECK CONSTRAINT [FK_Customer_Address]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Customer_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[Customer]'))
ALTER TABLE [dbo].[Customer]  WITH CHECK ADD  CONSTRAINT [FK_Customer_User] FOREIGN KEY([CreatedBy])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Customer_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[Customer]'))
ALTER TABLE [dbo].[Customer] CHECK CONSTRAINT [FK_Customer_User]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Customer_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Customer]'))
ALTER TABLE [dbo].[Customer]  WITH CHECK ADD  CONSTRAINT [FK_Customer_User1] FOREIGN KEY([LastUpdatedBy])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Customer_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Customer]'))
ALTER TABLE [dbo].[Customer] CHECK CONSTRAINT [FK_Customer_User1]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Device_DeviceType]') AND parent_object_id = OBJECT_ID(N'[dbo].[Device]'))
ALTER TABLE [dbo].[Device]  WITH CHECK ADD  CONSTRAINT [FK_Device_DeviceType] FOREIGN KEY([DeviceTypeId])
REFERENCES [dbo].[DeviceType] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Device_DeviceType]') AND parent_object_id = OBJECT_ID(N'[dbo].[Device]'))
ALTER TABLE [dbo].[Device] CHECK CONSTRAINT [FK_Device_DeviceType]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Device_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[Device]'))
ALTER TABLE [dbo].[Device]  WITH CHECK ADD  CONSTRAINT [FK_Device_User] FOREIGN KEY([CreatedBy])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Device_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[Device]'))
ALTER TABLE [dbo].[Device] CHECK CONSTRAINT [FK_Device_User]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Device_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Device]'))
ALTER TABLE [dbo].[Device]  WITH CHECK ADD  CONSTRAINT [FK_Device_User1] FOREIGN KEY([LastUpdatedBy])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Device_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Device]'))
ALTER TABLE [dbo].[Device] CHECK CONSTRAINT [FK_Device_User1]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_DeviceAlert_AlertType]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceAlert]'))
ALTER TABLE [dbo].[DeviceAlert]  WITH CHECK ADD  CONSTRAINT [FK_DeviceAlert_AlertType] FOREIGN KEY([AlertTypeId])
REFERENCES [dbo].[AlertType] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_DeviceAlert_AlertType]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceAlert]'))
ALTER TABLE [dbo].[DeviceAlert] CHECK CONSTRAINT [FK_DeviceAlert_AlertType]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_DeviceAlert_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceAlert]'))
ALTER TABLE [dbo].[DeviceAlert]  WITH CHECK ADD  CONSTRAINT [FK_DeviceAlert_Device] FOREIGN KEY([DeviceId])
REFERENCES [dbo].[Device] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_DeviceAlert_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceAlert]'))
ALTER TABLE [dbo].[DeviceAlert] CHECK CONSTRAINT [FK_DeviceAlert_Device]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_DeviceWashroom_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceWashroom]'))
ALTER TABLE [dbo].[DeviceWashroom]  WITH CHECK ADD  CONSTRAINT [FK_DeviceWashroom_Device] FOREIGN KEY([DeviceId])
REFERENCES [dbo].[Device] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_DeviceWashroom_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceWashroom]'))
ALTER TABLE [dbo].[DeviceWashroom] CHECK CONSTRAINT [FK_DeviceWashroom_Device]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_DeviceWashroom_Washroom]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceWashroom]'))
ALTER TABLE [dbo].[DeviceWashroom]  WITH CHECK ADD  CONSTRAINT [FK_DeviceWashroom_Washroom] FOREIGN KEY([WashroomId])
REFERENCES [dbo].[Washroom] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_DeviceWashroom_Washroom]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceWashroom]'))
ALTER TABLE [dbo].[DeviceWashroom] CHECK CONSTRAINT [FK_DeviceWashroom_Washroom]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Floor_Building]') AND parent_object_id = OBJECT_ID(N'[dbo].[Floor]'))
ALTER TABLE [dbo].[Floor]  WITH CHECK ADD  CONSTRAINT [FK_Floor_Building] FOREIGN KEY([BuildingId])
REFERENCES [dbo].[Building] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Floor_Building]') AND parent_object_id = OBJECT_ID(N'[dbo].[Floor]'))
ALTER TABLE [dbo].[Floor] CHECK CONSTRAINT [FK_Floor_Building]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Floor_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[Floor]'))
ALTER TABLE [dbo].[Floor]  WITH CHECK ADD  CONSTRAINT [FK_Floor_User] FOREIGN KEY([CreatedBy])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Floor_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[Floor]'))
ALTER TABLE [dbo].[Floor] CHECK CONSTRAINT [FK_Floor_User]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Floor_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Floor]'))
ALTER TABLE [dbo].[Floor]  WITH CHECK ADD  CONSTRAINT [FK_Floor_User1] FOREIGN KEY([LastUpdatedBy])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Floor_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Floor]'))
ALTER TABLE [dbo].[Floor] CHECK CONSTRAINT [FK_Floor_User1]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Property_Address]') AND parent_object_id = OBJECT_ID(N'[dbo].[Property]'))
ALTER TABLE [dbo].[Property]  WITH CHECK ADD  CONSTRAINT [FK_Property_Address] FOREIGN KEY([AddressId])
REFERENCES [dbo].[Address] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Property_Address]') AND parent_object_id = OBJECT_ID(N'[dbo].[Property]'))
ALTER TABLE [dbo].[Property] CHECK CONSTRAINT [FK_Property_Address]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Property_Customer]') AND parent_object_id = OBJECT_ID(N'[dbo].[Property]'))
ALTER TABLE [dbo].[Property]  WITH CHECK ADD  CONSTRAINT [FK_Property_Customer] FOREIGN KEY([CustomerId])
REFERENCES [dbo].[Customer] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Property_Customer]') AND parent_object_id = OBJECT_ID(N'[dbo].[Property]'))
ALTER TABLE [dbo].[Property] CHECK CONSTRAINT [FK_Property_Customer]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Property_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Property]'))
ALTER TABLE [dbo].[Property]  WITH CHECK ADD  CONSTRAINT [FK_Property_User1] FOREIGN KEY([CreatedBy])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Property_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Property]'))
ALTER TABLE [dbo].[Property] CHECK CONSTRAINT [FK_Property_User1]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Property_User2]') AND parent_object_id = OBJECT_ID(N'[dbo].[Property]'))
ALTER TABLE [dbo].[Property]  WITH CHECK ADD  CONSTRAINT [FK_Property_User2] FOREIGN KEY([LastUpdatedBy])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Property_User2]') AND parent_object_id = OBJECT_ID(N'[dbo].[Property]'))
ALTER TABLE [dbo].[Property] CHECK CONSTRAINT [FK_Property_User2]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_User_Customer]') AND parent_object_id = OBJECT_ID(N'[dbo].[User]'))
ALTER TABLE [dbo].[User]  WITH CHECK ADD  CONSTRAINT [FK_User_Customer] FOREIGN KEY([CustomerId])
REFERENCES [dbo].[Customer] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_User_Customer]') AND parent_object_id = OBJECT_ID(N'[dbo].[User]'))
ALTER TABLE [dbo].[User] CHECK CONSTRAINT [FK_User_Customer]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_User_Role]') AND parent_object_id = OBJECT_ID(N'[dbo].[User]'))
ALTER TABLE [dbo].[User]  WITH CHECK ADD  CONSTRAINT [FK_User_Role] FOREIGN KEY([RoleId])
REFERENCES [dbo].[Role] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_User_Role]') AND parent_object_id = OBJECT_ID(N'[dbo].[User]'))
ALTER TABLE [dbo].[User] CHECK CONSTRAINT [FK_User_Role]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_User_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[User]'))
ALTER TABLE [dbo].[User]  WITH CHECK ADD  CONSTRAINT [FK_User_User] FOREIGN KEY([CreatedBy])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_User_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[User]'))
ALTER TABLE [dbo].[User] CHECK CONSTRAINT [FK_User_User]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_User_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[User]'))
ALTER TABLE [dbo].[User]  WITH CHECK ADD  CONSTRAINT [FK_User_User1] FOREIGN KEY([LastUpdatedBy])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_User_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[User]'))
ALTER TABLE [dbo].[User] CHECK CONSTRAINT [FK_User_User1]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserBuilding_Building]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserBuilding]'))
ALTER TABLE [dbo].[UserBuilding]  WITH CHECK ADD  CONSTRAINT [FK_UserBuilding_Building] FOREIGN KEY([BuildingId])
REFERENCES [dbo].[Building] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserBuilding_Building]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserBuilding]'))
ALTER TABLE [dbo].[UserBuilding] CHECK CONSTRAINT [FK_UserBuilding_Building]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserBuilding_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserBuilding]'))
ALTER TABLE [dbo].[UserBuilding]  WITH CHECK ADD  CONSTRAINT [FK_UserBuilding_User] FOREIGN KEY([UserId])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserBuilding_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserBuilding]'))
ALTER TABLE [dbo].[UserBuilding] CHECK CONSTRAINT [FK_UserBuilding_User]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserProperty_Property]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserProperty]'))
ALTER TABLE [dbo].[UserProperty]  WITH CHECK ADD  CONSTRAINT [FK_UserProperty_Property] FOREIGN KEY([PropertyId])
REFERENCES [dbo].[Property] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserProperty_Property]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserProperty]'))
ALTER TABLE [dbo].[UserProperty] CHECK CONSTRAINT [FK_UserProperty_Property]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserProperty_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserProperty]'))
ALTER TABLE [dbo].[UserProperty]  WITH CHECK ADD  CONSTRAINT [FK_UserProperty_User] FOREIGN KEY([UserId])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserProperty_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserProperty]'))
ALTER TABLE [dbo].[UserProperty] CHECK CONSTRAINT [FK_UserProperty_User]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Washroom_Floor]') AND parent_object_id = OBJECT_ID(N'[dbo].[Washroom]'))
ALTER TABLE [dbo].[Washroom]  WITH CHECK ADD  CONSTRAINT [FK_Washroom_Floor] FOREIGN KEY([FloorId])
REFERENCES [dbo].[Floor] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Washroom_Floor]') AND parent_object_id = OBJECT_ID(N'[dbo].[Washroom]'))
ALTER TABLE [dbo].[Washroom] CHECK CONSTRAINT [FK_Washroom_Floor]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Washroom_Gender]') AND parent_object_id = OBJECT_ID(N'[dbo].[Washroom]'))
ALTER TABLE [dbo].[Washroom]  WITH CHECK ADD  CONSTRAINT [FK_Washroom_Gender] FOREIGN KEY([GenderId])
REFERENCES [dbo].[Gender] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Washroom_Gender]') AND parent_object_id = OBJECT_ID(N'[dbo].[Washroom]'))
ALTER TABLE [dbo].[Washroom] CHECK CONSTRAINT [FK_Washroom_Gender]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Washroom_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[Washroom]'))
ALTER TABLE [dbo].[Washroom]  WITH CHECK ADD  CONSTRAINT [FK_Washroom_User] FOREIGN KEY([LastUpdatedBy])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Washroom_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[Washroom]'))
ALTER TABLE [dbo].[Washroom] CHECK CONSTRAINT [FK_Washroom_User]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Washroom_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Washroom]'))
ALTER TABLE [dbo].[Washroom]  WITH CHECK ADD  CONSTRAINT [FK_Washroom_User1] FOREIGN KEY([CreatedBy])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Washroom_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Washroom]'))
ALTER TABLE [dbo].[Washroom] CHECK CONSTRAINT [FK_Washroom_User1]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Washroom_Wing]') AND parent_object_id = OBJECT_ID(N'[dbo].[Washroom]'))
ALTER TABLE [dbo].[Washroom]  WITH CHECK ADD  CONSTRAINT [FK_Washroom_Wing] FOREIGN KEY([WingId])
REFERENCES [dbo].[Wing] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Washroom_Wing]') AND parent_object_id = OBJECT_ID(N'[dbo].[Washroom]'))
ALTER TABLE [dbo].[Washroom] CHECK CONSTRAINT [FK_Washroom_Wing]
GO
