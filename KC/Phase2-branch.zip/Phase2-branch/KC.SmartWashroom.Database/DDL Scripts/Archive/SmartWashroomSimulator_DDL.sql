IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_SimulatorAlertFixStatus_AlertType]') AND parent_object_id = OBJECT_ID(N'[dbo].[SimulatorDeviceAlert]'))
ALTER TABLE [dbo].[SimulatorDeviceAlert] DROP CONSTRAINT [FK_SimulatorAlertFixStatus_AlertType]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_SimulatorAlertFixStatus_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[SimulatorDeviceAlert]'))
ALTER TABLE [dbo].[SimulatorDeviceAlert] DROP CONSTRAINT [FK_SimulatorAlertFixStatus_Device]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_SimulatorTempDeviceLog_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[SimulatorTempDeviceLog]'))
ALTER TABLE [dbo].[SimulatorTempDeviceLog] DROP CONSTRAINT [FK_SimulatorTempDeviceLog_Device]
GO
/****** Object:  Table [dbo].[SimulatorDeviceAlert]    Script Date: 10/20/2014 9:19:35 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SimulatorDeviceAlert]') AND type in (N'U'))
DROP TABLE [dbo].[SimulatorDeviceAlert]
GO
/****** Object:  Table [dbo].[SimulatorTempDeviceLog]    Script Date: 10/22/2014 8:19:35 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SimulatorTempDeviceLog]') AND type in (N'U'))
DROP TABLE [dbo].[SimulatorTempDeviceLog]
GO
/****** Object:  Table [dbo].[SimulatorDeviceAlert]    Script Date: 10/20/2014 8:57:58 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SimulatorDeviceAlert]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[SimulatorDeviceAlert](
	[DeviceId] [varchar](30) NOT NULL,
	[AlertTypeId] [tinyint] NOT NULL,
	[IsAlert] [bit] NOT NULL
CONSTRAINT [PK_SimulatorDeviceAlert] PRIMARY KEY CLUSTERED 
(
	[DeviceId] ASC,
	[AlertTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[SimulatorTempDeviceLog]    Script Date: 10/22/2014 8:15:58 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SimulatorTempDeviceLog]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[SimulatorTempDeviceLog](
	[DeviceId] [varchar](30) NOT NULL,
	[DeviceLog] [varchar](max) NOT NULL,
 CONSTRAINT [PK_DeviceId] PRIMARY KEY CLUSTERED 
(
	[DeviceId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
END
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_SimulatorAlertFixStatus_AlertType]') AND parent_object_id = OBJECT_ID(N'[dbo].[SimulatorDeviceAlert]'))
ALTER TABLE [dbo].[SimulatorDeviceAlert]  WITH CHECK ADD  CONSTRAINT [FK_SimulatorAlertFixStatus_AlertType] FOREIGN KEY([AlertTypeId])
REFERENCES [dbo].[AlertType] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_SimulatorAlertFixStatus_AlertType]') AND parent_object_id = OBJECT_ID(N'[dbo].[SimulatorDeviceAlert]'))
ALTER TABLE [dbo].[SimulatorDeviceAlert] CHECK CONSTRAINT [FK_SimulatorAlertFixStatus_AlertType]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_SimulatorAlertFixStatus_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[SimulatorDeviceAlert]'))
ALTER TABLE [dbo].[SimulatorDeviceAlert]  WITH CHECK ADD  CONSTRAINT [FK_SimulatorAlertFixStatus_Device] FOREIGN KEY([DeviceId])
REFERENCES [dbo].[Device] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_SimulatorAlertFixStatus_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[SimulatorDeviceAlert]'))
ALTER TABLE [dbo].[SimulatorDeviceAlert] CHECK CONSTRAINT [FK_SimulatorAlertFixStatus_Device]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_SimulatorTempDeviceLog_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[SimulatorTempDeviceLog]'))
ALTER TABLE [dbo].[SimulatorTempDeviceLog]  WITH CHECK ADD  CONSTRAINT [FK_SimulatorTempDeviceLog_Device] FOREIGN KEY([DeviceId])
REFERENCES [dbo].[Device] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_SimulatorTempDeviceLog_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[SimulatorTempDeviceLog]'))
ALTER TABLE [dbo].[SimulatorTempDeviceLog] CHECK CONSTRAINT [FK_SimulatorTempDeviceLog_Device]
GO