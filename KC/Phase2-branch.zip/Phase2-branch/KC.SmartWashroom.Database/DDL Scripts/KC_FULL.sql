IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Washroom_Wing]') AND parent_object_id = OBJECT_ID(N'[dbo].[Washroom]'))
ALTER TABLE [dbo].[Washroom] DROP CONSTRAINT [FK_Washroom_Wing]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Washroom_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Washroom]'))
ALTER TABLE [dbo].[Washroom] DROP CONSTRAINT [FK_Washroom_User1]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Washroom_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[Washroom]'))
ALTER TABLE [dbo].[Washroom] DROP CONSTRAINT [FK_Washroom_User]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Washroom_Gender]') AND parent_object_id = OBJECT_ID(N'[dbo].[Washroom]'))
ALTER TABLE [dbo].[Washroom] DROP CONSTRAINT [FK_Washroom_Gender]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Washroom_Floor]') AND parent_object_id = OBJECT_ID(N'[dbo].[Washroom]'))
ALTER TABLE [dbo].[Washroom] DROP CONSTRAINT [FK_Washroom_Floor]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserProperty_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserProperty]'))
ALTER TABLE [dbo].[UserProperty] DROP CONSTRAINT [FK_UserProperty_User1]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserProperty_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserProperty]'))
ALTER TABLE [dbo].[UserProperty] DROP CONSTRAINT [FK_UserProperty_User]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserProperty_Property]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserProperty]'))
ALTER TABLE [dbo].[UserProperty] DROP CONSTRAINT [FK_UserProperty_Property]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserBuilding_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserBuilding]'))
ALTER TABLE [dbo].[UserBuilding] DROP CONSTRAINT [FK_UserBuilding_User]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserBuilding_Building]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserBuilding]'))
ALTER TABLE [dbo].[UserBuilding] DROP CONSTRAINT [FK_UserBuilding_Building]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_User_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[User]'))
ALTER TABLE [dbo].[User] DROP CONSTRAINT [FK_User_User1]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_User_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[User]'))
ALTER TABLE [dbo].[User] DROP CONSTRAINT [FK_User_User]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_User_Role]') AND parent_object_id = OBJECT_ID(N'[dbo].[User]'))
ALTER TABLE [dbo].[User] DROP CONSTRAINT [FK_User_Role]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_User_Customer]') AND parent_object_id = OBJECT_ID(N'[dbo].[User]'))
ALTER TABLE [dbo].[User] DROP CONSTRAINT [FK_User_Customer]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_SimulatorTempDeviceLog_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[SimulatorTempDeviceLog]'))
ALTER TABLE [dbo].[SimulatorTempDeviceLog] DROP CONSTRAINT [FK_SimulatorTempDeviceLog_Device]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_SimulatorRaisedAlert_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[SimulatorRaisedAlert]'))
ALTER TABLE [dbo].[SimulatorRaisedAlert] DROP CONSTRAINT [FK_SimulatorRaisedAlert_Device]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_SimulatorRaisedAlert_AlertType]') AND parent_object_id = OBJECT_ID(N'[dbo].[SimulatorRaisedAlert]'))
ALTER TABLE [dbo].[SimulatorRaisedAlert] DROP CONSTRAINT [FK_SimulatorRaisedAlert_AlertType]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_SimulatorAlertFixStatus_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[SimulatorDeviceAlert]'))
ALTER TABLE [dbo].[SimulatorDeviceAlert] DROP CONSTRAINT [FK_SimulatorAlertFixStatus_Device]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_SimulatorAlertFixStatus_AlertType]') AND parent_object_id = OBJECT_ID(N'[dbo].[SimulatorDeviceAlert]'))
ALTER TABLE [dbo].[SimulatorDeviceAlert] DROP CONSTRAINT [FK_SimulatorAlertFixStatus_AlertType]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_RolePermission_Role]') AND parent_object_id = OBJECT_ID(N'[dbo].[RolePermission]'))
ALTER TABLE [dbo].[RolePermission] DROP CONSTRAINT [FK_RolePermission_Role]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_RolePermission_Feature]') AND parent_object_id = OBJECT_ID(N'[dbo].[RolePermission]'))
ALTER TABLE [dbo].[RolePermission] DROP CONSTRAINT [FK_RolePermission_Feature]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Property_User2]') AND parent_object_id = OBJECT_ID(N'[dbo].[Property]'))
ALTER TABLE [dbo].[Property] DROP CONSTRAINT [FK_Property_User2]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Property_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Property]'))
ALTER TABLE [dbo].[Property] DROP CONSTRAINT [FK_Property_User1]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Property_Customer]') AND parent_object_id = OBJECT_ID(N'[dbo].[Property]'))
ALTER TABLE [dbo].[Property] DROP CONSTRAINT [FK_Property_Customer]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Property_Address]') AND parent_object_id = OBJECT_ID(N'[dbo].[Property]'))
ALTER TABLE [dbo].[Property] DROP CONSTRAINT [FK_Property_Address]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Floor_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Floor]'))
ALTER TABLE [dbo].[Floor] DROP CONSTRAINT [FK_Floor_User1]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Floor_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[Floor]'))
ALTER TABLE [dbo].[Floor] DROP CONSTRAINT [FK_Floor_User]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Floor_Building]') AND parent_object_id = OBJECT_ID(N'[dbo].[Floor]'))
ALTER TABLE [dbo].[Floor] DROP CONSTRAINT [FK_Floor_Building]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_DeviceWashroom_Washroom]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceWashroom]'))
ALTER TABLE [dbo].[DeviceWashroom] DROP CONSTRAINT [FK_DeviceWashroom_Washroom]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_DeviceWashroom_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceWashroom]'))
ALTER TABLE [dbo].[DeviceWashroom] DROP CONSTRAINT [FK_DeviceWashroom_Device]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[fk_devicetype]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceAlertMapping]'))
ALTER TABLE [dbo].[DeviceAlertMapping] DROP CONSTRAINT [fk_devicetype]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[fk_devicealert]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceAlertMapping]'))
ALTER TABLE [dbo].[DeviceAlertMapping] DROP CONSTRAINT [fk_devicealert]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[fk_alertName]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceAlertMapping]'))
ALTER TABLE [dbo].[DeviceAlertMapping] DROP CONSTRAINT [fk_alertName]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_DeviceAlert_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceAlert]'))
ALTER TABLE [dbo].[DeviceAlert] DROP CONSTRAINT [FK_DeviceAlert_Device]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_DeviceAlert_AlertType]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceAlert]'))
ALTER TABLE [dbo].[DeviceAlert] DROP CONSTRAINT [FK_DeviceAlert_AlertType]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Device_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Device]'))
ALTER TABLE [dbo].[Device] DROP CONSTRAINT [FK_Device_User1]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Device_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[Device]'))
ALTER TABLE [dbo].[Device] DROP CONSTRAINT [FK_Device_User]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Device_DeviceType]') AND parent_object_id = OBJECT_ID(N'[dbo].[Device]'))
ALTER TABLE [dbo].[Device] DROP CONSTRAINT [FK_Device_DeviceType]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Customer_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Customer]'))
ALTER TABLE [dbo].[Customer] DROP CONSTRAINT [FK_Customer_User1]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Customer_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[Customer]'))
ALTER TABLE [dbo].[Customer] DROP CONSTRAINT [FK_Customer_User]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Customer_Address]') AND parent_object_id = OBJECT_ID(N'[dbo].[Customer]'))
ALTER TABLE [dbo].[Customer] DROP CONSTRAINT [FK_Customer_Address]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Building_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Building]'))
ALTER TABLE [dbo].[Building] DROP CONSTRAINT [FK_Building_User1]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Building_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[Building]'))
ALTER TABLE [dbo].[Building] DROP CONSTRAINT [FK_Building_User]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Building_Property]') AND parent_object_id = OBJECT_ID(N'[dbo].[Building]'))
ALTER TABLE [dbo].[Building] DROP CONSTRAINT [FK_Building_Property]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Address_Country]') AND parent_object_id = OBJECT_ID(N'[dbo].[Address]'))
ALTER TABLE [dbo].[Address] DROP CONSTRAINT [FK_Address_Country]
GO
-- --------------------------------------------------
-- Begin: Dropping FOREIGN KEY for API Return Parameters
-- --------------------------------------------------
IF OBJECT_ID(N'[dbo].[FK_CreatedBy_ParameterGroup]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DeviceParameterGroup] DROP CONSTRAINT [FK_CreatedBy_ParameterGroup];
GO
IF OBJECT_ID(N'[dbo].[FK_ModifiedBy_ParameterGroup]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DeviceParameterGroup] DROP CONSTRAINT [FK_ModifiedBy_ParameterGroup];
GO
IF OBJECT_ID(N'[dbo].[FK_Parameter_Group]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DeviceParameter] DROP CONSTRAINT [FK_Parameter_Group];
GO
IF OBJECT_ID(N'[dbo].[FK_Device_ParameterValue]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DeviceParameterValue] DROP CONSTRAINT [FK_Device_ParameterValue];
GO
IF OBJECT_ID(N'[dbo].[FK_DeviceType_Parameter]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DeviceParameter] DROP CONSTRAINT [FK_DeviceType_Parameter];
GO
IF OBJECT_ID(N'[dbo].[FK_CreatedByUser_Parameter]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DeviceParameter] DROP CONSTRAINT [FK_CreatedByUser_Parameter];
GO
IF OBJECT_ID(N'[dbo].[FK_ModifiedByUser_Parameter]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DeviceParameter] DROP CONSTRAINT [FK_ModifiedByUser_Parameter];
GO
IF OBJECT_ID(N'[dbo].[FK_Parameter_ParameterValue]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DeviceParameterValue] DROP CONSTRAINT [FK_Parameter_ParameterValue];
GO
IF OBJECT_ID(N'[dbo].[FK_Customer_ParameterValue]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DeviceParameterValue] DROP CONSTRAINT [FK_Customer_ParameterValue];
GO
IF OBJECT_ID(N'[dbo].[FK_CreatedBy_ParameterValue]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DeviceParameterValue] DROP CONSTRAINT [FK_CreatedBy_ParameterValue];
GO
IF OBJECT_ID(N'[dbo].[FK_ModifiedBy_ParameterValue]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DeviceParameterValue] DROP CONSTRAINT [FK_ModifiedBy_ParameterValue];
GO

-- --------------------------------------------------
-- End: Dropping FOREIGN KEY for API Return Parameters
-- --------------------------------------------------

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DF__Role__RoleLevel__367C1819]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[Role] DROP CONSTRAINT [DF__Role__RoleLevel__367C1819]
END

GO
/****** Object:  UserDefinedFunction [dbo].[GetDeviceProperty]    Script Date: 12/15/2014 5:21:09 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetDeviceProperty]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[GetDeviceProperty]
GO
/****** Object:  UserDefinedFunction [dbo].[GetAllDevicesAndProperties]    Script Date: 12/15/2014 5:21:09 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetAllDevicesAndProperties]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[GetAllDevicesAndProperties]
GO

/****** Object:  Table [dbo].[Wing]    Script Date: 12/15/2014 5:21:09 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Wing]') AND type in (N'U'))
DROP TABLE [dbo].[Wing]
GO
/****** Object:  Table [dbo].[Washroom]    Script Date: 12/15/2014 5:21:09 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Washroom]') AND type in (N'U'))
DROP TABLE [dbo].[Washroom]
GO
/****** Object:  Table [dbo].[UserProperty]    Script Date: 12/15/2014 5:21:09 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserProperty]') AND type in (N'U'))
DROP TABLE [dbo].[UserProperty]
GO
/****** Object:  Table [dbo].[UserBuilding]    Script Date: 12/15/2014 5:21:09 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserBuilding]') AND type in (N'U'))
DROP TABLE [dbo].[UserBuilding]
GO
/****** Object:  Table [dbo].[User]    Script Date: 12/15/2014 5:21:09 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[User]') AND type in (N'U'))
DROP TABLE [dbo].[User]
GO
/****** Object:  Table [dbo].[SimulatorTempDeviceLog]    Script Date: 12/15/2014 5:21:09 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SimulatorTempDeviceLog]') AND type in (N'U'))
DROP TABLE [dbo].[SimulatorTempDeviceLog]
GO
/****** Object:  Table [dbo].[SimulatorRaisedAlert]    Script Date: 12/15/2014 5:21:09 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SimulatorRaisedAlert]') AND type in (N'U'))
DROP TABLE [dbo].[SimulatorRaisedAlert]
GO
/****** Object:  Table [dbo].[SimulatorDeviceAlert]    Script Date: 12/15/2014 5:21:09 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SimulatorDeviceAlert]') AND type in (N'U'))
DROP TABLE [dbo].[SimulatorDeviceAlert]
GO
/****** Object:  Table [dbo].[RolePermission]    Script Date: 12/15/2014 5:21:09 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RolePermission]') AND type in (N'U'))
DROP TABLE [dbo].[RolePermission]
GO
/****** Object:  Table [dbo].[Role]    Script Date: 12/15/2014 5:21:09 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Role]') AND type in (N'U'))
DROP TABLE [dbo].[Role]
GO
/****** Object:  Table [dbo].[Property]    Script Date: 12/15/2014 5:21:09 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Property]') AND type in (N'U'))
DROP TABLE [dbo].[Property]
GO
/****** Object:  Table [dbo].[Product]    Script Date: 12/15/2014 5:21:09 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Product]') AND type in (N'U'))
DROP TABLE [dbo].[Product]
GO
/****** Object:  Table [dbo].[Gender]    Script Date: 12/15/2014 5:21:09 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Gender]') AND type in (N'U'))
DROP TABLE [dbo].[Gender]
GO
/****** Object:  Table [dbo].[Floor]    Script Date: 12/15/2014 5:21:09 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Floor]') AND type in (N'U'))
DROP TABLE [dbo].[Floor]
GO
/****** Object:  Table [dbo].[Feature]    Script Date: 12/15/2014 5:21:09 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Feature]') AND type in (N'U'))
DROP TABLE [dbo].[Feature]
GO
/****** Object:  Table [dbo].[ESoapRefillSize]    Script Date: 12/15/2014 5:21:09 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ESoapRefillSize]') AND type in (N'U'))
DROP TABLE [dbo].[ESoapRefillSize]
GO
/****** Object:  Table [dbo].[DeviceWashroom]    Script Date: 12/15/2014 5:21:09 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeviceWashroom]') AND type in (N'U'))
DROP TABLE [dbo].[DeviceWashroom]
GO
/****** Object:  Table [dbo].[DeviceType]    Script Date: 12/15/2014 5:21:09 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeviceType]') AND type in (N'U'))
DROP TABLE [dbo].[DeviceType]
GO
/****** Object:  Table [dbo].[DeviceAlertName]    Script Date: 12/15/2014 5:21:09 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeviceAlertName]') AND type in (N'U'))
DROP TABLE [dbo].[DeviceAlertName]
GO
/****** Object:  Table [dbo].[DeviceAlertMapping]    Script Date: 12/15/2014 5:21:09 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeviceAlertMapping]') AND type in (N'U'))
DROP TABLE [dbo].[DeviceAlertMapping]
GO
/****** Object:  Table [dbo].[DeviceAlert]    Script Date: 12/15/2014 5:21:09 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeviceAlert]') AND type in (N'U'))
DROP TABLE [dbo].[DeviceAlert]
GO
/****** Object:  Table [dbo].[Device]    Script Date: 12/15/2014 5:21:09 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Device]') AND type in (N'U'))
DROP TABLE [dbo].[Device]
GO
/****** Object:  Table [dbo].[Customer]    Script Date: 12/15/2014 5:21:09 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Customer]') AND type in (N'U'))
DROP TABLE [dbo].[Customer]
GO
/****** Object:  Table [dbo].[Country]    Script Date: 12/15/2014 5:21:09 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Country]') AND type in (N'U'))
DROP TABLE [dbo].[Country]
GO
/****** Object:  Table [dbo].[Building]    Script Date: 12/15/2014 5:21:09 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Building]') AND type in (N'U'))
DROP TABLE [dbo].[Building]
GO
/****** Object:  Table [dbo].[AlertType]    Script Date: 12/15/2014 5:21:09 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AlertType]') AND type in (N'U'))
DROP TABLE [dbo].[AlertType]
GO
/****** Object:  Table [dbo].[Address]    Script Date: 12/15/2014 5:21:09 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Address]') AND type in (N'U'))
DROP TABLE [dbo].[Address]
GO
/****** Object:  Table [dbo].[Activity]    Script Date: 12/15/2014 5:21:09 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Activity]') AND type in (N'U'))
DROP TABLE [dbo].[Activity]
GO
/****** Object:  Table [dbo].[ProductRefillDetail]    Script Date: 12/15/2014 5:21:09 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProductRefillDetail]') AND type in (N'U'))
DROP TABLE [dbo].[ProductRefillDetail]
GO

-- --------------------------------------------------
-- Begin: Dropping TABLES for API Return Parameters
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[DeviceParameterGroup]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DeviceParameterGroup];
GO
IF OBJECT_ID(N'[dbo].[DeviceParameter]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DeviceParameter];
GO
IF OBJECT_ID(N'[dbo].[DeviceParameterValue]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DeviceParameterValue];
GO
-- --------------------------------------------------
-- End: Dropping TABLES for API Return Parameters
-- --------------------------------------------------

/****** Object:  Table [dbo].[Activity]    Script Date: 12/15/2014 5:21:09 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Activity]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Activity](
    [ID] [tinyint] IDENTITY(1,1) NOT NULL,
    [Name] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_Activity] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Address]    Script Date: 12/15/2014 5:21:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Address]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Address](
    [ID] [int] IDENTITY(1,1) NOT NULL,
    [Street] [nvarchar](100) NULL,
    [BuildingAddress] [nvarchar](100) NULL,
    [City] [nvarchar](50) NULL,
    [State] [nvarchar](50) NULL,
    [CountryId] [tinyint] NOT NULL,
    [Zip] [nvarchar](20) NULL,
 CONSTRAINT [PK_Address] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[AlertType]    Script Date: 12/15/2014 5:21:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AlertType]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[AlertType](
    [ID] [tinyint] IDENTITY(1,1) NOT NULL,
    [Type] [nvarchar](10) NOT NULL,
 CONSTRAINT [PK_AlertType] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Building]    Script Date: 12/15/2014 5:21:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Building]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Building](
    [ID] [int] IDENTITY(1,1) NOT NULL,
    [PropertyId] [int] NOT NULL,
    [Name] [nvarchar](150) NOT NULL,
    [IsActive] [bit] NOT NULL,
    [CreatedBy] [int] NOT NULL,
    [CreatedOn] [datetime] NOT NULL,
    [LastUpdatedBy] [int] NULL,
    [LastUpdatedOn] [datetime] NULL,
 CONSTRAINT [PK_Building] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Country]    Script Date: 12/15/2014 5:21:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Country]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Country](
    [ID] [tinyint] IDENTITY(1,1) NOT NULL,
    [Name] [nvarchar](100) NOT NULL,
 CONSTRAINT [PK_Country] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Customer]    Script Date: 12/15/2014 5:21:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Customer]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Customer](
    [ID] [int] IDENTITY(1,1) NOT NULL,
    [Name] [nvarchar](150) NOT NULL,
    [AddressId] [int] NOT NULL,
    [IsActive] [bit] NOT NULL,
    [CreatedBy] [int] NOT NULL,
    [CreatedOn] [datetime] NOT NULL,
    [LastUpdatedBy] [int] NULL,
    [LastUpdatedOn] [datetime] NULL,
 CONSTRAINT [PK_Customer] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Device]    Script Date: 12/15/2014 5:21:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Device]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Device](
    [ID] [nvarchar](30) NOT NULL,
    [Name] [nvarchar](50) NOT NULL,
    [ImageUrl] [nvarchar](1000) NOT NULL,
    [DeviceTypeId] [tinyint] NOT NULL,
    [IsActive] [bit] NOT NULL,
    [CreatedBy] [int] NOT NULL,
    [CreatedOn] [datetime] NOT NULL,
    [LastUpdatedBy] [int] NULL,
    [LastUpdatedOn] [datetime] NULL,
 CONSTRAINT [PK_Device] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[DeviceAlert]    Script Date: 12/15/2014 5:21:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeviceAlert]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[DeviceAlert](
    [DeviceId] [nvarchar](30) NOT NULL,
    [AlertTypeId] [tinyint] NOT NULL,
    [ReceivedOn] [datetime] NOT NULL,
 CONSTRAINT [PK_DeviceAlert] PRIMARY KEY CLUSTERED 
(
    [DeviceId] ASC,
    [AlertTypeId] ASC,
    [ReceivedOn] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[DeviceAlertMapping]    Script Date: 12/15/2014 5:21:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeviceAlertMapping]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[DeviceAlertMapping](
    [ID] [int] IDENTITY(1,1) NOT NULL,
    [DeviceTypeId] [tinyint] NOT NULL,
    [AlertTypeId] [tinyint] NOT NULL,
    [AlertNameId] [int] NULL,
 CONSTRAINT [pk_DeviceAlertMapping] PRIMARY KEY CLUSTERED 
(
    [DeviceTypeId] ASC,
    [AlertTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[DeviceAlertName]    Script Date: 12/15/2014 5:21:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeviceAlertName]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[DeviceAlertName](
    [ID] [int] IDENTITY(1,1) NOT NULL,
    [AlertName] [nvarchar](60) NOT NULL,
PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[DeviceType]    Script Date: 12/15/2014 5:21:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeviceType]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[DeviceType](
    [ID] [tinyint] IDENTITY(1,1) NOT NULL,
    [Name] [nvarchar](10) NOT NULL,
 CONSTRAINT [PK_DeviceType] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[DeviceWashroom]    Script Date: 12/15/2014 5:21:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeviceWashroom]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[DeviceWashroom](
    [ID] [int] IDENTITY(1,1) NOT NULL,
    [DeviceId] [nvarchar](30) NOT NULL,
    [WashroomId] [int] NOT NULL,
    [StartDate] [datetime] NOT NULL,
    [EndDate] [datetime] NOT NULL,
 CONSTRAINT [PK_DeviceWashroom] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[ESoapRefillSize]    Script Date: 12/15/2014 5:21:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ESoapRefillSize]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ESoapRefillSize](
    [ID] [tinyint] IDENTITY(1,1) NOT NULL,
    [Size] [nchar](1) NOT NULL,
    [Quantity] [int] NOT NULL,
 CONSTRAINT [PK_ESoapRefillSize] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[Feature]    Script Date: 12/15/2014 5:21:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Feature]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Feature](
    [ID] [int] IDENTITY(1,1) NOT NULL,
    [Name] [nvarchar](70) NOT NULL,
 CONSTRAINT [PK_Feature] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Floor]    Script Date: 12/15/2014 5:21:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Floor]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Floor](
    [ID] [int] IDENTITY(1,1) NOT NULL,
    [BuildingId] [int] NOT NULL,
    [FloorLevel] [tinyint] NOT NULL,
    [IsActive] [bit] NOT NULL,
    [CreatedBy] [int] NOT NULL,
    [CreatedOn] [datetime] NOT NULL,
    [LastUpdatedBy] [int] NULL,
    [LastUpdatedOn] [datetime] NULL,
 CONSTRAINT [PK_Floor] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[Gender]    Script Date: 12/15/2014 5:21:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Gender]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Gender](
    [ID] [tinyint] IDENTITY(1,1) NOT NULL,
    [Name] [nvarchar](10) NOT NULL,
 CONSTRAINT [PK_Gender] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Product]    Script Date: 12/15/2014 5:21:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Product]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Product](
    [ID] [tinyint] IDENTITY(1,1) NOT NULL,
    [Type] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_Product] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[ProductRefillDetail]    Script Date: 12/15/2014 5:21:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProductRefillDetail]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ProductRefillDetail](
    [ID] [int] IDENTITY(1,1) NOT NULL,
    [ProductId] [tinyint] NOT NULL,
    [Size] [char](1) NOT NULL,
    [RefillValue] [decimal](18, 0) NOT NULL,
 CONSTRAINT [PK_ProductRefillDetail] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Property]    Script Date: 12/15/2014 5:21:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Property]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Property](
    [ID] [int] IDENTITY(1,1) NOT NULL,
    [CustomerId] [int] NOT NULL,
    [PropertyName] [nvarchar](150) NOT NULL,
    [LocationTimeZone] [nvarchar](60) NOT NULL,
    [AddressId] [int] NOT NULL,
    [ImageUrl] [nvarchar](1000) NOT NULL,
    [IsActive] [bit] NOT NULL,
    [CreatedBy] [int] NOT NULL,
    [CreatedOn] [datetime] NOT NULL,
    [LastUpdatedBy] [int] NULL,
    [LastUpdatedOn] [datetime] NULL,
 CONSTRAINT [PK_Property] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Role]    Script Date: 12/15/2014 5:21:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Role]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Role](
    [ID] [tinyint] IDENTITY(1,1) NOT NULL,
    [Name] [nvarchar](50) NOT NULL,
    [RoleLevel] [int] NOT NULL,
 CONSTRAINT [PK_Role] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[RolePermission]    Script Date: 12/15/2014 5:21:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RolePermission]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[RolePermission](
    [ID] [int] IDENTITY(1,1) NOT NULL,
    [FeatureId] [int] NOT NULL,
    [RoleId] [tinyint] NOT NULL,
 CONSTRAINT [PK_RolePermission] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[SimulatorDeviceAlert]    Script Date: 12/15/2014 5:21:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SimulatorDeviceAlert]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[SimulatorDeviceAlert](
    [DeviceId] [nvarchar](30) NOT NULL,
    [AlertTypeId] [tinyint] NOT NULL,
    [IsAlert] [bit] NOT NULL,
 CONSTRAINT [PK_SimulatorDeviceAlert] PRIMARY KEY CLUSTERED 
(
    [DeviceId] ASC,
    [AlertTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[SimulatorRaisedAlert]    Script Date: 12/15/2014 5:21:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SimulatorRaisedAlert]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[SimulatorRaisedAlert](
    [DeviceId] [nvarchar](30) NOT NULL,
    [AlertTypeId] [tinyint] NOT NULL,
    [LogTime] [datetime] NOT NULL,
 CONSTRAINT [PK_SimulatorRaisedAlert] PRIMARY KEY CLUSTERED 
(
    [DeviceId] ASC,
    [AlertTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[SimulatorTempDeviceLog]    Script Date: 12/15/2014 5:21:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SimulatorTempDeviceLog]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[SimulatorTempDeviceLog](
    [DeviceId] [nvarchar](30) NOT NULL,
    [DeviceLog] [nvarchar](max) NOT NULL,
 CONSTRAINT [PK_DeviceId] PRIMARY KEY CLUSTERED 
(
    [DeviceId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[User]    Script Date: 12/15/2014 5:21:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[User]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[User](
    [ID] [int] IDENTITY(1,1) NOT NULL,
    [FirstName] [nvarchar](50) NOT NULL,
    [LastName] [nvarchar](50) NOT NULL,
    [Email] [nvarchar](60) NULL,
    CONSTRAINT UNIQE_EMAIL UNIQUE(Email),
    [MobileNo] [nvarchar](25) NULL,
    [IsEmailAlert] [bit] NOT NULL,
    [IsMobileAlert] [bit] NOT NULL,
    [CustomerId] [int] NULL,
    [RoleId] [tinyint] NOT NULL,
    [IsDelete] [bit] NOT NULL,
    [CreatedBy] [int] NULL,
    [CreatedOn] [datetime] NOT NULL,
    [LastUpdatedBy] [int] NULL,
    [LastUpdatedOn] [datetime] NULL
) ON [PRIMARY]
SET ANSI_PADDING OFF
ALTER TABLE [dbo].[User] ADD [PasswordSalt] [nvarchar](100) NULL
ALTER TABLE [dbo].[User] ADD [Password] [nvarchar](100) NULL
ALTER TABLE [dbo].[User] ADD [IsAccountLocked] [bit] NULL
ALTER TABLE [dbo].[User] ADD [IsFirstLogin] [bit] NULL
 CONSTRAINT [PK_User] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[UserBuilding]    Script Date: 12/15/2014 5:21:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserBuilding]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UserBuilding](
    [UserId] [int] NOT NULL,
    [BuildingId] [int] NOT NULL,
    [CreatedBy] [int] NOT NULL,
    [CreatedOn] [datetime] NOT NULL,
    [ID] [int] IDENTITY(1,1) NOT NULL,
PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[UserProperty]    Script Date: 12/15/2014 5:21:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserProperty]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UserProperty](
    [UserPropertyId] [int] IDENTITY(1,1) NOT NULL,
    [UserId] [int] NOT NULL,
    [PropertyId] [int] NOT NULL,
    [CreatedBy] [int] NOT NULL,
    [CreatedOn] [datetime] NOT NULL,
    [LastUpdatedBy] [int] NULL,
    [LastUpdatedOn] [datetime] NULL,
 CONSTRAINT [PK_UserProperty] PRIMARY KEY CLUSTERED 
(
    [UserPropertyId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[Washroom]    Script Date: 12/15/2014 5:21:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Washroom]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Washroom](
    [ID] [int] IDENTITY(1,1) NOT NULL,
    [Name] [nvarchar](50) NOT NULL,
    [KCIdentifier] [nvarchar](50) NOT NULL,
    [FloorId] [int] NOT NULL,
    [GenderId] [tinyint] NOT NULL,
    [WingId] [tinyint] NOT NULL,
    [IsActive] [bit] NOT NULL,
    [CreatedBy] [int] NOT NULL,
    [CreatedOn] [datetime] NOT NULL,
    [LastUpdatedBy] [int] NULL,
    [LastUpdatedOn] [datetime] NULL,
 CONSTRAINT [PK_Washroom] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Wing]    Script Date: 12/15/2014 5:21:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Wing]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Wing](
    [ID] [tinyint] IDENTITY(1,1) NOT NULL,
    [Name] [nvarchar](10) NOT NULL,
 CONSTRAINT [PK_Wing] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
-- --------------------------------------------------
-- Begin: Creating TABLES for API Return Parameters
-- --------------------------------------------------


-- Creating table 'DeviceParameterGroup'
CREATE TABLE [dbo].[DeviceParameterGroup] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Name] nvarchar(20)  NOT NULL,
    [IsActive] bit  NOT NULL,
    [DisplayName] nvarchar(30)  NOT NULL,
    [Description] nvarchar(50)  NULL,
    [CreatedTime] datetime  NULL,
    [ModifiedTime] datetime  NULL,
    [CreatedById] int  NULL,
    [ModifiedById] int  NULL
);
GO
-- Creating table 'DeviceParameter'
CREATE TABLE [dbo].[DeviceParameter] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Name] nvarchar(20)  NOT NULL,
    [Index] int  NOT NULL,
    [FormatCode] nvarchar(255)  NULL,
    [IsReturnParameter] bit  NOT NULL,
    [IgnoreError] bit  NOT NULL,
    [IsAutoReset] bit  NOT NULL,
    [IsActive] bit  NOT NULL,
    [DisplayName] nvarchar(30)  NOT NULL,
    [Description] nvarchar(50)  NULL,
    [DataTypeName] nvarchar(25)  NULL,
    [FormatErrorMessage] nvarchar(100)  NULL,
    [CreatedTime] datetime  NULL,
    [ModifiedTime] datetime  NULL,
    [DeviceTypeId] tinyint   NULL,
    [CreatedById] int  NULL,
    [ModifiedById] int  NULL,
    [PropertyGroupId] int  NULL
);
GO

-- Creating table 'DeviceParameterValue'
CREATE TABLE [dbo].[DeviceParameterValue] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Value] nvarchar(25)  NOT NULL,
    [IsReset] bit  NULL,
    [ResetTime] datetime  NULL,
    [CreatedTime] datetime  NULL,
    [ModifiedTime] datetime  NULL,
    [ParameterId] int  NOT NULL,
    [CustomerId] int  NULL,
    [DeviceId] nvarchar(30)  NULL,
    [CreatedById] int  NULL,
    [ModifiedById] int  NULL
);
GO

-- --------------------------------------------------
-- End: Creating TABLES for API Return Parameters
-- --------------------------------------------------
GO
-- --------------------------------------------------
-- Begin: Creating PRIMARY KEY for API Return Parameter
-- --------------------------------------------------

-- Creating primary key on [Id] in table 'DeviceParameterGroup'
ALTER TABLE [dbo].[DeviceParameterGroup]
ADD CONSTRAINT [PK_DeviceParameterGroup]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO
-- Creating primary key on [Id] in table 'DeviceParameter'
ALTER TABLE [dbo].[DeviceParameter]
ADD CONSTRAINT [PK_DeviceParameter]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO
-- Creating primary key on [Id] in table 'DeviceParameterValue'
ALTER TABLE [dbo].[DeviceParameterValue]
ADD CONSTRAINT [PK_DeviceParameterValue]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO
-- --------------------------------------------------
-- End: Creating PRIMARY KEY for API Return Parameter
-- --------------------------------------------------

SET ANSI_PADDING OFF
GO
/****** Object:  UserDefinedFunction [dbo].[GetAllDevicesAndProperties]    Script Date: 12/15/2014 5:21:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetAllDevicesAndProperties]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[GetAllDevicesAndProperties] ()
RETURNS TABLE
AS
RETURN 
(
    Select d.ID, dt.Name as DeviceType, w.Name as Washroom, f.FloorLevel, b.Name as BuildingName, p.PropertyName, c.Name as CustomerName From Device d 
            INNER JOIN DeviceType dt on d.DeviceTypeId = dt.ID
            INNER JOIN DeviceWashroom dw on d.ID = dw.DeviceId
            INNER JOIN Washroom w on dw.WashroomId = w.ID
            INNER JOIN [Floor] f on w.FloorId = f.ID
            INNER JOIN Building b on f.BuildingId = b.ID
            INNER JOIN Property p on b.PropertyId = p.ID
            INNER JOIN Customer c on p.CustomerId = c.ID
);' 
END

GO
/****** Object:  UserDefinedFunction [dbo].[GetDeviceProperty]    Script Date: 12/15/2014 5:21:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetDeviceProperty]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[GetDeviceProperty] (@deviceId nvarchar(100))
RETURNS TABLE
AS
RETURN 
(
    Select d.ID, dt.Name as DeviceType, w.Name as Washroom, f.FloorLevel, b.Name as BuildingName, p.PropertyName, c.Name as CustomerName From Device d 
            INNER JOIN DeviceType dt on d.DeviceTypeId = dt.ID
            INNER JOIN DeviceWashroom dw on d.ID = dw.DeviceId
            INNER JOIN Washroom w on dw.WashroomId = w.ID
            INNER JOIN [Floor] f on w.FloorId = f.ID
            INNER JOIN Building b on f.BuildingId = b.ID
            INNER JOIN Property p on b.PropertyId = p.ID
            INNER JOIN Customer c on p.CustomerId = c.ID
    WHERE d.ID = @deviceId
);' 
END

GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DF__Role__RoleLevel__367C1819]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[Role] ADD  DEFAULT ((0)) FOR [RoleLevel]
END

GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Address_Country]') AND parent_object_id = OBJECT_ID(N'[dbo].[Address]'))
ALTER TABLE [dbo].[Address]  WITH CHECK ADD  CONSTRAINT [FK_Address_Country] FOREIGN KEY([CountryId])
REFERENCES [dbo].[Country] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Address_Country]') AND parent_object_id = OBJECT_ID(N'[dbo].[Address]'))
ALTER TABLE [dbo].[Address] CHECK CONSTRAINT [FK_Address_Country]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Building_Property]') AND parent_object_id = OBJECT_ID(N'[dbo].[Building]'))
ALTER TABLE [dbo].[Building]  WITH CHECK ADD  CONSTRAINT [FK_Building_Property] FOREIGN KEY([PropertyId])
REFERENCES [dbo].[Property] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Building_Property]') AND parent_object_id = OBJECT_ID(N'[dbo].[Building]'))
ALTER TABLE [dbo].[Building] CHECK CONSTRAINT [FK_Building_Property]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Building_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[Building]'))
ALTER TABLE [dbo].[Building]  WITH CHECK ADD  CONSTRAINT [FK_Building_User] FOREIGN KEY([CreatedBy])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Building_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[Building]'))
ALTER TABLE [dbo].[Building] CHECK CONSTRAINT [FK_Building_User]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Building_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Building]'))
ALTER TABLE [dbo].[Building]  WITH CHECK ADD  CONSTRAINT [FK_Building_User1] FOREIGN KEY([LastUpdatedBy])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Building_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Building]'))
ALTER TABLE [dbo].[Building] CHECK CONSTRAINT [FK_Building_User1]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Customer_Address]') AND parent_object_id = OBJECT_ID(N'[dbo].[Customer]'))
ALTER TABLE [dbo].[Customer]  WITH CHECK ADD  CONSTRAINT [FK_Customer_Address] FOREIGN KEY([AddressId])
REFERENCES [dbo].[Address] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Customer_Address]') AND parent_object_id = OBJECT_ID(N'[dbo].[Customer]'))
ALTER TABLE [dbo].[Customer] CHECK CONSTRAINT [FK_Customer_Address]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Customer_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[Customer]'))
ALTER TABLE [dbo].[Customer]  WITH CHECK ADD  CONSTRAINT [FK_Customer_User] FOREIGN KEY([CreatedBy])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Customer_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[Customer]'))
ALTER TABLE [dbo].[Customer] CHECK CONSTRAINT [FK_Customer_User]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Customer_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Customer]'))
ALTER TABLE [dbo].[Customer]  WITH CHECK ADD  CONSTRAINT [FK_Customer_User1] FOREIGN KEY([LastUpdatedBy])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Customer_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Customer]'))
ALTER TABLE [dbo].[Customer] CHECK CONSTRAINT [FK_Customer_User1]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Device_DeviceType]') AND parent_object_id = OBJECT_ID(N'[dbo].[Device]'))
ALTER TABLE [dbo].[Device]  WITH CHECK ADD  CONSTRAINT [FK_Device_DeviceType] FOREIGN KEY([DeviceTypeId])
REFERENCES [dbo].[DeviceType] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Device_DeviceType]') AND parent_object_id = OBJECT_ID(N'[dbo].[Device]'))
ALTER TABLE [dbo].[Device] CHECK CONSTRAINT [FK_Device_DeviceType]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Device_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[Device]'))
ALTER TABLE [dbo].[Device]  WITH CHECK ADD  CONSTRAINT [FK_Device_User] FOREIGN KEY([CreatedBy])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Device_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[Device]'))
ALTER TABLE [dbo].[Device] CHECK CONSTRAINT [FK_Device_User]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Device_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Device]'))
ALTER TABLE [dbo].[Device]  WITH CHECK ADD  CONSTRAINT [FK_Device_User1] FOREIGN KEY([LastUpdatedBy])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Device_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Device]'))
ALTER TABLE [dbo].[Device] CHECK CONSTRAINT [FK_Device_User1]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_DeviceAlert_AlertType]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceAlert]'))
ALTER TABLE [dbo].[DeviceAlert]  WITH CHECK ADD  CONSTRAINT [FK_DeviceAlert_AlertType] FOREIGN KEY([AlertTypeId])
REFERENCES [dbo].[AlertType] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_DeviceAlert_AlertType]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceAlert]'))
ALTER TABLE [dbo].[DeviceAlert] CHECK CONSTRAINT [FK_DeviceAlert_AlertType]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_DeviceAlert_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceAlert]'))
ALTER TABLE [dbo].[DeviceAlert]  WITH CHECK ADD  CONSTRAINT [FK_DeviceAlert_Device] FOREIGN KEY([DeviceId])
REFERENCES [dbo].[Device] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_DeviceAlert_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceAlert]'))
ALTER TABLE [dbo].[DeviceAlert] CHECK CONSTRAINT [FK_DeviceAlert_Device]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[fk_alertName]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceAlertMapping]'))
ALTER TABLE [dbo].[DeviceAlertMapping]  WITH CHECK ADD  CONSTRAINT [fk_alertName] FOREIGN KEY([AlertNameId])
REFERENCES [dbo].[DeviceAlertName] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[fk_alertName]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceAlertMapping]'))
ALTER TABLE [dbo].[DeviceAlertMapping] CHECK CONSTRAINT [fk_alertName]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[fk_devicealert]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceAlertMapping]'))
ALTER TABLE [dbo].[DeviceAlertMapping]  WITH CHECK ADD  CONSTRAINT [fk_devicealert] FOREIGN KEY([AlertTypeId])
REFERENCES [dbo].[AlertType] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[fk_devicealert]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceAlertMapping]'))
ALTER TABLE [dbo].[DeviceAlertMapping] CHECK CONSTRAINT [fk_devicealert]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[fk_devicetype]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceAlertMapping]'))
ALTER TABLE [dbo].[DeviceAlertMapping]  WITH CHECK ADD  CONSTRAINT [fk_devicetype] FOREIGN KEY([DeviceTypeId])
REFERENCES [dbo].[DeviceType] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[fk_devicetype]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceAlertMapping]'))
ALTER TABLE [dbo].[DeviceAlertMapping] CHECK CONSTRAINT [fk_devicetype]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_DeviceWashroom_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceWashroom]'))
ALTER TABLE [dbo].[DeviceWashroom]  WITH CHECK ADD  CONSTRAINT [FK_DeviceWashroom_Device] FOREIGN KEY([DeviceId])
REFERENCES [dbo].[Device] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_DeviceWashroom_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceWashroom]'))
ALTER TABLE [dbo].[DeviceWashroom] CHECK CONSTRAINT [FK_DeviceWashroom_Device]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_DeviceWashroom_Washroom]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceWashroom]'))
ALTER TABLE [dbo].[DeviceWashroom]  WITH CHECK ADD  CONSTRAINT [FK_DeviceWashroom_Washroom] FOREIGN KEY([WashroomId])
REFERENCES [dbo].[Washroom] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_DeviceWashroom_Washroom]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceWashroom]'))
ALTER TABLE [dbo].[DeviceWashroom] CHECK CONSTRAINT [FK_DeviceWashroom_Washroom]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Floor_Building]') AND parent_object_id = OBJECT_ID(N'[dbo].[Floor]'))
ALTER TABLE [dbo].[Floor]  WITH CHECK ADD  CONSTRAINT [FK_Floor_Building] FOREIGN KEY([BuildingId])
REFERENCES [dbo].[Building] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Floor_Building]') AND parent_object_id = OBJECT_ID(N'[dbo].[Floor]'))
ALTER TABLE [dbo].[Floor] CHECK CONSTRAINT [FK_Floor_Building]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Floor_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[Floor]'))
ALTER TABLE [dbo].[Floor]  WITH CHECK ADD  CONSTRAINT [FK_Floor_User] FOREIGN KEY([CreatedBy])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Floor_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[Floor]'))
ALTER TABLE [dbo].[Floor] CHECK CONSTRAINT [FK_Floor_User]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Floor_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Floor]'))
ALTER TABLE [dbo].[Floor]  WITH CHECK ADD  CONSTRAINT [FK_Floor_User1] FOREIGN KEY([LastUpdatedBy])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Floor_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Floor]'))
ALTER TABLE [dbo].[Floor] CHECK CONSTRAINT [FK_Floor_User1]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Property_Address]') AND parent_object_id = OBJECT_ID(N'[dbo].[Property]'))
ALTER TABLE [dbo].[Property]  WITH CHECK ADD  CONSTRAINT [FK_Property_Address] FOREIGN KEY([AddressId])
REFERENCES [dbo].[Address] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Property_Address]') AND parent_object_id = OBJECT_ID(N'[dbo].[Property]'))
ALTER TABLE [dbo].[Property] CHECK CONSTRAINT [FK_Property_Address]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Property_Customer]') AND parent_object_id = OBJECT_ID(N'[dbo].[Property]'))
ALTER TABLE [dbo].[Property]  WITH CHECK ADD  CONSTRAINT [FK_Property_Customer] FOREIGN KEY([CustomerId])
REFERENCES [dbo].[Customer] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Property_Customer]') AND parent_object_id = OBJECT_ID(N'[dbo].[Property]'))
ALTER TABLE [dbo].[Property] CHECK CONSTRAINT [FK_Property_Customer]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Property_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Property]'))
ALTER TABLE [dbo].[Property]  WITH CHECK ADD  CONSTRAINT [FK_Property_User1] FOREIGN KEY([CreatedBy])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Property_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Property]'))
ALTER TABLE [dbo].[Property] CHECK CONSTRAINT [FK_Property_User1]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Property_User2]') AND parent_object_id = OBJECT_ID(N'[dbo].[Property]'))
ALTER TABLE [dbo].[Property]  WITH CHECK ADD  CONSTRAINT [FK_Property_User2] FOREIGN KEY([LastUpdatedBy])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Property_User2]') AND parent_object_id = OBJECT_ID(N'[dbo].[Property]'))
ALTER TABLE [dbo].[Property] CHECK CONSTRAINT [FK_Property_User2]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_RolePermission_Feature]') AND parent_object_id = OBJECT_ID(N'[dbo].[RolePermission]'))
ALTER TABLE [dbo].[RolePermission]  WITH CHECK ADD  CONSTRAINT [FK_RolePermission_Feature] FOREIGN KEY([FeatureId])
REFERENCES [dbo].[Feature] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_RolePermission_Feature]') AND parent_object_id = OBJECT_ID(N'[dbo].[RolePermission]'))
ALTER TABLE [dbo].[RolePermission] CHECK CONSTRAINT [FK_RolePermission_Feature]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_RolePermission_Role]') AND parent_object_id = OBJECT_ID(N'[dbo].[RolePermission]'))
ALTER TABLE [dbo].[RolePermission]  WITH CHECK ADD  CONSTRAINT [FK_RolePermission_Role] FOREIGN KEY([RoleId])
REFERENCES [dbo].[Role] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_RolePermission_Role]') AND parent_object_id = OBJECT_ID(N'[dbo].[RolePermission]'))
ALTER TABLE [dbo].[RolePermission] CHECK CONSTRAINT [FK_RolePermission_Role]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_SimulatorAlertFixStatus_AlertType]') AND parent_object_id = OBJECT_ID(N'[dbo].[SimulatorDeviceAlert]'))
ALTER TABLE [dbo].[SimulatorDeviceAlert]  WITH CHECK ADD  CONSTRAINT [FK_SimulatorAlertFixStatus_AlertType] FOREIGN KEY([AlertTypeId])
REFERENCES [dbo].[AlertType] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_SimulatorAlertFixStatus_AlertType]') AND parent_object_id = OBJECT_ID(N'[dbo].[SimulatorDeviceAlert]'))
ALTER TABLE [dbo].[SimulatorDeviceAlert] CHECK CONSTRAINT [FK_SimulatorAlertFixStatus_AlertType]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_SimulatorAlertFixStatus_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[SimulatorDeviceAlert]'))
ALTER TABLE [dbo].[SimulatorDeviceAlert]  WITH CHECK ADD  CONSTRAINT [FK_SimulatorAlertFixStatus_Device] FOREIGN KEY([DeviceId])
REFERENCES [dbo].[Device] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_SimulatorAlertFixStatus_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[SimulatorDeviceAlert]'))
ALTER TABLE [dbo].[SimulatorDeviceAlert] CHECK CONSTRAINT [FK_SimulatorAlertFixStatus_Device]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_SimulatorRaisedAlert_AlertType]') AND parent_object_id = OBJECT_ID(N'[dbo].[SimulatorRaisedAlert]'))
ALTER TABLE [dbo].[SimulatorRaisedAlert]  WITH CHECK ADD  CONSTRAINT [FK_SimulatorRaisedAlert_AlertType] FOREIGN KEY([AlertTypeId])
REFERENCES [dbo].[AlertType] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_SimulatorRaisedAlert_AlertType]') AND parent_object_id = OBJECT_ID(N'[dbo].[SimulatorRaisedAlert]'))
ALTER TABLE [dbo].[SimulatorRaisedAlert] CHECK CONSTRAINT [FK_SimulatorRaisedAlert_AlertType]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_SimulatorRaisedAlert_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[SimulatorRaisedAlert]'))
ALTER TABLE [dbo].[SimulatorRaisedAlert]  WITH CHECK ADD  CONSTRAINT [FK_SimulatorRaisedAlert_Device] FOREIGN KEY([DeviceId])
REFERENCES [dbo].[Device] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_SimulatorRaisedAlert_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[SimulatorRaisedAlert]'))
ALTER TABLE [dbo].[SimulatorRaisedAlert] CHECK CONSTRAINT [FK_SimulatorRaisedAlert_Device]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_SimulatorTempDeviceLog_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[SimulatorTempDeviceLog]'))
ALTER TABLE [dbo].[SimulatorTempDeviceLog]  WITH CHECK ADD  CONSTRAINT [FK_SimulatorTempDeviceLog_Device] FOREIGN KEY([DeviceId])
REFERENCES [dbo].[Device] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_SimulatorTempDeviceLog_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[SimulatorTempDeviceLog]'))
ALTER TABLE [dbo].[SimulatorTempDeviceLog] CHECK CONSTRAINT [FK_SimulatorTempDeviceLog_Device]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_User_Customer]') AND parent_object_id = OBJECT_ID(N'[dbo].[User]'))
ALTER TABLE [dbo].[User]  WITH CHECK ADD  CONSTRAINT [FK_User_Customer] FOREIGN KEY([CustomerId])
REFERENCES [dbo].[Customer] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_User_Customer]') AND parent_object_id = OBJECT_ID(N'[dbo].[User]'))
ALTER TABLE [dbo].[User] CHECK CONSTRAINT [FK_User_Customer]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_User_Role]') AND parent_object_id = OBJECT_ID(N'[dbo].[User]'))
ALTER TABLE [dbo].[User]  WITH CHECK ADD  CONSTRAINT [FK_User_Role] FOREIGN KEY([RoleId])
REFERENCES [dbo].[Role] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_User_Role]') AND parent_object_id = OBJECT_ID(N'[dbo].[User]'))
ALTER TABLE [dbo].[User] CHECK CONSTRAINT [FK_User_Role]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_User_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[User]'))
ALTER TABLE [dbo].[User]  WITH CHECK ADD  CONSTRAINT [FK_User_User] FOREIGN KEY([CreatedBy])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_User_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[User]'))
ALTER TABLE [dbo].[User] CHECK CONSTRAINT [FK_User_User]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_User_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[User]'))
ALTER TABLE [dbo].[User]  WITH CHECK ADD  CONSTRAINT [FK_User_User1] FOREIGN KEY([LastUpdatedBy])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_User_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[User]'))
ALTER TABLE [dbo].[User] CHECK CONSTRAINT [FK_User_User1]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserBuilding_Building]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserBuilding]'))
ALTER TABLE [dbo].[UserBuilding]  WITH CHECK ADD  CONSTRAINT [FK_UserBuilding_Building] FOREIGN KEY([BuildingId])
REFERENCES [dbo].[Building] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserBuilding_Building]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserBuilding]'))
ALTER TABLE [dbo].[UserBuilding] CHECK CONSTRAINT [FK_UserBuilding_Building]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserBuilding_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserBuilding]'))
ALTER TABLE [dbo].[UserBuilding]  WITH CHECK ADD  CONSTRAINT [FK_UserBuilding_User] FOREIGN KEY([UserId])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserBuilding_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserBuilding]'))
ALTER TABLE [dbo].[UserBuilding] CHECK CONSTRAINT [FK_UserBuilding_User]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserProperty_Property]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserProperty]'))
ALTER TABLE [dbo].[UserProperty]  WITH CHECK ADD  CONSTRAINT [FK_UserProperty_Property] FOREIGN KEY([PropertyId])
REFERENCES [dbo].[Property] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserProperty_Property]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserProperty]'))
ALTER TABLE [dbo].[UserProperty] CHECK CONSTRAINT [FK_UserProperty_Property]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserProperty_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserProperty]'))
ALTER TABLE [dbo].[UserProperty]  WITH CHECK ADD  CONSTRAINT [FK_UserProperty_User] FOREIGN KEY([UserId])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserProperty_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserProperty]'))
ALTER TABLE [dbo].[UserProperty] CHECK CONSTRAINT [FK_UserProperty_User]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserProperty_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserProperty]'))
ALTER TABLE [dbo].[UserProperty]  WITH CHECK ADD  CONSTRAINT [FK_UserProperty_User1] FOREIGN KEY([LastUpdatedBy])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserProperty_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserProperty]'))
ALTER TABLE [dbo].[UserProperty] CHECK CONSTRAINT [FK_UserProperty_User1]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Washroom_Floor]') AND parent_object_id = OBJECT_ID(N'[dbo].[Washroom]'))
ALTER TABLE [dbo].[Washroom]  WITH CHECK ADD  CONSTRAINT [FK_Washroom_Floor] FOREIGN KEY([FloorId])
REFERENCES [dbo].[Floor] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Washroom_Floor]') AND parent_object_id = OBJECT_ID(N'[dbo].[Washroom]'))
ALTER TABLE [dbo].[Washroom] CHECK CONSTRAINT [FK_Washroom_Floor]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Washroom_Gender]') AND parent_object_id = OBJECT_ID(N'[dbo].[Washroom]'))
ALTER TABLE [dbo].[Washroom]  WITH CHECK ADD  CONSTRAINT [FK_Washroom_Gender] FOREIGN KEY([GenderId])
REFERENCES [dbo].[Gender] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Washroom_Gender]') AND parent_object_id = OBJECT_ID(N'[dbo].[Washroom]'))
ALTER TABLE [dbo].[Washroom] CHECK CONSTRAINT [FK_Washroom_Gender]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Washroom_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[Washroom]'))
ALTER TABLE [dbo].[Washroom]  WITH CHECK ADD  CONSTRAINT [FK_Washroom_User] FOREIGN KEY([LastUpdatedBy])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Washroom_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[Washroom]'))
ALTER TABLE [dbo].[Washroom] CHECK CONSTRAINT [FK_Washroom_User]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Washroom_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Washroom]'))
ALTER TABLE [dbo].[Washroom]  WITH CHECK ADD  CONSTRAINT [FK_Washroom_User1] FOREIGN KEY([CreatedBy])
REFERENCES [dbo].[User] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Washroom_User1]') AND parent_object_id = OBJECT_ID(N'[dbo].[Washroom]'))
ALTER TABLE [dbo].[Washroom] CHECK CONSTRAINT [FK_Washroom_User1]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Washroom_Wing]') AND parent_object_id = OBJECT_ID(N'[dbo].[Washroom]'))
ALTER TABLE [dbo].[Washroom]  WITH CHECK ADD  CONSTRAINT [FK_Washroom_Wing] FOREIGN KEY([WingId])
REFERENCES [dbo].[Wing] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Washroom_Wing]') AND parent_object_id = OBJECT_ID(N'[dbo].[Washroom]'))
ALTER TABLE [dbo].[Washroom] CHECK CONSTRAINT [FK_Washroom_Wing]
GO


-- --------------------------------------------------
-- Begin: Creating FOREIGN KEY for API Return Parameters
-- --------------------------------------------------

-- Creating foreign key on [CreatedById] in table 'DeviceParameterGroup'
ALTER TABLE [dbo].[DeviceParameterGroup]
ADD CONSTRAINT [FK_CreatedBy_ParameterGroup]
    FOREIGN KEY ([CreatedById])
    REFERENCES [dbo].[User]
        ([ID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_CreatedBy_ParameterGroup'
CREATE INDEX [IX_FK_CreatedBy_ParameterGroup]
ON [dbo].[DeviceParameterGroup]
    ([CreatedById]);
GO

-- Creating foreign key on [ModifiedById] in table 'DeviceParameterGroup'
ALTER TABLE [dbo].[DeviceParameterGroup]
ADD CONSTRAINT [FK_ModifiedBy_ParameterGroup]
    FOREIGN KEY ([ModifiedById])
    REFERENCES [dbo].[User]
        ([ID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ModifiedBy_ParameterGroup'
CREATE INDEX [IX_FK_ModifiedBy_ParameterGroup]
ON [dbo].[DeviceParameterGroup]
    ([ModifiedById]);
GO

-- Creating foreign key on [PropertyGroupId] in table 'DeviceParameter'
ALTER TABLE [dbo].[DeviceParameter]
ADD CONSTRAINT [FK_Parameter_Group]
    FOREIGN KEY ([PropertyGroupId])
    REFERENCES [dbo].[DeviceParameterGroup]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Parameter_Group'
CREATE INDEX [IX_FK_Parameter_Group]
ON [dbo].[DeviceParameter]
    ([PropertyGroupId]);
GO

-- Creating foreign key on [DeviceId] in table 'DeviceParameterValue'
ALTER TABLE [dbo].[DeviceParameterValue]
ADD CONSTRAINT [FK_Device_ParameterValue]
    FOREIGN KEY ([DeviceId])
    REFERENCES [dbo].[Device]
        ([ID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Device_ParameterValue'
CREATE INDEX [IX_FK_Device_ParameterValue]
ON [dbo].[DeviceParameterValue]
    ([DeviceId]);
GO

-- Creating foreign key on [DeviceTypeId] in table 'DeviceParameter'
ALTER TABLE [dbo].[DeviceParameter]
ADD CONSTRAINT [FK_DeviceType_Parameter]
    FOREIGN KEY ([DeviceTypeId])
    REFERENCES [dbo].[DeviceType]
        ([ID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DeviceType_Parameter'
CREATE INDEX [IX_FK_DeviceType_Parameter]
ON [dbo].[DeviceParameter]
    ([DeviceTypeId]);
GO

-- Creating foreign key on [CreatedById] in table 'DeviceParameter'
ALTER TABLE [dbo].[DeviceParameter]
ADD CONSTRAINT [FK_CreatedByUser_Parameter]
    FOREIGN KEY ([CreatedById])
    REFERENCES [dbo].[User]
        ([ID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_CreatedByUser_Parameter'
CREATE INDEX [IX_FK_CreatedByUser_Parameter]
ON [dbo].[DeviceParameter]
    ([CreatedById]);
GO

-- Creating foreign key on [ModifiedById] in table 'DeviceParameter'
ALTER TABLE [dbo].[DeviceParameter]
ADD CONSTRAINT [FK_ModifiedByUser_Parameter]
    FOREIGN KEY ([ModifiedById])
    REFERENCES [dbo].[User]
        ([ID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ModifiedByUser_Parameter'
CREATE INDEX [IX_FK_ModifiedByUser_Parameter]
ON [dbo].[DeviceParameter]
    ([ModifiedById]);
GO

-- Creating foreign key on [ParameterId] in table 'DeviceParameterValue'
ALTER TABLE [dbo].[DeviceParameterValue]
ADD CONSTRAINT [FK_Parameter_ParameterValue]
    FOREIGN KEY ([ParameterId])
    REFERENCES [dbo].[DeviceParameter]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Parameter_ParameterValue'
CREATE INDEX [IX_FK_Parameter_ParameterValue]
ON [dbo].[DeviceParameterValue]
    ([ParameterId]);
GO

-- Creating foreign key on [CustomerId] in table 'DeviceParameterValue'
ALTER TABLE [dbo].[DeviceParameterValue]
ADD CONSTRAINT [FK_Customer_ParameterValue]
    FOREIGN KEY ([CustomerId])
    REFERENCES [dbo].[Customer]
        ([ID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Customer_ParameterValue'
CREATE INDEX [IX_FK_Customer_ParameterValue]
ON [dbo].[DeviceParameterValue]
    ([CustomerId]);
GO

-- Creating foreign key on [CreatedById] in table 'DeviceParameterValue'
ALTER TABLE [dbo].[DeviceParameterValue]
ADD CONSTRAINT [FK_CreatedBy_ParameterValue]
    FOREIGN KEY ([CreatedById])
    REFERENCES [dbo].[User]
        ([ID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_CreatedBy_ParameterValue'
CREATE INDEX [IX_FK_CreatedBy_ParameterValue]
ON [dbo].[DeviceParameterValue]
    ([CreatedById]);
GO

-- Creating foreign key on [ModifiedById] in table 'DeviceParameterValue'
ALTER TABLE [dbo].[DeviceParameterValue]
ADD CONSTRAINT [FK_ModifiedBy_ParameterValue]
    FOREIGN KEY ([ModifiedById])
    REFERENCES [dbo].[User]
        ([ID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ModifiedBy_ParameterValue'
CREATE INDEX [IX_FK_ModifiedBy_ParameterValue]
ON [dbo].[DeviceParameterValue]
    ([ModifiedById]);
GO

-- --------------------------------------------------
-- End: Creating FOREIGN KEY for API Return Parameters
-- --------------------------------------------------
Go
-- --------------------------------------------------
-- Begin: Creating all DEFAULT constraints for API Return Parameters
-- --------------------------------------------------

-- Creating default value [IsActive] = 1 in table DeviceParameterGroup
Alter Table [dbo].[DeviceParameterGroup]
    Add Constraint DF_DeviceParameterGroup_IsActive
    Default 1 for [IsActive]
Go

-- Creating default value [CreatedDate] = GetDate() in table DeviceParameterGroup
Alter Table [dbo].[DeviceParameterGroup]
    Add Constraint DF_DeviceParameterGroup_CreatedTime
    Default GetDate() for [CreatedTime]
Go

-- Creating default value [Description] = '' in table DeviceParameterGroup
Alter Table [dbo].[DeviceParameterGroup]
    Add Constraint DF_DeviceParameterGroup_Description
    Default '' for [Description]
Go

-- Creating default value [IsReturnParameter] = 0 in table DeviceParameter
Alter Table [dbo].[DeviceParameter]
    Add Constraint DF_DeviceParameter_IsReturnParameter
    Default 0 for [IsReturnParameter]
Go
-- Creating default value [IsAutoReset] = 0 in table DeviceParameter
Alter Table [dbo].[DeviceParameter]
    Add Constraint DF_DeviceParameter_IsAutoReset
    Default 0 for [IsAutoReset]
Go
-- Creating default value [IsActive] = 1 in table DeviceParameter
Alter Table [dbo].[DeviceParameter]
    Add Constraint DF_DeviceParameter_IsActive
    Default 1 for [IsActive]
Go
-- Creating default value [DataTypeName] = 'Unsigned Short' in table DeviceParameter
Alter Table [dbo].[DeviceParameter]
    Add Constraint DF_DeviceParameter_DataTypeName
    Default 'Unsigned Short' for [DataTypeName]
Go

-- Creating default value [CreatedDate] = GetDate() in table DeviceParameter
Alter Table [dbo].[DeviceParameter]
    Add Constraint DF_DeviceParameter_CreatedDate
    Default GetDate() for [CreatedTime]
Go

-- Creating default value [FormatCode] = '' in table DeviceParameter
Alter Table [dbo].[DeviceParameter]
    Add Constraint DF_DeviceParameter_FormatCode
    Default '' for [FormatCode]
Go

-- Creating default value [Description] = '' in table DeviceParameter
Alter Table [dbo].[DeviceParameter]
    Add Constraint DF_DeviceParameter_Description
    Default '' for [Description]
Go

-- Creating default value [FormatErrorMessage] = '' in table DeviceParameter
Alter Table [dbo].[DeviceParameter]
    Add Constraint DF_DeviceParameter_FormatErrorMessage
    Default '' for [FormatErrorMessage]
Go
-- Creating default value [IgnoreError] = 1 in table DeviceParameter
Alter Table [dbo].[DeviceParameter]
    Add Constraint DF_DeviceParameter_IgnoreError
    Default 1 for [IgnoreError]
Go

-- Creating default value [IsReset] = 0 in table DeviceParameterValue
Alter Table [dbo].[DeviceParameterValue]
    Add Constraint DF_DeviceParameterValue_IsReset
    Default 0 for [IsReset]
Go

-- Creating default value [IsActive] = 1 in table DeviceParameterValue
Alter Table [dbo].[DeviceParameterValue]
    Add Constraint DF_DeviceParameterValue_CreatedTime
    Default GetDate() for [CreatedTime]
Go

-- --------------------------------------------------
-- End: Creating all DEFAULT constraints for API Return Parameters
-- --------------------------------------------------
Go
-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------
