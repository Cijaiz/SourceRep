﻿IF EXISTS(select * from sys.tables where name = 'EsoapShotSize')
BEGIN
DROP TABLE EsoapShotSize
END