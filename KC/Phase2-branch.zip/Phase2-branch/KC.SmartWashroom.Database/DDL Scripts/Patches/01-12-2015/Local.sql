
/****** Object:  UserDefinedFunction [dbo].[GetDeviceProperty]    Script Date: 01/12/2015 17:42:16 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetDeviceProperty]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[GetDeviceProperty]
GO
/****** Object:  UserDefinedFunction [dbo].[GetDeviceProperty]    Script Date: 01/12/2015 17:42:16 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [dbo].[GetDeviceProperty] (@deviceId nvarchar(100))
RETURNS TABLE
AS
RETURN 
(
    Select d.ID, dt.Name as DeviceType, w.ID as WashroomId,w.Name as Washroom, f.ID as FloorId,f.FloorLevel,b.ID as BuildingID, b.Name as BuildingName,p.ID as PropertyID, p.PropertyName,c.ID as CustomerID, c.Name as CustomerName From Device d 
			INNER JOIN DeviceType dt on d.DeviceTypeId = dt.ID
			INNER JOIN DeviceWashroom dw on d.ID = dw.DeviceId
			INNER JOIN Washroom w on dw.WashroomId = w.ID
			INNER JOIN [Floor] f on w.FloorId = f.ID
			INNER JOIN Building b on f.BuildingId = b.ID
			INNER JOIN Property p on b.PropertyId = p.ID
			INNER JOIN Customer c on p.CustomerId = c.ID
	WHERE d.ID = @deviceId
);
GO



/****** Object:  StoredProcedure [dbo].[SPGETDEVICEPROPERTY]    Script Date: 01/12/2015 17:43:43 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SPGETDEVICEPROPERTY]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[SPGETDEVICEPROPERTY]
GO


/****** Object:  StoredProcedure [dbo].[SPGETDEVICEPROPERTY]    Script Date: 01/12/2015 17:43:43 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SPGETDEVICEPROPERTY]
@DEVICEID nvarchar(100)
AS
BEGIN
	SELECT * FROM [dbo].[GetDeviceProperty] (@DEVICEID);
END

GO


