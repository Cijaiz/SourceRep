DECLARE @BatteryScaleFactor VarChar(20) = 'BatteryScaleFactor'
DECLARE @SQL nVarChar(max)

--DDL For Adding ProductUsageBuffer
IF NOT EXISTS (SELECT 1 FROM sys.columns c WHERE c.name = @BatteryScaleFactor)
BEGIN
	SELECT @SQL = '
		ALTER TABLE DeviceType
		ADD ' + @BatteryScaleFactor + ' decimal(15,10) NOT NULL DEFAULT 0'
		EXEC sys.sp_executesql @SQL
END



IF Exists(select * from sys.columns where Name = N'FloorLevel' and Object_ID = Object_ID(N'Floor'))
ALTER TABLE DBO.[FLOOR] ALTER COLUMN FLOORLEVEL SMALLINT NOT NULL

