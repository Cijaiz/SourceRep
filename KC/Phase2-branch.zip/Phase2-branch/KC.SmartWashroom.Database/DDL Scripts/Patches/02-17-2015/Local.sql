-- DROP CONSTRAINTS
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_DeviceAlert_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceAlert]'))
ALTER TABLE [dbo].[DeviceAlert] DROP CONSTRAINT [FK_DeviceAlert_Device]
GO


IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_DeviceAlert_AlertType]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceAlert]'))
ALTER TABLE [dbo].[DeviceAlert] DROP CONSTRAINT [FK_DeviceAlert_AlertType]
GO

-- DROP TABLES

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeviceAlert]') AND type in (N'U'))
DROP TABLE [dbo].[DeviceAlert]
GO

-- CREATE TABLES

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeviceAlert]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[DeviceAlert](
	[DeviceId] [nvarchar](30) NOT NULL,
	[AlertTypeId] [tinyint] NOT NULL,
	[ReceivedOn] [datetime] NOT NULL,
 CONSTRAINT [PK_DeviceAlert] PRIMARY KEY CLUSTERED 
(
	[DeviceId] ASC,
	[AlertTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO

-- CREATE CONSTRAINTS

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_DeviceAlert_AlertType]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceAlert]'))
ALTER TABLE [dbo].[DeviceAlert]  WITH CHECK ADD  CONSTRAINT [FK_DeviceAlert_AlertType] FOREIGN KEY([AlertTypeId])
REFERENCES [dbo].[AlertType] ([ID])
GO


IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_DeviceAlert_AlertType]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceAlert]'))
ALTER TABLE [dbo].[DeviceAlert] CHECK CONSTRAINT [FK_DeviceAlert_AlertType]
GO


IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_DeviceAlert_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceAlert]'))
ALTER TABLE [dbo].[DeviceAlert]  WITH CHECK ADD  CONSTRAINT [FK_DeviceAlert_Device] FOREIGN KEY([DeviceId])
REFERENCES [dbo].[Device] ([ID])
GO


IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_DeviceAlert_Device]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceAlert]'))
ALTER TABLE [dbo].[DeviceAlert] CHECK CONSTRAINT [FK_DeviceAlert_Device]
GO
