/****** Object:  StoredProcedure [dbo].[SPGETUSERPROPERTITYIDANDBUILDINGID]    Script Date: 1/15/2015 4:37:32 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SPGETUSERPROPERTITYIDANDBUILDINGID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[SPGETUSERPROPERTITYIDANDBUILDINGID]
GO
/****** Object:  StoredProcedure [dbo].[GETBUILDINGID]    Script Date: 1/15/2015 4:37:32 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GETBUILDINGID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[GETBUILDINGID]
GO
/****** Object:  StoredProcedure [dbo].[GETBUILDINGID]    Script Date: 1/15/2015 4:37:32 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GETBUILDINGID]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

CREATE PROCEDURE [dbo].[GETBUILDINGID]
AS
BEGIN
SELECT UserBuilding.BuildingId as BuildingID,UserBuilding.UserId FROM UserBuilding;
END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[SPGETUSERPROPERTITYIDANDBUILDINGID]    Script Date: 1/15/2015 4:37:32 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SPGETUSERPROPERTITYIDANDBUILDINGID]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SPGETUSERPROPERTITYIDANDBUILDINGID]
@USERID int
AS
BEGIN
	DECLARE @ROLEIDOFUSER INT
	SET NOCOUNT ON;
	SET @ROLEIDOFUSER = (SELECT [USER].RoleId FROM [User] WHERE [User].ID = @USERID) 
	
	IF @ROLEIDOFUSER =  1 /*Portal Admin*/
	BEGIN
	SELECT ID as PropertyID,@USERID as UserId FROM Property;
	
	SELECT ID as BuildingID,@USERID as UserId FROM Building;
	END
	ELSE IF @ROLEIDOFUSER = 3 /*Building Admin*/
	BEGIN	
	SELECT b.PropertyId as PropertyID ,0 as UserId FROM Building b 
	INNER JOIN UserBuilding ub ON b.ID = ub.BuildingId
	WHERE ub.UserId =@USERID ; 
	
	SELECT UserBuilding.BuildingId as BuildingID,UserBuilding.UserId FROM UserBuilding
	WHERE UserBuilding.UserId =@USERID ; 
    END
	ELSE IF @ROLEIDOFUSER = 2 /*Property Admin*/
	BEGIN	
	SELECT UserProperty.PropertyId as PropertyID ,UserProperty.UserId FROM UserProperty
	WHERE UserProperty.UserId =@USERID ; 
	
	SELECT b.ID as BuildingID ,0 as UserId FROM Building b 
	INNER JOIN UserProperty up ON b.PropertyId = up.PropertyId
	WHERE up.UserId =@USERID ; 
	END
END



' 
END
GO
