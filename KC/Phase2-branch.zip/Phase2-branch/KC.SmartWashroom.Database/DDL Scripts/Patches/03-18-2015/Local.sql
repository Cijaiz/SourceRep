GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TimeZone]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[TimeZone](
    [ID] [tinyint] IDENTITY(1,1) NOT NULL,
    [Name] [nvarchar](1000) NOT NULL,
 CONSTRAINT [PK_TimeZone] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF)
)
END
GO