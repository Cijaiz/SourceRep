ALTER TABLE [dbo].[AlertMart]
ALTER COLUMN [DeviceId] nvarchar(30)

ALTER TABLE [dbo].[UsageMart]
ALTER COLUMN [DeviceId] nvarchar(30)