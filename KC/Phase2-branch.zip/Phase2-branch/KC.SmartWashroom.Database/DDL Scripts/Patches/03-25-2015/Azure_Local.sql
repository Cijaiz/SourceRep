﻿-- Note: Work in progress version.

-- --------------------------------------------------
-- DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 03/23/2015 05:30 PM EST
-- Created by: Kiran Chand Palakkattiri
-- --------------------------------------------------

-- --------------------------------------------------
-- Dropping existing views
-- --------------------------------------------------

If Object_Id(N'[dbo].[DeviceMetadata]', 'V') Is Not Null
    Drop View [dbo].[DeviceMetadata];
Go
If Object_Id(N'[dbo].[DeviceParameterMetadata]', 'V') Is Not Null
    Drop View [dbo].[DeviceParameterMetadata];
Go

-- --------------------------------------------------
-- Begin: View for loading device metadata
-- --------------------------------------------------

Create View [dbo].[DeviceMetadata]
    As Select Distinct [c].[ID] As [CustomerId]
        , [c].[Name] As [CustomerName]
        , [p].[ID] As [PropertyId]
        , [p].[PropertyName] As [PropertyName]
        , [b].[ID] As [BuildingId]
        , [b].[Name] As [BuildingName]
        , [fs].[ID] As [FloorSectionId]
        , [fs].[Name] As [FloorSectionName]
        , [f].[ID] As [FloorId]
        , [f].[FloorLevel] As [FloorLevel]
        , [rt].[ID] As [RestroomTypeId]
        , [rt].[Name] As [RestroomTypeName]
        , [r].[ID] As [RestroomId]
        , [r].[Name] As [RestroomName]
        , [dt].[ID] As [DeviceTypeId]
        , [dt].[Name] As [DeviceTypeName]
        , [d].[ID] As [DeviceId]
        , [d].[Name] As [DeviceName]
    From [dbo].[Customer] As [c] With (Nolock)
    Inner Join [dbo].[Property] As [p] With (Nolock)
        On [p].[CustomerId] = [c].[ID]
    Inner Join [dbo].[Building] As [b] With (Nolock)
        On [b].[PropertyId] = [p].[ID]
    Inner Join [dbo].[Floor] As [f] With (Nolock)
        On [f].[BuildingId] = [b].[ID]
    Inner Join [dbo].[Washroom] As [r] With (Nolock)
        On [r].[FloorId] = [f].[ID]
    Inner Join [dbo].[DeviceWashroom] As [drm] With (Nolock)
        On [drm].[WashroomId] = [r].[ID]		  
    Inner Join [dbo].[Device] As [d] With (Nolock)
        On [d].[ID] = [drm].[DeviceId]
    Inner Join [dbo].[DeviceType] As [dt] With (Nolock)
        On  [dt].[ID] = [d].[DeviceTypeId]
    Inner Join [dbo].[Wing] As [fs] With (Nolock)
        On [fs].[ID] = [r].[WingId]			
    Inner Join [dbo].[Gender] As [rt] With (Nolock)
        On [rt].[ID] = [r].[GenderId]
    Where [c].[IsActive] = 1
        And [p].[IsActive] = 1
        And [b].[IsActive] = 1
        And [f].[IsActive] = 1
        And [r].[IsActive] = 1
        And [d].[IsActive] = 1
        And [drm].[IsActive] = 1
Go
-- --------------------------------------------------
-- End: View for loading device metadata
-- --------------------------------------------------
Go
-- --------------------------------------------------
-- Begin: View for loading device parameter metadata
-- --------------------------------------------------
Create View [dbo].[DeviceParameterMetadata]
    As Select Distinct [dp].[Id]As [ParameterId]
    , [dp].[Name]
    , [dp].[Index]
    , [dp].[FormatCode]
    , [dp].[IsReturnParameter]
    , [dp].[IgnoreError]
    , [dp].[IsAutoReset]
    , [dt].[Id] As [DeviceTypeId]
    , [dt].[Name] As [DeviceTypeName]
    , [dpg].[Id] As [GroupId]
    , [dpg].[Name] As [GroupName]
    , [dpv].[Id] As [ValueId]
    , [dpv].[Value]
    , [dpv].[IsReset]
    , [dpv].[ResetTime]
    , [dpv].[ModifiedTime] -- As [ValueModifiedTime]
    , [dpv].[CustomerId]
    , [dpv].[DeviceId]   
    From [dbo].[DeviceType] As [dt] With (Nolock)
    Inner Join [dbo].[DeviceParameter] As [dp] With (Nolock)
        On [dp].[DeviceTypeId] = [dt].[ID]
    Left Outer Join [dbo].[DeviceParameterValue] As [dpv] With (Nolock)
        On [dpv].[ParameterId] = [dp].[Id]
    Left Outer Join [dbo].[DeviceParameterGroup] As [dpg] With (Nolock)
        On [dpg].[Id] = [dp].[PropertyGroupId]
    Left Outer Join [dbo].[Device] As [d] With (Nolock)
        On [d].[DeviceTypeId] = [dt].[ID]
    Where [dp].[IsActive] = 1		
        And [dt].[IsActive] = 1
        And ([d].[IsActive] = 1 Or [d].[IsActive] Is Null)
        And ([dpg].[IsActive] = 1 Or [dpg].[IsActive] Is Null)
Go
-- --------------------------------------------------
-- End: View for loading device metadata
-- --------------------------------------------------