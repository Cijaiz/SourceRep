
-- DROP FUNCTION
/****** Object:  UserDefinedFunction [dbo].[SplitString]    Script Date: 01/29/2015 11:54:34 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SplitString]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[SplitString]
GO


/****** Object:  UserDefinedFunction [dbo].[SplitString]    Script Date: 01/29/2015 11:54:34 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- CREATED FUNCTION
CREATE FUNCTION [dbo].[SplitString]
(    
      @Input NVARCHAR(MAX),
      @Character CHAR(1)
)
RETURNS @Output TABLE (
      Item NVARCHAR(1000)
)
AS
BEGIN
      DECLARE @StartIndex INT, @EndIndex INT
 
      SET @StartIndex = 1
      IF SUBSTRING(@Input, LEN(@Input) - 1, LEN(@Input)) <> @Character
      BEGIN
            SET @Input = @Input + @Character
      END
 
      WHILE CHARINDEX(@Character, @Input) > 0
      BEGIN
            SET @EndIndex = CHARINDEX(@Character, @Input)
           
            INSERT INTO @Output(Item)
            SELECT SUBSTRING(@Input, @StartIndex, @EndIndex - 1)
           
            SET @Input = SUBSTRING(@Input, @EndIndex + 1, LEN(@Input))
      END
 
      RETURN
END

GO

--DROP STOREDPROCEDURE

/****** Object:  StoredProcedure [dbo].[GETDEVICEDETAILS]    Script Date: 01/29/2015 11:53:46 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GETDEVICEDETAILS]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[GETDEVICEDETAILS]
GO

--CREATE STOREDPROCEDURE

/****** Object:  StoredProcedure [dbo].[GETDEVICEDETAILS]    Script Date: 01/29/2015 11:53:46 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[GETDEVICEDETAILS](@DEVICEID VARCHAR(MAX))
AS
BEGIN
DECLARE @PARAMS VARCHAR(MAX),
		@SPLITPARAMS VARCHAR(MAX)
		
	SET  @SPLITPARAMS = @DEVICEID

	SELECT A.ID AS DEVICEID ,A.Name AS DEVICENAME , B.Name AS DEVICETYPE ,D.ID AS WASHROOMID ,D.Name AS WASHROOMNAME,J.ID AS GENDERID,J.Name AS GENDER, E.ID AS WINGID,E.Name AS WINGNAME,
		   F.ID AS FLOORID,F.FloorLevel AS FLOORLEVEL ,G.ID AS BUILDINGID,G.Name AS BUILDINGNAME , H.ID AS PROPERTYID,H.PropertyName AS PROPERTYNAME,
		   I.ID AS CUSTOMERID ,I.Name AS CUSTOMERNAME		   
	FROM Device AS A
	INNER JOIN DeviceType AS B ON B.ID = A.DeviceTypeId
	INNER JOIN DeviceWashroom AS C ON C.DeviceId = A.ID
	INNER JOIN Washroom AS D ON D.ID = C.WashroomId	
	INNER JOIN Wing AS E ON D.WingId = E.ID
	INNER JOIN [Floor] AS F ON F.ID = D.FloorId
	INNER JOIN Building AS G ON F.BuildingId = G.ID
	INNER JOIN Property AS H ON G.PropertyId = H.ID 
	INNER JOIN Customer AS I ON I.ID = H.CustomerId
	INNER JOIN Gender AS J ON D.GenderId = J.ID
	WHERE A.ID IN(
	SELECT Item FROM dbo.SplitString(@DEVICEID, ',') )
	
END

GO



