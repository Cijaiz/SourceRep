IF Not Exists(select * from sys.columns where Name = N'MaximumVoltage' and Object_ID = Object_ID(N'DeviceType'))
ALTER TABLE [DeviceType] ADD [MaximumVoltage] decimal(2,1)

IF Not Exists(select * from sys.columns where Name = N'MinimumVoltage' and Object_ID = Object_ID(N'DeviceType'))
ALTER TABLE [DeviceType] ADD [MinimumVoltage] decimal(2,1)

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EsoapShotSize]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[EsoapShotSize](
	[ID] [tinyint] IDENTITY(1,1) NOT NULL,
	[Size] [nchar](1) NOT NULL,
	[Quantity] [decimal](3,2) NOT NULL,
 CONSTRAINT [PK_EsoapShotSize] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO