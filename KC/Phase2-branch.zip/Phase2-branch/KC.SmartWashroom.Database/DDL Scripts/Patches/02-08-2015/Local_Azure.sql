﻿-- --------------------------------------------------
-- DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 02/08/2015 05:30 PM EST
-- Created by Kiran Chand Palakkattiri
-- --------------------------------------------------

-- --------------------------------------------------
-- Increasing the size of the field [FormatCode]
-- for the table [dbo].[DeviceParameter]
-- --------------------------------------------------

If Exists
(
    Select Count(*) From sys.columns As [c] With (Nolock)
        Where [c].[Name]  = N'FormatCode'
            And [c].[Object_Id] = OBJECT_ID(N'[dbo].[DeviceParameter]', 'U')
)
Begin
    Alter Table [dbo].[DeviceParameter]
        Alter Column [FormatCode] nvarchar(255) Null
End
Go