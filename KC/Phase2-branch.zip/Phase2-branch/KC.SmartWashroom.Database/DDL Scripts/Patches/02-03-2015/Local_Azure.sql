
-- --------------------------------------------------
-- DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 02/03/2015 05:15 PM EST
-- Created by Kiran Chand Palakkattiri
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[FK_CreatedBy_ParameterGroup]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DeviceParameterGroup] DROP CONSTRAINT [FK_CreatedBy_ParameterGroup];
GO
IF OBJECT_ID(N'[dbo].[FK_ModifiedBy_ParameterGroup]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DeviceParameterGroup] DROP CONSTRAINT [FK_ModifiedBy_ParameterGroup];
GO
IF OBJECT_ID(N'[dbo].[FK_Parameter_Group]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DeviceParameter] DROP CONSTRAINT [FK_Parameter_Group];
GO
IF OBJECT_ID(N'[dbo].[FK_Device_ParameterValue]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DeviceParameterValue] DROP CONSTRAINT [FK_Device_ParameterValue];
GO
IF OBJECT_ID(N'[dbo].[FK_DeviceType_Parameter]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DeviceParameter] DROP CONSTRAINT [FK_DeviceType_Parameter];
GO
IF OBJECT_ID(N'[dbo].[FK_CreatedByUser_Parameter]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DeviceParameter] DROP CONSTRAINT [FK_CreatedByUser_Parameter];
GO
IF OBJECT_ID(N'[dbo].[FK_ModifiedByUser_Parameter]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DeviceParameter] DROP CONSTRAINT [FK_ModifiedByUser_Parameter];
GO
IF OBJECT_ID(N'[dbo].[FK_Parameter_ParameterValue]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DeviceParameterValue] DROP CONSTRAINT [FK_Parameter_ParameterValue];
GO
IF OBJECT_ID(N'[dbo].[FK_Customer_ParameterValue]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DeviceParameterValue] DROP CONSTRAINT [FK_Customer_ParameterValue];
GO
IF OBJECT_ID(N'[dbo].[FK_CreatedBy_ParameterValue]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DeviceParameterValue] DROP CONSTRAINT [FK_CreatedBy_ParameterValue];
GO
IF OBJECT_ID(N'[dbo].[FK_ModifiedBy_ParameterValue]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DeviceParameterValue] DROP CONSTRAINT [FK_ModifiedBy_ParameterValue];
GO

-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[DeviceParameterGroup]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DeviceParameterGroup];
GO
IF OBJECT_ID(N'[dbo].[DeviceParameter]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DeviceParameter];
GO
IF OBJECT_ID(N'[dbo].[DeviceParameterValue]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DeviceParameterValue];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'DeviceParameterGroup'
CREATE TABLE [dbo].[DeviceParameterGroup] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Name] nvarchar(20)  NOT NULL,
    [IsActive] bit  NOT NULL,
    [DisplayName] nvarchar(30)  NOT NULL,
    [Description] nvarchar(50)  NULL,
    [CreatedTime] datetime  NULL,
    [ModifiedTime] datetime  NULL,
    [CreatedById] int  NULL,
    [ModifiedById] int  NULL
);
GO
-- Creating table 'DeviceParameter'
CREATE TABLE [dbo].[DeviceParameter] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Name] nvarchar(20)  NOT NULL,
    [Index] int  NOT NULL,
    [FormatCode] nvarchar(255)  NULL,
    [IsReturnParameter] bit  NOT NULL,
    [IgnoreError] bit  NOT NULL,
    [IsAutoReset] bit  NOT NULL,
    [IsActive] bit  NOT NULL,
    [DisplayName] nvarchar(30)  NOT NULL,
    [Description] nvarchar(50)  NULL,
    [DataTypeName] nvarchar(25)  NULL,
    [FormatErrorMessage] nvarchar(100)  NULL,
    [CreatedTime] datetime  NULL,
    [ModifiedTime] datetime  NULL,
    [DeviceTypeId] tinyint   NULL,
    [CreatedById] int  NULL,
    [ModifiedById] int  NULL,
    [PropertyGroupId] int  NULL
);
GO

-- Creating table 'DeviceParameterValue'
CREATE TABLE [dbo].[DeviceParameterValue] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Value] nvarchar(25)  NOT NULL,
    [IsReset] bit  NULL,
    [ResetTime] datetime  NULL,
    [CreatedTime] datetime  NULL,
    [ModifiedTime] datetime  NULL,
    [ParameterId] int  NOT NULL,
    [CustomerId] int  NULL,
    [DeviceId] nvarchar(30)  NULL,
    [CreatedById] int  NULL,
    [ModifiedById] int  NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [Id] in table 'DeviceParameterGroup'
ALTER TABLE [dbo].[DeviceParameterGroup]
ADD CONSTRAINT [PK_DeviceParameterGroup]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO
-- Creating primary key on [Id] in table 'DeviceParameter'
ALTER TABLE [dbo].[DeviceParameter]
ADD CONSTRAINT [PK_DeviceParameter]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO
-- Creating primary key on [Id] in table 'DeviceParameterValue'
ALTER TABLE [dbo].[DeviceParameterValue]
ADD CONSTRAINT [PK_DeviceParameterValue]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [CreatedById] in table 'DeviceParameterGroup'
ALTER TABLE [dbo].[DeviceParameterGroup]
ADD CONSTRAINT [FK_CreatedBy_ParameterGroup]
    FOREIGN KEY ([CreatedById])
    REFERENCES [dbo].[User]
        ([ID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_CreatedBy_ParameterGroup'
CREATE INDEX [IX_FK_CreatedBy_ParameterGroup]
ON [dbo].[DeviceParameterGroup]
    ([CreatedById]);
GO

-- Creating foreign key on [ModifiedById] in table 'DeviceParameterGroup'
ALTER TABLE [dbo].[DeviceParameterGroup]
ADD CONSTRAINT [FK_ModifiedBy_ParameterGroup]
    FOREIGN KEY ([ModifiedById])
    REFERENCES [dbo].[User]
        ([ID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ModifiedBy_ParameterGroup'
CREATE INDEX [IX_FK_ModifiedBy_ParameterGroup]
ON [dbo].[DeviceParameterGroup]
    ([ModifiedById]);
GO

-- Creating foreign key on [PropertyGroupId] in table 'DeviceParameter'
ALTER TABLE [dbo].[DeviceParameter]
ADD CONSTRAINT [FK_Parameter_Group]
    FOREIGN KEY ([PropertyGroupId])
    REFERENCES [dbo].[DeviceParameterGroup]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Parameter_Group'
CREATE INDEX [IX_FK_Parameter_Group]
ON [dbo].[DeviceParameter]
    ([PropertyGroupId]);
GO

-- Creating foreign key on [DeviceId] in table 'DeviceParameterValue'
ALTER TABLE [dbo].[DeviceParameterValue]
ADD CONSTRAINT [FK_Device_ParameterValue]
    FOREIGN KEY ([DeviceId])
    REFERENCES [dbo].[Device]
        ([ID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Device_ParameterValue'
CREATE INDEX [IX_FK_Device_ParameterValue]
ON [dbo].[DeviceParameterValue]
    ([DeviceId]);
GO

-- Creating foreign key on [DeviceTypeId] in table 'DeviceParameter'
ALTER TABLE [dbo].[DeviceParameter]
ADD CONSTRAINT [FK_DeviceType_Parameter]
    FOREIGN KEY ([DeviceTypeId])
    REFERENCES [dbo].[DeviceType]
        ([ID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_DeviceType_Parameter'
CREATE INDEX [IX_FK_DeviceType_Parameter]
ON [dbo].[DeviceParameter]
    ([DeviceTypeId]);
GO

-- Creating foreign key on [CreatedById] in table 'DeviceParameter'
ALTER TABLE [dbo].[DeviceParameter]
ADD CONSTRAINT [FK_CreatedByUser_Parameter]
    FOREIGN KEY ([CreatedById])
    REFERENCES [dbo].[User]
        ([ID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_CreatedByUser_Parameter'
CREATE INDEX [IX_FK_CreatedByUser_Parameter]
ON [dbo].[DeviceParameter]
    ([CreatedById]);
GO

-- Creating foreign key on [ModifiedById] in table 'DeviceParameter'
ALTER TABLE [dbo].[DeviceParameter]
ADD CONSTRAINT [FK_ModifiedByUser_Parameter]
    FOREIGN KEY ([ModifiedById])
    REFERENCES [dbo].[User]
        ([ID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ModifiedByUser_Parameter'
CREATE INDEX [IX_FK_ModifiedByUser_Parameter]
ON [dbo].[DeviceParameter]
    ([ModifiedById]);
GO

-- Creating foreign key on [ParameterId] in table 'DeviceParameterValue'
ALTER TABLE [dbo].[DeviceParameterValue]
ADD CONSTRAINT [FK_Parameter_ParameterValue]
    FOREIGN KEY ([ParameterId])
    REFERENCES [dbo].[DeviceParameter]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Parameter_ParameterValue'
CREATE INDEX [IX_FK_Parameter_ParameterValue]
ON [dbo].[DeviceParameterValue]
    ([ParameterId]);
GO

-- Creating foreign key on [CustomerId] in table 'DeviceParameterValue'
ALTER TABLE [dbo].[DeviceParameterValue]
ADD CONSTRAINT [FK_Customer_ParameterValue]
    FOREIGN KEY ([CustomerId])
    REFERENCES [dbo].[Customer]
        ([ID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Customer_ParameterValue'
CREATE INDEX [IX_FK_Customer_ParameterValue]
ON [dbo].[DeviceParameterValue]
    ([CustomerId]);
GO

-- Creating foreign key on [CreatedById] in table 'DeviceParameterValue'
ALTER TABLE [dbo].[DeviceParameterValue]
ADD CONSTRAINT [FK_CreatedBy_ParameterValue]
    FOREIGN KEY ([CreatedById])
    REFERENCES [dbo].[User]
        ([ID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_CreatedBy_ParameterValue'
CREATE INDEX [IX_FK_CreatedBy_ParameterValue]
ON [dbo].[DeviceParameterValue]
    ([CreatedById]);
GO

-- Creating foreign key on [ModifiedById] in table 'DeviceParameterValue'
ALTER TABLE [dbo].[DeviceParameterValue]
ADD CONSTRAINT [FK_ModifiedBy_ParameterValue]
    FOREIGN KEY ([ModifiedById])
    REFERENCES [dbo].[User]
        ([ID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ModifiedBy_ParameterValue'
CREATE INDEX [IX_FK_ModifiedBy_ParameterValue]
ON [dbo].[DeviceParameterValue]
    ([ModifiedById]);
GO


-- --------------------------------------------------
-- Creating all DEFAULT constraints
-- --------------------------------------------------

-- Creating default value [IsActive] = 1 in table DeviceParameterGroup
Alter Table [dbo].[DeviceParameterGroup]
    Add Constraint DF_DeviceParameterGroup_IsActive
    Default 1 for [IsActive]
Go

-- Creating default value [CreatedDate] = GetDate() in table DeviceParameterGroup
Alter Table [dbo].[DeviceParameterGroup]
    Add Constraint DF_DeviceParameterGroup_CreatedTime
    Default GetDate() for [CreatedTime]
Go

-- Creating default value [Description] = '' in table DeviceParameterGroup
Alter Table [dbo].[DeviceParameterGroup]
    Add Constraint DF_DeviceParameterGroup_Description
    Default '' for [Description]
Go

-- Creating default value [IsReturnParameter] = 0 in table DeviceParameter
Alter Table [dbo].[DeviceParameter]
    Add Constraint DF_DeviceParameter_IsReturnParameter
    Default 0 for [IsReturnParameter]
Go
-- Creating default value [IsAutoReset] = 0 in table DeviceParameter
Alter Table [dbo].[DeviceParameter]
    Add Constraint DF_DeviceParameter_IsAutoReset
    Default 0 for [IsAutoReset]
Go
-- Creating default value [IsActive] = 1 in table DeviceParameter
Alter Table [dbo].[DeviceParameter]
    Add Constraint DF_DeviceParameter_IsActive
    Default 1 for [IsActive]
Go
-- Creating default value [DataTypeName] = 'Unsigned Short' in table DeviceParameter
Alter Table [dbo].[DeviceParameter]
    Add Constraint DF_DeviceParameter_DataTypeName
    Default 'Unsigned Short' for [DataTypeName]
Go

-- Creating default value [CreatedDate] = GetDate() in table DeviceParameter
Alter Table [dbo].[DeviceParameter]
    Add Constraint DF_DeviceParameter_CreatedDate
    Default GetDate() for [CreatedTime]
Go

-- Creating default value [FormatCode] = '' in table DeviceParameter
Alter Table [dbo].[DeviceParameter]
    Add Constraint DF_DeviceParameter_FormatCode
    Default '' for [FormatCode]
Go

-- Creating default value [Description] = '' in table DeviceParameter
Alter Table [dbo].[DeviceParameter]
    Add Constraint DF_DeviceParameter_Description
    Default '' for [Description]
Go

-- Creating default value [FormatErrorMessage] = '' in table DeviceParameter
Alter Table [dbo].[DeviceParameter]
    Add Constraint DF_DeviceParameter_FormatErrorMessage
    Default '' for [FormatErrorMessage]
Go

-- Creating default value [IgnoreError] = 1 in table DeviceParameter
Alter Table [dbo].[DeviceParameter]
    Add Constraint DF_DeviceParameter_IgnoreError
    Default 1 for [IgnoreError]
Go

-- Creating default value [IsReset] = 0 in table DeviceParameterValue
Alter Table [dbo].[DeviceParameterValue]
    Add Constraint DF_DeviceParameterValue_IsReset
    Default 0 for [IsReset]
Go

-- Creating default value [IsActive] = 1 in table DeviceParameterValue
Alter Table [dbo].[DeviceParameterValue]
    Add Constraint DF_DeviceParameterValue_CreatedTime
    Default GetDate() for [CreatedTime]
Go

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------