
/****** Object:  Table [dbo].[AlertMart]    Script Date: 01/13/2015 17:42:16 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AlertMart]') AND type in (N'U'))
DROP TABLE [dbo].[AlertMart]
GO
/****** Object:  Table [dbo].[AlertMart]   Script Date: 01/12/2015 17:42:16 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[AlertMart](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[AlertDate] [datetime] NOT NULL,
	[AlertDay] [int] NOT NULL,
	[AlertDayOfWeek] [nvarchar](10) NOT NULL,
	[AlertMonth] [nvarchar](10) NOT NULL,
	[AlertWeek] [int] NOT NULL,
	[AlertYear] [int] NOT NULL,
	[CustomerId] [nvarchar](10) NOT NULL,
	[PropertyId] [nvarchar](10) NOT NULL,
	[BuildingId] [nvarchar](10) NOT NULL,
	[FloorId] [nvarchar](10) NOT NULL,
	[FloorName] [nvarchar](50) NOT NULL,
	[WashRoomId] [nvarchar](20) NOT NULL,
	[DeviceId] [nvarchar](20) NOT NULL,
	[DeviceType] [nvarchar](50) NOT NULL,
	[AlertType] [nvarchar](10) NOT NULL,
	[CountOfAlert] [int] NOT NULL,
 CONSTRAINT [PK_AlertMart] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)
)

GO

/****** Object:  Table [dbo].[AggregationStatus]    Script Date: 1/13/2015 2:17:48 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AggregationStatus]') AND type in (N'U'))
DROP TABLE [dbo].[AggregationStatus]
GO


/****** Object:  Table [dbo].[AggregationStatus]    Script Date: 1/13/2015 2:17:48 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[AggregationStatus](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[CustomerId] [int] NOT NULL,
	[CustomerName] [nvarchar](50) NOT NULL,
	[Status] [nvarchar](20) NOT NULL,
	[Details] [nvarchar](max) NULL,
	[ProcessedDate] [date] NOT NULL,
 CONSTRAINT [PK_AggregationStatus] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)
)

GO

/****** Object:  Table [dbo].[UsageMart]    Script Date: 1/13/2015 2:23:46 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UsageMart]') AND type in (N'U'))
DROP TABLE [dbo].[UsageMart]
GO

/****** Object:  Table [dbo].[UsageMart]    Script Date: 1/13/2015 2:23:47 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[UsageMart](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[UsageDate] [datetime] NOT NULL,
	[UsageDay] [int] NOT NULL,
	[UsageDayOfWeek] [nvarchar](10) NOT NULL,
	[UsageMonth] [nvarchar](10) NOT NULL,
	[UsageWeek] [int] NOT NULL,
	[UsageYear] [int] NOT NULL,
	[CustomerId] [nvarchar](10) NOT NULL,
	[PropertyId] [nvarchar](10) NOT NULL,
	[BuildingId] [nvarchar](10) NOT NULL,
	[FloorId] [nvarchar](10) NOT NULL,
	[FloorName] [nvarchar](50) NOT NULL,
	[WashRoomId] [nvarchar](10) NOT NULL,
	[DeviceId] [nvarchar](20) NOT NULL,
	[DeviceType] [nvarchar](50) NOT NULL,
	[CountOfUsage] [int] NOT NULL,
	[TotalUsed] [int] NOT NULL,
	[TotalPaperTowel] [int] NOT NULL,
	[DispenserSize] [nvarchar](10) NOT NULL,
	[CountOfPaperUsed] [int] NOT NULL,
	[TotalBatteryChange] [int] NOT NULL,
	[CountOfBattery] [int] NOT NULL,
	[BatteryRefillBeforeThres] [int] NOT NULL,
	[TowelRefillBeforeThres] [int] NOT NULL,
 CONSTRAINT [PK_UsageMart] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)
)

GO






