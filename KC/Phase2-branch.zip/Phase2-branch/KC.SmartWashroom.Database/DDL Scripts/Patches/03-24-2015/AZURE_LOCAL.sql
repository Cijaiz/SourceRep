

/****** Object:  StoredProcedure [dbo].[SPGETUSERPROPERTITYIDANDBUILDINGID]    Script Date: 3/24/2015 12:40:46 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
ALTER PROCEDURE [dbo].[SPGETUSERPROPERTITYIDANDBUILDINGID] --2
@USERID int
AS
BEGIN
	DECLARE @ROLEIDOFUSER INT
	SET NOCOUNT ON;
	SET @ROLEIDOFUSER = (SELECT [USER].RoleId FROM [User] WHERE [User].ID = @USERID) 
	
	IF @ROLEIDOFUSER = 1 /*Portal Admin*/
	BEGIN
	SELECT ID as PropertyID,@USERID as UserId FROM Property;
	
	SELECT ID as BuildingID,@USERID as UserId FROM Building;
	END
	ELSE IF @ROLEIDOFUSER = 3 /*Building Admin*/
	BEGIN	
	SELECT b.PropertyId as PropertyID ,0 as UserId FROM Building b 
	INNER JOIN UserBuilding ub ON b.ID = ub.BuildingId
	WHERE ub.UserId =@USERID ; 
	
	SELECT UserBuilding.BuildingId as BuildingID,UserBuilding.UserId FROM UserBuilding
	WHERE UserBuilding.UserId =@USERID ; 
    END
	ELSE IF @ROLEIDOFUSER = 2 /*Property Admin*/
	BEGIN	
	SELECT UserProperty.PropertyId as PropertyID ,UserProperty.UserId FROM UserProperty
	WHERE UserProperty.UserId =@USERID ; 
	
	SELECT b.ID as BuildingID ,0 as UserId FROM Building b 
	INNER JOIN UserProperty up ON b.PropertyId = up.PropertyId
	WHERE up.UserId =@USERID ; 
	END
	ELSE IF @ROLEIDOFUSER = 4 /*Customer Admin*/
	BEGIN	
	SELECT p.ID as PropertyID,@USERID as UserId FROM Property p
	INNER JOIN [dbo].[User] u ON p.CustomerId = u.CustomerId
	WHERE u.ID = @USERID	
	
	SELECT b.ID as BuildingID,@USERID as UserId 
	FROM building b
	INNER JOIN Property p on b.propertyId = P.ID
	INNER JOIN [dbo].[User] u ON p.CustomerId = u.CustomerId
	WHERE u.ID = @USERID
	END
END









