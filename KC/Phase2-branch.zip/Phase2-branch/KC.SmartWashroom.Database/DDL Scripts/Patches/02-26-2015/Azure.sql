
/****** Object:  Table [dbo].[AzureSchedulerAudit]    Script Date: 2/26/2015 4:52:02 AM ******/
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AzureSchedulerAudit]') AND type in (N'U'))
DROP TABLE [dbo].[AzureSchedulerAudit]
GO

/****** Object:  Table [dbo].[AzureSchedulerAudit]    Script Date: 2/26/2015 4:52:03 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[AzureSchedulerAudit](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[SchedulerJobId] [nvarchar](100) NOT NULL,
	[CustomerId] [int] NOT NULL,
	[IsActive] [bit] NOT NULL,
 CONSTRAINT [PK_AzureSchedulerAudit] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)
)

GO


