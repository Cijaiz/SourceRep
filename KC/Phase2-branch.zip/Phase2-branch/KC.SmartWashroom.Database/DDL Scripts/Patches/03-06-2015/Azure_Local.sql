IF Not Exists(select * from sys.columns where Name = N'IsActive' and Object_ID = Object_ID(N'DeviceWashroom'))
ALTER TABLE [DeviceWashroom] ADD IsActive bit not null default 1