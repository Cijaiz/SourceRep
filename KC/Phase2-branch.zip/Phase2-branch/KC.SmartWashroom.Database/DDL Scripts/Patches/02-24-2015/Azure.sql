IF Not Exists(select * from sys.columns where Name = N'ImageUrl' and Object_ID = Object_ID(N'Building'))
ALTER TABLE [Building] ADD [ImageUrl] nvarchar(1000) 