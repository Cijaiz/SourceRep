IF Not Exists(select * from sys.columns where Name = N'ProductRefillId' and Object_ID = Object_ID(N'Device'))
ALTER TABLE [Device] ADD [ProductRefillId] int

IF OBJECT_ID(N'[dbo].[FK_ProductRefill]', 'F') IS  NULL
ALTER TABLE [dbo].[Device]
ADD CONSTRAINT [FK_ProductRefill]
    FOREIGN KEY ([ProductRefillId])
    REFERENCES [dbo].[ProductRefillDetail]
        ([ID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

