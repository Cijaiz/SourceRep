IF Not Exists(select * from sys.columns where Name = N'ProductRefillId' and Object_ID = Object_ID(N'Device'))
ALTER TABLE [Device] ADD [ProductRefillId] int

GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ProductRefill]') AND parent_object_id = OBJECT_ID(N'[dbo].[Device]'))
ALTER TABLE [dbo].[Device]  WITH CHECK ADD  CONSTRAINT [FK_ProductRefill] FOREIGN KEY([ProductRefillId])
REFERENCES [dbo].[ProductRefillDetail] ([ID])
GO