DECLARE @ProductUsageBuffer VarChar(20) = 'ProductUsageBuffer'
DECLARE @DeviceTypeFormats VarChar(20) = 'DeviceFormat'
DECLARE @SQL nVarChar(max)

--DDL For Adding ProductUsageBuffer
IF NOT EXISTS (SELECT 1 FROM sys.columns c WHERE c.name = @ProductUsageBuffer)
BEGIN
	SELECT @SQL = '
		ALTER TABLE DeviceType
		ADD ' + @ProductUsageBuffer + ' tinyint DEFAULT 10'
		EXEC sys.sp_executesql @SQL
END

--DDL For Adding DeviceTypeFormats
IF NOT EXISTS (SELECT 1 FROM sys.columns c WHERE c.name = @DeviceTypeFormats)
BEGIN

SELECT @SQL = '
          ALTER TABLE DeviceType
          ADD ' + @DeviceTypeFormats + ' VarChar(20)'
PRINT @SQL
     EXEC sys.sp_executesql @SQL
END