IF Exists(select * from sys.columns where Name = N'CustomerId' and Object_ID = Object_ID(N'AzureSchedulerAudit'))
EXEC SP_RENAME 'AzureSchedulerAudit.[CustomerId]' , 'PropertyId', 'COLUMN'


IF Exists(select * from sys.columns where Name = N'CustomerId' and Object_ID = Object_ID(N'AggregationStatus'))
EXEC SP_RENAME 'AggregationStatus.[CustomerId]' , 'PropertyId', 'COLUMN'



IF Exists(select * from sys.columns where Name = N'CustomerName' and Object_ID = Object_ID(N'AggregationStatus'))
ALTER TABLE AggregationStatus DROP COLUMN CustomerName