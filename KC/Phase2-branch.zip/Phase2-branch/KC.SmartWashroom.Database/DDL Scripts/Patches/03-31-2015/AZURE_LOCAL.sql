﻿DECLARE @ValueMapping VarChar(20) = 'ValueMapping'
DECLARE @SQL nVarChar(max)

--DDL For Adding ProductUsageBuffer
IF NOT EXISTS (SELECT 1 FROM sys.columns c WHERE c.name = @ValueMapping)
BEGIN
	SELECT @SQL = '
		ALTER TABLE DeviceParameterValue
		ADD ' + @ValueMapping + ' decimal(18,2) NOT NULL DEFAULT 0'
		EXEC sys.sp_executesql @SQL
END


