IF Not Exists(select * from sys.columns where Name = N'JobInterval' and Object_ID = Object_ID(N'Property'))
ALTER TABLE [Property] ADD [JobInterval]  int not null default 2