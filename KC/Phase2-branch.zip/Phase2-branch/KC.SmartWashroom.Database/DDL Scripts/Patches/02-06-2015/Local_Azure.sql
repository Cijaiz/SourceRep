IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeviceType]') AND type in (N'U'))
BEGIN
IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = N'IsActive' and OBJECT_ID = OBJECT_ID(N'[dbo].[DeviceType]'))
BEGIN
ALTER TABLE [dbo].[DeviceType]
ADD IsActive  bit NOT NULL DEFAULT 1
END
END