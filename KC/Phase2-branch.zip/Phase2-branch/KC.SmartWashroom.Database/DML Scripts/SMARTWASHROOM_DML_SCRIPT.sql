IF (SELECT COUNT(*) FROM [dbo].Country Where NAME = 'India') = 0
BEGIN
INSERT INTO [dbo].[Country]
           ([Name])
     VALUES
           ('India')
END

IF (SELECT COUNT(*) FROM [dbo].Country Where NAME = 'United States') = 0
BEGIN
INSERT INTO [dbo].[Country]
           ([Name])
     VALUES
           ('United States')
END

IF (SELECT COUNT(*) FROM [dbo].Country Where NAME = 'United Kingdom') = 0
BEGIN
INSERT INTO [dbo].[Country]
           ([Name])
     VALUES
           ('United Kingdom')
END


PRINT '[AlertType]'
IF (SELECT COUNT(*) FROM [dbo].[AlertType] Where [Type] = 'J1') = 0
BEGIN
INSERT INTO [dbo].[AlertType]
           ([Type])
     VALUES
           ('J1')
END
IF (SELECT COUNT(*) FROM [dbo].[AlertType] Where [Type] = 'J2') = 0
BEGIN
INSERT INTO [dbo].[AlertType]
           ([Type])
     VALUES
           ('J2')
END
IF (SELECT COUNT(*) FROM [dbo].[AlertType] Where [Type] = 'J3') = 0
BEGIN
INSERT INTO [dbo].[AlertType]
           ([Type])
     VALUES
           ('J3')
END
IF (SELECT COUNT(*) FROM [dbo].[AlertType] Where [Type] = 'S1') = 0
BEGIN
INSERT INTO [dbo].[AlertType]
           ([Type])
     VALUES
           ('S1')
END
IF (SELECT COUNT(*) FROM [dbo].[AlertType] Where [Type] = 'S2') = 0
BEGIN
INSERT INTO [dbo].[AlertType]
           ([Type])
     VALUES
           ('S2')
END
IF (SELECT COUNT(*) FROM [dbo].[AlertType] Where [Type] = 'S3') = 0
BEGIN
INSERT INTO [dbo].[AlertType]
           ([Type])
     VALUES
           ('S3')
END
IF (SELECT COUNT(*) FROM [dbo].[AlertType] Where [Type] = 'S4') = 0
BEGIN
INSERT INTO [dbo].[AlertType]
           ([Type])
     VALUES
           ('S4')
END
IF (SELECT COUNT(*) FROM [dbo].[AlertType] Where [Type] = 'H1') = 0
BEGIN
INSERT INTO [dbo].[AlertType]
           ([Type])
     VALUES
           ('H1')
END
IF (SELECT COUNT(*) FROM [dbo].[AlertType] Where [Type] = 'H2') = 0
BEGIN
INSERT INTO [dbo].[AlertType]
           ([Type])
     VALUES
           ('H2')
END
IF (SELECT COUNT(*) FROM [dbo].[AlertType] Where [Type] = 'H3') = 0
BEGIN
INSERT INTO [dbo].[AlertType]
           ([Type])
     VALUES
           ('H3')
END
IF (SELECT COUNT(*) FROM [dbo].[AlertType] Where [Type] = 'H4') = 0
BEGIN
INSERT INTO [dbo].[AlertType]
           ([Type])
     VALUES
           ('H4')
END
IF (SELECT COUNT(*) FROM [dbo].[AlertType] Where [Type] = 'H5') = 0
BEGIN
INSERT INTO [dbo].[AlertType]
           ([Type])
     VALUES
           ('H5')
END
IF (SELECT COUNT(*) FROM [dbo].[AlertType] Where [Type] = 'SR1') = 0
BEGIN
INSERT INTO [dbo].[AlertType]
           ([Type])
     VALUES
           ('SR1')
END
IF (SELECT COUNT(*) FROM [dbo].[AlertType] Where [Type] = 'SR2') = 0
BEGIN
INSERT INTO [dbo].[AlertType]
           ([Type])
     VALUES
           ('SR2')
END
IF (SELECT COUNT(*) FROM [dbo].[AlertType] Where [Type] = 'SR3') = 0
BEGIN
INSERT INTO [dbo].[AlertType]
           ([Type])
     VALUES
           ('SR3')
END



IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertName] Where [AlertName] = 'LowBatteryAlert') = 0
BEGIN
INSERT INTO [dbo].[DeviceAlertName]
           ([AlertName])
     VALUES
           ('LowBatteryAlert')
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertName] Where [AlertName] = 'PaperTransferAlert') = 0
BEGIN
INSERT INTO [dbo].[DeviceAlertName]
           ([AlertName])
     VALUES
           ('PaperTransferAlert')
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertName] Where [AlertName] = 'LowPaperAlert') = 0
BEGIN
INSERT INTO [dbo].[DeviceAlertName]
           ([AlertName])
     VALUES
           ('LowPaperAlert')
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertName] Where [AlertName] = 'LowSoapAlert') = 0
BEGIN
INSERT INTO [dbo].[DeviceAlertName]
           ([AlertName])
     VALUES
           ('LowSoapAlert')
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertName] Where [AlertName] = 'MotorOvercurrentAlert') = 0
BEGIN
INSERT INTO [dbo].[DeviceAlertName]
           ([AlertName])
     VALUES
           ('MotorOvercurrentAlert')
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertName] Where [AlertName] = 'VeryLowSoapAlert') = 0
BEGIN
INSERT INTO [dbo].[DeviceAlertName]
           ([AlertName])
     VALUES
           ('VeryLowSoapAlert')
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertName] Where [AlertName] = 'PaperJamAlert') = 0
BEGIN
INSERT INTO [dbo].[DeviceAlertName]
           ([AlertName])
     VALUES
           ('PaperJamAlert')
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertName] Where [AlertName] = 'TrashFullAlert') = 0
BEGIN
INSERT INTO [dbo].[DeviceAlertName]
           ([AlertName])
     VALUES
           ('TrashFullAlert')
END

PRINT '[DeviceType]'
IF (SELECT COUNT(*) FROM [dbo].[DeviceType] Where [Name]='JRT' ) = 0
BEGIN
INSERT INTO [dbo].[DeviceType]
           ([Name])
     VALUES
           ('JRT')
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceType] Where [Name]='eHRT' ) = 0
BEGIN
INSERT INTO [dbo].[DeviceType]
           ([Name])
     VALUES
           ('eHRT')
END
IF (SELECT COUNT(*) FROM [dbo].[DeviceType] Where [Name]='eSOAP' ) = 0
BEGIN
INSERT INTO [dbo].[DeviceType]
           ([Name])
     VALUES
           ('eSoap')

END

IF (SELECT COUNT(*) FROM [dbo].[DeviceType] Where [Name]='SRB' ) = 0
BEGIN
INSERT INTO [dbo].[DeviceType]
           ([Name])
     VALUES
           ('SRB')
END


IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 1 AND [AlertTypeId] =1 ) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
            DeviceTypeId,
            AlertTypeId,
            AlertNameId)
     VALUES
           (
           1
           ,1
           ,1
           )
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 1 AND [AlertTypeId] =2 ) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
            DeviceTypeId,
            AlertTypeId,
            AlertNameId)
     VALUES
           (
           1
           ,2
           ,2
           )
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 1 AND [AlertTypeId] =3 ) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
            DeviceTypeId,
            AlertTypeId,
            AlertNameId)
     VALUES
           (
           1
           ,3
           ,3
           )
END


IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 2 AND [AlertTypeId] =8 ) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
            DeviceTypeId,
            AlertTypeId,
            AlertNameId)
     VALUES
           (
           2
           ,8
           ,2
           )
END


IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 2 AND [AlertTypeId] =9 ) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
            DeviceTypeId,
            AlertTypeId,
            AlertNameId)
     VALUES
           (
           2
           ,9
           ,1
           )
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 2 AND [AlertTypeId] =10 ) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
            DeviceTypeId,
            AlertTypeId,
            AlertNameId)
     VALUES
           (
           2
           ,10
           ,7
           )
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 2 AND [AlertTypeId] =11) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
            DeviceTypeId,
            AlertTypeId,
            AlertNameId)
     VALUES
           (
           2
           ,11
           ,3
           )
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 2 AND [AlertTypeId] =12) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
            DeviceTypeId,
            AlertTypeId,
            AlertNameId)
     VALUES
           (
           2
           ,12
           ,8
           )
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 3 AND [AlertTypeId] =4) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
            DeviceTypeId,
            AlertTypeId,
            AlertNameId)
     VALUES
           (
           3
           ,4
           ,4
           )
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 3 AND [AlertTypeId] =5) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
            DeviceTypeId,
            AlertTypeId,
            AlertNameId)
     VALUES
           (
           3
           ,5
           ,1
           )
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 3 AND [AlertTypeId] =6) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
            DeviceTypeId,
            AlertTypeId,
            AlertNameId)
     VALUES
           (
           3
           ,6
           ,5
           )
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 3 AND [AlertTypeId] =7) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
            DeviceTypeId,
            AlertTypeId,
            AlertNameId)
     VALUES
           (
           3
           ,7
           ,6
           )
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 4 AND [AlertTypeId] =13) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
            DeviceTypeId,
            AlertTypeId,
            AlertNameId)
     VALUES
           (
           4
           ,13
           ,1
           )
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 4 AND [AlertTypeId] =14) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
            DeviceTypeId,
            AlertTypeId,
            AlertNameId)
     VALUES
           (
           4
           ,14
           ,2
           )
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 4 AND [AlertTypeId] =15) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
            DeviceTypeId,
            AlertTypeId,
            AlertNameId)
     VALUES
           (
           4
           ,15
           ,3
           )
END

IF (SELECT COUNT(*) FROM [dbo].[Role] Where [RoleLevel] = 1) = 0
BEGIN
INSERT INTO [dbo].[Role]
           (
            Name,
            RoleLevel
           )
     VALUES
           ('Portal Admin',
             1
             )
END

IF (SELECT COUNT(*) FROM [dbo].[Role] Where [RoleLevel] = 10) = 0
BEGIN
INSERT INTO [dbo].[Role]
           (
            Name,
            RoleLevel
           )
     VALUES
           ('Property Admin',
             10
             )
END

IF (SELECT COUNT(*) FROM [dbo].[Role] Where [RoleLevel] = 20) = 0
BEGIN
INSERT INTO [dbo].[Role]
           (
            Name,
            RoleLevel
           )
     VALUES
           ('Building Admin',
             20
             )

    END		 

IF (SELECT COUNT(*) FROM [dbo].[User] Where [LastName] = 'Admin' AND [FirstName]='Super' AND [RoleId] =1 ) = 0
BEGIN		   
INSERT INTO [dbo].[User]
           ([FirstName]
           ,[LastName]
           ,[Email]
           ,[MobileNo]
           ,[IsEmailAlert]
           ,[IsMobileAlert]
           ,[CustomerId]
           ,[RoleId]
           ,[IsDelete]
           ,[CreatedBy]
           ,[CreatedOn]
           ,[LastUpdatedBy]
           ,[LastUpdatedOn]
           ,[PasswordSalt]
           ,[Password])
     VALUES
           ('Super'
           ,'Admin'
           ,'admin@kcc.com'
           ,NULL
           ,1
           ,1
           ,NULL
           ,1
           ,0
           ,NULL
           ,GETDATE()
           ,NULL
           ,NULL
           ,'xuBGZYg+YA9tsgdfoBt33A=='
           ,'1dcJjWKEeqYm2ljQNawpvGBI9n8=')

END

IF (SELECT COUNT(*) FROM Product WHERE Type='eSOAP') = 0
BEGIN
INSERT INTO [dbo].[Product]
           ([Type])
     VALUES
           ('eSOAP')
END
IF (SELECT COUNT(*) FROM Product WHERE Type='JRT') = 0
BEGIN
INSERT INTO [dbo].[Product]
           ([Type])
     VALUES
           ('JRT')
END
IF (SELECT COUNT(*) FROM Product WHERE Type='eHRT') = 0
BEGIN
INSERT INTO [dbo].[Product]
           ([Type])
     VALUES
           ('eHRT')
END

IF (SELECT COUNT(*) FROM Product WHERE Type='SRB') = 0
BEGIN
INSERT INTO [dbo].[Product]
           ([Type])
     VALUES
           ('SRB')
END

IF (SELECT COUNT(*) FROM [ProductRefillDetail] WHERE [ProductId]=1 AND [Size]='S') = 0
BEGIN

INSERT INTO [dbo].[ProductRefillDetail]
           ([ProductId]
           ,[Size]
           ,[RefillValue])
     VALUES
           (1
           ,'S'
           ,'500')
END
IF (SELECT COUNT(*) FROM [ProductRefillDetail] WHERE [ProductId]=1 AND [Size]='M') = 0
BEGIN

INSERT INTO [dbo].[ProductRefillDetail]
           ([ProductId]
           ,[Size]
           ,[RefillValue])
     VALUES
           (1
           ,'M'
           ,'750')
END
IF (SELECT COUNT(*) FROM [ProductRefillDetail] WHERE [ProductId]=1 AND [Size]='L') = 0
BEGIN


INSERT INTO [dbo].[ProductRefillDetail]
           ([ProductId]
           ,[Size]
           ,[RefillValue])
     VALUES
           (1
           ,'L'
           ,'1000')
END
IF (SELECT COUNT(*) FROM [ProductRefillDetail] WHERE [ProductId]=2 AND [Size]='S') = 0
BEGIN


INSERT INTO [dbo].[ProductRefillDetail]
           ([ProductId]
           ,[Size]
           ,[RefillValue])
     VALUES
           (2
           ,'S'
           ,'500')
END
IF (SELECT COUNT(*) FROM [ProductRefillDetail] WHERE [ProductId]=2 AND [Size]='M') = 0
BEGIN

INSERT INTO [dbo].[ProductRefillDetail]
           ([ProductId]
           ,[Size]
           ,[RefillValue])
     VALUES
           (2
           ,'M'
           ,'750')
END
IF (SELECT COUNT(*) FROM [ProductRefillDetail] WHERE [ProductId]=2 AND [Size]='L') = 0
BEGIN

INSERT INTO [dbo].[ProductRefillDetail]
           ([ProductId]
           ,[Size]
           ,[RefillValue])
     VALUES
           (2
           ,'L'
           ,'1000')
END
IF (SELECT COUNT(*) FROM [ProductRefillDetail] WHERE [ProductId]=3 AND [Size]='S') = 0
BEGIN

INSERT INTO [dbo].[ProductRefillDetail]
           ([ProductId]
           ,[Size]
           ,[RefillValue])
     VALUES
           (3
           ,'S'
           ,'500')
END
IF (SELECT COUNT(*) FROM [ProductRefillDetail] WHERE [ProductId]=3 AND [Size]='M') = 0
BEGIN

INSERT INTO [dbo].[ProductRefillDetail]
           ([ProductId]
           ,[Size]
           ,[RefillValue])
     VALUES
           (3
           ,'M'
           ,'750')
END
IF (SELECT COUNT(*) FROM [ProductRefillDetail] WHERE [ProductId]=3 AND [Size]='L') = 0
BEGIN
INSERT INTO [dbo].[ProductRefillDetail]
           ([ProductId]
           ,[Size]
           ,[RefillValue])
     VALUES
           (3
           ,'L'
           ,'1000')
END

IF (SELECT COUNT(*) FROM [ProductRefillDetail] WHERE [ProductId]=4 AND [Size]='S') = 0
BEGIN

INSERT INTO [dbo].[ProductRefillDetail]
           ([ProductId]
           ,[Size]
           ,[RefillValue])
     VALUES
           (4
           ,'S'
           ,'500')
END
IF (SELECT COUNT(*) FROM [ProductRefillDetail] WHERE [ProductId]=4 AND [Size]='M') = 0
BEGIN

INSERT INTO [dbo].[ProductRefillDetail]
           ([ProductId]
           ,[Size]
           ,[RefillValue])
     VALUES
           (4
           ,'M'
           ,'750')
END
IF (SELECT COUNT(*) FROM [ProductRefillDetail] WHERE [ProductId]=4 AND [Size]='L') = 0
BEGIN


INSERT INTO [dbo].[ProductRefillDetail]
           ([ProductId]
           ,[Size]
           ,[RefillValue])
     VALUES
           (4
           ,'L'
           ,'1000')
END

IF (SELECT COUNT(*) FROM [dbo].[Gender] Where [Name]='Men' ) = 0
BEGIN
INSERT INTO [dbo].[Gender]
           ([Name])
     VALUES
           ('Men')
END
IF (SELECT COUNT(*) FROM [dbo].[Gender] Where [Name]='Women' ) = 0
BEGIN
INSERT INTO [dbo].[Gender]
           ([Name])
     VALUES
           ('Women')

END
IF (SELECT COUNT(*) FROM [dbo].[Gender] Where [Name]='Unisex' ) = 0
BEGIN
INSERT INTO [dbo].[Gender]
           ([Name])
     VALUES
           ('Unisex')

END
IF (SELECT COUNT(*) FROM [dbo].[Gender] Where [Name]='Family' ) = 0
BEGIN
INSERT INTO [dbo].[Gender]
           ([Name])
     VALUES
           ('Family')

END


PRINT '[Wing]'
IF (SELECT COUNT(*) FROM [dbo].[Wing] Where [Name]='North' ) = 0
BEGIN
INSERT INTO [dbo].[Wing]
           ([Name])
     VALUES
           ('North')
END
IF (SELECT COUNT(*) FROM [dbo].[Wing] Where [Name]='South' ) = 0
BEGIN
INSERT INTO [dbo].[Wing]
           ([Name])
     VALUES
           ('South')
END
IF (SELECT COUNT(*) FROM [dbo].[Wing] Where [Name]='Center' ) = 0
BEGIN
INSERT INTO [dbo].[Wing]
           ([Name])
     VALUES
           ('Center')
END

IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'ViewProperties - Dashboard') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('ViewProperties - Dashboard')
END

IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'ViewBuildings - Dashboard') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('ViewBuildings - Dashboard')
END

IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'ViewFloors - Dashboard') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('ViewFloors - Dashboard')
END

IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'ViewWashrooms - Dashboard') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('ViewWashrooms - Dashboard')
END

IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'ViewActivities - Dashboard') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('ViewActivities - Dashboard')
END

IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'ViewCustomers - Admin') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('ViewCustomers - Admin')
END

IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'CreateCustomers - Admin') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('CreateCustomers - Admin')
END

IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'EditCustomers - Admin') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('EditCustomers - Admin')
END

IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'DeleteCustomers - Admin') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('DeleteCustomers - Admin')
END

IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'ViewUsers - Admin') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('ViewUsers - Admin')
END

IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'CreateUsers - Admin') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('CreateUsers - Admin')
END

IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'EditUsers - Admin') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('EditUsers - Admin')
END

IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'DeleteUsers - Admin') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('DeleteUsers - Admin')
END
IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'ViewProperties - Admin') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('ViewProperties - Admin')
END

IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'CreateProperties - Admin') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('CreateProperties - Admin')
END

IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'EditProperties - Admin') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('EditProperties - Admin')
END

IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'DeleteProperties - Admin') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('DeleteProperties - Admin')
END

IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'ViewBuildings - Admin') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('ViewBuildings - Admin')
END

IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'CreateBuildings - Admin') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('CreateBuildings - Admin')
END

IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'EditBuildings - Admin') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('EditBuildings - Admin')
END

IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'DeleteBuildings - Admin') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('DeleteBuildings - Admin')
END


IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'ViewFloors - Admin') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('ViewFloors - Admin')
END

IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'CreateFloors - Admin') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('CreateFloors - Admin')
END

IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'EditFloors - Admin') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('EditFloors - Admin')
END

IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'DeleteFloors - Admin') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('DeleteFloors - Admin')
END
IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'ViewWashrooms - Admin') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('ViewWashrooms - Admin')
END

IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'CreateWashrooms - Admin') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('CreateWashrooms - Admin')
END

IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'EditWashrooms - Admin') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('EditWashrooms - Admin')
END

IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'DeleteWashrooms - Admin') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('DeleteWashrooms - Admin')
END

IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'ViewDevices - Admin') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('ViewDevices - Admin')
END

IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'CreateDevices - Admin') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('CreateDevices - Admin')
END

IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'EditDevices - Admin') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('EditDevices - Admin')
END


IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'DeleteDevices - Admin') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('DeleteDevices - Admin')
END


IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'Analytics') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('Analytics')
END

IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'GetAllCustomers') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('GetAllCustomers')
END

IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'GetAllBuildings') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('GetAllBuildings')
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =1 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(1,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =2 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(2,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =3 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(3,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =4 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(4,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =5 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(5,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =6 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(6,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =7 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(7,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =8 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(8,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =9 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(9,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =10 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(10,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =11 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(11,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =12 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(12,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =13 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(13,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =14 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(14,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =15 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(15,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =16 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(16,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =17 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(17,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =18 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(18,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =19 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(19,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =20 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(20,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =21 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(21,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =22 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(22,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =23 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(23,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =24 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(24,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =25 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(25,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =26 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(26,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =27 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(27,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =28 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(28,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =29 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(29,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =30 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(30,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =31 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(31,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =32 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(32,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =33 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(33,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =34 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(34,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =35 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(35,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =36 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(36,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =1 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(1,2)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =2 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(2,2)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =3 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(3,2)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =4 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(4,2)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =5 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(5,2)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =6 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(6,2)
END


IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =8 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(8,2)
END


IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =10 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(10,2)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =11 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(11,2)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =12 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(12,2)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =13 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(13,2)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =14 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(14,2)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =15 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(15,2)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =16 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(16,2)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =17 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(17,2)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =18 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(18,2)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =19 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(19,2)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =20 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(20,2)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =21 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(21,2)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =22 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(22,2)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =23 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(23,2)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =24 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(24,2)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =25 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(25,2)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =26 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(26,2)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =27 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(27,2)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =28 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(28,2)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =29 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(29,2)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =30 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(30,2)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =31 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(31,2)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =32 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(32,2)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =33 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(33,2)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =34 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(34,2)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =35 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(35,2)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =36 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(36,2)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =1 and RoleId = 3) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(1,3)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =2 and RoleId = 3) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(2,3)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =3 and RoleId = 3) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(3,3)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =4 and RoleId = 3) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(4,3)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =5 and RoleId = 3) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(5,3)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =18 and RoleId = 3) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(18,3)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =19 and RoleId = 3) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(19,3)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =20 and RoleId = 3) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(20,3)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =21 and RoleId = 3) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(21,3)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =22 and RoleId = 3) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(22,3)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =23 and RoleId = 3) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(23,3)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =24 and RoleId = 3) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(24,3)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =25 and RoleId = 3) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(25,3)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =26 and RoleId = 3) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(26,3)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =27 and RoleId = 3) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(27,3)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =28 and RoleId = 3) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(28,3)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =29 and RoleId = 3) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(29,3)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =30 and RoleId = 3) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(30,3)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =31 and RoleId = 3) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(31,3)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =32 and RoleId = 3) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(32,3)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =33 and RoleId = 3) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(33,3)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =34 and RoleId = 3) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(34,3)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =36 and RoleId = 3) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(36,3)
END

-- --------------------------------------------------
-- DML Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 02/08/2015 06:30 PM EST
-- Created by Kiran Chand Palakkattiri
-- --------------------------------------------------
Go

-- --------------------------------------------------
-- Begin: Initial data load for DeviceParameterGroup
-- --------------------------------------------------

-- Group Name: Gateway Detail
If Not Exists(Select * From [dbo].[DeviceParameterGroup] As [dpg] Where [dpg].[Name] = 'gatewayDetail') 
Insert InTo [dbo].[DeviceParameterGroup]
        ([Name], [DisplayName], [Description])
    Values
        ('gatewayDetail', 'Gateway Details', 'The gateway parameters')
Go

-- Group Name: Device Detail
If Not Exists(Select * From [dbo].[DeviceParameterGroup] As [dpg] Where [dpg].[Name] = 'deviceDetail') 
Insert InTo [dbo].[DeviceParameterGroup]
        ([Name], [DisplayName], [Description])
    Values
        ('deviceDetail', 'Device Details', 'The device parameters')
Go
-- --------------------------------------------------
-- End: Initial data load for DeviceParameterGroup
-- --------------------------------------------------
Go
-- --------------------------------------------------
-- Begin: Initial data load for DeviceParameter
-- --------------------------------------------------

-- Parameter Name: Sync Interval, Device Type: JRT, Index: 10
If Not Exists(Select * From [dbo].[DeviceParameter] As [dp] Where [dp].[Name] = 'syncInterval' And [dp].[DeviceTypeId] = 1)
Insert InTo [dbo].[DeviceParameter]
        ([Name], [Index], [IsReturnParameter], [IsAutoReset], [FormatCode], [DisplayName], [Description], [DataTypeName], [DeviceTypeId])
    Values
        ('syncInterval', 10, 1, 0, N'^([2-9]|[1-9][0-9]{1,2}|1[0-3][0-9]{2}|14[0-3][0-9]|1440)$', N'Sync Interval', N'Check-in Interval', 'Unsigned Short', 1)
Go

-- Parameter Name: Reset Device, Device Type: JRT, Index: 11
If Not Exists(Select * From [dbo].[DeviceParameter] As [dp] Where [dp].[Name] = 'resetDevice' And [dp].[DeviceTypeId] = 1)
Insert InTo [dbo].[DeviceParameter]
        ([Name], [Index], [IsReturnParameter], [IsAutoReset], [FormatCode], [DisplayName], [Description], [DataTypeName], [DeviceTypeId])
    Values	        
        ('resetDevice', 11, 1, 1, N'^[0-1]$', N'Reset Device', N'Restore Factory Settings', 'Boolean', 1)
Go

-- Parameter Name: Alert Resend Interval, Device Type: JRT, Index: 12
If Not Exists(Select * From [dbo].[DeviceParameter] As [dp] Where [dp].[Name] = 'alertResendInterval' And [dp].[DeviceTypeId] = 1)
Insert InTo [dbo].[DeviceParameter]
        ([Name], [Index],[IsReturnParameter], [IsAutoReset], [FormatCode], [DisplayName], [Description], [DataTypeName], [DeviceTypeId])
    Values	        
        ('alertResendInterval', 12, 1, 0, N'^([2-9]|[1-9][0-9]{1,2}|1[0-3][0-9]{2}|14[0-3][0-9]|1440)$', N'Alert Resend Interval', N'Alert Resend Interval', 'Unsigned Short', 1)
Go

-- Parameter Name: Reset Device, Device Type: eHRT, Index: 17
If Not Exists(Select * From [dbo].[DeviceParameter] As [dp] Where [dp].[Name] = 'resetDevice' And [dp].[DeviceTypeId] = 2)
Insert InTo [dbo].[DeviceParameter]
        ([Name], [Index],[IsReturnParameter], [IsAutoReset], [FormatCode], [DisplayName], [Description], [DataTypeName], [DeviceTypeId])
    Values	        
        ('resetDevice', 17, 1, 1, N'^[0-1]$', N'Reset Device', N'Restore Factory Settings', 'Boolean', 2)
Go

-- Parameter Name: Sync Interval, Device Type: eHRT, Index: 21
If Not Exists(Select * From [dbo].[DeviceParameter] As [dp] Where [dp].[Name] = 'syncInterval' And [dp].[DeviceTypeId] = 2)
Insert InTo [dbo].[DeviceParameter]
        ([Name], [Index],[IsReturnParameter], [IsAutoReset], [FormatCode], [DisplayName], [Description], [DataTypeName], [DeviceTypeId])
    Values
        ('syncInterval', 21, 1, 0, N'^([2-9]|[1-9][0-9]{1,2}|1[0-3][0-9]{2}|14[0-3][0-9]|1440)$', N'Sync Interval', N'Check-in Interval', 'Unsigned Short', 2)
Go
-- Parameter Name: Delay Enabled, Device Type: eHRT, Index: 23
If Not Exists(Select * From [dbo].[DeviceParameter] As [dp] Where [dp].[Name] = 'useAlert' And [dp].[DeviceTypeId] = 2)
Insert InTo [dbo].[DeviceParameter]
        ([Name], [Index],[IsReturnParameter], [IsAutoReset], [FormatCode], [DisplayName], [Description], [DataTypeName], [DeviceTypeId])
    Values	        
        ('useAlert', 23, 1, 0, N'^[0-1]$', N'Delay Enabled', N'Delay enabled in raising alerts', 'Boolean', 2)
Go

-- Parameter Name: Delay Count, Device Type: eHRT, Index: 24
If Not Exists(Select * From [dbo].[DeviceParameter] As [dp] Where [dp].[Name] = 'alertVal' And [dp].[DeviceTypeId] = 2)
Insert InTo [dbo].[DeviceParameter]
        ([Name], [Index],[IsReturnParameter], [IsAutoReset], [FormatCode], [DisplayName], [Description], [DataTypeName], [DeviceTypeId])
    Values
        ('alertVal', 24, 1, 0, N'^(0|[1-9][0-9]{0,3}|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-5])$', N'Delay Count', N'Delay count for raising alert', 'Unsigned Short', 2)
Go

-- Parameter Name: Alert Resend Interval, Device Type: eHRT, Index: 25
If Not Exists(Select * From [dbo].[DeviceParameter] As [dp] Where [dp].[Name] = 'alertResendInterval' And [dp].[DeviceTypeId] = 2)
Insert InTo [dbo].[DeviceParameter]
        ([Name], [Index],[IsReturnParameter], [IsAutoReset], [FormatCode], [DisplayName], [Description], [DataTypeName], [DeviceTypeId])
    Values	        
        ('alertResendInterval', 25, 1, 0, N'^([2-9]|[1-9][0-9]{1,2}|1[0-3][0-9]{2}|14[0-3][0-9]|1440)$', N'Alert Resend Interval', N'Alert Resend Interval', 'Unsigned Short', 2)
Go

-- Parameter Name: Sync Interval, Device Type: Soap, Index: 20
If Not Exists(Select * From [dbo].[DeviceParameter] As [dp] Where [dp].[Name] = 'syncInterval' And [dp].[DeviceTypeId] = 3)
Insert InTo [dbo].[DeviceParameter]
        ([Name], [Index],[IsReturnParameter], [IsAutoReset], [FormatCode], [DisplayName], [Description], [DataTypeName], [DeviceTypeId])
    Values
        ('syncInterval', 20, 1, 0, N'^([2-9]|[1-9][0-9]{1,2}|1[0-3][0-9]{2}|14[0-3][0-9]|1440)$', N'Sync Interval', N'Check-in Interval', 'Unsigned Short', 3)
Go

-- Parameter Name: Reset Device, Device Type: eSoap, Index: 21
If Not Exists(Select * From [dbo].[DeviceParameter] As [dp] Where [dp].[Name] = 'resetDevice' And [dp].[DeviceTypeId] = 3)
Insert InTo [dbo].[DeviceParameter]
        ([Name], [Index],[IsReturnParameter], [IsAutoReset], [FormatCode], [DisplayName], [Description], [DataTypeName], [DeviceTypeId])
    Values	        
        ('resetDevice', 21, 1, 1, N'^[0-1]$', N'Reset Device', N'Restore Factory Settings', 'Boolean', 3)
Go

-- Parameter Name: Alert Resend Interval, Device Type: eSoap, Index: 22
If Not Exists(Select * From [dbo].[DeviceParameter] As [dp] Where [dp].[Name] = 'alertResendInterval' And [dp].[DeviceTypeId] = 3)
Insert InTo [dbo].[DeviceParameter]
        ([Name], [Index],[IsReturnParameter], [IsAutoReset], [FormatCode], [DisplayName], [Description], [DataTypeName], [DeviceTypeId])
    Values	        
        ('alertResendInterval', 22, 1, 0, N'^([2-9]|[1-9][0-9]{1,2}|1[0-3][0-9]{2}|14[0-3][0-9]|1440)$', N'Alert Resend Interval', N'Alert Resend Interval', 'Unsigned Short', 3)
Go

-- Parameter Name: Sync Interval, Device Type: SRB, Index: 8
If Not Exists(Select * From [dbo].[DeviceParameter] As [dp] Where [dp].[Name] = 'syncInterval' And [dp].[DeviceTypeId] = 4)
Insert InTo [dbo].[DeviceParameter]
        ([Name], [Index],[IsReturnParameter], [IsAutoReset], [FormatCode], [DisplayName], [Description], [DataTypeName], [DeviceTypeId])
    Values
        ('syncInterval', 8, 1, 0, N'^([2-9]|[1-9][0-9]{1,2}|1[0-3][0-9]{2}|14[0-3][0-9]|1440)$', N'Sync Interval', N'Check-in Interval', 'Unsigned Short', 4)
Go

-- Parameter Name: Reset Device, Device Type: SRB, Index: 9
If Not Exists(Select * From [dbo].[DeviceParameter] As [dp] Where [dp].[Name] = 'resetDevice' And [dp].[DeviceTypeId] = 4)
Insert InTo [dbo].[DeviceParameter]
        ([Name], [Index],[IsReturnParameter], [IsAutoReset], [FormatCode], [DisplayName], [Description], [DataTypeName], [DeviceTypeId])
    Values	        
        ('resetDevice', 9, 1, 1, N'^[0-1]$', N'Reset Device', N'Restore Factory Settings', 'Boolean', 4)
Go

-- Parameter Name: Alert Resend Interval, Device Type: SRB, Index: 10
If Not Exists(Select * From [dbo].[DeviceParameter] As [dp] Where [dp].[Name] = 'alertResendInterval' And [dp].[DeviceTypeId] = 4)
Insert InTo [dbo].[DeviceParameter]
        ([Name], [Index],[IsReturnParameter], [IsAutoReset], [FormatCode], [DisplayName], [Description], [DataTypeName], [DeviceTypeId])
    Values	        
        ('alertResendInterval', 10, 1, 0, N'^([2-9]|[1-9][0-9]{1,2}|1[0-3][0-9]{2}|14[0-3][0-9]|1440)$', N'Alert Resend Interval', N'Alert Resend Interval', 'Unsigned Short', 4)
Go

-- --------------------------------------------------
-- End: Initial data load for DeviceParameter
-- --------------------------------------------------
Go

-- --------------------------------------------------
-- Begin: Initial data load for DeviceParameterValue
-- --------------------------------------------------

-- Device Type: JRT; Parameter Name: Sync Interval
If Not Exists(Select * From [dbo].[DeviceParameterValue] As [dpv] Where [dpv].[ParameterId] = 1)
Insert InTo [dbo].[DeviceParameterValue]
        ([Value], [ParameterId])
    Values	        
        ('480', 1)
Go

-- Device Type: JRT; Parameter Name: Reset Device
If Not Exists(Select * From [dbo].[DeviceParameterValue] As [dpv] Where [dpv].[ParameterId] = 2)
Insert InTo [dbo].[DeviceParameterValue]
        ([Value], [ParameterId])
    Values	        
        ('0', 2)
Go

-- Device Type: JRT; Parameter Name: Alert Resend Interval
If Not Exists(Select * From [dbo].[DeviceParameterValue] As [dpv] Where [dpv].[ParameterId] = 3)
Insert InTo [dbo].[DeviceParameterValue]
        ([Value], [ParameterId])
    Values	        
        ('480', 3)
Go

-- Device Type: eHRT; Parameter Name: Reset Device
If Not Exists(Select * From [dbo].[DeviceParameterValue] As [dpv] Where [dpv].[ParameterId] = 4)
Insert InTo [dbo].[DeviceParameterValue]
        ([Value], [ParameterId])
    Values	        
        ('0', 4)
Go
-- Device Type: eHRT; Parameter Name: Sync Interval
If Not Exists(Select * From [dbo].[DeviceParameterValue] As [dpv] Where [dpv].[ParameterId] = 5)
Insert InTo [dbo].[DeviceParameterValue]
        ([Value], [ParameterId])
    Values	        
        ('480', 5)
Go

-- Device Type: eHRT; Parameter Name: Delay Enabled
If Not Exists(Select * From [dbo].[DeviceParameterValue] As [dpv] Where [dpv].[ParameterId] = 6)
Insert InTo [dbo].[DeviceParameterValue]
        ([Value], [ParameterId])
    Values	        
        ('0', 6)
Go

-- Device Type: eHRT; Parameter Name: Delay Value
If Not Exists(Select * From [dbo].[DeviceParameterValue] As [dpv] Where [dpv].[ParameterId] = 7)
Insert InTo [dbo].[DeviceParameterValue]
        ([Value], [ParameterId])
    Values	        
        ('40', 7)
Go

-- Device Type: eHRT; Parameter Name: Alert Resend Interval
If Not Exists(Select * From [dbo].[DeviceParameterValue] As [dpv] Where [dpv].[ParameterId] = 8)
Insert InTo [dbo].[DeviceParameterValue]
        ([Value], [ParameterId])
    Values	        
        ('480', 8)
Go

-- Device Type: eSoap; Parameter Name: Sync Interval
If Not Exists(Select * From [dbo].[DeviceParameterValue] As [dpv] Where [dpv].[ParameterId] = 9)
Insert InTo [dbo].[DeviceParameterValue]
        ([Value], [ParameterId])
    Values	        
        ('480', 9)
Go

-- Device Type: eSoap; Parameter Name: Reset Device
If Not Exists(Select * From [dbo].[DeviceParameterValue] As [dpv] Where [dpv].[ParameterId] = 10)
Insert InTo [dbo].[DeviceParameterValue]
        ([Value], [ParameterId])
    Values	        
        ('0', 10)
Go

-- Device Type: eSoap; Parameter Name: Alert Resend Interval
If Not Exists(Select * From [dbo].[DeviceParameterValue] As [dpv] Where [dpv].[ParameterId] = 11)
Insert InTo [dbo].[DeviceParameterValue]
        ([Value], [ParameterId])
    Values	        
        ('480', 11)
Go

-- Device Type: SRB; Parameter Name: Sync Interval
If Not Exists(Select * From [dbo].[DeviceParameterValue] As [dpv] Where [dpv].[ParameterId] = 12)
Insert InTo [dbo].[DeviceParameterValue]
        ([Value], [ParameterId])
    Values	        
        ('480', 12)
Go

-- Device Type: SRB; Parameter Name: Reset Device
If Not Exists(Select * From [dbo].[DeviceParameterValue] As [dpv] Where [dpv].[ParameterId] = 13)
Insert InTo [dbo].[DeviceParameterValue]
        ([Value], [ParameterId])
    Values	        
        ('0', 13)
Go

-- Device Type: SRB; Parameter Name: Alert Resend Interval
If Not Exists(Select * From [dbo].[DeviceParameterValue] As [dpv] Where [dpv].[ParameterId] = 14)
Insert InTo [dbo].[DeviceParameterValue]
        ([Value], [ParameterId])
    Values	        
        ('480', 14)
Go
-- --------------------------------------------------
-- End: Initial data load for DeviceParameterValue
-- --------------------------------------------------