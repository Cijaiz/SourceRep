
-- Update DeviceFormat for All Device TYpes
UPDATE DeviceType SET BatteryScaleFactor = '0.007949' WHERE Name = 'JRT'
UPDATE DeviceType SET BatteryScaleFactor = '0.0103125' WHERE Name = 'eHRT'
UPDATE DeviceType SET BatteryScaleFactor = '0.0103125' WHERE Name = 'eSoap'
UPDATE DeviceType SET BatteryScaleFactor = '0.007949' WHERE Name = 'SRB'