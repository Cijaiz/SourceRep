IF (SELECT COUNT(*) FROM [dbo].[Role] Where [Name] = 'Customer Admin') = 0
BEGIN
INSERT INTO [dbo].[Role]
           ([Name] ,[RoleLevel])
     VALUES
           ('Customer Admin',
		    5
		   )
END
IF (SELECT COUNT(*) FROM [dbo].[Role] Where [Name] = 'Cleaner') = 0
BEGIN
INSERT INTO [dbo].[Role]
           ([Name] ,[RoleLevel])
     VALUES
           ('Cleaner',
		    40
		   )
END




IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'ReturnParameters - Admin') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('ReturnParameters - Admin')
END


IF (SELECT COUNT(*) FROM [dbo].[Feature] Where NAME = 'GetAllProperties') = 0
BEGIN
INSERT INTO [dbo].[Feature]
([Name])
VALUES
('GetAllProperties')
END


IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =1 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(1,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =2 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(2,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =3 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(3,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =4 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(4,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =5 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(5,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =6 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(6,4)
END



IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =8 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(8,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =9 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(9,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =10 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(10,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =11 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(11,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =12 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(12,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =13 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(13,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =14 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(14,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =15 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(15,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =16 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(16,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =17 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(17,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =18 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(18,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =19 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(19,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =20 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(20,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =21 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(21,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =22 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(22,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =23 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(23,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =24 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(24,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =25 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(25,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =26 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(26,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =27 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(27,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =28 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(28,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =29 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(29,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =30 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(30,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =31 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(31,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =32 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(32,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =33 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(33,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =34 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(34,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =35 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(35,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =36 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(36,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =37 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(37,4)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =38 and RoleId = 4) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(38,4)
END


IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =38 and RoleId = 2) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(38,2)
END


IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =37 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(37,1)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =38 and RoleId = 1) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(38,1)
END

---To Delete the create and delete properties access for proeprty admin


IF (SELECT COUNT(*) FROM [DBO].[ROLEPERMISSION] WHERE [FEATUREID] =15 AND ROLEID = 2) = 1
BEGIN
DELETE FROM 
DBO.ROLEPERMISSION 
WHERE FEATUREID = 15 AND ROLEID=2
END

IF (SELECT COUNT(*) FROM [DBO].[ROLEPERMISSION] WHERE [FEATUREID] =17 AND ROLEID = 2) = 1
BEGIN
DELETE FROM 
DBO.ROLEPERMISSION 
WHERE FEATUREID = 17 AND ROLEID=2
END