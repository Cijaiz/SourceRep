IF (SELECT COUNT(*) FROM [dbo].TimeZone Where Name = 'India Standard Time') = 0
BEGIN
INSERT INTO [dbo].[TimeZone]
           ([Name])
     VALUES
           ('India Standard Time')
END

IF (SELECT COUNT(*) FROM [dbo].TimeZone Where Name = 'Central America Standard Time') = 0
BEGIN
INSERT INTO [dbo].[TimeZone]
           ([Name])
     VALUES
           ('Central America Standard Time')
END

IF (SELECT COUNT(*) FROM [dbo].TimeZone Where Name = 'Alaskan Standard Time') = 0
BEGIN
INSERT INTO [dbo].[TimeZone]
           ([Name])
     VALUES
           ('Alaskan Standard Time')
END

IF (SELECT COUNT(*) FROM [dbo].TimeZone Where Name = 'Atlantic Standard Time') = 0
BEGIN
INSERT INTO [dbo].[TimeZone]
           ([Name])
     VALUES
           ('Atlantic Standard Time')
END

IF (SELECT COUNT(*) FROM [dbo].TimeZone Where Name = 'Eastern Standard Time') = 0
BEGIN
INSERT INTO [dbo].[TimeZone]
           ([Name])
     VALUES
           ('Eastern Standard Time')
END

IF (SELECT COUNT(*) FROM [dbo].TimeZone Where Name = 'Mountain Standard Time') = 0
BEGIN
INSERT INTO [dbo].[TimeZone]
           ([Name])
     VALUES
           ('Mountain Standard Time')
END

IF (SELECT COUNT(*) FROM [dbo].TimeZone Where Name = 'Pacific Standard Time') = 0
BEGIN
INSERT INTO [dbo].[TimeZone]
           ([Name])
     VALUES
           ('Pacific Standard Time')
END

IF (SELECT COUNT(*) FROM [dbo].TimeZone Where Name = 'Hawaiian Standard Time') = 0
BEGIN
INSERT INTO [dbo].[TimeZone]
           ([Name])
     VALUES
           ('Hawaiian Standard Time')
END

IF (SELECT COUNT(*) FROM [dbo].TimeZone Where Name = 'E. Europe Standard Time') = 0
BEGIN
INSERT INTO [dbo].[TimeZone]
           ([Name])
     VALUES
           ('E. Europe Standard Time')
END

IF (SELECT COUNT(*) FROM [dbo].TimeZone Where Name = 'Central Europe Standard Time') = 0
BEGIN
INSERT INTO [dbo].[TimeZone]
           ([Name])
     VALUES
           ('Central Europe Standard Time')
END

IF (SELECT COUNT(*) FROM [dbo].TimeZone Where Name = 'W. Europe Standard Time') = 0
BEGIN
INSERT INTO [dbo].[TimeZone]
           ([Name])
     VALUES
           ('W. Europe Standard Time')
END