IF (SELECT COUNT(*) FROM [dbo].ProductRefillDetail Where ProductId = 1 and Size ='S') = 1
BEGIN
UPDATE [dbo].[ProductRefillDetail] SET
 RefillValue=800
 where ProductId = 1 and Size='S'
END

IF (SELECT COUNT(*) FROM [dbo].ProductRefillDetail Where ProductId = 1 and Size ='M') = 1
BEGIN
UPDATE [dbo].[ProductRefillDetail] SET
 RefillValue=1200
 where ProductId = 1 and Size='M'
END

IF (SELECT COUNT(*) FROM [dbo].ProductRefillDetail Where ProductId = 1 and Size ='L') = 1
BEGIN
UPDATE [dbo].[ProductRefillDetail] SET
 RefillValue=1500
 where ProductId = 1 and Size='L'
END

GO

IF (SELECT COUNT(*) FROM [dbo].ProductRefillDetail Where ProductId = 3 and Size ='S') = 1
BEGIN
UPDATE [dbo].[ProductRefillDetail] SET
 RefillValue=700
 where ProductId = 3 and Size='S'
END

IF (SELECT COUNT(*) FROM [dbo].ProductRefillDetail Where ProductId = 3 and Size ='M') = 1
BEGIN
UPDATE [dbo].[ProductRefillDetail] SET
 RefillValue=997
 where ProductId = 3 and Size='M'
END

IF (SELECT COUNT(*) FROM [dbo].ProductRefillDetail Where ProductId = 3 and Size ='L') = 1
BEGIN
UPDATE [dbo].[ProductRefillDetail] SET
 RefillValue=1150
 where ProductId = 3 and Size='L'
END