--Set the default value to 'S' for eHRT devices
IF (SELECT COUNT(*) FROM [dbo].[Device] Where DeviceTypeId = 2) >= 1
BEGIN
Update [dbo].[Device] 
    SET ProductRefillId=7 
	WHERE DeviceTypeId=2
END
