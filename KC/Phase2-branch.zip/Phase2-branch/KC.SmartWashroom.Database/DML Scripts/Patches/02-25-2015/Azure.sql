IF (SELECT COUNT(*) FROM [dbo].DeviceType Where NAME = 'JRT') = 1
BEGIN
UPDATE [dbo].[DeviceType] SET
 MaximumVoltage=6,
 MinimumVoltage=4.4 
 where Name='JRT'
END

IF (SELECT COUNT(*) FROM [dbo].DeviceType Where NAME = 'eHRT') = 1
BEGIN
UPDATE [dbo].[DeviceType] SET
 MaximumVoltage=6,
 MinimumVoltage=5.0 
 where Name='eHRT'
END

IF (SELECT COUNT(*) FROM [dbo].DeviceType Where NAME = 'eSoap') = 1
BEGIN
UPDATE [dbo].[DeviceType] SET
 MaximumVoltage=6,
 MinimumVoltage=4.4 
 where Name='eSoap'
END

IF (SELECT COUNT(*) FROM [dbo].DeviceType Where NAME = 'SRB') = 1
BEGIN
UPDATE [dbo].[DeviceType] SET
 MaximumVoltage=6,
 MinimumVoltage=4.4 
 where Name='SRB'
END

IF (SELECT COUNT(*) FROM [dbo].[EsoapShotSize] Where [Size] = 'S') = 0
BEGIN
INSERT INTO [dbo].[EsoapShotSize]
           ([Size],
		    [Quantity]
		   )
     VALUES
           ('S',
		    0.68
		   )
END

IF (SELECT COUNT(*) FROM [dbo].[EsoapShotSize] Where [Size] = '1') = 0
BEGIN
INSERT INTO [dbo].[EsoapShotSize]
           ([Size],
		    [Quantity]
		   )
     VALUES
           ('1',
		    0.68
		   )
END

IF (SELECT COUNT(*) FROM [dbo].[EsoapShotSize] Where [Size] = '2') = 0
BEGIN
INSERT INTO [dbo].[EsoapShotSize]
           ([Size],
		    [Quantity]
		   )
     VALUES
           ('2',
		    0.68
		   )
END