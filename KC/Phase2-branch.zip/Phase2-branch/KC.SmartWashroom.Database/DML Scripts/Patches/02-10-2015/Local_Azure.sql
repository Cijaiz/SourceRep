﻿
-- --------------------------------------------------
-- DML Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 02/10/2015 
-- Created by Mohankumar
-- --------------------------------------------------
Go

-- Update validation message
UPDATE [DeviceParameter] SET FormatErrorMessage = 'Please enter value between 2 to 1440' WHERE Name IN ('syncInterval','alertResendInterval')
GO
UPDATE [DeviceParameter] SET FormatErrorMessage = 'Please enter value between 0 to 1' WHERE Name IN ('resetDevice','useAlert' )
GO
UPDATE [DeviceParameter] SET FormatErrorMessage = 'Please enter value between 0 to 65535' WHERE Name ='alertVal'
GO
