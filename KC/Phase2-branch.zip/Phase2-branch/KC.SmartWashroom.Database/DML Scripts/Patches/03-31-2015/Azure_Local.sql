IF EXISTS(Select 1 from [dbo].[Property] where imageurl='http://kcdevelopment.blob.core.windows.net/mediastore/no_image.png')
BEGIN
update [dbo].[Property]
set imageurl=''
 where imageurl='http://kcdevelopment.blob.core.windows.net/mediastore/no_image.png'
END 

IF EXISTS(Select 1 from [dbo].[Building] where imageurl='http://kcdevelopment.blob.core.windows.net/mediastore/no_image.png')
BEGIN
update [dbo].[Building]
set imageurl=''
 where imageurl='http://kcdevelopment.blob.core.windows.net/mediastore/no_image.png'
END 


IF NOT EXISTS(Select 1 From DeviceParameter Where Name = 'eSoapShotSize')
BEGIN
INSERT INTO DeviceParameter
VALUES
('eSoapShotSize',2,null,'False','True','False','True','eSoapShotSize','Shot Size For ESoap','Decimal','',GETDATE(),NULL,3,NULL,NULL,NULL)
END


IF NOT EXISTS(Select 1 From DeviceParameterValue Where ParameterId=16 AND CustomerId IS NULL And DeviceID IS NULL AND VALUE='S')
BEGIN
INSERT INTO DeviceParameterValue
VALUES
('S','False',NULL,GETDATE(),NULL,16,NULL,NULL,NULL,NULL,0.68)
END

IF NOT EXISTS(Select 1 From DeviceParameterValue Where ParameterId=16 AND CustomerId IS NULL And DeviceID IS NULL AND VALUE='1')
BEGIN
INSERT INTO DeviceParameterValue
VALUES
('1','False',NULL,GETDATE(),NULL,16,NULL,NULL,NULL,NULL,0.68)
END

IF NOT EXISTS(Select 1 From DeviceParameterValue Where ParameterId=16 AND CustomerId IS NULL And DeviceID IS NULL AND VALUE='2')
BEGIN
INSERT INTO DeviceParameterValue
VALUES
('2','False',NULL,GETDATE(),NULL,16,NULL,NULL,NULL,NULL,0.68)
END