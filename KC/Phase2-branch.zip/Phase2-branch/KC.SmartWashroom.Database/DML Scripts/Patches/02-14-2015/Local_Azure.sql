﻿
-- --------------------------------------------------
-- DML Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 02/14/2015 
-- Created by Mohankumar
-- --------------------------------------------------
Go

-- removed alertresend for soap -Defect Id 2566
Update deviceParameter SET IsACtive=0 where deviceTypeId=3 and Name='alertResendInterval'
GO

