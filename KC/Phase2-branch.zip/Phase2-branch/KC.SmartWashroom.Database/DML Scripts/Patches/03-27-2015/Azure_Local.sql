--Update Product Usage Buffer to Default 10
UPDATE DeviceType SET ProductUsageBuffer = 10

-- Update DeviceFormat for All Device TYpes
UPDATE DeviceType SET DeviceFormat = '000008' WHERE Name = 'JRT'
UPDATE DeviceType SET DeviceFormat = '000000' WHERE Name = 'eHRT'
UPDATE DeviceType SET DeviceFormat = '000007' WHERE Name = 'eSoap'
UPDATE DeviceType SET DeviceFormat = '000011' WHERE Name = 'SRB'