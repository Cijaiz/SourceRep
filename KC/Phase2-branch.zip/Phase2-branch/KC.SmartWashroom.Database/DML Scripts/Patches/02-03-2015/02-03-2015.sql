﻿
-- --------------------------------------------------
-- DML Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 02/03/2015 08:30 PM EST
-- Created by Kiran Chand Palakkattiri
-- --------------------------------------------------
Go
-- --------------------------------------------------
-- Begin: Initial data load for DeviceParameterGroup
-- --------------------------------------------------

-- Group Name: Gateway Detail
If Not Exists(Select * From [dbo].[DeviceParameterGroup] As [dpg] Where [dpg].[Name] = 'gatewayDetail') 
Insert InTo [dbo].[DeviceParameterGroup]
        ([Name], [DisplayName], [Description])
    Values
        ('gatewayDetail', 'Gateway Details', 'The gateway parameters')
Go

-- Group Name: Device Detail
If Not Exists(Select * From [dbo].[DeviceParameterGroup] As [dpg] Where [dpg].[Name] = 'deviceDetail') 
Insert InTo [dbo].[DeviceParameterGroup]
        ([Name], [DisplayName], [Description])
    Values
        ('deviceDetail', 'Device Details', 'The device parameters')
Go
-- --------------------------------------------------
-- End: Initial data load for DeviceParameterGroup
-- --------------------------------------------------
Go
-- --------------------------------------------------
-- Begin: Initial data load for DeviceParameter
-- --------------------------------------------------

-- Parameter Name: Sync Interval, Device Type: JRT, Index: 10
If Not Exists(Select * From [dbo].[DeviceParameter] As [dp] Where [dp].[Name] = 'syncInterval' And [dp].[DeviceTypeId] = 1)
Insert InTo [dbo].[DeviceParameter]
        ([Name], [Index], [IsReturnParameter], [IsAutoReset], [FormatCode], [DisplayName], [Description], [DataTypeName], [DeviceTypeId])
    Values
        ('syncInterval', 10, 1, 0,  N'^([2-9]|[1-9][0-9]{1,2}|1[0-3][0-9]{2}|14[0-3][0-9]|1440)$', N'Sync Interval', N'Check-in Interval', 'Unsigned Short', 1)
Go

-- Parameter Name: Reset Device, Device Type: JRT, Index: 11
If Not Exists(Select * From [dbo].[DeviceParameter] As [dp] Where [dp].[Name] = 'resetDevice' And [dp].[DeviceTypeId] = 1)
Insert InTo [dbo].[DeviceParameter]
        ([Name], [Index], [IsReturnParameter], [IsAutoReset], [FormatCode], [DisplayName], [Description], [DataTypeName], [DeviceTypeId])
    Values	        
        ('resetDevice', 11, 1, 1, N'^[0-1]$', N'Reset Device', N'Restore Factory Settings', 'Boolean', 1)
Go

-- Parameter Name: Alert Resend Interval, Device Type: JRT, Index: 12
If Not Exists(Select * From [dbo].[DeviceParameter] As [dp] Where [dp].[Name] = 'alertResendInterval' And [dp].[DeviceTypeId] = 1)
Insert InTo [dbo].[DeviceParameter]
        ([Name], [Index],[IsReturnParameter], [IsAutoReset], [FormatCode], [DisplayName], [Description], [DataTypeName], [DeviceTypeId])
    Values	        
        ('alertResendInterval', 12, 1, 0,  N'^([2-9]|[1-9][0-9]{1,2}|1[0-3][0-9]{2}|14[0-3][0-9]|1440)$', N'Alert Resend Interval', N'Alert Resend Interval', 'Unsigned Short', 1)
Go

-- Parameter Name: Reset Device, Device Type: eHRT, Index: 17
If Not Exists(Select * From [dbo].[DeviceParameter] As [dp] Where [dp].[Name] = 'resetDevice' And [dp].[DeviceTypeId] = 2)
Insert InTo [dbo].[DeviceParameter]
        ([Name], [Index],[IsReturnParameter], [IsAutoReset], [FormatCode], [DisplayName], [Description], [DataTypeName], [DeviceTypeId])
    Values	        
        ('resetDevice', 17, 1, 1, N'^[0-1]$', N'Reset Device', N'Restore Factory Settings', 'Boolean', 2)
Go

-- Parameter Name: Sync Interval, Device Type: eHRT, Index: 21
If Not Exists(Select * From [dbo].[DeviceParameter] As [dp] Where [dp].[Name] = 'syncInterval' And [dp].[DeviceTypeId] = 2)
Insert InTo [dbo].[DeviceParameter]
        ([Name], [Index],[IsReturnParameter], [IsAutoReset], [FormatCode], [DisplayName], [Description], [DataTypeName], [DeviceTypeId])
    Values
        ('syncInterval', 21, 1, 0,  N'^([2-9]|[1-9][0-9]{1,2}|1[0-3][0-9]{2}|14[0-3][0-9]|1440)$', N'Sync Interval', N'Check-in Interval', 'Unsigned Short', 2)
Go
-- Parameter Name: Delay Enabled, Device Type: eHRT, Index: 23
If Not Exists(Select * From [dbo].[DeviceParameter] As [dp] Where [dp].[Name] = 'useAlert' And [dp].[DeviceTypeId] = 2)
Insert InTo [dbo].[DeviceParameter]
        ([Name], [Index],[IsReturnParameter], [IsAutoReset], [FormatCode], [DisplayName], [Description], [DataTypeName], [DeviceTypeId])
    Values	        
        ('useAlert', 23, 1, 0, N'^[0-1]$', N'Delay Enabled', N'Delay enabled in raising alerts', 'Boolean', 2)
Go

-- Parameter Name: Delay Count, Device Type: eHRT, Index: 24
If Not Exists(Select * From [dbo].[DeviceParameter] As [dp] Where [dp].[Name] = 'alertVal' And [dp].[DeviceTypeId] = 2)
Insert InTo [dbo].[DeviceParameter]
        ([Name], [Index],[IsReturnParameter], [IsAutoReset], [FormatCode], [DisplayName], [Description], [DataTypeName], [DeviceTypeId])
    Values
        ('alertVal', 24, 1, 0, N'^(0|[1-9][0-9]{0,3}|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-5])$', N'Delay Count', N'Delay count for raising alert', 'Unsigned Short', 2)
Go

-- Parameter Name: Alert Resend Interval, Device Type: eHRT, Index: 25
If Not Exists(Select * From [dbo].[DeviceParameter] As [dp] Where [dp].[Name] = 'alertResendInterval' And [dp].[DeviceTypeId] = 2)
Insert InTo [dbo].[DeviceParameter]
        ([Name], [Index],[IsReturnParameter], [IsAutoReset], [FormatCode], [DisplayName], [Description], [DataTypeName], [DeviceTypeId])
    Values	        
        ('alertResendInterval', 25, 1, 0,  N'^([2-9]|[1-9][0-9]{1,2}|1[0-3][0-9]{2}|14[0-3][0-9]|1440)$', N'Alert Resend Interval', N'Alert Resend Interval', 'Unsigned Short', 2)
Go

-- Parameter Name: Sync Interval, Device Type: Soap, Index: 20
If Not Exists(Select * From [dbo].[DeviceParameter] As [dp] Where [dp].[Name] = 'syncInterval' And [dp].[DeviceTypeId] = 3)
Insert InTo [dbo].[DeviceParameter]
        ([Name], [Index],[IsReturnParameter], [IsAutoReset], [FormatCode], [DisplayName], [Description], [DataTypeName], [DeviceTypeId])
    Values
        ('syncInterval', 20, 1, 0,  N'^([2-9]|[1-9][0-9]{1,2}|1[0-3][0-9]{2}|14[0-3][0-9]|1440)$', N'Sync Interval', N'Check-in Interval', 'Unsigned Short', 3)
Go

-- Parameter Name: Reset Device, Device Type: eSoap, Index: 21
If Not Exists(Select * From [dbo].[DeviceParameter] As [dp] Where [dp].[Name] = 'resetDevice' And [dp].[DeviceTypeId] = 3)
Insert InTo [dbo].[DeviceParameter]
        ([Name], [Index],[IsReturnParameter], [IsAutoReset], [FormatCode], [DisplayName], [Description], [DataTypeName], [DeviceTypeId])
    Values	        
        ('resetDevice', 21, 1, 1, N'^[0-1]$', N'Reset Device', N'Restore Factory Settings', 'Boolean', 3)
Go

-- Parameter Name: Alert Resend Interval, Device Type: eSoap, Index: 22
If Not Exists(Select * From [dbo].[DeviceParameter] As [dp] Where [dp].[Name] = 'alertResendInterval' And [dp].[DeviceTypeId] = 3)
Insert InTo [dbo].[DeviceParameter]
        ([Name], [Index],[IsReturnParameter], [IsAutoReset], [FormatCode], [DisplayName], [Description], [DataTypeName], [DeviceTypeId])
    Values	        
        ('alertResendInterval', 22, 1, 0,  N'^([2-9]|[1-9][0-9]{1,2}|1[0-3][0-9]{2}|14[0-3][0-9]|1440)$', N'Alert Resend Interval', N'Alert Resend Interval', 'Unsigned Short', 3)
Go

-- Parameter Name: Sync Interval, Device Type: SRB, Index: 8
If Not Exists(Select * From [dbo].[DeviceParameter] As [dp] Where [dp].[Name] = 'syncInterval' And [dp].[DeviceTypeId] = 4)
Insert InTo [dbo].[DeviceParameter]
        ([Name], [Index],[IsReturnParameter], [IsAutoReset], [FormatCode], [DisplayName], [Description], [DataTypeName], [DeviceTypeId])
    Values
        ('syncInterval', 8, 1, 0,  N'^([2-9]|[1-9][0-9]{1,2}|1[0-3][0-9]{2}|14[0-3][0-9]|1440)$', N'Sync Interval', N'Check-in Interval', 'Unsigned Short', 4)
Go

-- Parameter Name: Reset Device, Device Type: SRB, Index: 9
If Not Exists(Select * From [dbo].[DeviceParameter] As [dp] Where [dp].[Name] = 'resetDevice' And [dp].[DeviceTypeId] = 4)
Insert InTo [dbo].[DeviceParameter]
        ([Name], [Index],[IsReturnParameter], [IsAutoReset], [FormatCode], [DisplayName], [Description], [DataTypeName], [DeviceTypeId])
    Values	        
        ('resetDevice', 9, 1, 1, N'^[0-1]$', N'Reset Device', N'Restore Factory Settings', 'Boolean', 4)
Go

-- Parameter Name: Alert Resend Interval, Device Type: SRB, Index: 10
If Not Exists(Select * From [dbo].[DeviceParameter] As [dp] Where [dp].[Name] = 'alertResendInterval' And [dp].[DeviceTypeId] = 4)
Insert InTo [dbo].[DeviceParameter]
        ([Name], [Index],[IsReturnParameter], [IsAutoReset], [FormatCode], [DisplayName], [Description], [DataTypeName], [DeviceTypeId])
    Values	        
        ('alertResendInterval', 10, 1, 0,  N'^([2-9]|[1-9][0-9]{1,2}|1[0-3][0-9]{2}|14[0-3][0-9]|1440)$', N'Alert Resend Interval', N'Alert Resend Interval', 'Unsigned Short', 4)
Go

-- --------------------------------------------------
-- End: Initial data load for DeviceParameter
-- --------------------------------------------------
Go

-- --------------------------------------------------
-- Begin: Initial data load for DeviceParameterValue
-- --------------------------------------------------

-- Device Type: JRT; Parameter Name: Sync Interval
If Not Exists(Select * From [dbo].[DeviceParameterValue] As [dpv] Where [dpv].[ParameterId] = 1)
Insert InTo [dbo].[DeviceParameterValue]
        ([Value], [ParameterId])
    Values	        
        ('480', 1)
Go

-- Device Type: JRT; Parameter Name: Reset Device
If Not Exists(Select * From [dbo].[DeviceParameterValue] As [dpv] Where [dpv].[ParameterId] = 2)
Insert InTo [dbo].[DeviceParameterValue]
        ([Value], [ParameterId])
    Values	        
        ('0', 2)
Go

-- Device Type: JRT; Parameter Name: Alert Resend Interval
If Not Exists(Select * From [dbo].[DeviceParameterValue] As [dpv] Where [dpv].[ParameterId] = 3)
Insert InTo [dbo].[DeviceParameterValue]
        ([Value], [ParameterId])
    Values	        
        ('480', 3)
Go

-- Device Type: eHRT; Parameter Name: Reset Device
If Not Exists(Select * From [dbo].[DeviceParameterValue] As [dpv] Where [dpv].[ParameterId] = 4)
Insert InTo [dbo].[DeviceParameterValue]
        ([Value], [ParameterId])
    Values	        
        ('0', 4)
Go
-- Device Type: eHRT; Parameter Name: Sync Interval
If Not Exists(Select * From [dbo].[DeviceParameterValue] As [dpv] Where [dpv].[ParameterId] = 5)
Insert InTo [dbo].[DeviceParameterValue]
        ([Value], [ParameterId])
    Values	        
        ('480', 5)
Go

-- Device Type: eHRT; Parameter Name: Delay Enabled
If Not Exists(Select * From [dbo].[DeviceParameterValue] As [dpv] Where [dpv].[ParameterId] = 6)
Insert InTo [dbo].[DeviceParameterValue]
        ([Value], [ParameterId])
    Values	        
        ('0', 6)
Go

-- Device Type: eHRT; Parameter Name: Delay Value
If Not Exists(Select * From [dbo].[DeviceParameterValue] As [dpv] Where [dpv].[ParameterId] = 7)
Insert InTo [dbo].[DeviceParameterValue]
        ([Value], [ParameterId])
    Values	        
        ('40', 7)
Go

-- Device Type: eHRT; Parameter Name: Alert Resend Interval
If Not Exists(Select * From [dbo].[DeviceParameterValue] As [dpv] Where [dpv].[ParameterId] = 8)
Insert InTo [dbo].[DeviceParameterValue]
        ([Value], [ParameterId])
    Values	        
        ('480', 8)
Go

-- Device Type: eSoap; Parameter Name: Sync Interval
If Not Exists(Select * From [dbo].[DeviceParameterValue] As [dpv] Where [dpv].[ParameterId] = 9)
Insert InTo [dbo].[DeviceParameterValue]
        ([Value], [ParameterId])
    Values	        
        ('480', 9)
Go

-- Device Type: eSoap; Parameter Name: Reset Device
If Not Exists(Select * From [dbo].[DeviceParameterValue] As [dpv] Where [dpv].[ParameterId] = 10)
Insert InTo [dbo].[DeviceParameterValue]
        ([Value], [ParameterId])
    Values	        
        ('0', 10)
Go

-- Device Type: eSoap; Parameter Name: Alert Resend Interval
If Not Exists(Select * From [dbo].[DeviceParameterValue] As [dpv] Where [dpv].[ParameterId] = 11)
Insert InTo [dbo].[DeviceParameterValue]
        ([Value], [ParameterId])
    Values	        
        ('480', 11)
Go

-- Device Type: SRB; Parameter Name: Sync Interval
If Not Exists(Select * From [dbo].[DeviceParameterValue] As [dpv] Where [dpv].[ParameterId] = 12)
Insert InTo [dbo].[DeviceParameterValue]
        ([Value], [ParameterId])
    Values	        
        ('480', 12)
Go

-- Device Type: SRB; Parameter Name: Reset Device
If Not Exists(Select * From [dbo].[DeviceParameterValue] As [dpv] Where [dpv].[ParameterId] = 13)
Insert InTo [dbo].[DeviceParameterValue]
        ([Value], [ParameterId])
    Values	        
        ('0', 13)
Go

-- Device Type: SRB; Parameter Name: Alert Resend Interval
If Not Exists(Select * From [dbo].[DeviceParameterValue] As [dpv] Where [dpv].[ParameterId] = 14)
Insert InTo [dbo].[DeviceParameterValue]
        ([Value], [ParameterId])
    Values	        
        ('480', 14)
Go
-- --------------------------------------------------
-- End: Initial data load for DeviceParameterValue
-- --------------------------------------------------