---INSERT SCRIPT FOR GATEWAYID PARAMETER

IF NOT EXISTS(Select 1 From DeviceParameter Where Name = 'GateWayId')
BEGIN
	INSERT INTO [dbo].[DeviceParameter]
           ([Name]
           ,[Index]
           ,[FormatCode]
           ,[IsReturnParameter]
           ,[IgnoreError]
           ,[IsAutoReset]
           ,[IsActive]
           ,[DisplayName]
           ,[Description]
           ,[DataTypeName]
           ,[FormatErrorMessage]
           ,[CreatedTime]
           ,[ModifiedTime]
           ,[DeviceTypeId]
           ,[CreatedById]
           ,[ModifiedById]
           ,[PropertyGroupId])
     VALUES
           ('GatewayId'
           ,1
           ,''
           ,0
           ,1
           ,0
           ,1
           ,'GatewayId'
           ,'The Gateway Identifier'
           ,'Hexadecimal'
           ,'18 digit hexadecimal value'
           ,GETDATE()
           ,NULL
           ,1
           ,NULL
           ,NULL
           ,1)
END
GO

---INSERT SCRIPT FOR DEFAULT LEVEL OVERRIDE

IF NOT EXISTS(Select 1 From DeviceParameterValue Where ParameterId=15 AND CustomerId IS NULL And DeviceID IS NULL)
BEGIN

INSERT INTO [dbo].[DeviceParameterValue]
           ([Value]
           ,[IsReset]
           ,[ResetTime]
           ,[CreatedTime]
           ,[ModifiedTime]
           ,[ParameterId]
           ,[CustomerId]
           ,[DeviceId]
           ,[CreatedById]
           ,[ModifiedById])
     VALUES
           ('1234567890abcdef01'
           ,0
           ,NULL
           ,GetDate()
           ,NULL
           ,15
           ,NULL
           ,NULL
           ,NULL
           ,NULL)
END
GO