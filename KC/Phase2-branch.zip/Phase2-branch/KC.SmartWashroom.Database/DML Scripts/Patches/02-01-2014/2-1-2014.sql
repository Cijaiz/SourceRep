IF (SELECT COUNT(*) FROM [dbo].Country Where NAME = 'United States Of America') = 1
BEGIN
UPDATE [dbo].[Country] SET Name='United States' where Name='United States Of America'
END