IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where  [AlertTypeId] =7) <> 0
BEGIN

DELETE [dbo].[DeviceAlertMapping]
WHERE  [AlertTypeId] =7

END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertName] Where [AlertName] = 'VeryLowSoapAlert') <> 0
BEGIN

DELETE [dbo].[DeviceAlertName] 
Where [AlertName] = 'VeryLowSoapAlert'

END

IF (SELECT COUNT(*) FROM [dbo].[SimulatorRaisedAlert] Where  [AlertTypeId] =7) <> 0
BEGIN

DELETE [dbo].[SimulatorRaisedAlert]
WHERE [AlertTypeId] =7

END

IF (SELECT COUNT(*) FROM [dbo].[AlertType] Where [Type] = 'S4') <> 0
BEGIN

DELETE [dbo].[AlertType]
WHERE [Type] = 'S4'

END