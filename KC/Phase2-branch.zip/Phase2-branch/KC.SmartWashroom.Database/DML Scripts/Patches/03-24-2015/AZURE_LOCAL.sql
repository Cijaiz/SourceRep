
--------------------------- Add building admin permissions to CRUD operations on User---------------------
IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =10 and RoleId = 3) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(10,3)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =11 and RoleId = 3) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(11,3)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =12 and RoleId = 3) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(12,3)
END

IF (SELECT COUNT(*) FROM [dbo].[RolePermission] Where [FeatureId] =13 and RoleId = 3) = 0
BEGIN
INSERT INTO [dbo].[RolePermission]
([FeatureId]
,[RoleId])
VALUES
(13,3)
END

------------------------------------------END---------------------------------------------------

--------------------------- Update portal admin user's customer id null---------------------

UPDATE DBO.[USER]
SET CUSTOMERID = NULL
WHERE ROLEID=1

---------------------------------------------END -------------------------------