IF (SELECT COUNT(*) FROM [dbo].Country Where NAME = 'India') = 0
BEGIN
INSERT INTO [dbo].[Country]
           ([Name])
     VALUES
           ('India')
END


PRINT '[AlertType]'
IF (SELECT COUNT(*) FROM [dbo].[AlertType] Where [Type] = 'J1') = 0
BEGIN
INSERT INTO [dbo].[AlertType]
           ([Type])
     VALUES
           ('J1')
END
IF (SELECT COUNT(*) FROM [dbo].[AlertType] Where [Type] = 'J2') = 0
BEGIN
INSERT INTO [dbo].[AlertType]
           ([Type])
     VALUES
           ('J2')
END
IF (SELECT COUNT(*) FROM [dbo].[AlertType] Where [Type] = 'J3') = 0
BEGIN
INSERT INTO [dbo].[AlertType]
           ([Type])
     VALUES
           ('J3')
END
IF (SELECT COUNT(*) FROM [dbo].[AlertType] Where [Type] = 'S1') = 0
BEGIN
INSERT INTO [dbo].[AlertType]
           ([Type])
     VALUES
           ('S1')
END
IF (SELECT COUNT(*) FROM [dbo].[AlertType] Where [Type] = 'S2') = 0
BEGIN
INSERT INTO [dbo].[AlertType]
           ([Type])
     VALUES
           ('S2')
END
IF (SELECT COUNT(*) FROM [dbo].[AlertType] Where [Type] = 'S3') = 0
BEGIN
INSERT INTO [dbo].[AlertType]
           ([Type])
     VALUES
           ('S3')
END
IF (SELECT COUNT(*) FROM [dbo].[AlertType] Where [Type] = 'S4') = 0
BEGIN
INSERT INTO [dbo].[AlertType]
           ([Type])
     VALUES
           ('S4')
END
IF (SELECT COUNT(*) FROM [dbo].[AlertType] Where [Type] = 'H1') = 0
BEGIN
INSERT INTO [dbo].[AlertType]
           ([Type])
     VALUES
           ('H1')
END
IF (SELECT COUNT(*) FROM [dbo].[AlertType] Where [Type] = 'H2') = 0
BEGIN
INSERT INTO [dbo].[AlertType]
           ([Type])
     VALUES
           ('H2')
END
IF (SELECT COUNT(*) FROM [dbo].[AlertType] Where [Type] = 'H3') = 0
BEGIN
INSERT INTO [dbo].[AlertType]
           ([Type])
     VALUES
           ('H3')
END
IF (SELECT COUNT(*) FROM [dbo].[AlertType] Where [Type] = 'H4') = 0
BEGIN
INSERT INTO [dbo].[AlertType]
           ([Type])
     VALUES
           ('H4')
END
IF (SELECT COUNT(*) FROM [dbo].[AlertType] Where [Type] = 'H5') = 0
BEGIN
INSERT INTO [dbo].[AlertType]
           ([Type])
     VALUES
           ('H5')
END




IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertName] Where [AlertName] = 'LowBatteryAlert') = 0
BEGIN
INSERT INTO [dbo].[DeviceAlertName]
           ([AlertName])
     VALUES
           ('LowBatteryAlert')
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertName] Where [AlertName] = 'PaperTransferAlert') = 0
BEGIN
INSERT INTO [dbo].[DeviceAlertName]
           ([AlertName])
     VALUES
           ('PaperTransferAlert')
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertName] Where [AlertName] = 'LowPaperAlert') = 0
BEGIN
INSERT INTO [dbo].[DeviceAlertName]
           ([AlertName])
     VALUES
           ('LowPaperAlert')
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertName] Where [AlertName] = 'LowSoapAlert') = 0
BEGIN
INSERT INTO [dbo].[DeviceAlertName]
           ([AlertName])
     VALUES
           ('LowSoapAlert')
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertName] Where [AlertName] = 'MotorOvercurrentAlert') = 0
BEGIN
INSERT INTO [dbo].[DeviceAlertName]
           ([AlertName])
     VALUES
           ('MotorOvercurrentAlert')
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertName] Where [AlertName] = 'VeryLowSoapAlert') = 0
BEGIN
INSERT INTO [dbo].[DeviceAlertName]
           ([AlertName])
     VALUES
           ('VeryLowSoapAlert')
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertName] Where [AlertName] = 'PaperJamAlert') = 0
BEGIN
INSERT INTO [dbo].[DeviceAlertName]
           ([AlertName])
     VALUES
           ('PaperJamAlert')
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertName] Where [AlertName] = 'TrashFullAlert') = 0
BEGIN
INSERT INTO [dbo].[DeviceAlertName]
           ([AlertName])
     VALUES
           ('TrashFullAlert')
END

PRINT '[DeviceType]'
IF (SELECT COUNT(*) FROM [dbo].[DeviceType] Where [Name]='JRT' ) = 0
BEGIN
INSERT INTO [dbo].[DeviceType]
           ([Name])
     VALUES
           ('JRT')
END
IF (SELECT COUNT(*) FROM [dbo].[DeviceType] Where [Name]='eHRT' ) = 0
BEGIN
INSERT INTO [dbo].[DeviceType]
           ([Name])
     VALUES
           ('eHRT')
END
IF (SELECT COUNT(*) FROM [dbo].[DeviceType] Where [Name]='eSOAP' ) = 0
BEGIN
INSERT INTO [dbo].[DeviceType]
           ([Name])
     VALUES
           ('eSoap')

END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 1 AND [AlertTypeId] =1 ) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
			DeviceTypeId,
			AlertTypeId,
			AlertNameId)
     VALUES
           (
		   1
           ,1
           ,1
           )
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 1 AND [AlertTypeId] =2 ) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
			DeviceTypeId,
			AlertTypeId,
			AlertNameId)
     VALUES
           (
		   1
           ,2
           ,2
           )
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 1 AND [AlertTypeId] =3 ) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
			DeviceTypeId,
			AlertTypeId,
			AlertNameId)
     VALUES
           (
		   1
           ,3
           ,3
           )
END


IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 2 AND [AlertTypeId] =8 ) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
			DeviceTypeId,
			AlertTypeId,
			AlertNameId)
     VALUES
           (
		   2
           ,8
           ,2
           )
END


IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 2 AND [AlertTypeId] =9 ) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
			DeviceTypeId,
			AlertTypeId,
			AlertNameId)
     VALUES
           (
		   2
           ,9
           ,1
           )
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 2 AND [AlertTypeId] =10 ) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
			DeviceTypeId,
			AlertTypeId,
			AlertNameId)
     VALUES
           (
		   2
           ,10
           ,7
           )
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 2 AND [AlertTypeId] =11) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
			DeviceTypeId,
			AlertTypeId,
			AlertNameId)
     VALUES
           (
		   2
           ,11
           ,3
           )
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 2 AND [AlertTypeId] =12) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
			DeviceTypeId,
			AlertTypeId,
			AlertNameId)
     VALUES
           (
		   2
           ,12
           ,8
           )
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 3 AND [AlertTypeId] =4) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
			DeviceTypeId,
			AlertTypeId,
			AlertNameId)
     VALUES
           (
		   3
           ,4
           ,4
           )
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 3 AND [AlertTypeId] =5) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
			DeviceTypeId,
			AlertTypeId,
			AlertNameId)
     VALUES
           (
		   3
           ,5
           ,1
           )
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 3 AND [AlertTypeId] =6) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
			DeviceTypeId,
			AlertTypeId,
			AlertNameId)
     VALUES
           (
		   3
           ,6
           ,5
           )
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 3 AND [AlertTypeId] =7) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
			DeviceTypeId,
			AlertTypeId,
			AlertNameId)
     VALUES
           (
		   3
           ,7
           ,6
           )
END



IF (SELECT COUNT(*) FROM [dbo].[Role] Where [RoleLevel] = 1) = 0
BEGIN
INSERT INTO [dbo].[Role]
           (
			Name,
			RoleLevel
		   )
     VALUES
           ('Portal Admin',
		     1
			 )
END

IF (SELECT COUNT(*) FROM [dbo].[Role] Where [RoleLevel] = 10) = 0
BEGIN
INSERT INTO [dbo].[Role]
           (
			Name,
			RoleLevel
		   )
     VALUES
           ('Property Admin',
		     10
			 )
END

IF (SELECT COUNT(*) FROM [dbo].[Role] Where [RoleLevel] = 20) = 0
BEGIN
INSERT INTO [dbo].[Role]
           (
			Name,
			RoleLevel
		   )
     VALUES
           ('Building Admin',
		     20
			 )

	END		 

IF (SELECT COUNT(*) FROM [dbo].[User] Where [LastName] = 'Admin' AND [FirstName]='Super' AND [RoleId] =1 ) = 0
BEGIN		   
INSERT INTO [dbo].[User]
           ([FirstName]
           ,[LastName]
           ,[Email]
           ,[MobileNo]
           ,[IsEmailAlert]
           ,[IsMobileAlert]
           ,[CustomerId]
           ,[RoleId]
           ,[IsDelete]
           ,[CreatedBy]
           ,[CreatedOn]
           ,[LastUpdatedBy]
           ,[LastUpdatedOn]
		   ,[PasswordSalt]
		   ,[Password])
     VALUES
           ('Super'
           ,'Admin'
           ,'admin@kcc.com'
           ,NULL
           ,1
           ,1
           ,NULL
           ,1
           ,0
           ,NULL
           ,GETDATE()
           ,NULL
           ,NULL
		   ,'CgSE5Nx7Y6v80q2RkvdaiA=='
		   ,'JanwxB33tDOZ4tJHeHkmXg43WLI=')

END

IF (SELECT COUNT(*) FROM Product WHERE Type='eSOAP') = 0
BEGIN
INSERT INTO [dbo].[Product]
           ([Type])
     VALUES
           ('eSOAP')
END
IF (SELECT COUNT(*) FROM Product WHERE Type='JRT') = 0
BEGIN
INSERT INTO [dbo].[Product]
           ([Type])
     VALUES
           ('JRT')
END
IF (SELECT COUNT(*) FROM Product WHERE Type='eHRT') = 0
BEGIN
INSERT INTO [dbo].[Product]
           ([Type])
     VALUES
           ('eHRT')
END
IF (SELECT COUNT(*) FROM [ProductRefillDetail] WHERE [ProductId]=1 AND [Size]='S') = 0
BEGIN

INSERT INTO [dbo].[ProductRefillDetail]
           ([ProductId]
           ,[Size]
           ,[RefillValue])
     VALUES
           (1
           ,'S'
           ,'500')
END
IF (SELECT COUNT(*) FROM [ProductRefillDetail] WHERE [ProductId]=1 AND [Size]='M') = 0
BEGIN

INSERT INTO [dbo].[ProductRefillDetail]
           ([ProductId]
           ,[Size]
           ,[RefillValue])
     VALUES
           (1
           ,'M'
           ,'750')
END
IF (SELECT COUNT(*) FROM [ProductRefillDetail] WHERE [ProductId]=1 AND [Size]='L') = 0
BEGIN


INSERT INTO [dbo].[ProductRefillDetail]
           ([ProductId]
           ,[Size]
           ,[RefillValue])
     VALUES
           (1
           ,'L'
           ,'1000')
END
IF (SELECT COUNT(*) FROM [ProductRefillDetail] WHERE [ProductId]=2 AND [Size]='S') = 0
BEGIN


INSERT INTO [dbo].[ProductRefillDetail]
           ([ProductId]
           ,[Size]
           ,[RefillValue])
     VALUES
           (2
           ,'S'
           ,'500')
END
IF (SELECT COUNT(*) FROM [ProductRefillDetail] WHERE [ProductId]=2 AND [Size]='M') = 0
BEGIN

INSERT INTO [dbo].[ProductRefillDetail]
           ([ProductId]
           ,[Size]
           ,[RefillValue])
     VALUES
           (2
           ,'M'
           ,'750')
END
IF (SELECT COUNT(*) FROM [ProductRefillDetail] WHERE [ProductId]=2 AND [Size]='L') = 0
BEGIN

INSERT INTO [dbo].[ProductRefillDetail]
           ([ProductId]
           ,[Size]
           ,[RefillValue])
     VALUES
           (2
           ,'L'
           ,'1000')
END
IF (SELECT COUNT(*) FROM [ProductRefillDetail] WHERE [ProductId]=3 AND [Size]='S') = 0
BEGIN

INSERT INTO [dbo].[ProductRefillDetail]
           ([ProductId]
           ,[Size]
           ,[RefillValue])
     VALUES
           (3
           ,'S'
           ,'500')
END
IF (SELECT COUNT(*) FROM [ProductRefillDetail] WHERE [ProductId]=3 AND [Size]='M') = 0
BEGIN

INSERT INTO [dbo].[ProductRefillDetail]
           ([ProductId]
           ,[Size]
           ,[RefillValue])
     VALUES
           (3
           ,'M'
           ,'750')
END
IF (SELECT COUNT(*) FROM [ProductRefillDetail] WHERE [ProductId]=3 AND [Size]='L') = 0
BEGIN
INSERT INTO [dbo].[ProductRefillDetail]
           ([ProductId]
           ,[Size]
           ,[RefillValue])
     VALUES
           (3
           ,'L'
           ,'1000')
END


IF (SELECT COUNT(*) FROM [dbo].[Gender] Where [Name]='Men' ) = 0
BEGIN
INSERT INTO [dbo].[Gender]
           ([Name])
     VALUES
           ('Men')
END
IF (SELECT COUNT(*) FROM [dbo].[Gender] Where [Name]='Women' ) = 0
BEGIN
INSERT INTO [dbo].[Gender]
           ([Name])
     VALUES
           ('Women')

END
IF (SELECT COUNT(*) FROM [dbo].[Gender] Where [Name]='Unisex' ) = 0
BEGIN
INSERT INTO [dbo].[Gender]
           ([Name])
     VALUES
           ('Unisex')

END
IF (SELECT COUNT(*) FROM [dbo].[Gender] Where [Name]='Family' ) = 0
BEGIN
INSERT INTO [dbo].[Gender]
           ([Name])
     VALUES
           ('Family')

END


PRINT '[Wing]'
IF (SELECT COUNT(*) FROM [dbo].[Wing] Where [Name]='Wing A' ) = 0
BEGIN
INSERT INTO [dbo].[Wing]
           ([Name])
     VALUES
           ('Wing A')
END
IF (SELECT COUNT(*) FROM [dbo].[Wing] Where [Name]='Wing B' ) = 0
BEGIN
INSERT INTO [dbo].[Wing]
           ([Name])
     VALUES
           ('Wing B')
END