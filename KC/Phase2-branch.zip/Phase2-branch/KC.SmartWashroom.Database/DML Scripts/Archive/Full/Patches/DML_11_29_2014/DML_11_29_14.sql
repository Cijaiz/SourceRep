
IF (SELECT COUNT(*) FROM [dbo].[Role] Where [RoleLevel] = 1) = 0
BEGIN
INSERT INTO [dbo].[Role]
           (
			Name,
			RoleLevel
		   )
     VALUES
           ('Portal Admin',
		     1
			 )
END

IF (SELECT COUNT(*) FROM [dbo].[Role] Where [RoleLevel] = 10) = 0
BEGIN
INSERT INTO [dbo].[Role]
           (
			Name,
			RoleLevel
		   )
     VALUES
           ('Property Admin',
		     10
			 )
END

IF (SELECT COUNT(*) FROM [dbo].[Role] Where [RoleLevel] = 20) = 0
BEGIN
INSERT INTO [dbo].[Role]
           (
			Name,
			RoleLevel
		   )
     VALUES
           ('Building Admin',
		     20
			 )
END
