
IF (SELECT COUNT(*) FROM Product WHERE Type='eSOAP') = 0
BEGIN
INSERT INTO [dbo].[Product]
           ([Type])
     VALUES
           ('eSOAP')
END
IF (SELECT COUNT(*) FROM Product WHERE Type='JRT') = 0
BEGIN
INSERT INTO [dbo].[Product]
           ([Type])
     VALUES
           ('JRT')
END
IF (SELECT COUNT(*) FROM Product WHERE Type='eHRT') = 0
BEGIN
INSERT INTO [dbo].[Product]
           ([Type])
     VALUES
           ('eHRT')
END
IF (SELECT COUNT(*) FROM [ProductRefillDetail] WHERE [ProductId]=1 AND [Size]='S') = 0
BEGIN

INSERT INTO [dbo].[ProductRefillDetail]
           ([ProductId]
           ,[Size]
           ,[RefillValue])
     VALUES
           (1
           ,'S'
           ,'500')
END
IF (SELECT COUNT(*) FROM [ProductRefillDetail] WHERE [ProductId]=1 AND [Size]='M') = 0
BEGIN

INSERT INTO [dbo].[ProductRefillDetail]
           ([ProductId]
           ,[Size]
           ,[RefillValue])
     VALUES
           (1
           ,'M'
           ,'750')
END
IF (SELECT COUNT(*) FROM [ProductRefillDetail] WHERE [ProductId]=1 AND [Size]='L') = 0
BEGIN


INSERT INTO [dbo].[ProductRefillDetail]
           ([ProductId]
           ,[Size]
           ,[RefillValue])
     VALUES
           (1
           ,'L'
           ,'1000')
END
IF (SELECT COUNT(*) FROM [ProductRefillDetail] WHERE [ProductId]=2 AND [Size]='S') = 0
BEGIN


INSERT INTO [dbo].[ProductRefillDetail]
           ([ProductId]
           ,[Size]
           ,[RefillValue])
     VALUES
           (2
           ,'S'
           ,'500')
END
IF (SELECT COUNT(*) FROM [ProductRefillDetail] WHERE [ProductId]=2 AND [Size]='M') = 0
BEGIN

INSERT INTO [dbo].[ProductRefillDetail]
           ([ProductId]
           ,[Size]
           ,[RefillValue])
     VALUES
           (2
           ,'M'
           ,'750')
END
IF (SELECT COUNT(*) FROM [ProductRefillDetail] WHERE [ProductId]=2 AND [Size]='L') = 0
BEGIN

INSERT INTO [dbo].[ProductRefillDetail]
           ([ProductId]
           ,[Size]
           ,[RefillValue])
     VALUES
           (2
           ,'L'
           ,'1000')
END
IF (SELECT COUNT(*) FROM [ProductRefillDetail] WHERE [ProductId]=3 AND [Size]='S') = 0
BEGIN

INSERT INTO [dbo].[ProductRefillDetail]
           ([ProductId]
           ,[Size]
           ,[RefillValue])
     VALUES
           (3
           ,'S'
           ,'500')
END
IF (SELECT COUNT(*) FROM [ProductRefillDetail] WHERE [ProductId]=3 AND [Size]='M') = 0
BEGIN

INSERT INTO [dbo].[ProductRefillDetail]
           ([ProductId]
           ,[Size]
           ,[RefillValue])
     VALUES
           (3
           ,'M'
           ,'750')
END
IF (SELECT COUNT(*) FROM [ProductRefillDetail] WHERE [ProductId]=3 AND [Size]='L') = 0
BEGIN


INSERT INTO [dbo].[ProductRefillDetail]
           ([ProductId]
           ,[Size]
           ,[RefillValue])
     VALUES
           (3
           ,'L'
           ,'1000')
END