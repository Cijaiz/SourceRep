

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertName] Where [AlertName] = 'LowBatteryAlert') = 0
BEGIN
INSERT INTO [dbo].[DeviceAlertName]
           ([AlertName])
     VALUES
           ('LowBatteryAlert')
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertName] Where [AlertName] = 'PaperTransferAlert') = 0
BEGIN
INSERT INTO [dbo].[DeviceAlertName]
           ([AlertName])
     VALUES
           ('PaperTransferAlert')
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertName] Where [AlertName] = 'LowPaperAlert') = 0
BEGIN
INSERT INTO [dbo].[DeviceAlertName]
           ([AlertName])
     VALUES
           ('LowPaperAlert')
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertName] Where [AlertName] = 'LowSoapAlert') = 0
BEGIN
INSERT INTO [dbo].[DeviceAlertName]
           ([AlertName])
     VALUES
           ('LowSoapAlert')
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertName] Where [AlertName] = 'MotorOvercurrentAlert') = 0
BEGIN
INSERT INTO [dbo].[DeviceAlertName]
           ([AlertName])
     VALUES
           ('MotorOvercurrentAlert')
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertName] Where [AlertName] = 'VeryLowSoapAlert') = 0
BEGIN
INSERT INTO [dbo].[DeviceAlertName]
           ([AlertName])
     VALUES
           ('VeryLowSoapAlert')
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertName] Where [AlertName] = 'PaperJamAlert') = 0
BEGIN
INSERT INTO [dbo].[DeviceAlertName]
           ([AlertName])
     VALUES
           ('PaperJamAlert')
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertName] Where [AlertName] = 'TrashFullAlert') = 0
BEGIN
INSERT INTO [dbo].[DeviceAlertName]
           ([AlertName])
     VALUES
           ('TrashFullAlert')
END


IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 1 AND [AlertTypeId] =1 ) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
			DeviceTypeId,
			AlertTypeId,
			AlertNameId)
     VALUES
           (
		   1
           ,1
           ,1
           )
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 1 AND [AlertTypeId] =2 ) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
			DeviceTypeId,
			AlertTypeId,
			AlertNameId)
     VALUES
           (
		   1
           ,2
           ,2
           )
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 1 AND [AlertTypeId] =3 ) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
			DeviceTypeId,
			AlertTypeId,
			AlertNameId)
     VALUES
           (
		   1
           ,3
           ,3
           )
END


IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 2 AND [AlertTypeId] =8 ) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
			DeviceTypeId,
			AlertTypeId,
			AlertNameId)
     VALUES
           (
		   2
           ,8
           ,2
           )
END


IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 2 AND [AlertTypeId] =9 ) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
			DeviceTypeId,
			AlertTypeId,
			AlertNameId)
     VALUES
           (
		   2
           ,9
           ,1
           )
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 2 AND [AlertTypeId] =10 ) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
			DeviceTypeId,
			AlertTypeId,
			AlertNameId)
     VALUES
           (
		   2
           ,10
           ,7
           )
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 2 AND [AlertTypeId] =11) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
			DeviceTypeId,
			AlertTypeId,
			AlertNameId)
     VALUES
           (
		   2
           ,11
           ,3
           )
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 2 AND [AlertTypeId] =12) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
			DeviceTypeId,
			AlertTypeId,
			AlertNameId)
     VALUES
           (
		   2
           ,12
           ,8
           )
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 3 AND [AlertTypeId] =4) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
			DeviceTypeId,
			AlertTypeId,
			AlertNameId)
     VALUES
           (
		   3
           ,4
           ,4
           )
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 3 AND [AlertTypeId] =5) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
			DeviceTypeId,
			AlertTypeId,
			AlertNameId)
     VALUES
           (
		   3
           ,5
           ,1
           )
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 3 AND [AlertTypeId] =6) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
			DeviceTypeId,
			AlertTypeId,
			AlertNameId)
     VALUES
           (
		   3
           ,6
           ,5
           )
END

IF (SELECT COUNT(*) FROM [dbo].[DeviceAlertMapping] Where [DeviceTypeId] = 3 AND [AlertTypeId] =7) = 0
BEGIN	
INSERT INTO [dbo].[DeviceAlertMapping]
           (
			DeviceTypeId,
			AlertTypeId,
			AlertNameId)
     VALUES
           (
		   3
           ,7
           ,6
           )
END



