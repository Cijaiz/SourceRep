﻿using KC.SmartWashroom.BusinessEntities.BusinessHubEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using KC.SmartWashroom.Core.Localization;

namespace KC.SmartWashroom.BusinessEntities
{
    public class Building
    {
        public Int32 ID { get; set; }
        public Int32 PropertyId { get; set; }
        [RequiredLocalizable("Building_Name_Required")]
        [StringLengthLocalized(100, "Name_Length")]
        public string Name { get; set; }
        public bool IsActive { get; set; }
        public int CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
        public Nullable<int> LastUpdatedBy { get; set; }
        public Nullable<System.DateTime> LastUpdatedOn { get; set; }
        public List<FloorSet> floorSets { get; set; }
        public List<Floor> floors { get; set; }

        public int CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string PropertyName { get; set; }
        public Names CrumbName { get; set; }
        public int TotalALertCount { get; set; }
        public string ImageUrl { get; set; }
    }
}
