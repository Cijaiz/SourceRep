﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities
{
    public class DeviceTrafficTrace
    {
        public string PartitionKey { get; set; }
        public string DeviceId { get; set; }
        public DateTime InTime { get; set; }
        public DateTime OutTime { get; set; }
        public string Section { get; set; }

        public TimeSpan Duration { get; set; }
    }
}
