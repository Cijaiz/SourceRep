﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities
{
    public class DeviceParameterValueEntity
    {
        public Nullable<int> DeviceParameterValueId { get; set; }
        public string Value { get; set; }
        public Nullable<bool> IsReset { get; set; }

        public Nullable<DateTime> ResetTime { get; set; }
        public Nullable<DateTime> CreatedTime { get; set; }
        public Nullable<DateTime> ModifiedTime { get; set; }

        public Nullable<int> ParameterId { get; set; }
        public Nullable<int> CustomerId { get; set; }
        public string DeviceId { get; set; }

        public Nullable<int> CreatedById { get; set; }
        public Nullable<int> ModifiedById { get; set; }

        public string OldValue { get; set; }
        public string DeviceName { get; set; }
    }
}
