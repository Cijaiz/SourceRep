﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities
{
    public class eSoapParameters
    {
        public decimal SoftwareVersion { get; set; }
        public char Shot { get; set; }
        public char Range { get; set; }

        public char RefillSize { get; set; }
        public int CleanModeSinceBatteryChange { get; set; }
        public int TotalDispenseSinceConstruction { get; set; }

        public int DispenseDuringLastBattery { get; set; }
        public int DispenseSinceLastBatteryChange { get; set; }
        public int NumberOfBatteryChanges { get; set; }

        public decimal VoltageAtLastBatteryChange { get; set; }
        public decimal CurrentBatteryVoltage { get; set; }
        public bool LowSoapAlert { get; set; }

        public bool LowBatteryAlert { get; set; }
        public bool MotorOverCurrentAlert { get; set; }
        public int TotalRefillsSinceConstruction { get; set; }

        public int RefillsduringLastBattery { get; set; }
        public int RefillsSinceBatteryChange { get; set; }
        public int NoOfDispensesSinceLastRefill { get; set; }

        public int UpdateInterval { get; set; }
        public bool Reset { get; set; }

        public int RefilledBatteryBeforeThreshold { get; set; }
        public int RefilledSoapBeforeThreshold { get; set; }

       
    }
}
