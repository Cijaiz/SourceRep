﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities
{
    public class ReportFilterEntity
    {
        public int UserId { get; set; }
        public string CustomerId { get; set; }
        public string PropertyId { get; set; }
        public string BuildingId { get; set; }
        public string FloorId { get; set; }
        public string RoomId { get; set; }
        public Nullable<DateTime> StartDate { get; set; }
        public Nullable<DateTime> EndDate { get; set; }
        public string Month { get; set; }
        public int Year { get; set; }
        public string PeriodId { get; set; }
        public string ChartType { get; set; }
    }
}
