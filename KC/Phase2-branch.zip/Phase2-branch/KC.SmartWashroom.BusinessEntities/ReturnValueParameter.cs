﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KC.SmartWashroom.BusinessEntities
{
    public class ReturnValueParameter
    {
        public ReturnValueParameter()
        {
            this.Parameter = new DeviceParameterEntity();
            this.ParameterValue = new DeviceParameterValueEntity();
        }

        public DeviceParameterEntity Parameter { get; set; }
        public DeviceParameterValueEntity ParameterValue { get; set; }
    }
}
