﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities
{
    public class DeviceParameterEntity
    {
        public int DeviceParameterId { get; set; }
        public string Name { get; set; }
        public int? Index { get; set; }

        public string FormatCode { get; set; }
        public bool IsReturnParameter { get; set; }
        public bool IgnoreError { get; set; }

        public bool? IsAutoReset { get; set; }
        public bool? IsActive { get; set; }
        public string DisplayName { get; set; }

        public string Description { get; set; }
        public string DataTypeName { get; set; }
        public string FormatErrorMessage { get; set; }

        public DateTime? CreatedTime { get; set; }
        public DateTime? ModifiedTime { get; set; }
        public byte DeviceTypeId { get; set; }

        public int? CreatedById { get; set; }
        public int? ModifiedById { get; set; }
        public int? PropertyGroupId { get; set; }
    }
}
