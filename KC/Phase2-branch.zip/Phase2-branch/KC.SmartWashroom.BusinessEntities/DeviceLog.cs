﻿using Microsoft.WindowsAzure.Storage.Table;
using System;

namespace KC.SmartWashroom.BusinessEntities
{
    public class DeviceLog
    {
        public string DeviceId { get; set; }
        public int DeviceType { get; set; }
        public DateTime Timestamp { get; set; }
        public string DeviceParameter { get; set; }
        public string GatewayId { get; set; }
        public string GatewayFirmwareVersion { get; set; }
        public dynamic Parameter { get; set; }
        public int WashroomId { get; set; }
        public int FloorLevel { get; set; }
        public int FloorId { get; set; }
        public int BuildingId { get; set; }
        public int PropertyId { get; set; }
        public int CustomerId { get; set; }
    }
}
