﻿using KC.SmartWashroom.BusinessEntities.BusinessHubEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities
{
    public class ActivityResult
    {
        public List<DeviceAlertsResolutionDetail> Activities { get; set; }
        public int TotalResolvedAlertsCount { get; set; }
        public int TotalAlertsCount { get; set; }
        public int AverageResponseTime  { get; set; }
        public string NextRowKey { get; set; }
        public string NextPartitionKey { get; set; }
        public int TrafficUsage { get; set; }

    }
}
