﻿
namespace KC.SmartWashroom.BusinessEntities
{
    public class Wing
    {
        public byte ID { get; set; }
        public string Name { get; set; }
    }
}
