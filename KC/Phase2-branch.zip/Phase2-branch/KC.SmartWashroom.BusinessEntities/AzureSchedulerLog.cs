﻿
namespace KC.SmartWashroom.BusinessEntities
{
    public class AzureSchedulerLog
    {
        public int Id { get; set; }

        public string JobId { get; set; }

        public int CustomerId { get; set; }

        public int PropertyId { get; set; }

        public bool IsActive { get; set; }
    }
}
