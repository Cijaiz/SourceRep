﻿using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities
{

    public class ReturnParameterResponse
    {
        public ReturnParameterResponse()
        {
            this.deviceTypes = new DeviceTypes();
            this.returnValueParameters = new List<ReturnValueParameter>();
        }

        public DeviceTypes deviceTypes { get; set; }
        public List<BusinessEntities.ReturnValueParameter> returnValueParameters { get; set; }

        public string LocationTimeZone { get; set; }
    }
}
