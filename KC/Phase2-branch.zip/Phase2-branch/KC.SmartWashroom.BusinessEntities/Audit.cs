﻿
namespace KC.SmartWashroom.BusinessEntities
{
    public class Audit
    {
        public KC.SmartWashroom.Core.Enumerations.Enums.AuditActivity AuditActivityType { get; set; }
        public string PerformedBy { get; set; }
        public string AuditInfo { get; set; }
    }
}
