﻿using KC.SmartWashroom.BusinessEntities.BusinessHubEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities.DashboardApiEntities
{
    public class BuildingEntity
    {
        public List<Building> buildings { get; set; }
        public string ImageUrl { get; set; }
        public Building building { get; set; }
        public string PropertyName { get; set; }

        public string CustomerName { get; set; }
    }
}
