﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities.DashboardApiEntities
{
    public class PropertyAlert
    {
        public int ID { get; set; }
        public string PropertyName { get; set; }
        public string ImageUrl { get; set; }
        public int AlertCount { get; set; }
    }
}
