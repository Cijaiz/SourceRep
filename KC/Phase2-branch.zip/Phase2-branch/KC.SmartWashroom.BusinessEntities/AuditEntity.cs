﻿using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities
{
    public class AuditEntity : TableEntity
    {
        public AuditEntity() : base() { }
        public AuditEntity(string partitionKey, string rowKey) : base(partitionKey, rowKey) { }

        public string PerformedBy { get; set; }
        public string AuditInfo { get; set; }
        public string CreatedOn { get; set; }
    }
}
