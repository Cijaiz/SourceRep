﻿using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using System;
using System.Collections.Generic;

namespace KC.SmartWashroom.BusinessEntities
{
    public class Washroom
    {
        public Int32 ID { get; set; }
        public Int32 FloorId { get; set; }

        public byte GenderId { get; set; }
        public byte WingId { get; set; }

        public string Gender { get; set; }
        public string Wing { get; set; }

        public string Name { get; set; }
        public string KCIdentifier { get; set; }
        public string FloorLevel { get; set; }

        public bool IsActive { get; set; }
        public List<Device> Devices { get; set; }

        public int CreatedBy { get; set; }
        public Nullable<int> LastUpdatedBy { get; set; }

        public System.DateTime CreatedOn { get; set; }
        public Nullable<System.DateTime> LastUpdatedOn { get; set; }
    }
}
