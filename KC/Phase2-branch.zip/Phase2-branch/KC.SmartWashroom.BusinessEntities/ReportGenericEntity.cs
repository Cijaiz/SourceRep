﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities
{
    public class ReportGenericEntity
    {
        // Fields
        private Dictionary<string, object> properties;

        // Methods
        public ReportGenericEntity()
        {
            this.properties = new Dictionary<string, object>();
        }

        public override string ToString()
        {
            StringBuilder builder = new StringBuilder();
            int num = 0;
            if (this.properties != null)
            {
                foreach (KeyValuePair<string, object> pair in this.properties)
                {
                    string str;
                    if (num > 0)
                    {
                        builder.Append("|");
                    }
                    if (pair.Value == null)
                    {
                        str = string.Empty;
                    }
                    else
                    {
                        str = pair.Value.ToString();
                    }
                    builder.Append(pair.Key + "=" + str);
                    num++;
                }
            }
            return builder.ToString();
        }

        // Properties
        public object this[string key]
        {
            get
            {
                try
                {
                    return this.properties[key];
                }
                catch
                {
                    return null;
                }
            }
            set
            {
                this.properties[key] = value;
            }
        }

        public Dictionary<string, object> Properties
        {
            get
            {
                return this.properties;
            }
            set
            {
                this.properties = value;
            }
        }

    }

}
