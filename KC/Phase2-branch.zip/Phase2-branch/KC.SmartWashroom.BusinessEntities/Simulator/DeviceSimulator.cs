﻿using KC.SmartWashroom.BusinessEntities.Simulator;
using System;
using System.Collections.Generic;

namespace KC.SmartWashroom.BusinessEntities
{
    public class DeviceSimulator
    {
        public string DeviceID { get; set; }
        public string Type { get; set; }
        public string DeviceParameter { get; set; }

        public bool IsNewDevice { get; set; }
        public DateTime Timestamp { get; set; }
        public List<AlertSimulator> Alerts { get; set; }

        public DeviceSimulator()
        {
            Alerts = new List<AlertSimulator>();
        }        
    }
}
