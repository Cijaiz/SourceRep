﻿
namespace KC.SmartWashroom.BusinessEntities.Simulator
{
    public class AlertSimulator
    {
        public bool IsAlertRequired { get; set; }
        public bool IsAlertFixed { get; set; }

        public string AlertCode { get; set; }
        public string AlertParameter { get; set; }
    }
}
