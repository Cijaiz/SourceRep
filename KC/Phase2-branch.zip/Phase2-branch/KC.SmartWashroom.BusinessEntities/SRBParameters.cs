﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities
{
    public class SRBParameters
    {
        public decimal SoftwareVersion { get; set; }
        public decimal BatteryVoltage { get; set; }
        public decimal PaperRollRemainingPercent { get; set; }
        public bool LowBatteryAlert { get; set; }
        public bool LowPaperAlert { get; set; }
        public int TotalRollsDispensed { get; set; }
        public int UpdateIntervalInMinutes { get; set; }
        public bool Reset { get; set; }
        public int RefilledBatteryBeforeThreshold { get; set; }
        public int RefilledTissueBeforeThreshold { get; set; }
    }
}
