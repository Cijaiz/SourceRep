﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KC.SmartWashroom.Core.Attributes;

namespace KC.SmartWashroom.BusinessEntities
{
    public class eSoapEntity: DeviceEntity
    {
        //public eSoapEntity(string partitionKey, string rowKey) : base(partitionKey, rowKey) { }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public double SoftwareVersion { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public string Shot { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public string Range { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public string RefillSize { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public int CleanModeSinceBatteryChange { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public int TotalDispenseSinceConstruction { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public int DispenseDuringLastBattery { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public int DispenseSinceLastBatteryChange { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public int NumberOfBatteryChanges { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public double VoltageAtLastBatteryChange { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public double CurrentBatteryVoltage { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public bool LowSoapAlert { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public bool LowBatteryAlert { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public bool MotorOverCurrentAlert { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public int TotalRefillsSinceConstruction { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public int RefillsduringLastBattery { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public int RefillsSinceBatteryChange { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public int NoOfDispensesSinceLastRefill { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public int UpdateInterval { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public bool Reset { get; set; }
    }
}
