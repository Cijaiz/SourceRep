﻿using KC.SmartWashroom.Core.Localization;
using System.ComponentModel.DataAnnotations;

namespace KC.SmartWashroom.BusinessEntities
{
    public class LoginModel : ErrorEntity
    {
        private string _name;

        [RequiredLocalizable("Email_Address_Required")]
        [LocalizedDisplayName("EmailAddress")]
        [RegularExpressionLocalizable("InvalidEmailErrorMessage", @"^\s*([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" +
                            @"\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\" +
                            @".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)\s*$")]
        public string UserName {
            get { return this._name; }
            set { this._name = (value == null) ? "" : value.Trim(); }
        }

        [RequiredLocalizable("Password_Required")]
        [DataType(DataType.Password)]
        //[StringLength(20, MinimumLength = 8, ErrorMessage = "Password should not exceed 20 characters in length and should be minimum of 8 characters")]
        //[RegularExpression(@"([a-z]+[0-9]|[0-9]+[a-z]|[0-9]+[A-Z]|[A-Z]+[0-9])[a-z0-9]*", ErrorMessage = "Password should be alphanumeric")]
        [LocalizedDisplayName("password")]
        public string Password { get; set; }

        [LocalizedDisplayName("RememberMe")]
        public bool RememberMe { get; set; }
    }
}
