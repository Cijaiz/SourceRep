﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities.TenantApiEntities
{
   public class RefillSize
    {
        public int RefillId { get; set; }
        public string RefillValue { get; set; }
    }
}
