﻿using System;
using System.Collections.Generic;

namespace KC.SmartWashroom.BusinessEntities.TenantApiEntities
{
    public class CustomerDetail
    {
        public int CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string Street { get; set; }
        public string BuildingAddress { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
        public byte CountryId { get; set; }
        public string Pincode { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int LastUpdatedBy { get; set; }
        public DateTime LastUpdatedOn { get; set; }
        public int AddressId { get; set; }
        public List<Property> Properties { get; set; }
        public List<User> Users { get; set; }
        public int UserId { get; set;}
    }


}
