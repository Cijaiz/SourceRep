﻿using System;
using System.Collections.Generic;

namespace KC.SmartWashroom.BusinessEntities.TenantApiEntities
{
    public class Device
    {
        public Device()
        {
            this.ReturnParameters = new ReturnParameterResponse();
        }

        public string ID { get; set; }
        public Int32 WashroomId { get; set; }

        public string Name { get; set; }
        public string ImageUrl { get; set; }
        public string DeviceType { get; set; }

        public byte DeviceTypeId { get; set; }
        public bool IsActive { get; set; }

        public int CreatedBy { get; set; }
        public Nullable<int> LastUpdatedBy { get; set; }

        public System.DateTime CreatedOn { get; set; }
        public Nullable<System.DateTime> LastUpdatedOn { get; set; }
        public int UserId { get; set; }
        public Nullable<int> ProductRefillId { get; set; }

        public ReturnParameterResponse ReturnParameters { get; set; }

        public ReturnParameterDataTransfer dataTaransfer { get; set; }
    }
}
