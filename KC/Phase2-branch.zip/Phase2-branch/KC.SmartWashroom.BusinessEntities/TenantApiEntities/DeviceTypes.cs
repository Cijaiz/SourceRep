﻿using Newtonsoft.Json;
using System;

namespace KC.SmartWashroom.BusinessEntities.TenantApiEntities
{
    [JsonObject]
    [Serializable]
    public class DeviceTypes
    {
        public int DeviceId { get; set; }
        public string DeviceName { get; set; }
        public string DbDeviceType { get; set; }
        public string MacFormat { get; set; }
        public decimal BatteryScaleFactor { get; set; }
    }
}
