﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities.TenantApiEntities
{
   public class Names
    {
        public string CustomerName { get; set; }
        public int CustomerId { get; set; }
        public string PropertyName { get; set; }
        public Int32 PropertyId { get; set; }
        public string BuildingName { get; set; }
        public Int32 BuildingId { get; set; }
        public short FloorLevel { get; set; }
        public Int32 FloorId { get; set; }
        public string Room { get; set; }
        public byte RoomId { get; set; }
        public string DeviceId { get; set; }
    }
}
