﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities.TenantApiEntities
{
    public class User
    {
        public int UserId { get; set; }
        public int CustomerId { get; set; }
        public int RoleId { get; set; }

        public string FirstName { get; set; }
        public string LastName { get; set; }

        public string Email { get; set; }
        public string Mobile { get; set; }

        public string Role { get; set; }
        public int RoleLevel { get; set; }
        public string CustomerName { get; set; }

        public bool EmailAlert { get; set; }
        public bool TextAlert { get; set; }

        public List<Property> Properties { get; set; }
        public List<Building> Buildings { get; set; }

        public string Password { get; set; }
        public bool IsFirstLogin { get; set; }

        public int UpdatedBy { get; set; }
    }
}
