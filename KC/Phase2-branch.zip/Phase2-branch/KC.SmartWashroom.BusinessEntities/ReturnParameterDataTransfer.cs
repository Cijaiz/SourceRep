﻿using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities
{
    public class ReturnParameterDataTransfer
    {
        public ReturnParameterDataTransfer()
        {

            this.ReturnValueParameters = new List<ReturnParameterResponse>();
            this.ReturnParameterResponse = new ReturnParameterResponse();
            this.ParamterValueIds = new List<int?>();
        }

        public List<ReturnParameterResponse> ReturnValueParameters { get; set; }
        public ReturnParameterResponse ReturnParameterResponse { get; set; }

        public List<Nullable<int>> ParamterValueIds { get; set; }
        public int customerId { get; set; }

        public string DeviceId { get; set; }

        public List<int?> ClearAllDeviceParameterIds { get; set; }
    }
}
