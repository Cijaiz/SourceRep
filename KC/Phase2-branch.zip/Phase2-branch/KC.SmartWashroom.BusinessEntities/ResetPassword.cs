﻿using KC.SmartWashroom.Core.Localization;
using System.ComponentModel.DataAnnotations;

namespace KC.SmartWashroom.BusinessEntities
{
    public class ResetPassword : ErrorEntity
    {
        private string _name;

        [RequiredLocalizable("Email_Address_Required")]
        [LocalizedDisplayName("EmailAddress")]
        [RegularExpressionLocalizable("InvalidEmailErrorMessage", @"^\s*([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" +
                            @"\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\" +
                            @".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)\s*$")]
        public string UserName
        {
            get { return this._name; }
            set { this._name = (value == null) ? "" : value.Trim(); }
        }

        [RequiredLocalizable("Password_Required")]
        [DataType(DataType.Password)]
        [StringLengthLocalized(20, 8, "Password_Length_Error")]
        //[RegularExpression(@"([a-z]+[0-9]|[0-9]+[a-z]|[0-9]+[A-Z]|[A-Z]+[0-9])[a-z0-9]*", ErrorMessage = "Password should be alphanumeric")]
        //[RegularExpression("([a-zA-Z0-9 .&'-]+)", ErrorMessage = "Password should be alphanumeric")]
        [LocalizedDisplayName("Old_Password")]
        public string OldPassword { get; set; }

        [RequiredLocalizable("Password_Required")]
        [DataType(DataType.Password)]
        [StringLengthLocalized(20, 8, "Password_Length_Error")]
        [RegularExpressionLocalizable("Password_Alphanumeric_Error", @"(?=.*\d)(?=.*[A-Za-z])[A-Za-z0-9]*")]
        //[RegularExpression("([a-zA-Z0-9 .&'-]+)", ErrorMessage = "Password should be alphanumeric")]
        [LocalizedDisplayName("New_Password")]
        public string Password { get; set; }

        [RequiredLocalizable("Password_Required")]
        [DataType(DataType.Password)]
        [StringLengthLocalized(20, 8, "Password_Length_Error")]
        [RegularExpressionLocalizable("Password_Alphanumeric_Error", @"(?=.*\d)(?=.*[A-Za-z])[A-Za-z0-9]*")]
        //[RegularExpression("([a-zA-Z0-9 .&'-]+)", ErrorMessage = "Password should be alphanumeric")]
        //[Compare("Password", ErrorMessage = ResourceLocalization.LoadString("Confirm_Password_Mismatch"))]
        [LocalizedCompare("Password","Confirm_Password_Mismatch")]
        [LocalizedDisplayName("Confirm_New_Password")]
        public string ConfirmPassword { get; set; }

        public string UserSecret { get; set; }
    }
}
