﻿
namespace KC.SmartWashroom.BusinessEntities.Aggregation
{
    public class DeviceWashroom
    {
        public string DeviceId { get; set; }
        public string WashroomId { get; set; }
    }
}
