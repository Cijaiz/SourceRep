﻿using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities
{
    public class Property
    {
        public Property() { }

        public Property(int propertyID, string name)
        {
            this.ID = propertyID;
            this.Name = name;
        }

        public int ID { get; set; }
        public string Name { get; set; }

        public int CustomerId { get; set; }
        public string PropertyName { get; set; }
        public int AddressId { get; set; }

        public int UserId { get; set; }
        public string ImageUrl { get; set; }
        public bool IsDelete { get; set; }

        public string Street { get; set; }
        public string City { get; set; }
        public string State { get; set; }

        public string  Country { get; set; }
        public byte CountryId { get; set; }
        public string Zip { get; set; }

        public bool IsCustomerAddress { get; set; }
        public string TimeZone { get; set; }
        public int JobInterval { get; set; }
        public int CreatedBy { get; set; }

        public DateTime CreatedDate { get; set; }
        public Nullable<int> LastUpdatedBy { get; set; }
        public Nullable<DateTime> LastUpdatedOn { get; set; }

        public List<Building> Buildings { get; set; }
        public CustomerDetail Customer { get; set; }
    }
}
