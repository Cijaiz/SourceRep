﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.WindowsAzure.Storage.Table;

namespace KC.SmartWashroom.BusinessEntities
{
    public class DeviceTrafficTraceEntity : TableEntity
    {

        public DeviceTrafficTraceEntity(string partitionKey, string rowKey) : base(partitionKey, rowKey) { }

        public string Correlation { get; set; }
        public string InTime { get; set; }
        public string OutTime { get; set; }
        public string Section { get; set; }

        public string Duration { get; set; }
    }
}
