﻿

namespace KC.SmartWashroom.BusinessEntities.DeviceUpdate
{
    using System;
    using System.Runtime.Serialization;
    /// <summary>
    /// Represents the device parameter value
    /// with a set of computed states
    /// </summary>
    [Serializable]
    [KnownType(typeof(DeviceUpdateParameter))]
    public class DeviceUpdateValue : ICloneable
    {
        /// <summary>
        /// The customer id associated with the value
        /// </summary>
        public int? CustomerId { get; set; }

        /// <summary>
        /// The device id associated with the value
        /// </summary>
        public string DeviceId { get; set; }

        /// <summary>
        /// Value id associated with the value
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Whether the parameter is reset
        /// </summary>
        public bool? IsReset { get; set; }

        /// <summary>
        /// States whether the state is valid or not
        /// </summary>
        public bool IsValid { get; set; }

        /// <summary>
        /// Modified Time
        /// </summary>
        public DateTime? ModifiedTime { get; set; }

        /// <summary>
        /// Reset time
        /// </summary>
        public DateTime? ResetTime { get; set; }

        /// <summary>
        /// Value
        /// </summary>
        public string Value { get; set; }

        /// <summary>
        /// The device parameter information associated with the parameter value
        /// </summary>
        public DeviceUpdateParameter Parameter { get; set; }


        /// <summary>
        /// The parameter id of the underlying parameter
        /// </summary>
        public int ParameterId { get; set; }

        /// <summary>
        /// States whether the value is the default value or not
        /// </summary>
        public bool IsDefault
        {
            get
            {
                return (!this.CustomerId.HasValue || this.CustomerId.Value <= 0)
                    && string.IsNullOrWhiteSpace(this.DeviceId)
                    && !string.IsNullOrWhiteSpace(this.Value)
                    && this.ParameterId > 0;
            }
        }

        /// <summary>
        ///  States whether the given value is a customer override or not
        /// </summary>
        public bool IsCustomerOverride
        {
            get
            {
                return this.CustomerId.HasValue
                    && this.CustomerId.Value > 0
                    && string.IsNullOrWhiteSpace(this.DeviceId)
                    && !string.IsNullOrWhiteSpace(this.Value)
                    && this.ParameterId > 0;
            }
        }

        /// <summary>
        /// States whether the given value is a device override or not
        /// </summary>
        public bool IsDeviceOverride
        {
            get
            {
                return this.CustomerId.HasValue
                    && this.CustomerId.Value > 0
                    && !string.IsNullOrWhiteSpace(this.DeviceId)
                    && !string.IsNullOrWhiteSpace(this.Value)
                    && this.ParameterId > 0;
            }
        }

        /// <summary>
        /// Instantiates the device update value
        /// </summary>
        public DeviceUpdateValue()
        {
            this.Value = string.Empty;
            this.DeviceId = string.Empty;
        }

        /// <summary>
        /// Clones the device update value
        /// </summary>
        /// <returns>Returns the cloned instance</returns>
        public DeviceUpdateValue Clone()
        {
            return new DeviceUpdateValue()
            {
                CustomerId = this.CustomerId,
                DeviceId = this.DeviceId,
                Id = this.Id,
                IsReset = this.IsReset,
                IsValid = this.IsValid,
                ModifiedTime = this.ModifiedTime,
                Parameter = this.Parameter,
                ParameterId = this.ParameterId,
                ResetTime = this.ResetTime,
                Value = this.Value,
            };
        }

        object ICloneable.Clone()
        {
            return this.Clone();
        }
    }
}
