﻿/*
 * TODO: To be moved to an independent assembly. This is the part of the global contract definition, not business hub specific 
 */

namespace KC.SmartWashroom.BusinessEntities.DeviceUpdate
{
    using System;
    using System.Collections.Generic;
    using System.Runtime.Serialization;
    /// <summary>
    /// Represents the instance of one input parameter
    /// </summary>  
    [Serializable]
    [KnownType(typeof(DeviceUpdateValue))]
    [KnownType(typeof(DeviceUpdateDetails))]
    public class DeviceUpdateParameter : ICloneable
    {
        // ### Note: Any state added to the class should be applied on clone ###

        /// <summary>
        /// The index of the parameter, typically the parameter index 
        /// in the input string or the prefix in the return parameter value
        /// </summary>
        public int Index { get; set; }

        /// <summary>
        /// The name of the parameter, the paramter name in the JSON for
        /// return parameters an the field names for input parameters
        /// </summary>
        public string Name { get; set; }


        /// <summary>
        /// The format code
        /// </summary>
        public string FormatCode { get; set; }

        /// <summary>
        /// Whether an input parameter or the return parameter
        /// </summary>
        public bool IsReturn { get; set; }

        /// <summary>
        /// Is auto reset enabled?
        /// Whether the API has to go back to DB to update this?
        /// </summary>
        public bool IsAutoReset { get; set; }

        /// <summary>
        /// Whether to ignore the errors or not
        /// </summary>
        public bool IgnoreErrors { get; set; }


        /// <summary>
        /// Device Type id
        /// </summary>
        public int DeviceTypeId { get; set; }


        /// <summary>
        /// Parameter id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// The group id of the parameter
        /// </summary>
        /// <remarks>Not yet implemented</remarks>
        public int GroupId { get; set; }

        /// <summary>
        /// The group name of the parameter
        /// </summary>
        /// <remarks>Not yet implemented</remarks>
        public string GroupName { get; set; }

        /// <summary>
        /// Device details association
        /// </summary>
        public DeviceUpdateDetails Device { get; set; }

        /// <summary>
        /// Gets or sets the parameter values associated with the parameter
        /// </summary>
        public IList<DeviceUpdateValue> Values { get; set; }


        /// <summary>
        /// Default constructor
        /// </summary>
        public DeviceUpdateParameter()
        {
            // ### Note: Any state added to the class should be applied on clone ###
            this.Name = string.Empty;
            this.FormatCode = string.Empty;
            this.GroupName = string.Empty;
            this.Values = new List<DeviceUpdateValue>();
        }
        /// <summary>
        /// Creates the copy of the parameter with values
        /// </summary>
        /// <returns>
        /// The instance of a new parameter with the copy of the states of
        /// the current parameter and its values
        /// </returns>
        public DeviceUpdateParameter Clone()
        {
            // State
            var parameter = new DeviceUpdateParameter()
            {
                Device = this.Device,
                DeviceTypeId = this.DeviceTypeId,
                FormatCode = this.FormatCode,
                GroupId = this.GroupId,
                GroupName = this.GroupName,
                Id = this.Id,
                IgnoreErrors = this.IgnoreErrors,
                Index = this.Index,
                IsAutoReset = this.IsAutoReset,
                IsReturn = this.IsReturn,
                Name = this.Name,
            };

            // Values
            for (int index = 0; index < this.Values.Count; index++)
            {
                var value = this.Values[index];
                var clone = value.Clone();
                clone.Parameter = parameter;
                parameter.Values.Add(clone);
            }

            return parameter;
        }

        /// <summary>
        /// Cloneable.Clone
        /// </summary>
        /// <returns>The clone of the current object</returns>
        object ICloneable.Clone()
        {
            return this.Clone();
        }

        /// <summary>
        /// Deserialization logic
        /// </summary>
        /// <param name="context">Streaming context</param>
        [OnDeserialized]
        internal void OnDeserialized(StreamingContext context)
        {
            if (this.Values == null)
            {
                this.Values = new List<DeviceUpdateValue>();
            }

            for (int index = 0; index < this.Values.Count; index++)
            {
                var value = this.Values[index];
                value.Parameter = this;
            }
        }


        /// <summary>
        /// Serialization logic
        /// </summary>
        /// <param name="context">Streaming context</param>
        [OnSerializing]
        internal void OnSerializing(StreamingContext context)
        {
            if (this.Values != null && this.Values.Count > 0)
            {
                for (int index = 0; index < this.Values.Count; index++)
                {
                    var value = this.Values[index];
                    value.Parameter = null;
                }
            }
        }



    }
}
