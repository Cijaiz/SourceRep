﻿

namespace KC.SmartWashroom.BusinessEntities.DeviceUpdate
{
    using System;
    using System.Collections.Generic;
    using System.Runtime.Serialization;
    /// <summary>
    /// Represents the device check in data
    /// </summary>
    [Serializable]
    [KnownType(typeof(DeviceUpdateParameter))]
    public class DeviceUpdateDetails : ICloneable
    {
        /// <summary>
        /// Building id
        /// </summary>
        public int BuildingId { get; set; }

        /// <summary>
        /// Gets or sets the building name
        /// </summary>
        public string BuildingName { get; set; }

        /// <summary>
        /// Gets or sets the customer id
        /// </summary>
        public int CustomerId { get; set; }

        /// <summary>
        /// Gets or sets the customer name
        /// </summary>
        public string CustomerName { get; set; }

        /// <summary>
        /// Gets or sets the device id
        /// </summary>
        public string DeviceId { get; set; }

        /// <summary>
        /// Gets or sets the device id
        /// </summary>
        public string DeviceName { get; set; }

        /// <summary>
        /// Gets or sets the device type id
        /// </summary>
        public int DeviceTypeId { get; set; }

        /// <summary>
        /// Gets or sets the device type name
        /// </summary>
        public string DeviceTypeName { get; set; }

        /// <summary>
        /// Gets or sets the floor id
        /// </summary>
        public int FloorId { get; set; }

        /// <summary>
        /// Gets or sets the floor level
        /// </summary>
        public short FloorLevel { get; set; }

        /// <summary>
        /// Gets or sets the floor section id or wing id
        /// </summary>
        public int FloorSectionId { get; set; }

        /// <summary>
        /// Gets or sets the floor section name or wing name
        /// </summary>
        public string FloorSectionName { get; set; }

        /// <summary>
        /// Gets or sets the property id
        /// </summary>
        public int PropertyId { get; set; }

        /// <summary>
        /// Gets or sets the property name
        /// </summary>
        public string PropertyName { get; set; }

        /// <summary>
        /// Gets or sets the restroom Id
        /// </summary>
        public int RestroomId { get; set; }

        /// <summary>
        /// Gets or sets the restroom name
        /// </summary>
        public string RestroomName { get; set; }

        /// <summary>
        /// Gets or sets the restroom Id
        /// </summary>
        public int RestroomTypeId { get; set; }

        /// <summary>
        /// Gets or sets the restroom name
        /// </summary>
        public string RestroomTypeName { get; set; }

        /// <summary>
        /// Gets or sets the parameters
        /// </summary>
        public IList<DeviceUpdateParameter> Parameters { get; set; }

        /// <summary>
        /// Default constructor
        /// </summary>
        public DeviceUpdateDetails()
        {
            this.Parameters = new List<DeviceUpdateParameter>();
            this.BuildingName = string.Empty;
            this.CustomerName = string.Empty;
            this.DeviceTypeName = string.Empty;
            this.FloorSectionName = string.Empty;
            this.PropertyName = string.Empty;
            this.RestroomName = string.Empty;
        }

        public DeviceUpdateDetails Clone()
        {
            var device = new DeviceUpdateDetails()
            {
                BuildingId = this.BuildingId,
                BuildingName = this.BuildingName,
                CustomerId = this.CustomerId,
                CustomerName = this.CustomerName,
                DeviceId = this.DeviceId,
                DeviceName = this.DeviceName,
                DeviceTypeId = this.DeviceTypeId,
                DeviceTypeName = this.DeviceTypeName,
                FloorId = this.FloorId,
                FloorLevel = this.FloorLevel,
                FloorSectionId = this.FloorSectionId,
                FloorSectionName = this.FloorSectionName,
                PropertyId = this.PropertyId,
                PropertyName = this.PropertyName,
                RestroomId = this.RestroomId,
                RestroomName = this.RestroomName,
                RestroomTypeId = this.RestroomTypeId,
                RestroomTypeName = this.RestroomTypeName,
            };

            for (int index = 0; index < this.Parameters.Count; index++)
            {
                var parameter = this.Parameters[index];
                var clone = parameter.Clone();
                clone.Device = device;
                device.Parameters.Add(clone);
            }

            return device;
        }

        object ICloneable.Clone()
        {
            return this.Clone();
        }

        /// <summary>
        /// Serialization logic
        /// </summary>
        /// <param name="context">Streaming context instance</param>
        [OnDeserialized]
        internal void OnDeserialized(StreamingContext context)
        {
            if (this.Parameters == null)
            {
                this.Parameters = new List<DeviceUpdateParameter>();
            }

            for (int index = 0; index < this.Parameters.Count; index++)
            {
                var parameter = this.Parameters[index];
                parameter.Device = this;
            }
        }

        /// <summary>
        /// Serialization logic
        /// </summary>
        /// <param name="context">Streaming context</param>
        [OnSerializing]
        internal void OnSerializing(StreamingContext context)
        {
            if (this.Parameters != null && this.Parameters.Count > 0)
            {
                for (int index = 0; index < this.Parameters.Count; index++)
                {
                    var parameter = this.Parameters[index];
                    parameter.Device = null;
                }
            }
        }


    }
}
