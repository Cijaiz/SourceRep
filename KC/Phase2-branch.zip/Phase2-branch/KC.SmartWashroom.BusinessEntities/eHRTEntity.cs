﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KC.SmartWashroom.Core.Attributes;

namespace KC.SmartWashroom.BusinessEntities
{
    public class eHRTEntity : DeviceEntity
    {
        //public eHRTEntity(string partitionKey, string rowKey) : base(partitionKey, rowKey) { }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public double SoftwareVersion { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public string Sensitivity { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public string DispenseLength { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public string DispenserDelay { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public string DispenseMode { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public int TotalDispenseCount { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public int DispensesWithLastBattery { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public int DispensesWithCurrentBattery { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public int NumberOfBatteryChanges { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public double VoltageLastBatteryChange { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public double CurrentBatteryVoltage { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public bool LowPaperAlert { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public bool LowBatteryAlert { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public bool PaperJamAlert { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public int PaperDispensedSinceLastRefill { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public bool Reset { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public bool PlaceHolder { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public int TrashEmptyPercent { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public bool TrashFullAlert { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public int UpdateInterval { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public int TotalRollsDispensed { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public bool DelayEnabled { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public int DelayValue { get; set; }
    }
}
