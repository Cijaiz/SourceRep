﻿using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities.AlertEngineEntities
{
    public class AlertEntity : TableEntity
    {
        public AlertEntity() : base() { }
        public AlertEntity(string partitionKey, string rowKey) : base(partitionKey, rowKey) { }

        public string AlertType { get; set; }
        public int IsAlert { get; set; }
        public string AlertIssuedOn { get; set; }

        public string DeviceId { get; set; }
        public string DeviceType { get; set; }
        public int WashroomId { get; set; }

        public int FloorLevel { get; set; }
        public int FloorId { get; set; }

        public int BuildingId { get; set; }
        public int PropertyID { get; set; }

        public int CustomerID { get; set; }
        public string RefillPercentage { get; set; }
    }
}
