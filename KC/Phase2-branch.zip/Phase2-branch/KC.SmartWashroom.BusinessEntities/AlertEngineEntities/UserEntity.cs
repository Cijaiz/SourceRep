﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities.AlertEngineEntities
{
    public class UserEntity
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }

        public string MobileNo { get; set; }
        public int CustomerID { get; set; }
        public int RoleID { get; set; }

        public string DeviceName { get; set; }
        public string AlertType { get; set; }
        public int FloorID { get; set; }

        public string Washroom { get; set; }
        public string Gender { get; set; }

        public string Building { get; set; }
        public bool IsEmailAlert { get; set; }
        public bool IsMobileAlert { get; set; }

        public string Wing { get; set; }
        public string LocalTimeZone { get; set; }
        public int RoleLevel { get; set; }

        public int UserAccessBuildingID { get; set; }
        public int UserAccessPropertyID { get; set; }

        public List<int> buildingIds { get; set; }
    }
}
