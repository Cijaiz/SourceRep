﻿
namespace KC.SmartWashroom.BusinessEntities.AlertEngineEntities
{
    public class UserAccountInformation
    {
        //For Alert Engine Welcome Email for New Users..
        public string Password { get; set; }
    }
}
