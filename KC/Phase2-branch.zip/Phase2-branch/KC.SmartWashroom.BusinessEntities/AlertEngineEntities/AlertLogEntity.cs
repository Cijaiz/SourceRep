﻿using Microsoft.WindowsAzure.Storage.Table;
using System;
namespace KC.SmartWashroom.BusinessEntities.AlertEngineEntities
{
    public class AlertLogEntity : TableEntity
    {
        public AlertLogEntity() : base() { }
        public AlertLogEntity(string partitionKey, string rowKey) : base(partitionKey, rowKey) { }

        public string AlertType { get; set; }
        public int IsAlert { get; set; }
    }
}
