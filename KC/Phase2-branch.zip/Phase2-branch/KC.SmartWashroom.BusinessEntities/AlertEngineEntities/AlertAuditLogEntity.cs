﻿using Microsoft.WindowsAzure.Storage.Table;
using System;

namespace KC.SmartWashroom.BusinessEntities.AlertEngineEntities
{
    public class AlertAuditLogEntity : TableEntity
    {
        public AlertAuditLogEntity() : base() { }
        public AlertAuditLogEntity(string partitionKey, string rowKey) : base(partitionKey, rowKey) { }


        public string ToEmailAddresses { get; set; }
        public string ToPhoneNumbers { get; set; }

        public string EmailContent { get; set; }
        public string SMSContent { get; set; }
        public string AlertType { get; set; }

        public bool isEmailOutForDelivery { get; set; }
        public bool isSMSOutForDelivery { get; set; }

        public int IsAlert { get; set; }
        public string CreatedOn { get; set; }

    }
}
