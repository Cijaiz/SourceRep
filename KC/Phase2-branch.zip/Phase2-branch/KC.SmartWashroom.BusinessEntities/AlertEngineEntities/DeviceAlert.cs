﻿using System;
namespace KC.SmartWashroom.BusinessEntities.AlertEngineEntities
{
    public class DeviceAlert
    {
        public string DeviceId { get; set; }
        public int AlertTypeId { get; set; }
        public bool IsAlert { get; set; }
       
        public string AlertType { get; set; }
        public string AlertTypeName { get; set; }
        public System.DateTime DateTime { get; set; }
        
        public string Gender { get; set; }
        public string DeviceName { get; set; }
        public Int32 FloorID { get; set; }

        public int FloorLevel { get; set; }
        public string Wing { get; set; }
        public string WashroomName { get; set; }
        public Int32 WashroomId { get; set; }

        public string LocalTimeZone { get; set; }
        public bool isBuilding { get; set; }
    }
}
