﻿using Microsoft.WindowsAzure.Storage.Table;
using System;
namespace KC.SmartWashroom.BusinessEntities.AlertEngineEntities
{
    public class AlertStatusEntity : AlertEntity
    {
        public string AlertResolvedOn { get; set; }
    }
}
