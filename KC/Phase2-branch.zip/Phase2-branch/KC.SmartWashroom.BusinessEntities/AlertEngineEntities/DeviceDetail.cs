﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities.AlertEngineEntities
{
    public class DeviceDetail
    {
        public DeviceDetail()
        {
            this.UserDetails = new List<UserEntity>();
        }

        public string DeviceID { get; set; }
        public bool IsAlert { get; set; }
        public string DeviceName { get; set; }

        public string AlertType { get; set; }
        public int Floor { get; set; }
        public List<UserEntity> UserDetails { get; set; }

        public string Washroom { get; set; }
        public string Gender { get; set; }
        public string PropertyName { get; set; }

        public string Building { get; set; }
        public string Comments { get; set; }

        public string Wing { get; set; }
        public string ReceivedOn { get; set; }
        public int CustomerId { get; set; }

        public string LocalTimeZone { get; set; }
        public bool IsAlertForCleaner { get; set; }
    }
}
