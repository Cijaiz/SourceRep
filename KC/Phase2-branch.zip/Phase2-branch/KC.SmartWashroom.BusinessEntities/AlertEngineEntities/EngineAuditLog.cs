﻿using Microsoft.WindowsAzure.Storage.Table;
using System.Collections.Generic;

namespace KC.SmartWashroom.BusinessEntities.AlertEngineEntities
{
    public class EngineAuditLog
    {
        public ICollection<string> ToEmailAddresses { get; set; }
        public ICollection<string> ToPhoneNumbers { get; set; }

        public string EmailContent { get; set; }
        public string SMSContent { get; set; }
        public string AlertType { get; set; }

        public bool isEmailOutForDelivery { get; set; }
        public bool isSMSOutForDelivery { get; set; }

        public int IsAlert { get; set; }
    }
}
