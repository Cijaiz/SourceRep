﻿
namespace KC.SmartWashroom.BusinessEntities
{
    public class DeviceInformation
    {
        public string DeviceId { get; set; }
        public string DeviceType { get; set; }
        public int WashroomId { get; set; }

        public string WashroomName { get; set; }
        public short FloorLevel { get; set; }
        public int FloorId { get; set; }

        public int BuildingId { get; set; }
        public string BuildingName { get; set; }
        public int PropertyID { get; set; }

        public string PropertyName { get; set; }
        public int CustomerID { get; set; }
        public string CustomerName { get; set; }

        public string AlertType { get; set; }
        public int IsAlert { get; set; }
    }
}
