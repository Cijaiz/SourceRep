﻿
namespace KC.SmartWashroom.BusinessEntities.AlertEngineEntities
{
    public class ExceptionTrace
    {
        public string DeviceID { get; set; }
        public string ExceptionMessage { get; set; }
        public string Time { get; set; }
    }
}
