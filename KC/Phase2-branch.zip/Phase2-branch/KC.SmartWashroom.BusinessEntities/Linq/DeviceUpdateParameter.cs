﻿

namespace KC.SmartWashroom.BusinessEntities.Linq
{
    using KC.SmartWashroom.BusinessEntities.DeviceUpdate;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    /// <summary>
    /// Linq extensions for the device parameter info
    /// </summary>
    public static class DeviceParameterInfoExtensions
    {
        /// <summary>
        /// Gets the default values for a particular device parameter
        /// </summary>
        /// <param name="parameters">Enumerable of device parameter</param>
        /// <returns>An enumerable of device parameters with the default values alone</returns>
        public static IEnumerable<KeyValuePair<DeviceUpdateParameter, DeviceUpdateValue>> WithDefaultValues(this IEnumerable<DeviceUpdateParameter> parameters)
        {
            var defaultValues = default(IEnumerable<KeyValuePair<DeviceUpdateParameter, DeviceUpdateValue>>);

            if (parameters != null)
            {
                defaultValues = parameters.Select(p => new KeyValuePair<DeviceUpdateParameter, DeviceUpdateValue> (p, p.DefaultValue())).Where(value => value.Value != null);
            }

            return defaultValues ?? Enumerable.Empty<KeyValuePair<DeviceUpdateParameter, DeviceUpdateValue>>();
        }
        
        /// <summary>
        /// Gets the preceding override for the given device parameter
        /// </summary>
        /// <param name="parameters">An enumerable of device parameters</param>
        /// <returns>An enumerable with the most relavant overrides</returns>
        public static IEnumerable<KeyValuePair<DeviceUpdateParameter, DeviceUpdateValue>> WithCurrentValueOverrides(this IEnumerable<DeviceUpdateParameter> parameters)
        {
            var returnParameters = default(IEnumerable<KeyValuePair<DeviceUpdateParameter, DeviceUpdateValue>>);

            if (parameters != null)
            {
                returnParameters = parameters.Select(p => new KeyValuePair<DeviceUpdateParameter, DeviceUpdateValue>(p, p.CurrentValue())).Where(value => value.Value != null);
            }

            return returnParameters ?? Enumerable.Empty<KeyValuePair<DeviceUpdateParameter, DeviceUpdateValue>>();
        }

        /// <summary>
        /// Gets the device level override for the given device parameter
        /// </summary>
        /// <param name="parameters">An enumerable of device parameters</param>
        /// <returns>An enumerable with the most relavant overrides</returns>
        public static IEnumerable<KeyValuePair<DeviceUpdateParameter, DeviceUpdateValue>> WithCustomerOverrides(this IEnumerable<DeviceUpdateParameter> parameters)
        {
            var returnParameters = default(IEnumerable<KeyValuePair<DeviceUpdateParameter, DeviceUpdateValue>>);

            if (parameters != null)
            {
                returnParameters = parameters.Select(p => new KeyValuePair<DeviceUpdateParameter, DeviceUpdateValue>(p, p.CustomerOverride())).Where(value => value.Value != null);
            }

            return returnParameters ?? Enumerable.Empty<KeyValuePair<DeviceUpdateParameter, DeviceUpdateValue>>();
        }

        /// <summary>
        /// Gets the customer level override for the given device parameter
        /// </summary>
        /// <param name="parameters">An enumerable of device parameters</param>
        /// <returns>An enumerable with the most relavant overrides</returns>
        public static IEnumerable<KeyValuePair<DeviceUpdateParameter, DeviceUpdateValue>> WithDeviceOverrides(this IEnumerable<DeviceUpdateParameter> parameters)
        {
            var returnParameters = default(IEnumerable<KeyValuePair<DeviceUpdateParameter, DeviceUpdateValue>>);

            if (parameters != null)
            {
                returnParameters = parameters.Select(p => new KeyValuePair<DeviceUpdateParameter, DeviceUpdateValue>(p, p.DeviceOverride())).Where(value => value.Value != null);
            }

            return returnParameters ?? Enumerable.Empty<KeyValuePair<DeviceUpdateParameter, DeviceUpdateValue>>();
        }
        /// <summary>
        /// Filters the return parameters alone
        /// </summary>
        /// <param name="parameters">An enumerable of device parameters</param>
        /// <returns>An enumerable of the return parameters</returns>
        public static IEnumerable<DeviceUpdateParameter> ReturnParameters(this IEnumerable<DeviceUpdateParameter> parameters)
        {
            var returnParameters = default(IEnumerable<DeviceUpdateParameter>);

            if (parameters != null)
            {
                returnParameters = parameters.Where(p => p.IsReturn
                    && p.Index >= 0
                    && !string.IsNullOrWhiteSpace(p.Name));
            }

            return returnParameters ?? Enumerable.Empty<DeviceUpdateParameter>();
        }


        /// <summary>
        /// Filters the auto reset parameters alone
        /// </summary>
        /// <param name="parameters">An enumerable of the parameters</param>
        /// <returns>The autoreset parameters</returns>
        public static IEnumerable<DeviceUpdateParameter> AutoReset(this IEnumerable<DeviceUpdateParameter> parameters)
        {
            var autoReset = default(IEnumerable<DeviceUpdateParameter>);

            if (parameters != null)
            {
                autoReset = parameters
                    .ReturnParameters() // shold I do it here?
                    .Where(p => p.IsAutoReset);
            }

            return autoReset ?? Enumerable.Empty<DeviceUpdateParameter>();
        }      

        /// <summary>
        /// Gets the current active value based on the precedence
        /// </summary>
        /// <param name="parameter">The device parameter</param>
        /// <returns>Returns the current value based on the precedence, if found, else null</returns>
        /// <remarks>Not null safe</remarks>
        public static DeviceUpdateValue CurrentValue(this DeviceUpdateParameter parameter)
        {
            return parameter.DeviceOverride()
                ?? parameter.CustomerOverride()
                ?? parameter.DefaultValue();
        }

        /// <summary>
        /// Gets the default value, or in another words the value at the device type level
        /// </summary>
        /// <param name="parameter">The device parameter</param>
        /// <returns>Returns the default value, or in another words the value at the device level, if found, else null</returns>
        /// <remarks>Not null safe</remarks>
        public static DeviceUpdateValue DefaultValue(this DeviceUpdateParameter parameter)
        {
            return parameter != null
                && parameter.Values != null
                // IsDefault is a calculated property
                ? parameter.Values.Where(value => value.IsDefault).FirstOrDefault() : default(DeviceUpdateValue);
        }
        /// <summary>
        /// Gets the customer override value
        /// </summary>
        /// <param name="parameter">The device parameter</param>
        /// <returns>Returns the customer override value if found, else null</returns>
        /// <remarks>Not null safe</remarks>
        public static DeviceUpdateValue CustomerOverride(this DeviceUpdateParameter parameter)
        {
            return parameter != null
                && parameter.Values != null
                ? parameter.Values.Where(value => value.IsCustomerOverride).FirstOrDefault() : default(DeviceUpdateValue);
        }
        /// <summary>
        /// Gets the device override value
        /// </summary>
        /// <param name="parameter">The device parameter</param>
        /// <returns>Returns the device level override if found, else null</returns>
        /// <remarks>Not null safe</remarks>
        public static DeviceUpdateValue DeviceOverride(this DeviceUpdateParameter parameter)
        {
            return parameter != null
                && parameter.Values != null
                ? parameter.Values.Where(value => value.IsDeviceOverride).FirstOrDefault() : default(DeviceUpdateValue);
        }

        public static IDictionary<int, IList<DeviceUpdateParameter>> CleanupAndGroupByDeviceType(this IEnumerable<DeviceUpdateParameter> enumerable)
        {
            // de-duplicating data and creating lookup

            var lookup = new Dictionary<int, IList<DeviceUpdateParameter>>();

            if (enumerable != null)
            {

                foreach (var item in enumerable)
                {
                    var parameters = default(IList<DeviceUpdateParameter>);
                    if (!lookup.ContainsKey(item.DeviceTypeId))
                    {
                        parameters = new List<DeviceUpdateParameter>() { item };
                        lookup.Add(item.DeviceTypeId, parameters);
                    }
                    else
                    {
                        parameters = lookup[item.DeviceTypeId];
                        var parameter = parameters.FirstOrDefault(p => p.Id == item.Id);
                        if (parameter == null)
                        {
                            parameter = item;
                            parameters.Add(parameter);
                        }
                        else
                        {

                            for (int valueIndex = 0; valueIndex < item.Values.Count; valueIndex++)
                            {
                                var value = item.Values[valueIndex];

                                if (!parameter.Values.Any(v => v.Id == value.Id))
                                {
                                    parameter.Values.Add(value);
                                    value.Parameter = parameter;
                                }
                            }
                        }
                    }
                }
            }

            return lookup;

        }

    }
}
