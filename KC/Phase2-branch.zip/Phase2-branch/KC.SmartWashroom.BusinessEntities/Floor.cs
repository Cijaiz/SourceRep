﻿using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KC.SmartWashroom.Core.Localization;

namespace KC.SmartWashroom.BusinessEntities
{
    public class Floor
    {
        public Int32 ID { get; set; }
        public Int32 BuildingId { get; set; }
        [LocalizedRangeAttribute(-5, byte.MaxValue,"FLOOR_LEVEL_RANGE")]
        //[Range(-5, byte.MaxValue, ErrorMessage = ResourceLocalization.LoadString("FLOOR_LEVEL_RANGE"))]        
        [RegularExpressionLocalizable("PLEASE_ENTER_NUMBER", @"^-?[0-9]\d*(\.\d+)?$")]
        public short FloorLevel { get; set; }
        public bool IsActive { get; set; }
        public int CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
        public Nullable<int> LastUpdatedBy { get; set; }
        public Nullable<System.DateTime> LastUpdatedOn { get; set; }
        public List<KeyValuePair<KeyValuePair<string, Int32>, List<DeviceAlert>>> WashroomSets { get; set; }
        public List<DeviceAlert> Alerts { get; set; }
        public List<Washroom> Washrooms { get; set; }
        public string BuildingName { get; set; }
        public string PropertyName { get; set; }
        public Names Name { get; set; }

        public string CustomerName { get; set; }
    }
}
