﻿

namespace KC.SmartWashroom.BusinessEntities
{
    using Microsoft.WindowsAzure.Storage.Table;
    public class DeviceAuditLogEntity : TableEntity
    {
        public DeviceAuditLogEntity(string partitionKey, string rowKey) : base(partitionKey, rowKey) { }

        public string RequestHeaders { get; set; }
        public string ResponseHeaders { get; set; }
        public string RequestBody { get; set; }
        public string ResponseBody { get; set; }
        public int ResponseCode { get; set; }
        public string SourceIP { get; set; }
        public string InTime { get; set; }
        public string OutTime { get; set; }
        /// <summary>
        /// The device identifier
        /// </summary>
        public string DeviceId { get; set; }
    }
}
