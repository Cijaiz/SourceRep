﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities
{
   public  class DeviceDetailParameter
    {
       public string gatewayDetail { get; set; }
        public string  deviceDetail { get; set; }
    }

    public class AlertParameter
    {
        public string deviceAlerts { get; set; }
    }
}
