﻿using KC.SmartWashroom.Core.Localization;
using System.ComponentModel.DataAnnotations;

namespace KC.SmartWashroom.BusinessEntities
{
    public class ForgotPassword : ErrorEntity
    {
        private string _name;

        [RequiredLocalizable("Email_Address_Required")]
        [LocalizedDisplayName("EmailAddress")]
        [RegularExpressionLocalizable("InvalidEmailErrorMessage", @"^\s*([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" +
                            @"\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\" +
                            @".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)\s*$")]
        public string UserName
        {
            get { return this._name; }
            set { this._name = (value == null) ? "" : value.Trim(); }
        }
    }
}
