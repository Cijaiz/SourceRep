﻿

namespace KC.SmartWashroom.BusinessEntities.Search
{
    using KC.SmartWashroom.Core;
    using System.Collections.Generic;
    using System.Linq;
    public class DeviceSearchParameters : IPropertyBag
    {
        public string DeviceId
        {
            get { return this.Get<string>("DeviceId"); }
            set { this.Set<string>(value, "DeviceId"); }
        }
        public string DeviceType
        {
            get { return this.Get<string>("DeviceType"); }
            set { this.Set<string>(value, "DeviceType"); }
        }
        public int CustomerId
        {
            get { return this.Get<int>("CustomerId"); }
            set { this.Set<int>(value, "CustomerId"); }
        }
        public int DeviceTypeId
        {
            get { return this.Get<int>("DeviceTypeId"); }
            set { this.Set<int>(value, "DeviceTypeId"); }
        }
        public DeviceSearchParameters()
            : this(null)
        {

        }
        public DeviceSearchParameters(IPropertyBag instance)
        {
            this.Instance = instance ?? new PropertyBag();
        }

        protected T Get<T>(string key)
        {
            return this.Instance != null ? this.Instance.Get<T>(key) : default(T);
        }

        protected IEnumerable<KeyValuePair<string, object>> Parameters
        {
            get
            {
                return this.Instance != null ? this.Instance.Parameters : Enumerable.Empty<KeyValuePair<string, object>>();
            }
        }

        protected bool Set<T>(T instance, string key = null, bool updateExisting = true)
        {
            return this.Instance != null ? this.Instance.Set<T>(instance, key, updateExisting) : false;
        }

        T IPropertyBag.Get<T>(string key)
        {
            return this.Get<T>(key);
        }

        IEnumerable<KeyValuePair<string, object>> IPropertyBag.Parameters
        {
            get
            {
                return this.Parameters;
            }
        }

        bool IPropertyBag.Set<T>(T instance, string key, bool updateExisting)
        {
            return this.Set<T>(instance, key, updateExisting);
        }

        protected IPropertyBag Instance { get; set; }

        /* Not required for now; the idea is to write maximum managed code
        private void Dispose()
        {
            if (this.Instance != null)
            {
                this.Instance.Dispose();
            }
            this.Dispose(true);
        }

        protected virtual void Dispose(bool disposing)
        {
        }

        void System.IDisposable.Dispose()
        {
            this.Dispose();
        }
        */
    }
}
