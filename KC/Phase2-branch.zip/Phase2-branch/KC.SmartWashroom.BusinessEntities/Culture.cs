﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities
{
    public class Culture : ImplemtedCulture
    {
        public int ID { get; set; }
        public string CultureName { get; set; }
    }

    public class ImplemtedCulture
    {
        public List<string> List { get; set; }
    }
}
