﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KC.SmartWashroom.Core.Attributes;

namespace KC.SmartWashroom.BusinessEntities
{
    public class JRTEntity:DeviceEntity
    {
        //public JRTEntity(string partitionKey, string rowKey) : base(partitionKey, rowKey) { }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public double SoftwareVersion { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public double BatteryVoltage { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public double PaperRollRemainingPercent { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public bool LowBatteryAlert { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public bool PlaceHolder1 { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public bool LowPaperAlert { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public bool PlaceHolder2 { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public int TotalRollsDispensed { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public int UpdateIntervalInMinutes { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public bool Reset { get; set; }
    }
}
