﻿
namespace KC.SmartWashroom.BusinessEntities.BusinessHubEntities
{
    public class DeviceAlertsResolutionDetail
    {
        public string DeviceId { get; set; }
        public string DeviceName { get; set; }
        public string AlertType { get; set; }
        public string AlertDescription { get; set; }

        public string AlertReceivedOn { get; set; }
        public string AlertResolvedOn { get; set; }
        public string ResolutionTime { get; set; }

        public int Floor { get; set; }
        public string WashroomGender { get; set; }

        public int RefillPercentage { get; set; }
        public bool IsRefillHappened { get; set; }

        public int ResolutionTimeSpanMinutes { get; set; }

        public decimal NoOfDispensesSinceLastRefill { get; set; }

        public string RefillSize { get; set; }

        public string DeviceType { get; set; }

        public int CustomerID { get; set; }

        public string LocalTimeZone { get; set; }

        /// <summary>
        /// The name of the property
        /// </summary>
        public string PropertyName { get; set; }

        /// <summary>
        /// The name of the building
        /// </summary>
        public string BuildingName { get; set; }

        public string Wing { get; set; }
    }
}
