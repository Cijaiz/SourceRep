﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities.BusinessHubEntities
{
    public class DeviceRefillDetail : eSoapParameters
    {
        public string DeviceId { get; set; }
        public decimal PaperRollRemainingPercent { get; set; }
        public string DeviceType { get; set; }

        public int PaperDispensedSinceLastRefill { get; set; }

        public char EHRTRefillSize { get; set; }

        public char JRTRefillSize { get; set; }
    }
}
