﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities.BusinessHubEntities
{
    public class DeviceSizeAndDispensedValue
    {
        public string DeviceSize { get; set; }
        public int DeviceSinceLastDispensed { get; set; }
        public double CurrentBatteryVoltage { get; set; }

        public string ShotSize { get; set; }
    }
}
