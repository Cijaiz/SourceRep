﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities.BusinessHubEntities
{
    public class UserAccessAsserts
    {
        public List<UserAssertRelationship> UserAccessBuildings { get; set; }
        public List<UserAssertRelationship> UserAccessProperties { get; set; }
    }
}
