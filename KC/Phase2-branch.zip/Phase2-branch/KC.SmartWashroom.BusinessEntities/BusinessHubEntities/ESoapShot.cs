﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities.BusinessHubEntities
{
    public class ESoapShot
    {
        public string Size { get; set; }
        public decimal Quantity { get; set; }
    }
}
