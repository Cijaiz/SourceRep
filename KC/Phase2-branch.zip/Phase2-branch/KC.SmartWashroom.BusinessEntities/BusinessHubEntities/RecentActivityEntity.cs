﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities.BusinessHubEntities
{
    public class RecentActivityEntity
    {
        public RecentActivityEntity()
        {
            JRTDetail = new JRTParameters();
            EHRTDetail = new eHRTParameters();
            SoapDetail = new eSoapParameters();
        }

        public eSoapParameters SoapDetail { get; set; }

        public string DeviceId { get; set; }

        public DateTime ReceivedOn { get; set; }

        public JRTParameters JRTDetail { get; set; }

        public eHRTParameters EHRTDetail { get; set; }
    }
}
