﻿using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
using System;
using System.Collections.Generic;

namespace KC.SmartWashroom.BusinessEntities.BusinessHubEntities
{
    public class SearchCriteria
    {
        public DateTime FromDate { get; set; }

        public DateTime ToDate { get; set; }

        public List<int> BuildingList { get; set; }

        public int FloorId { get; set; }

        public int PropertyId { get; set; }

        public int CustomerId { get; set; }

        public List<int> WashroomList { get; set; }
        
        public byte WashroomGenderId { get; set; }

        public string AlertCode { get; set; }

        public byte DeviceTypeId { get; set; }

        public int PageSize { get; set; }

        public string NextRowKey { get; set; }

        public string NextPartitionKey { get; set; }

        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }

        public string FilterString { get; set; }

        public IList<AlertStatusEntity> Results { get; set; }

        public bool SearchByPartition { get; set; }

        public bool ResolutionOnly { get; set; }

        public int UserId { get; set; }

        public SearchCriteria()
        {
            this.ToDate = DateTime.UtcNow.Date;
            this.FromDate = this.ToDate.AddDays(-7);
            //this.CustomerId = 1;
            //this.PropertyId = 1;
            this.FilterString = "";
            this.Results = new List<AlertStatusEntity>();
            this.SearchByPartition = true;
            this.ResolutionOnly = true;
        }
    }
}
