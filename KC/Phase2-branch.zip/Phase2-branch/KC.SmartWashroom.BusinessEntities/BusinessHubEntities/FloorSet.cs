﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities.BusinessHubEntities
{
    public class FloorSet
    {
        public Floor FloorWithAlert { get; set; }
        public List<Floor> FloorsWithoutAlert { get; set; }

        public int CustomerId { get; set; }
        public Int32 PropertyId { get; set; }
        public string PropertyName { get; set; }
    }
}
