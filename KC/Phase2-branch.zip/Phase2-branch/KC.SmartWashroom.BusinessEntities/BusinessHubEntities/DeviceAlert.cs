﻿using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities.BusinessHubEntities
{
    public class DeviceAlertDetail
    {
        public string DeviceId { get; set; }
        public String ReceivedOn { get; set; }
        public String ResolvedOn { get; set; }

        public string AlertType { get; set; }
        public bool IsAlert { get; set; }
        public List<ProductRefillDetail> ProductRefillDetail { get; set; }

        public Int32 PropertyId { get; set; }
        public Int32 FloorId { get; set; }
        public byte DeviceTypeId { get; set; }
        public byte RoomTypeId { get; set; }

        public string DeviceType { get; set; }
        public int CustomerID { get; set; }

        public string LocalTimeZone { get; set; }
        public decimal RefillPercentage { get; set; }
    }
}
