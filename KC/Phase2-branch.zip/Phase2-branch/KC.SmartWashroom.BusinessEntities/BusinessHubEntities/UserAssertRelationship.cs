﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities.BusinessHubEntities
{
    public class UserAssertRelationship
    {
        public int UserId { get; set; }
        public int AssertId { get; set; }
    }
}
