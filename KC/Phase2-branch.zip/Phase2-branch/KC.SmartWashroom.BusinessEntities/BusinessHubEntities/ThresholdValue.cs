﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KC.SmartWashroom.BusinessEntities.BusinessHubEntities
{
    public class ThresholdValue
    {
        public string ProductRefillValue { get; set; }
        public string LowBatteryThresholdValue { get; set; }
    }
}
