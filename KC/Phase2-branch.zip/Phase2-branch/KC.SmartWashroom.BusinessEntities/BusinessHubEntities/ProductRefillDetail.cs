﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities.BusinessHubEntities
{
    public class ProductRefillDetail
    {
        public int ProductId { get; set; }
        public decimal RefillValue { get; set; }
        public string Size { get; set; }

        public string DeviceType { get; set; }

        public byte? ProductUsageBuffer { get; set; }
    }
}
