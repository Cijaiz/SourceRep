﻿using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
using System;
using System.Collections.Generic;

namespace KC.SmartWashroom.BusinessEntities.BusinessHubEntities
{
    public class DeviceResolutionDetail : DeviceDetail
    {
        public string WashroomGender { get; set; }

        public string DeviceType { get; set; }

        public List<ProductRefillDetail> ProductRefillDetail { get; set; }

        public Int32 PropertyId { get; set; }
        public Int32 FloorId { get; set; }
        public byte DeviceTypeId { get; set; }
        public byte RoomTypeId { get; set; }
    }
}
