﻿using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KC.SmartWashroom.Core.Attributes;

namespace KC.SmartWashroom.BusinessEntities
{
    public class DeviceEntity : TableEntity
    {
        
        public DeviceEntity() : base() { }
        public DeviceEntity(string partitionKey, string rowKey) : base(partitionKey, rowKey) { }

        public string DeviceParameter { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Base)]
        public string DeviceId { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Base)]
        public string GatewayId { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Base)]
        public string GatewayFirmwareVersion { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Base)]
        public int DeviceType { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Base)]
        public int CustomerId { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Base)]
        public int WashroomId { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Base)]
        public int FloorLevel { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Base)]
        public int FloorId { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Base)]
        public int BuildingId { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Base)]
        public int PropertyId { get; set; }
    }
}
