﻿using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
using System;
using System.Collections.Generic;

namespace KC.SmartWashroom.BusinessEntities
{
    public class DeviceAlertInfo
    {
        public string DeviceID { get; set; }
        public Int16 IsAlert { get; set; }
        public string AlertType { get; set; }
        public int BatteryRemaining { get; set; }

        public string MessageContent { get; set; }
        public string SharedBy { get; set; }
        public ICollection<string> SharedEmailAddresses { get; set; }
        public ICollection<string> SharedMobileNumbers { get; set; }

        public List<UserEntity> SharedUsers { get; set; }
        public string AlertReceivedOn { get; set; }
        public bool IsAlertForCleaner { get; set; }
    }
}
