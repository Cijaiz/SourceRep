﻿using System.Collections.Generic;

namespace KC.SmartWashroom.BusinessEntities
{
    public class DeviceStatus
    {
        public string DeviceName { get; set; }
        public string DeviceId { get; set; }
        public string DeviceType { get; set; }
        
        public List<DeviceAlertInfo> DeviceAlerts { get; set; }
        public decimal PercentageLevel { get; set; }
        public string DeviceSize { get; set; }
        public decimal DeviceLastDispensed { get; set; }
        public decimal DeviceRefillValue { get; set; }

        public decimal LowBatteryPercentageLevel { get; set; }
        public double CurrentBatteryVoltage { get; set; }

        public decimal MaxBatteryVoltage { get; set; }
        public decimal MinBatteryVoltage { get; set; }

        public decimal ProductThresholdValue { get; set; }


        public byte? ProductUsageBuffer { get; set; }
    }
}
