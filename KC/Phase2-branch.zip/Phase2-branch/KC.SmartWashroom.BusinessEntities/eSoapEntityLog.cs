﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KC.SmartWashroom.Core.Attributes;

namespace KC.SmartWashroom.BusinessEntities
{
    public class eSoapEntityLog :eSoapEntity
    {
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public int RefilledBatteryBeforeThreshold { get; set; }
        [DeviceEntityAttribute(Core.Enumerations.Enums.DeviceEntityType.Specific)]
        public int RefilledSoapBeforeThreshold { get; set; }
        public string CreatedOn { get; set; }


    }
}
