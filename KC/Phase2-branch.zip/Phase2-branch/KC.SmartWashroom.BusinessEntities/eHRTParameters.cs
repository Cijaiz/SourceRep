﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities
{
    public class eHRTParameters
    {
        public decimal SoftwareVersion { get; set; }
        public char Sensitivity { get; set; }
        public char DispenseLength { get; set; }

        public char DispenserDelay { get; set; }
        public char DispenseMode { get; set; }
        public int TotalDispenseCount { get; set; }

        public int DispensesWithLastBattery { get; set; }
        public int DispensesWithCurrentBattery { get; set; }
        public int NumberOfBatteryChanges { get; set; }

        public decimal VoltageLastBatteryChange { get; set; }
        public decimal CurrentBatteryVoltage { get; set; }
        public bool LowPaperAlert { get; set; }

        public bool LowBatteryAlert { get; set;}
        public bool PaperJamAlert { get; set; }
        public int PaperDispensedSinceLastRefill { get; set; }

        public bool Reset { get; set; }
        public bool PlaceHolder { get; set; }
        public int TrashEmptyPercent { get; set; }

        public bool TrashFullAlert { get; set; }
        public int UpdateInterval { get; set; }
        public int TotalRollsDispensed { get; set; }

        public int RefilledBatteryBeforeThreshold { get; set; }
        public int RefilledTowelBeforeThreshold { get; set; }
        public bool DelayEnabled { get; set; }
        public int DelayValue { get; set; }


    }
}
