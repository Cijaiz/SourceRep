﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities
{
    public class DeviceAssociation
    {
        public string DeviceId { get; set; }
        public int WashroomId { get; set; }
        public int FloorLevel { get; set; }
        public int FloorId { get; set; }
        public int BuildingId { get; set; }
        public int PropertyId { get; set; }
        public int CustomerId { get; set; }
        public bool IsDeviceActive { get; set; }

    }
}
