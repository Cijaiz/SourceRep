﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities
{
    public class StoryboardReportEntity
    {
        public int TotalVisits { get; set; }
        public int TotalAlerts { get; set; }
        public int TotalPaperUsed { get; set; }
        public int TotalTissueUsed { get; set; }
        public int TotalSoapBottlesUsed { get; set; }
        public int TotalBatteriesChanges { get; set; }
        public double AvgVisits { get; set; }
        public double AvgAlerts { get; set; }
        public double AvgPaperUsed { get; set; }
        public double AvgTissueUsed { get; set; }
        public double AvgSoapBottlesUsed { get; set; }
        public double AvgBatteriesChanges { get; set; }
    }
}
