﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities
{
    public class DeviceAlertGroupInfo
    {
        public string AlertGroup { get; set; }
        public string AlertType { get; set; }
    }
}
