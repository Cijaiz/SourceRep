﻿
namespace KC.SmartWashroom.BusinessEntities
{
    public class Gender
    {
        public byte ID { get; set; }
        public string Name { get; set; }
    }
}
