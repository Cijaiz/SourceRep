﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessEntities
{
    public class SearchDeviceDetailsEntity
    {
        public string DEVICEID { get; set; }
        public string DEVICENAME { get; set; }

        public string DEVICETYPE { get; set; }

        public int WASHROOMID { get; set; }
        public string WASHROOMNAME { get; set; }

        public int GENDERID { get; set; }
        public string GENDER { get; set; }

        public int WINGID { get; set; }
        public string WINGNAME { get; set; }

        public int FLOORID { get; set; }
        public int FLOORLEVEL { get; set; }

        public int BUILDINGID { get; set; }
        public string BUILDINGNAME { get; set; }

        public int PROPERTYID { get; set; }
        public string PROPERTYNAME { get; set; }

        public int CUSTOMERID { get; set; }
        public string CUSTOMERNAME { get; set; }
    }
}
