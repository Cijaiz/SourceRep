﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.Core.Log;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http.Filters;

namespace KC.SmartWashroom.BusinessHub.Filters
{
    public class ServiceExceptionFilterAttribute : ExceptionFilterAttribute
    {
        public override void OnException(HttpActionExecutedContext actionExecutedContext)
        {
            HttpResponseMessage outgoingResponseMessage = null;
            if (actionExecutedContext.Exception != null)
            {
                outgoingResponseMessage = new HttpResponseMessage();
                outgoingResponseMessage.StatusCode = HttpStatusCode.OK;

                //Serialize the Error Response..
                string serializedErrorResponse = SerializationHelper.JsonSerialize<ProcessResponseForGateway>
                                                        (new ProcessResponseForGateway()
                                                        {
                                                            message = actionExecutedContext.Exception.Message,
                                                            status = "failed"
                                                        });

                StringContent responseContent = new StringContent(serializedErrorResponse);
                outgoingResponseMessage.Content = responseContent;

                //Reset the Exception occured before pumping to the outgoing channel...
                Logger.Error(string.Format("Exception Occured: {0} /n Exception Details: {1}", actionExecutedContext.Exception.Message, actionExecutedContext.Exception.StackTrace));
                actionExecutedContext.Exception = null;
                actionExecutedContext.Response = outgoingResponseMessage;
            }
        }
    }
}