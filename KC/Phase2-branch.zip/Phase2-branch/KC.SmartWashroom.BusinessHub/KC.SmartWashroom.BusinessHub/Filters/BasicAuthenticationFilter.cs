﻿using KC.SmartWashroom.Core.Helper;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Controllers;

// This is been replaced with Message Handlers : Look at Core for Handling Security... Also Check at the App_Start -> Webapi.config....
namespace KC.SmartWashroom.BusinessHub.Filters
{
    public class BasicAuthenticationFilter : AuthorizeAttribute
    {
        public override void OnAuthorization(HttpActionContext actionContext)
        {
            Exception authenticationException = null;
            bool isAuthenticated = KC.SmartWashroom.Core.Security.Validator.TrafficAuthenticator.IncommingMessageValidator(out authenticationException);

            if (!isAuthenticated)
            {
                HttpResponseMessage responseMessage = null;
                string serializedErrorResponse = string.Empty;
                if (authenticationException is KeyNotFoundException)
                {
                    //Serialize the Error Response..
                    serializedErrorResponse = SerializationHelper.JsonSerialize<ProcessResponseForGateway>
                                                            (new ProcessResponseForGateway()
                                                            {
                                                                message = "Unable to Authenticate user.. No Valid Authentication Credentials Found at Server..",
                                                                status = "authenticationfailure"
                                                            });

                    responseMessage = new HttpResponseMessage(HttpStatusCode.OK)
                    {
                        Content = new StringContent(serializedErrorResponse),
                        ReasonPhrase = "Please check the Service Credentials.. Unable to authenticate the authorization token..".Replace('/', '#').Replace("\n", string.Empty).Replace("\r", string.Empty)
                    };
                }
                if (authenticationException is UnauthorizedAccessException)
                {
                    //Serialize the Error Response..
                    serializedErrorResponse = SerializationHelper.JsonSerialize<ProcessResponseForGateway>
                                                            (new ProcessResponseForGateway()
                                                            {
                                                                message = "Unable to Authenticate user.. Please check Service Credentials",
                                                                status = "authenticationfailure"
                                                            });

                    responseMessage = new HttpResponseMessage(HttpStatusCode.OK)
                    {
                        Content = new StringContent(serializedErrorResponse),
                        ReasonPhrase = "Please check the Service Credentials.. Unable to Authorize..".Replace('/', '#').Replace("\n", string.Empty).Replace("\r", string.Empty)
                    };
                }
                else if (authenticationException is ApplicationException)
                {
                    //Serialize the Error Response..
                    serializedErrorResponse = SerializationHelper.JsonSerialize<ProcessResponseForGateway>
                                                            (new ProcessResponseForGateway()
                                                            {
                                                                message = string.Format("Unable to serve the requests .. Service.. Server unavailable.. Details below /n {0}",
                                                                authenticationException.Message + authenticationException.StackTrace),
                                                                status = "generalfailure with Authorization TOken: " + KC.SmartWashroom.Core.Security.Validator.TrafficAuthenticator.IncommingAuthorizationToken
                                                            });

                    responseMessage = new HttpResponseMessage(HttpStatusCode.OK)
                    {
                        Content = new StringContent(serializedErrorResponse),
                        ReasonPhrase = "Application Error Occured...",
                    };
                }
                else if (authenticationException is Exception)
                {
                    //Serialize the Error Response..
                    serializedErrorResponse = SerializationHelper.JsonSerialize<ProcessResponseForGateway>
                                                            (new ProcessResponseForGateway()
                                                            {
                                                                message = string.Format("Unable to serve the requests .. Service.. Server unavailable.. Details below /n {0}",
                                                                authenticationException.Message.Replace('/', '#') + authenticationException.StackTrace.Replace('/', '#')),
                                                                status = "generalfailure In Authentication Token: " + KC.SmartWashroom.Core.Security.Validator.TrafficAuthenticator.IncommingAuthorizationToken
                                                            });

                    responseMessage = new HttpResponseMessage(HttpStatusCode.OK)
                    {
                        Content = new StringContent(serializedErrorResponse),
                        ReasonPhrase = (authenticationException.Message).Replace('/', '#').Replace("\n", string.Empty).Replace("\r", string.Empty),
                    };
                }
                else
                {
                    //Serialize the Error Response..
                    serializedErrorResponse = SerializationHelper.JsonSerialize<ProcessResponseForGateway>
                                                            (new ProcessResponseForGateway()
                                                            {
                                                                message = "Authentication Failure..",
                                                                status = "Authentication Token sent: " + KC.SmartWashroom.Core.Security.Validator.TrafficAuthenticator.IncommingAuthorizationToken
                                                            });

                    responseMessage = new HttpResponseMessage(HttpStatusCode.OK)
                    {
                        Content = new StringContent(serializedErrorResponse),
                        ReasonPhrase = "Authentication Failure..",
                    };
                }
                //base.OnAuthorization(actionContext);
                actionContext.Response = responseMessage;
            }

        }
    }
}