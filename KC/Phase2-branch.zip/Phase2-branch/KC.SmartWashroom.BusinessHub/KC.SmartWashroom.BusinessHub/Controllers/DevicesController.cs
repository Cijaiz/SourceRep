﻿using KC.SmartWashroom.Business;
using KC.SmartWashroom.Business.Simulator;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers;
using System.Collections.Generic;
using System.Web.Http;

namespace KC.SmartWashroom.BusinessHub.Controllers
{
    public class DevicesController : ControllerBase
    {
        //api/device/Post/5
        //[HttpPost]
        //public ProcessResponseForGateway Post(DeviceDetailParameter deviceDetailParameter)
        //{
        //    DeviceBusinessManager deviceBusinessManager = new DeviceBusinessManager();

        //    ProcessResponseForGateway processResponse = new ProcessResponseForGateway { status = "failed", message = "error" };

        //    if (deviceBusinessManager.ComposeDeviceLog(deviceDetailParameter.deviceDetail))
        //        processResponse = deviceBusinessManager.SaveDeviceLog();

        //    return processResponse;
        //}

        [HttpPost]
        public ProcessResponseForGateway PostAlertMessage(DeviceAlertInfo deviceAlertInfo)
        {
            DeviceBusinessManager deviceBusinessManager = new DeviceBusinessManager();
            ProcessResponseForGateway processResponse = new ProcessResponseForGateway { status = "failed", message = "error" };

            processResponse = deviceBusinessManager.SaveDeviceAlert(deviceAlertInfo);
            return processResponse;
        }

        [HttpPost]
        public ProcessResponse StartSimulation(object obj)
        {
            GatewayFeedManager gfMgr = new GatewayFeedManager();
            gfMgr.GatewayFeeder();
            ProcessResponse Response = new ProcessResponse();
            return Response;
        }

        public string GetDeviceAlertCode(string alertName, string deviceType)
        {
            DeviceBusinessManager deviceBusinessManager = new DeviceBusinessManager();
            return deviceBusinessManager.GetDeviceAlertCode(alertName, deviceType);
        }

        public bool GetIfAlertExist(string deviceID, string alertcode)
        {
            DeviceBusinessManager deviceBusinessManager = new DeviceBusinessManager();
            return deviceBusinessManager.IfAlertExists(deviceID, alertcode);
        }

        public DeviceAssociation GetDeviceAssociation(string deviceId)
        {
            DeviceBusinessManager deviceBusinessManager = new DeviceBusinessManager();
            return deviceBusinessManager.GetDeviceAssociation(deviceId);
        }

        public DeviceInformation GetDeviceAlertStatus(string deviceID)
        {
            DeviceBusinessManager deviceBusinessManager = new DeviceBusinessManager();
            return deviceBusinessManager.GetDeviceAlertStatus(deviceID);
        }

        [HttpPost]
        public void TraceDeviceTraffic(string deviceId, string section)
        {
            DeviceBusinessManager deviceBusinessManager = new DeviceBusinessManager();
            ProcessResponseForGateway processResponse = new ProcessResponseForGateway { status = "failed", message = "error" };
        }

        public ProcessResponse ClearAllDeviceOverrides(ReturnParameterDataTransfer dataTransfer)
        {
            Guard.IsNotNull(dataTransfer, "dataTransfers");

            DeviceBusinessManager manager = new DeviceBusinessManager();
            return manager.ClearAllDeviceOverrides(dataTransfer.ClearAllDeviceParameterIds, dataTransfer.customerId);
        }
    }
}
