﻿using KC.SmartWashroom.Business;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.BusinessHub.Filters;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.Helper;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace KC.SmartWashroom.BusinessHub.Controllers
{
    [BasicAuthenticationFilter]
    public class FloorController : ApiController
    {
        FloorBusinessManager manager = new FloorBusinessManager();
        WashroomBusinessManager washroomManager = new WashroomBusinessManager();
        [HttpPost]
        public ProcessResponse<Floor> CreateFloorRange(List<Floor> floors)
        {
            return manager.CreateFloorRange(floors);
        }

        [HttpGet]
        public Floor GetFloorDetails(int floorId, int userId)
        {
            return manager.GetFloorDetails(floorId, userId);
        }

        [HttpPost]
        public ProcessResponse<Floor> Delete(Floor floor)
        {
            return manager.Delete(floor.ID, floor.LastUpdatedBy != null ? Convert.ToInt32(floor.LastUpdatedBy) : 0);
        }

        [HttpPost]
        public ProcessResponse<Floor> Update(Floor floor)
        {
            return manager.Update(floor);
        }

        public Names GetNames(int buildingId)
        {
            return manager.GetNames(buildingId);
        }

        [HttpGet]
        public Floor GetFloorAlerts(int floorId, int buildingId, int userId)
        {
            Floor floor = new Floor();
            floor = manager.GetFloorAlerts(floorId, buildingId, 0, 0, userId);
            var genders = washroomManager.GetWashroomsByFloorIdGroupedByGender(floorId).GroupBy(x => new { x.Gender, x.GenderId });
            floor.WashroomSets = new List<KeyValuePair<KeyValuePair<string, Int32>, List<DeviceAlert>>>();
            if (floor.Alerts.Count > 0)
            {
                //List<DeviceAlert> MaxOfAlerts = new List<DeviceAlert>();
                //var AllDevices = floor.Alerts.GroupBy(x => new { x.DeviceId, x.AlertType }).ToList();

                //foreach (var item in AllDevices)
                //{
                //    var MaxOfalert = floor.Alerts.FindAll(x => x.DeviceId.Equals(item.Key.DeviceId) && x.AlertType.Equals(item.Key.AlertType)).MaxObject(x => x.DateTime);
                //    var KeyPair = GetDeviceAlertType(MaxOfalert.AlertType);
                //    MaxOfalert.AlertTypeName = KeyPair.Value;
                //    MaxOfAlerts.Add(MaxOfalert);
                //} 
                //floor.Alerts = MaxOfAlerts;
                foreach (var alert in floor.Alerts)
                {
                    var KeyPair = CommonHelper.GetDeviceAlertType(alert.AlertType);
                    alert.AlertTypeName = KeyPair.Value;
                    //alert.DeviceName = KeyPair.Key;
                }
            }


            foreach (var item in genders.Select(x => x).ToList())
            {
                KeyValuePair<string, Int32> genderPair = new KeyValuePair<string, Int32>(item.Key.Gender, item.Key.GenderId);
                KeyValuePair<KeyValuePair<string, Int32>, List<DeviceAlert>> floorPair = new KeyValuePair<KeyValuePair<string, Int32>, List<DeviceAlert>>(genderPair, floor.Alerts.FindAll(x => x.Gender.Equals(item.Key.Gender.ToString())));
                floor.WashroomSets.Add(floorPair);
            }

            return floor;
        }



        [HttpGet]
        public Floor GetFloorAlertsbyGenderId(int floorId, int buildingId, byte genderId, int userId)
        {
            Floor floor = new Floor();
            floor = manager.GetFloorAlerts(floorId, buildingId, genderId, 0, 0);
            var genders = washroomManager.GetWashroomsByFloorIdGroupedByGender(floorId).Where(x => x.GenderId.Equals(genderId)).GroupBy(x => new { x.Gender, x.GenderId });
            if (floor.Alerts.Count > 0)
            {
                //List<DeviceAlert> MaxOfAlerts = new List<DeviceAlert>();
                //var AllDevices = floor.Alerts.GroupBy(x => new { x.DeviceId, x.AlertType }).ToList();

                //foreach (var item in AllDevices)
                //{
                //    var MaxOfalert = floor.Alerts.FindAll(x => x.DeviceId.Equals(item.Key.DeviceId) && x.AlertType.Equals(item.Key.AlertType)).MaxObject(x => x.DateTime);
                //    var KeyPair = GetDeviceAlertType(MaxOfalert.AlertType);
                //    MaxOfalert.AlertTypeName = KeyPair.Value;
                //    MaxOfAlerts.Add(MaxOfalert);
                //} 
                //floor.Alerts = MaxOfAlerts;
                foreach (var alert in floor.Alerts)
                {
                    var KeyPair = CommonHelper.GetDeviceAlertType(alert.AlertType);
                    alert.AlertTypeName = KeyPair.Value;
                    //alert.DeviceName = KeyPair.Key;
                }
            }
            floor.WashroomSets = new List<KeyValuePair<KeyValuePair<string, Int32>, List<DeviceAlert>>>();
            foreach (var item in genders.Select(x => x).ToList())
            {
                KeyValuePair<string, Int32> genderPair = new KeyValuePair<string, Int32>(item.Key.Gender, item.Key.GenderId);
                KeyValuePair<KeyValuePair<string, Int32>, List<DeviceAlert>> floorPair = new KeyValuePair<KeyValuePair<string, Int32>, List<DeviceAlert>>(genderPair, floor.Alerts.FindAll(x => x.Gender.Equals(item.Key.Gender.ToString())));
                floor.WashroomSets.Add(floorPair);
            }


            return floor;
        }

        [HttpGet]
        public Floor GetFloorAlertsWashroomDetailsbyGenderId(int floorId, int buildingId, byte genderId)
        {
            Floor floor = new Floor();
            floor = manager.GetFloorAlerts(floorId, buildingId, genderId, 0, 0);
            var floorWashrooms = floor.Alerts.GroupBy(x => new { x.WashroomId }).ToList();
            if (floor.Alerts.Count > 0)
            {
                //List<DeviceAlert> MaxOfAlerts = new List<DeviceAlert>();
                //var AllDevices = floor.Alerts.GroupBy(x => new { x.DeviceId, x.AlertType }).ToList();

                //foreach (var item in AllDevices)
                //{
                //    var MaxOfalert = floor.Alerts.FindAll(x => x.DeviceId.Equals(item.Key.DeviceId) && x.AlertType.Equals(item.Key.AlertType)).MaxObject(x => x.DateTime);
                //    var KeyPair = GetDeviceAlertType(MaxOfalert.AlertType);
                //    MaxOfalert.AlertTypeName = KeyPair.Value;
                //    MaxOfAlerts.Add(MaxOfalert);
                //} 
                //floor.Alerts = MaxOfAlerts;
                foreach (var alert in floor.Alerts)
                {
                    var KeyPair = CommonHelper.GetDeviceAlertType(alert.AlertType);
                    alert.AlertTypeName = KeyPair.Value;
                    //alert.DeviceName = KeyPair.Key;
                }
            }
            if (floorWashrooms != null)
            {
                if (floorWashrooms.Count > 0)
                {
                    var washrooms = washroomManager.GetWashroomsByFloorIdWithoutLog(floorId).Where(x => x.ID.Equals(floorWashrooms[0].Key.WashroomId)).GroupBy(x => new { x.ID, x.Name });
                    floor.WashroomSets = new List<KeyValuePair<KeyValuePair<string, Int32>, List<DeviceAlert>>>();
                    foreach (var item in washrooms.Select(x => x).ToList())
                    {
                        KeyValuePair<string, Int32> washroomPair = new KeyValuePair<string, Int32>(item.Key.Name, item.Key.ID);
                        KeyValuePair<KeyValuePair<string, Int32>, List<DeviceAlert>> floorPair = new KeyValuePair<KeyValuePair<string, Int32>, List<DeviceAlert>>(washroomPair, floor.Alerts.FindAll(x => x.WashroomId.Equals(item.Key.ID)));
                        floor.WashroomSets.Add(floorPair);
                    }


                }
                else
                {
                    var washrooms = washroomManager.GetWashroomsByFloorIdWithoutLog(floorId).Where(x => x.GenderId.Equals(genderId)).GroupBy(x => new { x.ID, x.Name });
                    floor.WashroomSets = new List<KeyValuePair<KeyValuePair<string, Int32>, List<DeviceAlert>>>();
                    foreach (var item in washrooms.Select(x => x).ToList())
                    {
                        KeyValuePair<string, Int32> washroomPair = new KeyValuePair<string, Int32>(item.Key.Name, item.Key.ID);
                        KeyValuePair<KeyValuePair<string, Int32>, List<DeviceAlert>> floorPair = new KeyValuePair<KeyValuePair<string, Int32>, List<DeviceAlert>>(washroomPair, floor.Alerts.FindAll(x => x.WashroomId.Equals(item.Key.ID)));
                        floor.WashroomSets.Add(floorPair);
                    }
                }
            }
            return floor;
        }

        [HttpGet]
        public Floor GetFloorAlertsbyWashroomId(int floorId, int buildingId, int washroomID)
        {
            Floor floor = new Floor();
            floor = manager.GetFloorAlerts(floorId, buildingId, 0, washroomID, 0);
            var washrooms = washroomManager.GetWashroomsByFloorIdWithoutLog(floorId).Where(x => x.ID.Equals(washroomID)).GroupBy(x => new { x.ID, x.Name });
            floor.WashroomSets = new List<KeyValuePair<KeyValuePair<string, Int32>, List<DeviceAlert>>>();
            if (floor.Alerts.Count > 0)
            {
                //List<DeviceAlert> MaxOfAlerts = new List<DeviceAlert>();
                //var AllDevices = floor.Alerts.GroupBy(x => new { x.DeviceId, x.AlertType }).ToList();

                //foreach (var item in AllDevices)
                //{
                //    var MaxOfalert = floor.Alerts.FindAll(x => x.DeviceId.Equals(item.Key.DeviceId) && x.AlertType.Equals(item.Key.AlertType)).MaxObject(x => x.DateTime);
                //    var KeyPair = GetDeviceAlertType(MaxOfalert.AlertType);
                //    MaxOfalert.AlertTypeName = KeyPair.Value;
                //    MaxOfAlerts.Add(MaxOfalert);
                //} 
                //floor.Alerts = MaxOfAlerts;
                foreach (var alert in floor.Alerts)
                {
                    var KeyPair = CommonHelper.GetDeviceAlertType(alert.AlertType);
                    alert.AlertTypeName = KeyPair.Value;
                    //alert.DeviceName = KeyPair.Key;
                }

            }
            foreach (var item in washrooms.Select(x => x).ToList())
            {
                KeyValuePair<string, Int32> washroomPair = new KeyValuePair<string, Int32>(item.Key.Name, item.Key.ID);
                KeyValuePair<KeyValuePair<string, Int32>, List<DeviceAlert>> floorPair = new KeyValuePair<KeyValuePair<string, Int32>, List<DeviceAlert>>(washroomPair, floor.Alerts.FindAll(x => x.WashroomId.Equals(item.Key.ID)));
                floor.WashroomSets.Add(floorPair);
            }



            return floor;
        }

        
    }

}
