﻿using KC.SmartWashroom.Business;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessHub.Filters;
using KC.SmartWashroom.BusinessHub.Models;
using KC.SmartWashroom.Core.Log;
using KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace KC.SmartWashroom.BusinessHub.Controllers
{
    public class HubTesterController : Controller
    {
        DeviceTenantManager deviceTenantManager = new DeviceTenantManager();
        //
        // GET: /HubTester/
        public ActionResult Index()
        {
            TenantsBusinessManager manager = new TenantsBusinessManager();
            //Logger.Debug("Index Called.. with Tenants Business Manager Load..");

            bool resposne = false;
            try
            {
                manager.ManualInjection<UserWorker>();
                resposne = manager.GetUserDetails("1");
                ViewBag.Response = resposne;
            }
            catch (Exception ex)
            {
                ViewBag.Response = resposne;
                ViewBag.Error = ex.Message;
            }
            //Logger.Debug(string.Format("GetUserDetails Resposne: {0}", resposne));

            return View();
        }

        private List<BusinessEntities.SearchDeviceDetailsEntity> GetDeviceDetails(string DeviceId)
        {
            List<BusinessEntities.SearchDeviceDetailsEntity> device = new List<BusinessEntities.SearchDeviceDetailsEntity>();
            device = deviceTenantManager.GetDeviceDetails(DeviceId);
            if (device.Equals(null))
                throw new Exception(deviceTenantManager.ErrorDetail);
            return device;
        }

        public ActionResult DeviceDetail(DeviceDetailViewModel id)
        {
            //bool resposne = false;
            ViewBag.Response = true;
            if (id.DeviceId != null)
            {
                try
                {

                    DeviceDetailViewModel deviceDetailsListModel = new DeviceDetailViewModel();
                    deviceDetailsListModel.DeviceDetailsList = new List<SearchDeviceDetailsEntity>();
                    string deviceId = id.DeviceId;
                    List<BusinessEntities.SearchDeviceDetailsEntity> deviceDetails = GetDeviceDetails(deviceId);

                    foreach (SearchDeviceDetailsEntity item in deviceDetails)
                    {
                        deviceDetailsListModel.DeviceDetailsList.Add(item);
                    }
                    //ViewBag.Response = true;
                    return View("Index", deviceDetailsListModel);

                }
                catch (Exception ex)
                {
                    //ViewBag.Response = true;
                    ViewBag.Error = ex.Message;
                    return View("Index");
                }
            }
            //ViewBag.Response = true;
            return View("Index");

        }
    }
}