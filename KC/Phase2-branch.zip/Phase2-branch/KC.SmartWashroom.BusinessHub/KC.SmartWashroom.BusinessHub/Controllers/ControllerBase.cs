﻿using KC.SmartWashroom.BusinessEntities;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace KC.SmartWashroom.BusinessHub.Controllers
{
    public class ControllerBase : ApiController
    {
       
    }
}