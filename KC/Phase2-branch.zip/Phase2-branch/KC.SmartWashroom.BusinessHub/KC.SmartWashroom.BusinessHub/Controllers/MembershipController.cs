﻿using KC.SmartWashroom.Business;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.Core.Security.Authorization.Structure;
using System.Collections.Generic;
using System.Web.Http;

namespace KC.SmartWashroom.BusinessHub.Controllers
{
    public class MembershipController : ApiController
    {
        const string INVALID_USER_CREDENTIALS_PASSWORDRESET = "INVALID_USER_CREDENTIALS_PASSWORDRESET";
        const string PASSWORD_RESET_SUCCESS = "PASSWORD_RESET_SUCCESS";
        const string PASSWORD_RESET_LINK_SENT = "PASSWORD_RESET_LINK_SENT";
        const string INVALID_USER_CREDENTIALS = "INVALID_USER_CREDENTIALS";
        const string INVALID_CUSTOMER = "INVALID_CUSTOMER";
        [HttpGet]
        public ProcessResponse<UserContext> LoginUser(string userName, string password)
        {
            ProcessResponse<UserContext> response = new ProcessResponse<UserContext>();
            MembershipBusinessManager manager = new MembershipBusinessManager();

            response = manager.LoginUser(userName, password);

            //On Successfull Logins retrive the user asserts..
            if (response.Status.Equals(ResponseStatus.Success))
                RetriveUserAsserts(response, manager);
            return response;
        }

        private static void RetriveUserAsserts(ProcessResponse<UserContext> response, MembershipBusinessManager manager)
        {
            UserAssetEntity asserts = manager.GetUserAssets(response.Object.UserId);
            response.Object.PropertyAccessAsserts = new List<int>();
            response.Object.BuildingAccessAsserts = new List<int>();

            //Add buildings to the Feature Permissions..
            foreach (var building in asserts.BuildingIDs)
                response.Object.BuildingAccessAsserts.Add(building);

            //Add Properties to the Feature permissions..
            foreach (var property in asserts.PropertyIDs)
                response.Object.PropertyAccessAsserts.Add(property);

            response.Status = ResponseStatus.Success;
        }

        [HttpGet]
        public ProcessResponse<bool> ResetUserCredentials(string userName, string oldPassword, string newPassword)
        {
            string saltedPassword = string.Empty;
            ProcessResponse<bool> response = new ProcessResponse<bool>() { Status = ResponseStatus.Success, Message = PASSWORD_RESET_SUCCESS };

            MembershipBusinessManager manager = new MembershipBusinessManager();

            //REset password only when COdes matches..
            if (string.Compare(oldPassword, CommonConstants.PASSWORD_RESET_CODE) == 0)
                if (manager.ValidateUserName(userName, ref saltedPassword))
                {
                    if (this.GenerateUserCredentials(userName, newPassword))
                        return response;
                }
                else
                {
                    response.Message = INVALID_USER_CREDENTIALS;
                    response.Status = ResponseStatus.Error;
                    return response;
                }

            if (!manager.ResetUserCredentials(userName, oldPassword, newPassword))
            {
                response.Status = ResponseStatus.Error;
                response.Message = INVALID_USER_CREDENTIALS_PASSWORDRESET;
            }
            return response;
        }

        [HttpGet]
        public bool GenerateUserCredentials(string userName, string password)
        {
            MembershipBusinessManager manager = new MembershipBusinessManager();
            return manager.GenerateUserCredentials(userName, password);
        }

        [HttpGet]
        public ProcessResponse<UserAccountInformation> ForgotPassword(string userName)
        {
            string saltedPassword = string.Empty;
            ProcessResponse<UserAccountInformation> response = new ProcessResponse<UserAccountInformation>() { Status = ResponseStatus.Success, Message = PASSWORD_RESET_LINK_SENT };

            MembershipBusinessManager manager = new MembershipBusinessManager();
            bool isUserNameValid = manager.ValidateUserName(userName, ref saltedPassword);
            bool isValidCustomer = manager.ValidateCustomer(userName);

            if (!isUserNameValid)
            {
                response.Status = ResponseStatus.Failed;
                response.Message = INVALID_USER_CREDENTIALS;
            }
            else if (!isValidCustomer)
            {
                 response.Status = ResponseStatus.Failed;
                 response.Message = INVALID_USER_CREDENTIALS;
            }
            else
            {
                TenantsBusinessManager userManager = new TenantsBusinessManager();
                User User = new User();

                string mobile = userManager.GetUserContactInfo(userName);
                User.Mobile = mobile;
                User.Password = saltedPassword;
                User.Email = userName;
                userManager.SavePasswordToQueue(User, false);
                response.Object = new UserAccountInformation() { Password = saltedPassword };
            }
            return response;
        }

        [HttpGet]
        public ProcessResponse<UserAccountInformation> GetUserAccountInformation(string userName)
        {
            string saltedPassword = string.Empty;
            ProcessResponse<UserAccountInformation> response = new ProcessResponse<UserAccountInformation>() { Status = ResponseStatus.Success, Message = PASSWORD_RESET_LINK_SENT };

            MembershipBusinessManager manager = new MembershipBusinessManager();
            bool isUserNameValid = manager.ValidateUserName(userName, ref saltedPassword);
            if (!isUserNameValid)
            {
                response.Status = ResponseStatus.Failed;
                response.Message = INVALID_USER_CREDENTIALS;
            }
            else
                response.Object = new UserAccountInformation() { Password = saltedPassword };

            return response;
        }

        [HttpGet]
        public List<RolePermission> GetUserPermissions(int userId)
        {
            MembershipBusinessManager manager = new MembershipBusinessManager();
            return manager.GetUserPermissions(userId);
        }

        [HttpPost]
        public bool CreateFeature(RolePermission feature)
        {
            MembershipBusinessManager authenticationManager = new MembershipBusinessManager();
            return authenticationManager.CreateFeatureForUserAuthorization(feature);
        }

        [HttpGet]
        public List<RolePermission> GetAuthorizationFeatureList()
        {
            MembershipBusinessManager authenticationManager = new MembershipBusinessManager();
            return authenticationManager.GetAuthorizationFeatures();
        }

        [HttpGet]
        public ProcessResponse<UserContext> RefreshUserAssets(int UserId)
        {
            ProcessResponse<UserContext> response = new ProcessResponse<UserContext>();
            MembershipBusinessManager manager = new MembershipBusinessManager();

            response.Object = new UserContext();
            response.Object.UserId = UserId;

            RetriveUserAsserts(response, manager);
            return response;
        }
    }
}