﻿using KC.SmartWashroom.Business;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
using KC.SmartWashroom.BusinessEntities.BusinessHubEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.BusinessHub.Filters;
using KC.SmartWashroom.Core.Helper;
using System;
using System.Collections.Generic;
using System.Web.Http;

namespace KC.SmartWashroom.BusinessHub.Controllers
{
    [BasicAuthenticationFilter]
    public class TenantsController : ApiController
    {
        [HttpGet]
        public int GetValue(int id)
        {
            return id + 1;
        }

        [HttpGet]
        public int GetValuesCount(int userId, int userCount)
        {
            return userId + userCount;
        }

        [HttpPost]
        public ProcessResponse UpdateFeedStatus(UserFeedStatus userFeedStatus)
        {
            //Do processing from DAL Layer and send response.
            ProcessResponse response = new ProcessResponse() { Message = "From Process", Status = ResponseStatus.Error };
            return response;
        }

        [HttpGet]
        public DeviceDetail GetUsersDetails(string deviceId)
        {
            Guard.IsNotBlank(deviceId, "Device Id");
            TenantsBusinessManager manager = new TenantsBusinessManager();

            manager.GetUserDetails(deviceId);
            return manager.DeviceLog;
        }

        [HttpGet]
        public DeviceDetail GetErrorAdminDetails()
        {

            TenantsBusinessManager manager = new TenantsBusinessManager();
            manager.GetErrorAdminDetails();
            return manager.DeviceLog;
        }

        [HttpPost]
        public ProcessResponse<DeviceAlert> PostDeviceAlert(DeviceAlert deviceAlert)
        {
            TenantsBusinessManager manager = new TenantsBusinessManager();
            ProcessResponse<DeviceAlert> processResponse = new ProcessResponse<DeviceAlert> { Status = ResponseStatus.Error, Message = "error" };

            if (deviceAlert.IsAlert)
            {
                //Check for Pre-exists Alerts..
                DeviceBusinessManager deviceManager = new DeviceBusinessManager();

                //Pull the Customer ID for the specific Device..
                DeviceAssociation deviceAssociation = deviceManager.GetDeviceAssociation(deviceAlert.DeviceId);
                //Now check for the preexist alert..
                bool isAlertExist = deviceManager.CheckAlertExist(deviceAssociation.CustomerId, deviceAlert.DeviceId, deviceAlert.AlertType);

                if (isAlertExist)
                {
                    processResponse.Message = "Alert Already Exists..";
                    processResponse.Status = ResponseStatus.Failed;
                    return processResponse;
                }
            }

            //If Parameter is a string we need this to be included.

            //DeviceAlert deviceAlert = deviceBusinessManager.ComposeDeviceAlertForEntity(deviceAlertParamater);
            processResponse = manager.SaveDeviceAlert(deviceAlert);

            return processResponse;
        }

        [HttpPost]
        public ProcessResponse<DeviceAlert> RemoveDeviceAlert(DeviceAlert deviceAlert)
        {
            TenantsBusinessManager manager = new TenantsBusinessManager();
            ProcessResponse<DeviceAlert> processResponse = new ProcessResponse<DeviceAlert> { Status = ResponseStatus.Failed, Message = "error" };

            //If Parameter is a string we need this to be included.

            //DeviceAlert deviceAlert = deviceBusinessManager.ComposeDeviceAlertForEntity(deviceAlertParamater);
            processResponse = manager.RemoveDeviceAlert(deviceAlert);

            return processResponse;
        }

        [HttpGet]
        public List<Role> GetRoles()
        {
            TenantsBusinessManager manager = new TenantsBusinessManager();
            return manager.GetRoles();
        }

        [HttpGet]
        public List<RolePermission> GetRolePermissions(short roleID)
        {
            TenantsBusinessManager manager = new TenantsBusinessManager();
            return manager.GetRolePermissions(roleID);
        }

        [HttpGet]
        public List<Property> GetProperties(string customerId)
        {
            TenantsBusinessManager manager = new TenantsBusinessManager();
            return manager.GetProperties(Convert.ToInt32(customerId));
        }

        [HttpGet]
        public List<Building> GetBuildings(string customerId)
        {
            TenantsBusinessManager manager = new TenantsBusinessManager();
            return manager.GetBuildings(Convert.ToInt32(customerId));
        }

        [HttpGet]
        public List<UserEntity> GetContactsForCustomer(int customerId,int buildingId)
        {
            TenantsBusinessManager manager = new TenantsBusinessManager();
            return manager.GetContactsForCustomer(customerId,buildingId);
        }

        [HttpGet]
        public User GetUserDetails(string userId, int performedBy)
        {
            TenantsBusinessManager manager = new TenantsBusinessManager();

            return manager.GetUserDetails(Convert.ToInt32(userId), performedBy);
        }

        [HttpPost]
        public ProcessResponse<User> CreateUser(User User)
        {
            TenantsBusinessManager manager = new TenantsBusinessManager();
            return manager.CreateUser(User);
        }

        [HttpPost]
        public ProcessResponse<User> UpdateUser(User User)
        {
            TenantsBusinessManager manager = new TenantsBusinessManager();
            return manager.UpdateUser(User);
        }

        [HttpPost]
        public ProcessResponse<User> DeleteUser(User User)
        {
            TenantsBusinessManager manager = new TenantsBusinessManager();
            return manager.DeleteUser(User);
        }
    }
}
