﻿using KC.SmartWashroom.Business;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.Enumerations;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.Core.Log;
using System;
using System.Collections.Generic;
using System.Web.Http;

namespace KC.SmartWashroom.BusinessHub.Controllers
{
    public class CustomerController : ApiController
    {
        CustomerBusinessManager manager = new CustomerBusinessManager();

        public ProcessResponse SaveCustomer(CustomerDetail customerDetail)
        {
            Guard.IsNotNull(customerDetail, "Customer");
            ProcessResponse response = new ProcessResponse { Status = ResponseStatus.Error, Message = AlertEngineConstants.MESSAGE_FAIL };
            response = manager.SaveCustomer(customerDetail);
            return response;
        }

        public List<CustomerDetail> GetAllCustomers(int userId)
        {
            List<CustomerDetail> customers = new List<CustomerDetail>();
            customers = manager.GetAllCustomers(userId);
            if (customers.Equals(null))
                throw new Exception(manager.ErrorDetail);
            return customers;
        }

        public CustomerDetail GetCustomer(int CustomerId, int UserId)
        {
            CustomerDetail customer = new CustomerDetail();
            customer = manager.GetCustomer(CustomerId, UserId);
            if (customer.Equals(null))
                throw new Exception(manager.ErrorDetail);
            return customer;
        }

        public string GetCustomerName(int propertyId)
        {
            return manager.GetCustomerName(propertyId);
        }

        public ProcessResponse UpdateCustomer(CustomerDetail customerDetail)
        {
            Guard.IsNotNull(customerDetail, "Customer");
            ProcessResponse response = new ProcessResponse { Status = ResponseStatus.Error, Message = AlertEngineConstants.MESSAGE_FAIL };
            response = manager.UpdateCustomer(customerDetail);
            return response;
        }

        public ProcessResponse RemoveCustomer(CustomerDetail Customer)
        {
            ProcessResponse response = new ProcessResponse { Status = ResponseStatus.Error, Message = AlertEngineConstants.MESSAGE_FAIL };
            response = manager.DeleteCustomer(Customer.CustomerId, Customer.UserId);
            return response;
        }

        public List<Countries> GetAllCountries()
        {
            List<Countries> countries = new List<Countries>();
            countries = manager.GetAllCountries();
            if (countries.Equals(null))
                throw new Exception(manager.ErrorDetail);
            return countries;
        }

        public List<ReturnParameterResponse> GetDeviceParameters(int customerId)
        {
            Dictionary<DeviceTypes, List<BusinessEntities.ReturnValueParameter>> parameters = new Dictionary<DeviceTypes, List<BusinessEntities.ReturnValueParameter>>();
            parameters = manager.GetDeviceParameters(customerId);

            List<ReturnParameterResponse> response = new List<ReturnParameterResponse>();
            foreach (var item in parameters)
            {
                ReturnParameterResponse parameterReponse = new ReturnParameterResponse();
                parameterReponse.deviceTypes = item.Key;
                parameterReponse.returnValueParameters = item.Value;
                response.Add(parameterReponse);
            }

            if (parameters.Equals(null))
                throw new Exception(manager.ErrorDetail);
            return response;
        }

        public ProcessResponse<List<ReturnValueParameter>> UpsetReturnParameters(ReturnParameterDataTransfer dataTransfer)
        {
            Guard.IsNotNull(dataTransfer, "dataTransfer");
            ProcessResponse<List<ReturnValueParameter>> response = new ProcessResponse<List<ReturnValueParameter>> { Status = ResponseStatus.Error, Message = AlertEngineConstants.MESSAGE_FAIL };
            response = manager.UpsetReturnParameters(dataTransfer.ReturnValueParameters, dataTransfer.customerId);
            return response;
        }

        public ProcessResponse RemoveReturnParameterValues(ReturnParameterDataTransfer dataTransfer)
        {
            Guard.IsNotNull(dataTransfer.ParamterValueIds, "paramterValueIds");
            ProcessResponse response = new ProcessResponse();
            response = manager.DeleteDeviceParameterValue(dataTransfer.ParamterValueIds, dataTransfer.customerId);
            return response;
        }

    }
}