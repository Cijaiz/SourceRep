﻿using KC.SmartWashroom.Business;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.BusinessHub.Filters;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace KC.SmartWashroom.BusinessHub.Controllers
{
    [BasicAuthenticationFilter]
    public class AzureSchedulerAuditController : ApiController
    {
        AzureSchedulerAuditManager manager = new AzureSchedulerAuditManager();

        [HttpPost]
        public ProcessResponse InsertJob(AzureSchedulerLog Scheduler)
        {
            Guard.IsNotNull(Scheduler, "Scheduler");            
            ProcessResponse response = new ProcessResponse { Status = ResponseStatus.Error, Message = AlertEngineConstants.MESSAGE_FAIL };
            response = manager.InsertJob(Scheduler);
            return response;
        }

        [HttpPost]
        public AzureSchedulerLog GetJob(Property property)
        {
            Guard.IsNotNull(property, "property");
            return manager.GetJob(property.ID);
        }

        [HttpPost]
        public ProcessResponse DeleteJob(Property property)
        {
            Guard.IsNotNull(property, "property");
            ProcessResponse response = new ProcessResponse { Status = ResponseStatus.Error, Message = AlertEngineConstants.MESSAGE_FAIL };
            response = manager.DeleteJob(property.ID);
            return response;
        }
    }
}
