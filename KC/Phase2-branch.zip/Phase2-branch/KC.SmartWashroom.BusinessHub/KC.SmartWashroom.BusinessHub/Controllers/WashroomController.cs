﻿using KC.SmartWashroom.Business;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.BusinessHubEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.BusinessHub.Filters;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.Helper;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace KC.SmartWashroom.BusinessHub.Controllers
{
    [BasicAuthenticationFilter]
    public class WashroomController : ApiController
    {
        WashroomBusinessManager manager = new WashroomBusinessManager();

        [HttpGet]
        public List<Gender> GetGenders()
        {
            return manager.GetGenders();
        }

        [HttpGet]
        public List<Wing> GetWings()
        {
            return manager.GetWings();
        }

        [HttpGet]
        public Washroom GetWashroomDetails(int washroomId, int userId)
        {
            return manager.GetWashroomDetails(washroomId, userId);
        }

        [HttpPost]
        public ProcessResponse<Washroom> Create(Washroom washroom)
        {
            return manager.Create(washroom);
        }

        [HttpPost]
        public ProcessResponse<Washroom> Update(Washroom washroom)
        {
            return manager.Update(washroom);
        }

        [HttpPost]
        public ProcessResponse<Washroom> Delete(Washroom washroom)
        {
            return manager.Delete(washroom);
        }

        [HttpGet]
        public List<Washroom> GetWashroomsByFloorId(string propertyName, string buildingName, string floorLevel, string washroomName, int floorId, int userId)
        {
            return manager.GetWashroomsByFloorId(propertyName, buildingName, floorLevel, washroomName, floorId, userId);
        }

        [HttpGet]
        public List<KeyValuePair<string, List<DeviceStatus>>> GetDeviceStatusInWashrooms(int floorId, int washroomId)
        {
            List<KeyValuePair<string, List<DeviceStatus>>> deviceStatusResponse = new List<KeyValuePair<string, List<DeviceStatus>>>();
            List<DeviceStatus> deviceStatuses = new List<DeviceStatus>();

            deviceStatuses = manager.GetDeviceStatusInWashrooms(floorId, washroomId);
            var deviceTypes = deviceStatuses.GroupBy(x => new { x.DeviceType });
            foreach (var deviceType in deviceTypes)
            {
                KeyValuePair<string, List<DeviceStatus>> deviceStatusPair = new KeyValuePair<string, List<DeviceStatus>>(GetDeviceName(deviceType.Key.DeviceType), deviceStatuses.FindAll(x => x.DeviceType.Equals(deviceType.Key.DeviceType)));
                deviceStatusResponse.Add(deviceStatusPair);
            }

            return deviceStatusResponse;
        }

        public string GetDeviceName(string deviceType)
        {

            Hashtable DeviceKeyValues = new Hashtable();
            DeviceKeyValues.Add(CommonConstants.JRT.ToUpper(), AlertEngineConstants.JRT_DEVICE_NAME);
            DeviceKeyValues.Add(CommonConstants.eHRT.ToUpper(), AlertEngineConstants.EHRT_DEVICE_NAME);
            DeviceKeyValues.Add(CommonConstants.eSoap.ToUpper(), AlertEngineConstants.ESOAP_DEVICE_NAME);
            DeviceKeyValues.Add(CommonConstants.SRB.ToUpper(), AlertEngineConstants.SRB_DEVICE_NAME);

            string item = DeviceKeyValues[deviceType.ToUpper()].ToString();
            return item;

        }

        [HttpGet]
        public Names GetNames(int floorId)
        {
            return manager.GetNames(floorId);
        }

        [HttpGet]
        public DeviceAlertsResolutionDetail GetDeviceLastDispensedValue(int customerId, string deviceId, string deviceType)
        {
            WashroomBusinessManager manager = new WashroomBusinessManager();
            return manager.GetDeviceLastDispensedValue(customerId, deviceId, deviceType);
        }
    }
}
