﻿using KC.SmartWashroom.Business;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
using KC.SmartWashroom.BusinessEntities.BusinessHubEntities;
using KC.SmartWashroom.BusinessEntities.DashboardApiEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.BusinessHub.Filters;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.Helper;
using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using System.Web.Http;

namespace KC.SmartWashroom.BusinessHub.Controllers
{
    [BasicAuthenticationFilter]
    public class BuildingController : ApiController
    {
        BuildingBusinessManager manager = new BuildingBusinessManager();

        [HttpGet]
        public BuildingEntity GetBuildingByPropertyId(int buildingId, int Id, int userId)
        {
            Guard.IsNotNull(Id, "Id");

            FloorSet floorSet = new FloorSet();
            List<FloorSet> floorSets = new List<FloorSet>();
            List<Floor> floorsWithoutAlerts = new List<Floor>();

            BuildingEntity buildingEntity = manager.GetBuildingDetailsByPropertyId(buildingId, Id, userId);

            return buildingEntity;
        }

        [HttpGet]
        public List<FloorSet> GetFloorSetsByBuildingId(int Id)
        {
            Guard.IsNotNull(Id, "Id");
            List<FloorSet> floorSets = new List<FloorSet>();
            FloorSet floorSet = new FloorSet();
            List<Floor> floorsWithoutAlerts = new List<Floor>();

            int i = 0;
            List<Floor> floors = manager.GetFloorsByBuildingId(Id);
            List<Floor> floorsrecentAlerts = manager.GetFloorsByBuildingId(Id);


            foreach (var floor in floors)
            {
                i++;
                if (floor.Alerts.Count > 0)
                {
                    //List<DeviceAlert> MaxOfAlerts = new List<DeviceAlert>();
                    //var AllDevices = floor.Alerts.GroupBy(x => new { x.DeviceId, x.AlertType }).ToList();

                    //foreach (var item in AllDevices)
                    //{
                    //    var MaxOfalert = floor.Alerts.FindAll(x => x.DeviceId.Equals(item.Key.DeviceId) && x.AlertType.Equals(item.Key.AlertType)).MaxObject(x => x.DateTime);
                    //    MaxOfAlerts.Add(MaxOfalert);
                    //}

                    //floor.Alerts = MaxOfAlerts;

                    if (floorsWithoutAlerts.Count > 0)
                    {

                        floorSet.FloorsWithoutAlert = floorsWithoutAlerts;
                        floorsWithoutAlerts = new List<Floor>();
                        floorSets.Add(floorSet);

                        floorSet = new FloorSet();
                    }

                    floorSet.FloorWithAlert = floor;
                    floorSet.FloorsWithoutAlert = null;
                    floorSets.Add(floorSet);
                    floorSet = new FloorSet();
                }
                else
                {
                    floorsWithoutAlerts.Add(floor);

                    if (i == floors.Count)
                    {
                        floorSet = new FloorSet();
                        floorSet.FloorsWithoutAlert = floorsWithoutAlerts;
                        floorSets.Add(floorSet);
                    }
                }

                foreach (var alert in floor.Alerts)
                {
                    var KeyPair = CommonHelper.GetDeviceAlertType(alert.AlertType);
                    alert.AlertTypeName = KeyPair.Value;
                    //alert.DeviceName = KeyPair.Key;
                }

            }
            return floorSets;
        }
        [HttpGet]
        public List<DeviceAlert> GetAlertDetailsByAlertGroup(string alertGroupName, int floorId, byte genderId)
        {
            List<DeviceAlert> deviceAlerts = new List<DeviceAlert>();
            deviceAlerts = manager.GetAlertDetailsByAlertGroup(alertGroupName, floorId, genderId);

            return deviceAlerts;
        }
        [HttpGet]
        public List<DeviceAlert> GetAlertDetailsByAlertType(byte alertTypeId, int floorId, byte genderId)
        {
            List<DeviceAlert> deviceAlerts = new List<DeviceAlert>();
            deviceAlerts = manager.GetAlertDetailsByAlertType(alertTypeId, floorId, genderId);
            if (deviceAlerts.Count > 0)
            {
                //List<DeviceAlert> MaxOfAlerts = new List<DeviceAlert>();
                //var AllDevices = deviceAlerts.GroupBy(x => new { x.DeviceId, x.AlertType }).ToList();

                //foreach (var item in AllDevices)
                //{
                //    var MaxOfalert = deviceAlerts.FindAll(x => x.DeviceId.Equals(item.Key.DeviceId) && x.AlertType.Equals(item.Key.AlertType)).MaxObject(x => x.DateTime);
                //    MaxOfAlerts.Add(MaxOfalert);
                //}

                //deviceAlerts = MaxOfAlerts;
                foreach (var alert in deviceAlerts)
                {
                    var KeyPair = CommonHelper.GetDeviceAlertType(alert.AlertType);
                    alert.AlertTypeName = KeyPair.Value;
                    //  alert.DeviceName = KeyPair.Key;
                }

            }


            return deviceAlerts;
        }


        [HttpPost]
        public ProcessResponse<Building> CreateBuilding(Building building)
        {
            return manager.CreateBuilding(building);
        }

        [HttpPost]
        public ProcessResponse<Building> UpdateBuilding(Building building)
        {
            return manager.UpdateBuilding(building);
        }

        [HttpPost]
        public ProcessResponse<Building> DeleteBuilding(Building building)
        {
            return manager.DeleteBuilding(building);
        }

        [HttpGet]
        public Building GetBuildingDetails(int buildingId, int userId)
        {
            return manager.GetBuildingDetails(buildingId, userId);
        }

        [HttpGet]
        public List<Floor> GetFloors(int buildingId)
        {
            return manager.GetFloors(buildingId);
        }

        public Names GetNames(int propertyId)
        {
            return manager.GetNames(propertyId);
        }

        [HttpGet]
        public List<DeviceAlert> GetUnresponsiveDevices(int propertyId, int buildingId, int floorId, int washroomId)
        {
            List<DeviceAlert> unresponsiveDevicesResponse = new List<DeviceAlert>();

            unresponsiveDevicesResponse = manager.GetUnresponsiveDevices(propertyId, buildingId, floorId, washroomId);

            return unresponsiveDevicesResponse;
        }

        [HttpGet]
        public List<Building> GetAllBuildings(int customerId, int UserId, int roleLevel)
        {
            return manager.GetAllBuildings(customerId,UserId,roleLevel);
        }
    }
}