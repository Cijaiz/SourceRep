﻿using KC.SmartWashroom.Business;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.BusinessHubEntities;
using KC.SmartWashroom.BusinessHub.Filters;
using System;
using System.Collections.Generic;
using System.Web.Http;

namespace KC.SmartWashroom.BusinessHub.Controllers
{
    [BasicAuthenticationFilter]
    public class RecentUpdatesController : ApiController
    {
        [HttpGet]
        public List<DeviceAlertsResolutionDetail> GetDeviceAlertsForBuildingWithResolution(int propertyId, int buildingId, int floorId, int washroomId)
        {
            RecentUpdatesManager manager = new RecentUpdatesManager();
            return manager.FetchDeviceAlertsForBuildingWithResolution(propertyId, buildingId, floorId, washroomId);
        }

        [HttpGet]
        public ActivityResult GetActivitiesForCustomer(int customerId, int userId, int noOfRecentAlerts, int roleLevel)
        {
            RecentUpdatesManager manager = new RecentUpdatesManager();
            return manager.FetchAllActivities(customerId, userId, noOfRecentAlerts, roleLevel);
        }

        [HttpGet]
        public ActivityResult FetchActivitiesLastDay(int customerId, int userId, int roleLevel)
        {
            RecentUpdatesManager manager = new RecentUpdatesManager();
            return manager.FetchActivitiesLastDay(customerId, userId, roleLevel);
        }

        [HttpGet]
        public ActivityResult GetActivitiesForCustomerWithFilter(int customerId, int userId, int noOfRecentAlerts, int roleLevel, string alertTypeCode, int propertyId, int buildingId, int floorId, byte deviceTypeId, byte roomTypeId, DateTime fromDate, DateTime toDate)
        {
            RecentUpdatesManager manager = new RecentUpdatesManager();
            return manager.FetchAllActivitiesWithFilter(customerId, userId, alertTypeCode, fromDate, toDate, propertyId, buildingId, floorId, deviceTypeId, roomTypeId, noOfRecentAlerts, roleLevel);
        }
    }
}
