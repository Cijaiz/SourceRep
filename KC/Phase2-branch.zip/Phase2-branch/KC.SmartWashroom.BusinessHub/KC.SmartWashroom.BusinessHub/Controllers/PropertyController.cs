﻿using KC.SmartWashroom.Business;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.DashboardApiEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.BusinessHub.Filters;
using KC.SmartWashroom.Core.Helper;
using System;
using System.Collections.Generic;
using System.Web.Http;

namespace KC.SmartWashroom.BusinessHub.Controllers
{
    [BasicAuthenticationFilter]
    public class PropertyController : ApiController
    {
        PropertyBusinessManager manager = new PropertyBusinessManager();

        [HttpPost]
        public ProcessResponse<Property> Create(Property property)
        {
            Guard.IsNotNull(property, "Property");
            ProcessResponse<Property> processResponse = manager.Create(property);
            return processResponse;
        }

        [HttpPost]
        public ProcessResponse<Property> Update(Property property)
        {
            Guard.IsNotNull(property, "Property");
            ProcessResponse<Property> processResponse = manager.Update(property);
            return processResponse;
        }

        [HttpGet]
        public Property GetProperty(int propertyID, int userID)
        {
            Guard.IsNotNull(propertyID, "propertyID");
            Property property = manager.GetProperty(propertyID, userID);
            return property;
        }

        [HttpPost]
        public ProcessResponse<Property> Delete(Property property)
        {
            Guard.IsNotNull(property, "property");
            ProcessResponse<Property> processResponse = manager.Delete(property.ID, property.UserId);
            return processResponse;
        }

        [HttpGet]
        public IList<PropertyAlert> GetAllProperties(int customerId, int userID, string customerName)
        {
            IList<PropertyAlert> AllProperties = manager.GetAllProperties(customerId, userID, customerName, 0);
            return AllProperties;
        }

        public string GetCustomerNameByID(int Id)
        {
            string Name = "";
            Name = manager.GetCustomerNameByID(Id);
            return Name;
        }

        public List<Timezone> GetAllTimezones()
        {
            List<Timezone> timezones = new List<Timezone>();
            timezones = manager.GetAllTimezones();
            if (timezones.Equals(null))
                throw new Exception(manager.ErrorDetail);
            return timezones;
        }
    }
}
