﻿using KC.SmartWashroom.Business;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessHub.Filters;
using KC.SmartWashroom.Core.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace KC.SmartWashroom.BusinessHub.Controllers
{
    [BasicAuthenticationFilter]
    public class UsageMartController : ApiController
    {
        UsageMartBusinessManager manager = new UsageMartBusinessManager();

        [HttpPost]
        public List<ReportGenericEntity> GetTrafficDataWeekwise(ReportFilterEntity FilterValues)
        {
            Guard.IsNotNull(FilterValues, "ReportFilterEntity");
            List<ReportGenericEntity> ReportEntity = new List<ReportGenericEntity>();
            ReportEntity = manager.GetTrafficDataWeekwise(FilterValues);
            return ReportEntity;
        }

        [HttpPost]
        public List<ReportGenericEntity> GetTrafficDataMonthWise(ReportFilterEntity FilterValues)
        {
            Guard.IsNotNull(FilterValues, "ReportFilterEntity");
            List<ReportGenericEntity> ReportEntity = new List<ReportGenericEntity>();
            ReportEntity = manager.GetTrafficDataMonthWise(FilterValues);
            return ReportEntity;
        }
        
        [HttpPost]
        public List<ReportGenericEntity> GetProductUsageWeekwise(ReportFilterEntity FilterValues)
        {
            Guard.IsNotNull(FilterValues, "ReportFilterEntity");
            List<ReportGenericEntity> ReportEntity = new List<ReportGenericEntity>();
            ReportEntity = manager.GetProductUsageWeekwise(FilterValues);
            return ReportEntity;
        }

        [HttpPost]
        public List<ReportGenericEntity> GetProductUsageMonthwise(ReportFilterEntity FilterValues)
        {
            Guard.IsNotNull(FilterValues, "ReportFilterEntity");
            List<ReportGenericEntity> ReportEntity = new List<ReportGenericEntity>();
            ReportEntity = manager.GetProductUsageMonthwise(FilterValues);
            return ReportEntity;
        }


        [HttpPost]
        public List<ReportGenericEntity> GetProductSummaryData(ReportFilterEntity FilterValues)
        {
            Guard.IsNotNull(FilterValues, "ReportFilterEntity");
            List<ReportGenericEntity> ReportEntity = new List<ReportGenericEntity>();
            ReportEntity = manager.GetProductSummaryData(FilterValues);
            return ReportEntity;
        }

        [HttpPost]
        public int GetRefillBeforeThreshold(ReportFilterEntity FilterValues)
        {
            Guard.IsNotNull(FilterValues, "ReportFilterEntity");
            return manager.GetRefillBeforeThreshold(FilterValues);
        }
    }
}