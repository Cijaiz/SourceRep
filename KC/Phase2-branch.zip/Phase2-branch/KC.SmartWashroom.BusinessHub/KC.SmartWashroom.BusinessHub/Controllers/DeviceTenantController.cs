﻿using KC.SmartWashroom.Business;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.Helper;
using System;
using System.Collections.Generic;
using System.Web.Http;

namespace KC.SmartWashroom.BusinessHub.Controllers
{
    public class DeviceTenantController : ApiController
    {
        DeviceTenantManager deviceTenantManager = new DeviceTenantManager();

        [HttpPost]
        public ProcessResponse<Device> Create(Device device)
        {
            Guard.IsNotNull(device, "Device");
            ProcessResponse<Device> processResponse = deviceTenantManager.Create(device);
            return processResponse;
        }

        [HttpPost]
        public ProcessResponse<Device> Update(Device device)
        {
            Guard.IsNotNull(device, "Device");
            ProcessResponse<Device> processResponse = deviceTenantManager.Update(device);
            return processResponse;
        }

        [HttpGet]
        public Device GetDevice(string DeviceID, int UserID, int CustomerId)
        {
            Guard.IsNotNull(DeviceID, "DeviceID");
            Device device = deviceTenantManager.GetDevice(DeviceID, UserID);

            //Retrive Return Parameters.
            device.ReturnParameters = deviceTenantManager.RetriveReturnParametersForDevice(DeviceID, CustomerId);

            if (device.Equals(null))
                throw new Exception(deviceTenantManager.ErrorDetail);
            return device;
        }

        [HttpPost]
        public ProcessResponse Delete(Device device)
        {
            Guard.IsNotNull(device, "device");
            ProcessResponse processResponse = deviceTenantManager.Delete(device.ID, device.UserId);
            return processResponse;
        }

        [HttpGet]
        public List<DeviceTypes> GetDeviceTypes()
        {
            List<DeviceTypes> deviceTypes = new List<DeviceTypes>();
            deviceTypes = deviceTenantManager.GetDeviceTypes();
            if (deviceTypes.Equals(null))
                throw new Exception(deviceTenantManager.ErrorDetail);
            return deviceTypes;
        }

        [HttpGet]
        public List<RefillSize> GetRefillSize()
        {
            List<RefillSize> refillSize = new List<RefillSize>();
            refillSize = deviceTenantManager.GetRefillSize();
            if (refillSize.Equals(null))
                throw new Exception(deviceTenantManager.ErrorDetail);
            return refillSize;
        }

        public Names GetNames(int washroomId)
        {
            return deviceTenantManager.GetNames(washroomId);
        }

        [HttpPost]
        public ProcessResponse<List<ReturnValueParameter>> UpsetReturnParameters(ReturnParameterDataTransfer device)
        {
            Guard.IsNotNull(device, "device");
            ProcessResponse<List<ReturnValueParameter>> response = new ProcessResponse<List<ReturnValueParameter>> { Status = ResponseStatus.Error, Message = AlertEngineConstants.MESSAGE_FAIL };
            response = deviceTenantManager.DeviceUpsetReturnParameters(device.DeviceId, device.ReturnValueParameters, device.customerId);
            return response;
        }

        public ProcessResponse RemoveReturnParameterValues(ReturnParameterDataTransfer device)
        {
            Guard.IsNotNull(device, "device");
            ProcessResponse processResponse = deviceTenantManager.DeleteDeviceParameterValues(device.DeviceId, device);
            return processResponse;
        }
    }
}