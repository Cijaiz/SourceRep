﻿using System.Web.Http;
using System.Web.Mvc;

namespace KC.SmartWashroom.BusinessHub.Controllers
{
    public class ErrorsController : ApiController, IController
    {
        [System.Web.Mvc.HttpGet]
        public void GetValue()
        {
        }

        public void Execute(System.Web.Routing.RequestContext requestContext)
        {
            throw new System.NotImplementedException();
        }
    }
}
