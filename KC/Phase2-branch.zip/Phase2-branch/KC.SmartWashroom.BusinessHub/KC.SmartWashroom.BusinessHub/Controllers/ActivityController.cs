﻿using KC.SmartWashroom.Business;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.DashboardApiEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.BusinessEntities.BusinessHubEntities;
using KC.SmartWashroom.BusinessHub.Filters;
using KC.SmartWashroom.Core.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace KC.SmartWashroom.BusinessHub.Controllers
{
    [BasicAuthenticationFilter]
    public class ActivityController : ApiController
    {
        ActivityBusinessManager manager = new ActivityBusinessManager();

        [HttpGet]
        public BuildingEntity GetActivities(int customerId, int userId)
        {
            Guard.IsNotNull(customerId, "Customer Id");
            return manager.GetActivities(customerId, userId);
        }

        [HttpGet]
        public BuildingEntity GetActivitiesByFilter(int customerId, int userId, string alertType, DateTime fromDate, DateTime toDate)
        {
            Guard.IsNotNull(customerId, "Customer Id");
            return manager.GetActivitiesByFilter(customerId, userId, alertType, fromDate, toDate);
        }

        [HttpGet]
        public List<string> GetAllAlertTypes()
        {
            return manager.GetAllAlertTypes();
        }

        [HttpGet]
        public List<string> GetAlertTypesForDeviceType(byte deviceTypeId)
        {
            return manager.GetAlertTypesForDeviceType(deviceTypeId);
        }

        [HttpGet]
        public List<DeviceTypes> GetAllDeviceTypes()
        {
            return manager.GetAllDeviceTypes();
        }

        [HttpGet]
        public List<Gender> GetAllRoomTypes()
        {
            return manager.GetAllRoomTypes();
        }

        [HttpGet]
        public List<Property> GetAllProperties(int customerId)
        {
            return manager.GetAllProperties(customerId);
        }

        [HttpGet]
        public List<Building> GetAllBuildings(int customerId, int propertyId)
        {
            return manager.GetAllBuildings(customerId, propertyId);
        }

        [HttpGet]
        public List<Floor> GetAllFloors(int buildingId)
        {
            return manager.GetAllFloors(buildingId);
        }

        [HttpGet]
        public int CountOutstandingDeviceAlerts(int customerId, int userId, string customerName)
        {
            return manager.CountOutstandingDeviceAlerts(customerId, userId, customerName);
        }

        [HttpGet]
        public int CountOutstandingDeviceAlertsFilter(int customerId, string alertTypeCode, DateTime fromDate, DateTime toDate)
        {
            return manager.CountOutstandingDeviceAlertsFilter(customerId, alertTypeCode, fromDate, toDate);
        }

        [HttpGet]
        public int CountDispenseseHRTDevices(int customerId, int userId, int roleLevel, int days)
        {
            return manager.CountDispenseseHRTDevices(customerId, userId, roleLevel, days);
        }

        [HttpPost]
        public ActivityResult GetActivities(SearchCriteria searchCriteria)
        {
            return manager.GetActivities(searchCriteria);
        }

        [HttpPost]
        public IList<DeviceAlertsResolutionDetail> GetRecentActivities(SearchCriteria searchCriteria)
        {
            return manager.GetRecentActivities(searchCriteria);
        }
    }
}
