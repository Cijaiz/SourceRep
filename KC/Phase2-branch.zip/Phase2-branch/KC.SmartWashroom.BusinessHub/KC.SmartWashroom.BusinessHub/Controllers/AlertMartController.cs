﻿using KC.SmartWashroom.Business;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessHub.Filters;
using KC.SmartWashroom.Core.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace KC.SmartWashroom.BusinessHub.Controllers
{
    [BasicAuthenticationFilter]
    public class AlertMartController : ApiController
    {
        AlertMartBusinessManager manager = new AlertMartBusinessManager();

        [HttpPost]
        public List<ReportGenericEntity> GetAlertDataWeekwise(ReportFilterEntity FilterValues)
        {
            Guard.IsNotNull(FilterValues, "ReportFilterEntity");
            List<ReportGenericEntity> ReportEntity = new List<ReportGenericEntity>();
            ReportEntity = manager.GetAlertDataWeekwise(FilterValues);
            return ReportEntity;
        }

        [HttpPost]
        public List<ReportGenericEntity> GetAlertDataMonthwise(ReportFilterEntity FilterValues)
        {
            Guard.IsNotNull(FilterValues, "ReportFilterEntity");
            List<ReportGenericEntity> ReportEntity = new List<ReportGenericEntity>();
            ReportEntity = manager.GetAlertDataMonthwise(FilterValues);
            return ReportEntity;
        }

        [HttpPost]
        public List<ReportGenericEntity> GetAlertSummaryData(ReportFilterEntity FilterValues)
        {
            Guard.IsNotNull(FilterValues, "ReportFilterEntity");
            List<ReportGenericEntity> ReportEntity = new List<ReportGenericEntity>();
            ReportEntity = manager.GetAlertSummaryData(FilterValues);
            return ReportEntity;
        }

        [HttpPost]
        public StoryboardReportEntity GetStoryBoardData(ReportFilterEntity FilterValues)
        {
            Guard.IsNotNull(FilterValues, "ReportFilterEntity");
            StoryboardReportEntity StoryboardReportEntity = new StoryboardReportEntity();
            StoryboardReportEntity = manager.GetStoryBoardData(FilterValues);
            return StoryboardReportEntity;
        }
                     
    }
}