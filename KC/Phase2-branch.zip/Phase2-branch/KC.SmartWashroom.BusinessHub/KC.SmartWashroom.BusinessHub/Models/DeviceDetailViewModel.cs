﻿using KC.SmartWashroom.BusinessEntities;
using System.Collections.Generic;

namespace KC.SmartWashroom.BusinessHub.Models
{
    public class DeviceDetailViewModel
    {

        public string DeviceId { get; set; }

        public List<SearchDeviceDetailsEntity> DeviceDetailsList { get; set; }

    }


}