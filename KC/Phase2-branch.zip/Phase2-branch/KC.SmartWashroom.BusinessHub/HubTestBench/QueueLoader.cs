﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using KC.SmartWashroom.Core.NotificationUtility;
using KC.SmartWashroom.BusinessEntities;

namespace HubTestBench
{
    public class QueueLoader
    {
        public static void InitializeQueueInjector(WebClient client, string domain)
        {
            Console.WriteLine("<<<<<<<<<<<<.... Queue injector ... >>>>>>>>>>>>>>>");

            Console.WriteLine("      ");

            Console.WriteLine("Enter UserName: ");
            string username = Console.ReadLine();//string.Empty;

            Console.WriteLine("Enter password: ");
            string password = Console.ReadLine();//string.Empty;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password)) //Default Credentials..
            {
                username = "kcuser";
                password = "kcpassword-1";

                Console.WriteLine("Default Credentials taken Username: " + username + " And Password: " + password);
            }

            //Set authentication header.
            client.SetAuthenticationHeaderToken(username, password);

            Console.WriteLine("Enter the Device ID for which Alerts need to be Injected..");
            string deviceId = Console.ReadLine();

            Console.WriteLine("                                                                                   ");

            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("Enter 1 For Push alerts, 2 For Resolve alerts..");
            string processType = Console.ReadLine();

            switch (processType)
            {
                case "1":
                    Console.WriteLine("                                                                                   ");

            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("Enter 1 For JRT Device Alerts, 2 For ESoap Device Alerts, 3 For EHRT Device Alerts, 4 for the Device ID for which Alerts need to be Injected..");
            string alertyType = Console.ReadLine();

            Console.WriteLine("                                                                                   ");

            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("Enter Total number of Alerts to be Injected into the Business Hub's PushAlert API.....");
            string injectionCount = Console.ReadLine();

            switch (alertyType)
            {
                case "1":
                    PushJRTMessageIntoLowPriorityQueue(client, "http://" + domain + "/api/Devices/PostAlertMessage", deviceId, injectionCount);
                    break;
                case "2":
                    PushESoapMessageIntoLowPriorityQueue(client, "http://" + domain + "/api/Devices/PostAlertMessage", deviceId, injectionCount);
                    break;
                case "3":
                    PushEHRTMessageIntoLowPriorityQueue(client, "http://" + domain + "/api/Devices/PostAlertMessage", deviceId, injectionCount);
                    break;
                default:
                    break;
            }
                    break;
                case "2":
                    Console.WriteLine("                                                                                   ");

                    Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
                    Console.WriteLine("Enter 1 For JRT Device Alerts, 2 For ESoap Device Alerts, 3 For EHRT Device Alerts, 4 for the Device ID for which Alerts need to be Resolved..");
                    string alertType = Console.ReadLine();

                    

                    switch (alertType)
                    {
                        case "1":
                            ResolveJRTMessageIntoLowPriorityQueue(client, "http://" + domain + "/api/Devices/PostAlertMessage", deviceId);
                            break;
                        case "2":
                             ResolveESoapMessageIntoLowPriorityQueue(client, "http://" + domain + "/api/Devices/PostAlertMessage", deviceId);
                            break;
                        case "3":
                             ResolveEHRTMessageIntoLowPriorityQueue(client, "http://" + domain + "/api/Devices/PostAlertMessage", deviceId);
                            break;
                        default:
                            break;
                    }
                    break;
                default:
                    break;

            }

            
            Console.Read();
        }

        public static void PushJRTMessageIntoLowPriorityQueue(WebClient client, string restURl, string deviceId, string iterationCount)
        {
            int defaultIteration = 0;
            string responseoutput = string.Empty;

            defaultIteration = int.TryParse(iterationCount, out defaultIteration) ? defaultIteration : defaultIteration;

            for (int iteration = 0; iteration < defaultIteration; iteration++)
            {
                try
                {
                    client.WebClientPostRequest<DeviceAlertInfo>(restURl, new DeviceAlertInfo { DeviceID = deviceId, AlertType = "J1", IsAlert = 1 });
                    //client.WebClientPostRequest<DeviceAlertInfo>(restURl, new DeviceAlertInfo { DeviceID = deviceId, AlertType = "J2", IsAlert = 1 });
                    client.WebClientPostRequest<DeviceAlertInfo>(restURl, new DeviceAlertInfo { DeviceID = deviceId, AlertType = "J3", IsAlert = 1 });
                    Console.Write(".");
                }
                catch (Exception ex)
                {
                    Console.Write("Exception Occured: " + ex.Message);
                    break;
                }
            }
            Console.WriteLine("Message PushJRTLowBatteryMessageIntoLowPriorityQueue for Device ID" + deviceId + "Inserted into URL: " + restURl + "Successfully..." + iterationCount + "times..");
        }

        public static void PushESoapMessageIntoLowPriorityQueue(WebClient client, string restURl, string deviceId, string iterationCount)
        {
            int defaultIteration = 0;
            string responseoutput = string.Empty;

            defaultIteration = int.TryParse(iterationCount, out defaultIteration) ? defaultIteration : defaultIteration;

            for (int iteration = 0; iteration < defaultIteration; iteration++)
            {
                try
                {
                    client.WebClientPostRequest<DeviceAlertInfo>(restURl, new DeviceAlertInfo { DeviceID = deviceId, AlertType = "S1", IsAlert = 1 });
                   client.WebClientPostRequest<DeviceAlertInfo>(restURl, new DeviceAlertInfo { DeviceID = deviceId, AlertType = "S2", IsAlert = 1 });
                   // client.WebClientPostRequest<DeviceAlertInfo>(restURl, new DeviceAlertInfo { DeviceID = deviceId, AlertType = "S3", IsAlert = 1 });
                    client.WebClientPostRequest<DeviceAlertInfo>(restURl, new DeviceAlertInfo { DeviceID = deviceId, AlertType = "S4", IsAlert = 1 });
                    Console.Write(".");
                }
                catch (Exception ex)
                {
                    Console.Write("Exception Occured: " + ex.Message);
                    break;
                }
            }
            Console.WriteLine("Message PushESoapMessageIntoLowPriorityQueue for Device ID" + deviceId + "Inserted into URL: " + restURl + "Successfully..." + iterationCount + "times..");
        }

        public static void PushEHRTMessageIntoLowPriorityQueue(WebClient client, string restURl, string deviceId, string iterationCount)
        {
            int defaultIteration = 0;
            string responseoutput = string.Empty;

            defaultIteration = int.TryParse(iterationCount, out defaultIteration) ? defaultIteration : defaultIteration;

            for (int iteration = 0; iteration < defaultIteration; iteration++)
            {
                try
                {
                   // client.WebClientPostRequest<DeviceAlertInfo>(restURl, new DeviceAlertInfo { DeviceID = deviceId, AlertType = "H1", IsAlert = 1 });
                  //  client.WebClientPostRequest<DeviceAlertInfo>(restURl, new DeviceAlertInfo { DeviceID = deviceId, AlertType = "H2", IsAlert = 1 });
                   // client.WebClientPostRequest<DeviceAlertInfo>(restURl, new DeviceAlertInfo { DeviceID = deviceId, AlertType = "H3", IsAlert = 1 });
                    //client.WebClientPostRequest<DeviceAlertInfo>(restURl, new DeviceAlertInfo { DeviceID = deviceId, AlertType = "H4", IsAlert = 1 });
                  //  client.WebClientPostRequest<DeviceAlertInfo>(restURl, new DeviceAlertInfo { DeviceID = deviceId, AlertType = "H5", IsAlert = 1 });
                    Console.Write(".");
                }
                catch (Exception ex)
                {
                    Console.Write("Exception Occured: " + ex.Message);
                    break;
                }
            }
            Console.WriteLine("Message PushEHRTLowSoapMessageIntoLowPriorityQueue for Device ID" + deviceId + "Inserted into URL: " + restURl + "Successfully..." + iterationCount + "times..");
        }

        public static void ResolveJRTMessageIntoLowPriorityQueue(WebClient client, string restURl, string deviceId)
        {
            string responseoutput = string.Empty;

          
                try
                {
                    client.WebClientPostRequest<DeviceAlertInfo>(restURl, new DeviceAlertInfo { DeviceID = deviceId, AlertType = "J1", IsAlert = 0 });
                    //client.WebClientPostRequest<DeviceAlertInfo>(restURl, new DeviceAlertInfo { DeviceID = deviceId, AlertType = "J2", IsAlert = 0 });
                    client.WebClientPostRequest<DeviceAlertInfo>(restURl, new DeviceAlertInfo { DeviceID = deviceId, AlertType = "J3", IsAlert = 0 });
                    Console.Write(".");
                }
                catch (Exception ex)
                {
                    Console.Write("Exception Occured: " + ex.Message);
                   
                }
           
            Console.WriteLine("Message ResolveJRTLowBatteryMessageIntoLowPriorityQueue for Device ID" + deviceId + "Inserted into URL: " + restURl + "Successfully..." );
        }

        public static void ResolveESoapMessageIntoLowPriorityQueue(WebClient client, string restURl, string deviceId)
        {
            string responseoutput = string.Empty;

                try
                {
                    client.WebClientPostRequest<DeviceAlertInfo>(restURl, new DeviceAlertInfo { DeviceID = deviceId, AlertType = "S1", IsAlert = 0 });
                    client.WebClientPostRequest<DeviceAlertInfo>(restURl, new DeviceAlertInfo { DeviceID = deviceId, AlertType = "S2", IsAlert = 0 });
                    // client.WebClientPostRequest<DeviceAlertInfo>(restURl, new DeviceAlertInfo { DeviceID = deviceId, AlertType = "S3", IsAlert = 0 });
                    client.WebClientPostRequest<DeviceAlertInfo>(restURl, new DeviceAlertInfo { DeviceID = deviceId, AlertType = "S4", IsAlert = 0 });
                    Console.Write(".");
                }
                catch (Exception ex)
                {
                    Console.Write("Exception Occured: " + ex.Message);
                   
                }
           
            Console.WriteLine("Message ResolveESoapMessageIntoLowPriorityQueue for Device ID" + deviceId + "Inserted into URL: " + restURl + "Successfully..." );
        }

        public static void ResolveEHRTMessageIntoLowPriorityQueue(WebClient client, string restURl, string deviceId)
        {
            string responseoutput = string.Empty;

           

            
                try
                {
                    // client.WebClientPostRequest<DeviceAlertInfo>(restURl, new DeviceAlertInfo { DeviceID = deviceId, AlertType = "H1", IsAlert = 1 });
                    //  client.WebClientPostRequest<DeviceAlertInfo>(restURl, new DeviceAlertInfo { DeviceID = deviceId, AlertType = "H2", IsAlert = 1 });
                    // client.WebClientPostRequest<DeviceAlertInfo>(restURl, new DeviceAlertInfo { DeviceID = deviceId, AlertType = "H3", IsAlert = 1 });
                    //client.WebClientPostRequest<DeviceAlertInfo>(restURl, new DeviceAlertInfo { DeviceID = deviceId, AlertType = "H4", IsAlert = 1 });
                    //  client.WebClientPostRequest<DeviceAlertInfo>(restURl, new DeviceAlertInfo { DeviceID = deviceId, AlertType = "H5", IsAlert = 1 });
                    Console.Write(".");
                }
                catch (Exception ex)
                {
                    Console.Write("Exception Occured: " + ex.Message);
                    
                }
            
            Console.WriteLine("Message ResolveEHRTLowSoapMessageIntoLowPriorityQueue for Device ID" + deviceId + "Inserted into URL: " + restURl + "Successfully...");
        }
    }
}
