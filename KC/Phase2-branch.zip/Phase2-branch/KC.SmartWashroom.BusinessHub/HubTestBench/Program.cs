﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using KC.SmartWashroom.Core.NotificationUtility;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
using KC.SmartWashroom.Core.Constants;

namespace HubTestBench
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("<<<<<<<<<<<<.... Hub Test Bench... >>>>>>>>>>>>>>>");

            Console.WriteLine("                                                                                   ");

            WebClient client = new WebClient();
            //string businessHubDomain = "businesshubdev.cloudapp.net";
            string businessHubDomain = "localhost:56853";
            //string deviceHubDomain = "d98a81a7ea8b47c0adf5b46d163b2c50.cloudapp.net";
            string deviceHubDomain = "localhost:55592";
            string responseOutput = string.Empty;

            Console.WriteLine("                                                                                   ");

            Console.WriteLine("      ");
            Console.WriteLine("Currently Testing Domains..");
            Console.WriteLine(businessHubDomain);
            Console.WriteLine(deviceHubDomain);

            Console.WriteLine("                                                                                   ");

            Console.WriteLine("<<<END Currently Testing Domains.. END >>>>>>");

            Console.WriteLine("                                                                                   ");

            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("Do you want to Run Hub Tester Or Queue Injector? Press 1 for Hub tester or 2 for Queue Injector or 3 for API Tester... Thanks");
            string inputKey = Console.ReadLine();

            if (inputKey.Equals("2"))
            {
                QueueLoader.InitializeQueueInjector(client, businessHubDomain);
            }
            else if (inputKey.Equals("1"))
            {
                #region Hub Test REgion
                Console.WriteLine("<<<<<<<<<<<<.... Business Hub Tester... >>>>>>>>>>>>>>>");

                Console.WriteLine("      ");

                Console.WriteLine("Enter UserName: ");
                string username = Console.ReadLine();//string.Empty;

                Console.WriteLine("Enter password: ");
                string password = Console.ReadLine();//string.Empty;

                if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password)) //Default Credentials..
                {
                    username = "kcuser";
                    password = "kcpassword-1";

                    Console.WriteLine("Default Credentials taken Username: " + username + " And Password: " + password);
                }

                //Set authentication header.
                //client.SetAuthenticationHeaderToken(username, password);
                StringBuilder response = new StringBuilder();

                response.Append(client.SafeWebClientProcessing("http://" + businessHubDomain + "/api/" +
                    AlertEngineConstants.AUTHENTICATION_CONTROLLER + "/" +
                    AlertEngineConstants.AUTHENTICATE_USER + "?userName=vijayananthan.jc@cognizant.com&password=12345"));

                Console.WriteLine("THe output from WebAPi call is: " + response);
                Console.Read();
                #endregion
            }
            else if (inputKey.Equals("3"))
            {
                #region API Tester
                Console.WriteLine("<<<<<<<<<<<<.... API Hub Tester... >>>>>>>>>>>>>>>");

                Console.WriteLine("      ");

                Console.WriteLine("Enter UserName: ");
                string username = Console.ReadLine();//string.Empty;

                Console.WriteLine("Enter password: ");
                string password = Console.ReadLine();//string.Empty;

                if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password)) //Default Credentials..
                {
                    username = "kcuser";
                    password = "kcpassword-1";

                    Console.WriteLine("Default Credentials taken Username: " + username + " And Password: " + password);
                }

                //Set authentication header.
                //client.SetAuthenticationHeaderToken(username, password);
                StringBuilder response = new StringBuilder();
                client.SetDeviceAuthenticationHeaderToken("Basic A0Y7ugAwSNYAJfcAW9RBLGOsU8U=");

                #region ESoap - Test Bed
                //ESoap
                //response.Append(client.WebClientPostRequest<DeviceDetailParameter>("http://" +
                //    deviceHubDomain + "/api/Devices/Post", new DeviceDetailParameter()
                //    {
                //        deviceDetail = "000007c006c122bf5,112,s,s,s,1193046,1193046,1193046,1193046,16777215,483,483,1,0,0,1193046,1193046,1193046,5,0,0",
                //        gatewayDetail = "1234567890abcdef,104"
                //    }));
                #endregion

                //SRB
                //response.Append(client.WebClientPostRequest<DeviceDetailParameter>("http://" +
                //deviceHubDomain + "/api/Devices/Post", new DeviceDetailParameter()
                //{
                //    deviceDetail = "00001112c81c540cb8,101.0,483,20,0,1,96,0,0",
                //    gatewayDetail = "1234567890abcdef,104"
                //}));

                #region EHRT - Test Bed
                //EHRT

                Console.WriteLine("Choose the alert 1 for tru and 0 for false..");

                string inputKey1 = Console.ReadLine();

                if (inputKey1.Equals("1"))
                {
                    response.Append(client.WebClientPostRequest<DeviceDetailParameter>("http://" +
                        deviceHubDomain + "/api/Devices/Post", new DeviceDetailParameter()
                        {
                            deviceDetail = "000000c006c122bf8a,112,s,s,s,H,1193046,1193046,1193046,1193046,483,483,1,0,0,1193046,0,1193046,46,0,23,334,0,0",
                            gatewayDetail = "1234567890abcdef,104"
                        }));
                }
                else
                {
                    response.Append(client.WebClientPostRequest<DeviceDetailParameter>("http://" +
                        deviceHubDomain + "/api/Devices/Post", new DeviceDetailParameter()
                        {
                            deviceDetail = "000000c006c122bf8a,112,s,s,s,H,1193046,1193046,1193046,1193046,483,483,0,0,0,1193046,0,1193046,46,0,23,334,0,0",
                            gatewayDetail = "1234567890abcdef,104"
                        }));
                }
                #endregion

                Console.WriteLine("THe output from WebAPi call is: " + response);
                Console.Read();
                #endregion
            }
        }
    }
}