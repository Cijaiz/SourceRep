﻿using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.NotificationUtility;
using KC.SmartWashroom.Core.Helper;
using System;
using System.Collections.Generic;
using System.Net;
using System.Web.Http;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.Business;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace KC.SmartWashroom.DeviceAPIHub.Controllers
{
    public class ControllerBase : ApiController
    {
        protected ServiceUnavailableResult ServiceUnavailableResult(string message)
        {
            return new ServiceUnavailableResult(message, Request);
        }
    }

    public class ServiceUnavailableResult : IHttpActionResult
    {
        public ServiceUnavailableResult(string message, HttpRequestMessage request)
        {
            if (message == null)
            {
                throw new ArgumentNullException("message");
            }

            if (request == null)
            {
                throw new ArgumentNullException("request");
            }

            Message = message;
            Request = request;
        }

        public string Message { get; private set; }

        public HttpRequestMessage Request { get; private set; }

        public Task<HttpResponseMessage> ExecuteAsync(CancellationToken cancellationToken)
        {
            return Task.FromResult(Execute());
        }

        public HttpResponseMessage Execute()
        {
            HttpResponseMessage response = new HttpResponseMessage(HttpStatusCode.ServiceUnavailable);
            response.Content = new StringContent(Message); // Put the message in the response body (text/plain content).
            response.RequestMessage = Request;
            return response;
        }
    }
}