﻿
namespace KC.SmartWashroom.DeviceAPIHub.Controllers
{
    using KC.SmartWashroom.Business;
    using KC.SmartWashroom.BusinessEntities;
    using KC.SmartWashroom.Core.Constants;
    using KC.SmartWashroom.Core.Log;
    using KC.SmartWashroom.DeviceAPIHub.Extensions;
    using System;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Web.Http;

    public class DevicesController : ControllerBase
    {
        //api/device/Post/5
        [HttpPost]
        public IHttpActionResult Post(DeviceDetailParameter model)
        {
            // Kiran Chand: this is to be cleared off from here :)
#if DEBUG
            DeviceTrafficTrace trace = AuditHelper.AuditManager.CreateDeviceTrafficTrace("DeviceControllerPost"
                , (model != null
                    ? model.deviceDetail
                    : string.Empty));
#endif

            var result = default(IHttpActionResult);

            if (!this.ValidatePayload(model))
            {
                result = this.BadRequest("Invalid JSON");
            }
            else
            {
                try
                {
                    //This is done here to avoid redudant calls from DB.. Do it at once alone and the plan is to retrive it from Cache.
                    BusinessEntities.DeviceUpdate.DeviceUpdateDetails deviceDetails = model.GetDeviceDetails(null, true).FirstOrDefault();

                    if (this.UpdateDeviceLog(model, deviceDetails))
                    {

                        

                        result = this.ReturnParameters(deviceDetails);
                        
                        // return parameters are there
                        if (result != null)
                        {
#if DEBUG
                            DeviceTrafficTrace resetParams = AuditHelper.AuditManager.CreateDeviceTrafficTrace("UpdateAutoResetParameters", (model != null
                                                                    ? model.deviceDetail
                                                                    : string.Empty));
#endif
                            DeviceBusinessManager deviceBM = new DeviceBusinessManager();
                            deviceBM.SaveDeviceToQueueForCache(deviceDetails.DeviceId, true);
#if DEBUG
                            //deviceDetails.UpdateAutoResetParameters();
                            AuditHelper.AuditManager.TraceDeviceTraffic(resetParams);
#endif
                        }
                        else
                        {
                            result = this.Ok();
                        }
                    }
                    else
                    {
                        result = this.InternalServerError(new ApplicationException("UpdateDeviceLog returned false"));
                    }

                }

                catch (Exception ex)
                {
                    bool isSqlException = false;

                    if ((ex is SqlException) && (ex.Data.Contains("HelpLink.EvtID")) && (ex.Data["HelpLink.EvtID"].ToString() == "18456"))
                    {
                        isSqlException = true;
                    }
                    else
                    {
                        Exception x = ex.InnerException;
                        while (x != null)
                        {
                            if ((x is SqlException) && (x.Data.Contains("HelpLink.EvtID")) && (x.Data["HelpLink.EvtID"].ToString() == "18456"))
                            {
                                isSqlException = true;
                                break;
                            }
                            x = x.InnerException;
                        }
                    }

                    if (isSqlException)
                    {
                        //result = this.ServiceUnavailableResult("Unable to connect to the underlying database");
                        result = this.ServiceUnavailableResult(String.Empty);
                    }
                    else if (ex is ApplicationException)
                    {
                        result = this.BadRequest();
                    }
                    else
                    {
                        result = this.InternalServerError();
                    }
                    Logger.Error(ex.ToString());
                }
#if DEBUG
                finally
                {
                    AuditHelper.AuditManager.TraceDeviceTraffic(trace);
                }
#endif
            }
            // by default, error; unless not calling ourselves OK
            return result ?? this.InternalServerError();
        }

        /// <summary>
        /// Validates the input
        /// </summary>
        /// <param name="model">The model</param>
        /// <returns>Boolean status</returns>
        protected virtual bool ValidatePayload(DeviceDetailParameter model)
        {
                return model != null
                && !string.IsNullOrWhiteSpace(model.gatewayDetail)
                && !string.IsNullOrWhiteSpace(model.deviceDetail);
        }


        private bool UpdateDeviceLog(DeviceDetailParameter deviceDetailParameter, BusinessEntities.DeviceUpdate.DeviceUpdateDetails deviceUpdates)
        {
                bool status = false;
                DeviceBusinessManager deviceBusinessManager = new DeviceBusinessManager();
                deviceBusinessManager.DeviceUpdateDetails = deviceUpdates; //Assign the updated device details taken from Cache to the lower layers.

                if (deviceBusinessManager.ComposeDeviceLog(deviceDetailParameter.deviceDetail, deviceDetailParameter.gatewayDetail))
                {
                    var processResponse = deviceBusinessManager.SaveDeviceLog();

                    status = processResponse != null
                            && string.Equals(AlertEngineConstants.STATUS_SUCCESS, processResponse.status, StringComparison.OrdinalIgnoreCase);
                }

                return status;
        }
    }
}
