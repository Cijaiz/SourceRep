﻿using KC.SmartWashroom.Business;
using KC.SmartWashroom.BusinessEntities.BusinessHubEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace KC.SmartWashroom.DeviceAPIHub.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        public ActionResult Index()
        {
            DeviceBusinessManager manager = new DeviceBusinessManager();
            //Logger.Debug("Index Called.. with Tenants Business Manager Load..");

            bool resposne = false;
            try
            {
                //manager.ManualInjection<UserWorker>();
                var responses = manager.FetchSoapDevicesForBuilding(1);

                resposne = true;
                ViewBag.Response = resposne;
            }
            catch (Exception ex)
            {
                ViewBag.Response = resposne;
                ViewBag.Error = ex.Message;
            }
            //Logger.Debug(string.Format("GetUserDetails Resposne: {0}", resposne));

            return View();
        }
    }
}