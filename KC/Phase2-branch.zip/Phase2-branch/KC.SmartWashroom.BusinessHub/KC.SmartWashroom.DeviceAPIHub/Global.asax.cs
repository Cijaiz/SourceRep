﻿using KC.SmartWashroom.DeviceAPIHub.App_Start;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Routing;
using KC.SmartWashroom.Business;
using KC.SmartWashroom.Core.Log;

namespace KC.SmartWashroom.DeviceAPIHub
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            GlobalConfiguration.Configure(WebApiConfig.Register);
            AreaRegistration.RegisterAllAreas();
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            DatabaseWarmUp();
            WarmupObjects();
        }
        void DatabaseWarmUp()
        {
            try
            {
                CustomerBusinessManager manager = new CustomerBusinessManager();
                manager.GetAllCountries();
            }
            catch (System.Exception ex)
            {
                Logger.Error(ex.ToString());
            }
        }
        void WarmupObjects()
        {
            try
            {
                new AuditBusinessManager();
                new DeviceBusinessManager();
                new TenantsBusinessManager();
                new DeviceUpdateValueManager();
            }
            catch (System.Exception ex)
            {
                //No need to throw the exception. Just logging is enough
                Logger.Error(ex.ToString());
            }
        }

    }
}
