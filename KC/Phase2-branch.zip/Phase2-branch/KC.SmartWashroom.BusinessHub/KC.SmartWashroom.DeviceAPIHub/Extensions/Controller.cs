﻿

namespace KC.SmartWashroom.DeviceAPIHub.Extensions
{
    using KC.SmartWashroom.BusinessEntities.DeviceUpdate;
    using KC.SmartWashroom.BusinessEntities.Linq;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Web;
    using System.Web.Http;
    using System.Web.Http.Controllers;
    using System.Web.Http.Results;    

    /// <summary>
    /// Extends the controller
    /// </summary>
    public static class ControllerExtensions
    {
        /// <summary>
        /// Returns the Device return parameter in an OK result
        /// </summary>
        /// <param name="controller">Current instance of the HTTP controller controller</param>
        /// <param name="parameters">An enumerable of Retrun Parameters</param>
        /// <returns>Returns the response message result with the JSON, if found, else null</returns>
        public static IHttpActionResult ReturnParameters(this IHttpController controller, IEnumerable<DeviceUpdateParameter> parameters)
        {
            var result = default(IHttpActionResult);

            if (controller != null
                && parameters != null)
            {
                var processedValue = string.Join(",", parameters
                    .ReturnParameters()
                    .WithCurrentValueOverrides()
                    .OrderBy(kvp => kvp.Key.Index)
                    .Select(kvp => string.Format("\"{0}_{1}\":\"{2}\"", kvp.Key.Index, kvp.Key.Name, kvp.Value.Value)));

                if (!string.IsNullOrWhiteSpace(processedValue))
                {
                    var jsonReturnParameter  = string.Join("", "{", processedValue, "}");

                    var response = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent(jsonReturnParameter) };
                    response.Content.Headers.ContentType.MediaType = "application/json";                    
                    result = new ResponseMessageResult(response);
                    
                }

            }
            return result;
        }


        /// <summary>
        /// Returns the Device return parameter in an OK result
        /// </summary>
        /// <param name="controller">Current instance of the HTTP controller controller</param>
        /// <param name="metadata">The current device metadata</param>
        /// <returns>Returns the response message result with the JSON, if found, else null</returns>
        public static IHttpActionResult ReturnParameters(this IHttpController controller, DeviceUpdateDetails metadata)
        {
            var result = default(IHttpActionResult);            

            if (controller != null
                && metadata != null)
            {
                result = controller.ReturnParameters(metadata.Parameters);

            }
            return result;
        }
    }
}