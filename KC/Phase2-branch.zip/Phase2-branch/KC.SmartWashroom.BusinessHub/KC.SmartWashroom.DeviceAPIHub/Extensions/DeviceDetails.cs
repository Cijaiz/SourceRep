﻿

namespace KC.SmartWashroom.DeviceAPIHub.Extensions
{
    using KC.SmartWashroom.Business;
    using KC.SmartWashroom.Business.Contracts;
    using KC.SmartWashroom.BusinessEntities;
    using KC.SmartWashroom.BusinessEntities.DeviceUpdate;
    using KC.SmartWashroom.Core.Linq;
    using System.Collections.Generic;
    using System.Linq;
    /// <summary>
    /// Extension behaviors for the device data
    /// </summary>
    internal static class DeviceDetailsExtensions
    {
        /// <summary>
        /// Returns an enumerable of the device detail parameters
        /// </summary>
        /// <param name="model">The payload</param>
        /// <param name="valueManager">The instance of the device parameter value manager, optional parameter with the default value known</param>
        /// <returns></returns>
        internal static IEnumerable<DeviceUpdateDetails> GetDeviceDetails(this DeviceDetailParameter model, IDeviceUpdateValueManager valueManager = null, bool Iscached = false)
        {
            var deviceParameters = default(IEnumerable<DeviceUpdateDetails>);

            string deviceId = model.deviceDetail.Split(',').Where(part => !string.IsNullOrWhiteSpace(part)).FirstOrDefault();

            if (model != null
                   && !string.IsNullOrWhiteSpace(model.deviceDetail))
            {
                if (!string.IsNullOrWhiteSpace(deviceId))
                {
                    if (valueManager == null)
                    {
                        valueManager = new DeviceUpdateValueManager();
                    }

                    if (Iscached)
                    {
                        deviceParameters = valueManager.RetrieveFromCache(deviceId);
                    }

                    if ((!Iscached) || (deviceParameters == null))
                    {
                        deviceParameters = valueManager.GetDeviceDetails(deviceId);
                    }
                }
            }

            return deviceParameters ?? Enumerable.Empty<DeviceUpdateDetails>();

        }


        /// <summary>
        /// Updates the auto reset parameters
        /// </summary>
        /// <param name="device">The device details</param>
        /// <param name="valueManager">The instance of the value manager, optional parameter</param>
        /// <returns>Returns the same collection modified</returns>
        internal static int UpdateAutoResetParameters(this DeviceUpdateDetails device
            , IDeviceUpdateValueManager valueManager = null)
        {
            var recordsAffected = -1;

            if (device != null)
            {
                recordsAffected = (new DeviceUpdateDetails[] { device }).UpdateAutoResetParameters(valueManager);
            }

            return recordsAffected;
        }



        /// <summary>
        /// Updates the auto reset parameters
        /// </summary>
        /// <param name="devices">The enumerable of device details</param>
        /// <param name="valueManager">The instance of the value manager, optional parameter</param>
        /// <returns>Returns the same collection modified</returns>
        internal static int UpdateAutoResetParameters(this IEnumerable<DeviceUpdateDetails> devices
            , IDeviceUpdateValueManager valueManager = null)
        {
            int recordsAffected = -1;
            if (devices != null)
            {
                recordsAffected = devices.Select(device => device.Parameters).Combine().UpdateAutoResetParameters(valueManager);
            }

            return recordsAffected;
        }

        /// <summary>
        /// Updates the auto reset parameters
        /// </summary>
        /// <param name="parameters">The enumerable of parameters</param>
        /// <param name="valueManager">The instance of the value manager, optional parameter</param>
        /// <returns>Returns the same collection modified</returns>
        internal static int UpdateAutoResetParameters(this IEnumerable<DeviceUpdateParameter> parameters
            , IDeviceUpdateValueManager valueManager = null)
        {
            int recordsAffected = -1;
            if (parameters != null)
            {
                if (valueManager == null)
                {
                    valueManager = new DeviceUpdateValueManager();
                }

                recordsAffected = valueManager.SetAutoResetParameterValues(parameters);
            }


            return recordsAffected;
        }


    }
}