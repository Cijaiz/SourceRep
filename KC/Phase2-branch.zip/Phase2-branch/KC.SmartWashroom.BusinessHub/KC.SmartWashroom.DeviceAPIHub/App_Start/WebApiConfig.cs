﻿using KC.SmartWashroom.DeviceAPIHub.Handlers;
using KC.SmartWashroom.DeviceAPIHub.Filters;
using System.Web.Http;

namespace KC.SmartWashroom.DeviceAPIHub
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            config.Routes.MapHttpRoute(
                name: "DefaultApiWithAction",
                routeTemplate: "api/{controller}/{action}");

            // config.MessageHandlers.Add(new LogMessageHandler());
            config.Filters.Add(new ServiceExceptionFilterAttribute());
            //config.Filters.Add(new BasicAuthenticationFilter());
            config.MessageHandlers.Add(new AuthenticationDeviceHandler());
        }
    }
}
