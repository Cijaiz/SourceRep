﻿using KC.SmartWashroom.DeviceAPIHub.Filters;
using System.Web.Mvc;

namespace KC.SmartWashroom.DeviceAPIHub.App_Start
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}