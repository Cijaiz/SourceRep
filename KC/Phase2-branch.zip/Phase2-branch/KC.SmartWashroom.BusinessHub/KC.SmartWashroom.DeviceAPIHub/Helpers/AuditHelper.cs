﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using KC.SmartWashroom.Business;

namespace KC.SmartWashroom.DeviceAPIHub
{
    public static class AuditHelper
    {
        static AuditHelper()
        {
            AuditManager = new AuditBusinessManager();
        }

        public static AuditBusinessManager AuditManager { get; set; }

    }
}