﻿using KC.SmartWashroom.Core.Helper;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Threading;
using System.Threading.Tasks;
using KC.SmartWashroom.Core.Log;
using KC.SmartWashroom.Core.Security;
using KC.SmartWashroom.Core.Security.Validator;
using KC.SmartWashroom.Business;
using KC.SmartWashroom.BusinessEntities;

namespace KC.SmartWashroom.DeviceAPIHub.Handlers
{
    public class AuthenticationDeviceHandler : DelegatingHandler
    {
        //Note .net 4.0
        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {

            Exception authenticationException = null;
            HttpResponseMessage responseMessage = null;
            HttpRequest reqeustContext = HttpContext.Current.Request;
            DeviceAuditLog entity = await CreateAuditLogEntityAsync(request, reqeustContext);

           
                try
                {

                    if (string.IsNullOrEmpty(reqeustContext.ContentType) || !reqeustContext.ContentType.ToLower().Contains("application/json"))
                    {
                        throw new ApplicationException("Content Type requirement not met");
                    }
                    bool isAuthenticated = TrafficAuthenticator.IncommingDeviceMessageValidator(out authenticationException);


                    if (!isAuthenticated)
                    {
                        responseMessage = new HttpResponseMessage(HttpStatusCode.Unauthorized);
                    }
                    else
                    {
                       
                        try
                        {
                            // Call the inner handler.
                            responseMessage = await base.SendAsync(request, cancellationToken);
                        }
                        catch (Exception exp)
                        {
                            responseMessage = new HttpResponseMessage(HttpStatusCode.InternalServerError);
                            Logger.Error(exp.ToString());
                        }
                       
                    }
                }
                catch (ApplicationException exp)
                {
                    responseMessage = new HttpResponseMessage(HttpStatusCode.BadRequest);
                    Logger.Error(exp.ToString());
                }
                catch (Exception exp)
                {
                    responseMessage = new HttpResponseMessage(HttpStatusCode.InternalServerError);
                    Logger.Error(exp.ToString());
                }

                await LogDeviceMessage(entity, responseMessage);
                return responseMessage;
            
           
        }
        private string GetDeviceId(string request)
        {
            string deviceId = string.Empty;
            string[] paramArray = (!string.IsNullOrWhiteSpace(request)) ? request.Trim('{', '}')
                 .Replace("\"", string.Empty)
                 .Replace("gatewayDetail", "")
                 .Replace("deviceDetail", "")
                 .Replace(":", "")
                 .Replace(" ", "")
                 .Split(',') : null;
            if (paramArray != null && paramArray.Length > 2 && !string.IsNullOrEmpty(paramArray[2]))
            {
                deviceId = paramArray[2].Trim();
            }
            return deviceId;
        }
        private async Task<DeviceAuditLog> CreateAuditLogEntityAsync(HttpRequestMessage request, HttpRequest reqeustContext)
        {
            DeviceAuditLog entity = new DeviceAuditLog();
            entity.InTime = DateTime.UtcNow;
            entity.RequestHeaders = request.Headers.ToString();
            if (request.Content != null)
            {
                entity.RequestBody = await request.Content.ReadAsStringAsync();
            }
            entity.DeviceId = GetDeviceId(entity.RequestBody);
            entity.SourceIP = reqeustContext.UserHostAddress;
            return entity;
        }
        private async Task LogDeviceMessage(DeviceAuditLog entity, HttpResponseMessage responseMessage)
        {

            try
            {
                if (responseMessage.Content != null)
                {
                    entity.ResponseBody = await responseMessage.Content.ReadAsStringAsync();
                }
                entity.ResponseCode = (int)responseMessage.StatusCode;
                entity.ResponseHeaders = responseMessage.Headers.ToString();
                entity.OutTime = DateTime.UtcNow;
                DeviceBusinessManager manager = new DeviceBusinessManager();
                manager.LogIncomingDeviceDetail(entity);
            }
            catch (Exception exp)
            {
                Logger.Error(exp.ToString());
            }
        }
    }
}
