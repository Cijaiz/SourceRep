﻿using KC.SmartWashroom.Business;
using Microsoft.Web.Administration;
using Microsoft.WindowsAzure.ServiceRuntime;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;

namespace KC.SmartWashroom.DeviceAPIHub
{
    public class WebRole : RoleEntryPoint
    {
        public override bool OnStart()
        {
            // Set the maximum number of concurrent connections 
            //Connection optimisation for http and webclient call.
            ServicePointManager.UseNagleAlgorithm = false;
            ServicePointManager.Expect100Continue = false;
            ServicePointManager.DefaultConnectionLimit = 48;
            return base.OnStart();
        }

        public override void Run()
        {
            using (var serverManager = new ServerManager())
            {
                foreach (var app in serverManager.Sites.SelectMany(x => x.Applications))
                {
                    app["preloadEnabled"] = true;
                }
                foreach (var appPool in serverManager.ApplicationPools)
                {
                    appPool.AutoStart = true;
                    appPool["startMode"] = "AlwaysRunning";
                    appPool.ProcessModel.IdleTimeout = TimeSpan.Zero;
                }
                serverManager.CommitChanges();

            }

            base.Run();
        }

       
    }
}