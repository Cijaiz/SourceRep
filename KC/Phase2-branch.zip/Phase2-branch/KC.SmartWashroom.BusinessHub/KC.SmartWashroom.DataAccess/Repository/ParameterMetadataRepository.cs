﻿

namespace KC.SmartWashroom.DataAccess.Repository
{
    using KC.SmartWashroom.BusinessEntities.DeviceUpdate;
    using KC.SmartWashroom.BusinessEntities.Search;
    using KC.SmartWashroom.Core;
    using KC.SmartWashroom.DataAccess.Extensions;
    using System;
    using System.Data;
    using System.Data.Common;
    using System.Text;

    public class ParameterMetadataRepository : SqlDataRepository<DeviceUpdateParameter> // , IDeviceDataRepository<DeviceUpdateParameter>
    {

        public ParameterMetadataRepository(string connectionString)
            : base(connectionString)
        {

        }
        protected override DeviceUpdateParameter ReadAsObject(DbDataReader reader)
        {
            var parameter = new DeviceUpdateParameter();

            parameter.Id = reader.GetValue<int>(0);

            if (parameter.Id > 0)
            {
                parameter.Name = reader.GetValue<string>(1);
                parameter.Index = reader.GetValue<int>(2);
                parameter.FormatCode = reader.GetValue<string>(3);
                parameter.IsReturn = reader.GetValue<bool>(4);
                parameter.IgnoreErrors = reader.GetValue<bool>(5);
                parameter.IsAutoReset = reader.GetValue<bool>(6);
                parameter.DeviceTypeId = reader.GetValue<int>(7);
                // TODO:
                // parameter.DeviceTypeName = reader.GetValue<string>(8);

                parameter.GroupId = reader.GetValue<int>(9);
                parameter.GroupName = reader.GetValue<string>(10);

                var value = new DeviceUpdateValue();

                value.Id = reader.GetValue<int>(11);
                value.ParameterId = parameter.Id;

                if (value.Id > 0)
                {
                
                    value.Value = reader.GetValue<string>(12);

                    value.IsReset = reader.GetValue<bool?>(13);
                    value.ResetTime = reader.GetValue<DateTime?>(14);
                    value.ModifiedTime = reader.GetValue<DateTime?>(15);
                    value.CustomerId = reader.GetValue<int?>(16);
                    value.DeviceId = reader.GetValue<string>(17);
                    parameter.Values.Add(value);
                }
            }


            return parameter.Id > 0 ? parameter : null;
        }

        protected override DbCommand CreateReadCommand(DbConnection connection, IPropertyBag searchParameters)
        {
            var command = base.CreateReadCommand(connection, searchParameters);

            command.CommandText = "Select * From [dbo].[DeviceParameterMetadata] As [dpm]" + this.CreatePredicate(searchParameters);
            command.CommandType = CommandType.Text;

            return command;
        }

        private string CreatePredicate(IPropertyBag searchParameters)
        {
            var predicate = string.Empty;

            if (searchParameters != null)
            {
                var searchCriteria = searchParameters is DeviceSearchParameters
                    ? searchParameters as DeviceSearchParameters
                    : new DeviceSearchParameters(searchParameters);

                var predicateBuilder = new StringBuilder();


                if (searchCriteria.CustomerId > 0)
                {
                    predicateBuilder.Append(" And ([dpm].[CustomerId] Is Null Or [dpm].[CustomerId] = ");
                    predicateBuilder.Append(searchCriteria.CustomerId);
                    predicateBuilder.Append(")");
                }
                if (searchCriteria.DeviceTypeId > 0)
                {
                    predicateBuilder.Append(" And [dpm].[DeviceTypeId] = ");
                    predicateBuilder.Append(searchCriteria.DeviceTypeId);
                }
                if (!string.IsNullOrWhiteSpace(searchCriteria.DeviceId))
                {
                    predicateBuilder.Append(" And ([dpm].[DeviceId] Is Null Or [dpm].[DeviceId] = '");
                    predicateBuilder.Append(searchCriteria.DeviceId);
                    predicateBuilder.Append("')");
                }
                if (!string.IsNullOrWhiteSpace(searchCriteria.DeviceType))
                {
                    predicateBuilder.Append(" And [dpm].[DeviceTypeName] = '");
                    predicateBuilder.Append(searchCriteria.DeviceType);
                    predicateBuilder.Append("'");
                }

                if (predicateBuilder.Length > 0)
                {
                    predicateBuilder.Remove(0, 5);
                    predicateBuilder.Insert(0, " Where ");
                }

                predicate = predicateBuilder.ToString();
                predicateBuilder.Clear();
            }

            return predicate;
        }


        //public IEnumerable<DeviceUpdateParameter> GetAll(DeviceSearchParameters searchParameters)
        //{
        //    return this.GetAll(searchParameters as IPropertyBag);
        //}
    }
}
