﻿
namespace KC.SmartWashroom.DataAccess.Repository
{
    using KC.SmartWashroom.Core;
    using KC.SmartWashroom.DataAccess.Skeleton;
    using System.Collections.Generic;
    using System.Data.Common;

    public abstract class DbDataRepository<T> : IDataRepository<T> where T : class
    {
        public DbDataRepository()
        {

        }

        public IEnumerable<T> GetAll(IPropertyBag searchParameters)
        {
            using (this.Connection = this.GetConnection())
            {
                using (var command = this.CreateReadCommand(this.Connection, searchParameters))
                {
                    this.Connection.Open();
                    using (var reader = command.ExecuteReader())
                    {

                        while (reader.Read())
                        {
                            var instance = this.ReadAsObject(reader);
                            if (instance != null)
                            {
                                yield return instance;
                            }
                        }
                    }
                }
            }
            this.Connection = null;
            yield break;
        }

        protected abstract T ReadAsObject(DbDataReader reader);

        protected virtual DbCommand CreateReadCommand(DbConnection connection, IPropertyBag searchParameters)
        {
            return connection.CreateCommand();
        }

        protected abstract DbConnection GetConnection();

        protected DbConnection Connection { get; set; }

        private void Dispose()
        {
            if (this.Connection != null)
            {
                this.Connection.Dispose();
                this.Connection = null;
            }

            this.Dispose(true);
        }

        protected virtual void Dispose(bool disposing)
        {
        }       

        void System.IDisposable.Dispose()
        {
            this.Dispose();
        }
    }
}
