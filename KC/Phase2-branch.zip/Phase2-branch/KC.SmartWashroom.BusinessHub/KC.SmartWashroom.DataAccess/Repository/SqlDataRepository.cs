﻿
namespace KC.SmartWashroom.DataAccess.Repository
{
    using KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers;
    using System;
    using System.Data.Common;
    using System.Data.Entity.Core.EntityClient;
    using System.Data.SqlClient;
    public abstract class SqlDataRepository<T> : DbDataRepository<T> where T : class
    {
        public SqlDataRepository(string connectionString = null)
            : base()
        {
            var proessedConnectionString = string.IsNullOrWhiteSpace(connectionString)
                ? EntityRepositoryManager.connectionString
                : connectionString;

            // entity connection string
            if (proessedConnectionString.StartsWith("metadata=", StringComparison.OrdinalIgnoreCase)
                || proessedConnectionString.IndexOf(".msl", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                var entityConnectionString = new EntityConnectionStringBuilder(proessedConnectionString);
                proessedConnectionString = entityConnectionString.ProviderConnectionString;
                
            }

            this.ConnectionString = proessedConnectionString;

        }

        protected override DbConnection GetConnection()
        {
            // TODO: Connection resiliency, retry
            return !string.IsNullOrWhiteSpace(this.ConnectionString)
                ? new SqlConnection(this.ConnectionString)
                : new SqlConnection();
        }

        public string ConnectionString { get; protected set; }
    }
}
