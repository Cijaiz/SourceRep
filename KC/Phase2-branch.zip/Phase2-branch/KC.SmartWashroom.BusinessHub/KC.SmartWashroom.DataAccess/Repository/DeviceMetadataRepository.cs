﻿
namespace KC.SmartWashroom.DataAccess.Repository
{
    using KC.SmartWashroom.BusinessEntities.DeviceUpdate;
    using KC.SmartWashroom.BusinessEntities.Search;
    using KC.SmartWashroom.Core;
    using KC.SmartWashroom.DataAccess.Extensions;
    using KC.SmartWashroom.DataAccess.Skeleton;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Text;

    public class DeviceMetadataRepository : SqlDataRepository<DeviceUpdateDetails> //, IDeviceDataRepository<DeviceUpdateDetails>
    {
        public DeviceMetadataRepository(string connectionString = null)
            : base(connectionString)
        {

        }
        protected override DeviceUpdateDetails ReadAsObject(DbDataReader reader)
        {
            var metadata = new DeviceUpdateDetails();

            metadata.CustomerId = reader.GetValue<int>(0);
            metadata.CustomerName = reader.GetValue<string>(1);
            metadata.PropertyId = reader.GetValue<int>(2);
            metadata.PropertyName = reader.GetValue<string>(3);
            metadata.BuildingId = reader.GetValue<int>(4);
            metadata.BuildingName = reader.GetValue<string>(5);
            metadata.FloorSectionId = reader.GetValue<int>(6);
            metadata.FloorSectionName = reader.GetValue<string>(7);
            metadata.FloorId = reader.GetValue<int>(8);
            metadata.FloorLevel = reader.GetValue<short>(9);
            metadata.RestroomTypeId = reader.GetValue<int>(10);
            metadata.RestroomTypeName = reader.GetValue<string>(11);
            metadata.RestroomId = reader.GetValue<int>(12);
            metadata.RestroomName = reader.GetValue<string>(13);
            metadata.DeviceTypeId = reader.GetValue<int>(14);
            metadata.DeviceTypeName = reader.GetValue<string>(15);
            metadata.DeviceId = reader.GetValue<string>(16);
            metadata.DeviceName = reader.GetValue<string>(17);

            return !string.IsNullOrWhiteSpace(metadata.DeviceId) ?  metadata : null;
        }

        protected override DbCommand CreateReadCommand(DbConnection connection, IPropertyBag searchParameters)
        {
            var command = base.CreateReadCommand(connection, searchParameters);

            string predicate = this.CreatePredicate(searchParameters);

            command.CommandText = "Select * From [dbo].[DeviceMetadata] As [dm]" + predicate;

            command.CommandType = CommandType.Text;

            return command;

        }

        private string CreatePredicate(IPropertyBag searchParameters)
        {
            var predicate = string.Empty;

            if (searchParameters != null)
            {
                var searchCriteria = searchParameters is DeviceSearchParameters
                    ? searchParameters as DeviceSearchParameters
                    : new DeviceSearchParameters(searchParameters);

                var predicateBuilder = new StringBuilder();


                if (searchCriteria.CustomerId > 0)
                {
                    predicateBuilder.Append(" And [dm].[CustomerId] = ");
                    predicateBuilder.Append(searchCriteria.CustomerId);
                }
                if (searchCriteria.DeviceTypeId > 0)
                {
                    predicateBuilder.Append(" And [dm].[DeviceTypeId] = ");
                    predicateBuilder.Append(searchCriteria.DeviceTypeId);
                }
                if (!string.IsNullOrWhiteSpace(searchCriteria.DeviceId))
                {
                    predicateBuilder.Append(" And [dm].[DeviceId] = '");
                    predicateBuilder.Append(searchCriteria.DeviceId);
                    predicateBuilder.Append("'");
                }
                if (!string.IsNullOrWhiteSpace(searchCriteria.DeviceType))
                {
                    predicateBuilder.Append(" And [dm].[DeviceTypeName] = '");
                    predicateBuilder.Append(searchCriteria.DeviceType);
                    predicateBuilder.Append("'");
                }

                if (predicateBuilder.Length > 0)
                {
                    predicateBuilder.Remove(0, 5);
                    predicateBuilder.Insert(0, " Where ");
                }

                predicate = predicateBuilder.ToString();
                predicateBuilder.Clear();
            }

            return predicate;
        }

        //public IEnumerable<DeviceUpdateDetails> GetAll(DeviceSearchParameters searchParameters)
        //{
        //    return this.GetAll(searchParameters as IPropertyBag);
        //}
    }
}
