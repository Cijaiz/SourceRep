﻿

namespace KC.SmartWashroom.DataAccess.Extensions
{
    using System;
    using System.Data.Common;
    public static class DbDataReaderExtensions
    {
        /// <summary>
        /// Reads the values null safe and type safe
        /// </summary>
        /// <typeparam name="TValue">The return data type. Only primitive data types alone are supported</typeparam>
        /// <param name="reader">The instance of the DbDataReader</param>
        /// <param name="index">The index of the parameter</param>
        /// <returns>The converted instance, if found, else default value</returns>
        /// <remarks>Primitive types are only supported</remarks>
        public static TValue GetValue<TValue>(this DbDataReader reader, int index)
        {
            var value = default(TValue);

            if (reader != null && index >= 0)
            {
                var obj = reader.GetValue(index);

                if (obj != null && !(obj is DBNull))
                {
                    value = typeof(TValue).IsAssignableFrom(obj.GetType())
                        ? (TValue)obj
                        : (TValue)Convert.ChangeType(obj, typeof(TValue));

                }
            }

            return value;
        }
    }
}
