﻿using KC.SmartWashroom.BusinessEntities.DashboardApiEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.Enumerations;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.DataAccess.Skeleton;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers
{
    public class PropertyWorker : IPropertyWorker
    {
        private string _errorDetail;

        string IPropertyWorker.ErrorDetail
        {
            get { return _errorDetail; }
            set { _errorDetail = value; }
        }

        public void CreateProperty(BusinessEntities.Property property)
        {
            throw new NotImplementedException();
        }

        public BusinessEntities.Property GetProperty(int propertyID)
        {
            BusinessEntities.Property response = new BusinessEntities.Property();

            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                var properties = dbEntity.Set<Property>();
                var property = dbEntity.Properties.Where(_property => _property.ID == propertyID && _property.IsActive == true).SingleOrDefault<Property>();
                response.AddressId = property.AddressId;
                response.CustomerId = property.CustomerId;
                response.ID = property.ID;

                response.ImageUrl = property.ImageUrl;
                response.PropertyName = property.PropertyName;
                response.State = property.Address.State;
                int addressId = property.Customer.AddressId;
                if (addressId == property.AddressId)
                    response.IsCustomerAddress = true;
                else
                    response.IsCustomerAddress = false;

                response.Street = property.Address.Street;
                response.City = property.Address.City;
                response.CountryId = property.Address.CountryId;
                response.Zip = property.Address.Zip;
                response.TimeZone = property.LocationTimeZone;
                response.JobInterval = property.JobInterval;
                response.Customer = new BusinessEntities.TenantApiEntities.CustomerDetail();
                response.Customer.Street = property.Customer.Address.Street;
                response.Customer.City = property.Customer.Address.City;
                response.Customer.State = property.Customer.Address.State;
                response.Customer.Pincode = property.Customer.Address.Zip;
                response.Customer.CountryId = property.Customer.Address.CountryId;
                response.Customer.CustomerName = property.Customer.Name;

                var buildings = (from dbbuilding in dbEntity.Buildings
                                 where dbbuilding.PropertyId == propertyID && dbbuilding.IsActive!=false
                                 select new BusinessEntities.Building
                                 {
                                     ID = dbbuilding.ID,
                                     Name = dbbuilding.Name
                                 }
                                   ).ToList();

                response.Buildings = buildings;
            }

            return response;

        }

        public ProcessResponse<BusinessEntities.Property> Create(BusinessEntities.Property propertyEntity)
        {
            ProcessResponse<BusinessEntities.Property> response = new ProcessResponse<BusinessEntities.Property>();
            int AddressId = 0;
            Property property = new Property();
            Address address = new Address();
            try
            {
                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    if (propertyEntity.IsCustomerAddress)
                    {
                        var customerDetails = (from Customers in dbEntity.Customers
                                               where Customers.ID.Equals(propertyEntity.CustomerId)
                                               select Customers).FirstOrDefault();
                        if (customerDetails != null)
                            AddressId = customerDetails.AddressId;
                    }
                    else
                    {
                        var addressContext = dbEntity.Set<Address>();

                        address.City = propertyEntity.City;
                        address.CountryId = propertyEntity.CountryId;
                        address.State = propertyEntity.State;

                        address.Street = propertyEntity.Street;
                        address.Zip = propertyEntity.Zip;
                       // address.BuildingAddress = "Test";

                        addressContext.Add(address);
                        dbEntity.SaveChanges();
                        AddressId = address.ID;
                    }

                    var properties = dbEntity.Set<Property>();

                    property.PropertyName = propertyEntity.PropertyName;
                    if (propertyEntity.ImageUrl != null)
                        property.ImageUrl = propertyEntity.ImageUrl;
                    else
                        property.ImageUrl = string.Empty;
                    property.IsActive = true;

                    property.AddressId = AddressId;
                    property.CustomerId = propertyEntity.CustomerId;
                    property.CreatedBy = propertyEntity.CreatedBy;

                    property.CreatedOn = propertyEntity.CreatedDate;
                    property.LastUpdatedBy = propertyEntity.CreatedBy;
                    property.LastUpdatedOn = propertyEntity.CreatedDate;
                    //StringBuilder builder = new StringBuilder(100);

                    //foreach (char c in propertyEntity.TimeZone)
                    //{
                    //    if (char.IsUpper(c))
                    //        builder.Append(c);
                    //}
                    property.LocationTimeZone = propertyEntity.TimeZone;
                    property.JobInterval = propertyEntity.JobInterval;

                    properties.Add(property);
                    dbEntity.SaveChanges();
                }

                response.Status = ResponseStatus.Success;
                response.Message = AlertEngineConstants.MESSAGE_SUCCESS;
                response.Object = new BusinessEntities.Property { ID = property.ID, PropertyName = property.PropertyName };
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.Failed;
                response.Message = ex.Message;
            }

            return response;
        }

        public ProcessResponse<BusinessEntities.Property> Update(BusinessEntities.Property propertyEntity)
        {
            ProcessResponse<BusinessEntities.Property> response = new ProcessResponse<BusinessEntities.Property>();
            int AddressId = 0;
            Address address = new Address();
            try
            {
                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {

                    var property = (from properties in dbEntity.Properties
                                    where properties.ID == propertyEntity.ID && properties.IsActive == true
                                    select properties).FirstOrDefault();
                    if (property != null)
                    {
                        if (propertyEntity.IsCustomerAddress)
                        {
                            AddressId = (from customers in dbEntity.Customers
                                         where customers.ID == propertyEntity.CustomerId
                                         select customers.AddressId).FirstOrDefault();
                        }
                        else
                        {
                            var addressContext = dbEntity.Set<Address>();

                            address.City = propertyEntity.City;
                            address.CountryId = propertyEntity.CountryId;
                            address.State = propertyEntity.State;
                            address.Street = propertyEntity.Street;
                            address.Zip = propertyEntity.Zip;

                            //address.BuildingAddress = "Test";

                            addressContext.Add(address);
                            dbEntity.SaveChanges();
                            AddressId = address.ID;
                        }
                        property.PropertyName = propertyEntity.PropertyName;
                        if (propertyEntity.ImageUrl != null)
                            property.ImageUrl = propertyEntity.ImageUrl;

                        property.AddressId = AddressId;
                        property.CustomerId = propertyEntity.CustomerId;
                        property.LastUpdatedBy = propertyEntity.LastUpdatedBy;

                        property.LastUpdatedOn = propertyEntity.LastUpdatedOn;
                        property.LocationTimeZone = propertyEntity.TimeZone;
                        property.JobInterval = propertyEntity.JobInterval;
                        dbEntity.SaveChanges();
                    }
                    response.Status = ResponseStatus.Success;
                    response.Message = AlertEngineConstants.MESSAGE_SUCCESS;
                    return response;
                }

            }

            catch (Exception ex)
            {
                response.Status = ResponseStatus.Failed;
                response.Message = ex.Message;
                return response;
            }

        }

        public ProcessResponse<BusinessEntities.Property> Delete(int propertyID)
        {
            ProcessResponse<BusinessEntities.Property> response = new ProcessResponse<BusinessEntities.Property>();

            try
            {
                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    var Property = (from properties in dbEntity.Properties
                                    where properties.ID == propertyID
                                    select properties
                                  ).FirstOrDefault();
                    if (Property != null)
                    {
                        Property.IsActive = false;
                        Property.Buildings.ToList().ForEach(s => s.IsActive=false);
                        dbEntity.SaveChanges();
                    }
                }
                response.Status = ResponseStatus.Success;
                response.Message = AlertEngineConstants.MESSAGE_REMOVE_SUCCESS;
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.Failed;
                response.Message = ex.Message;
            }
            return response;
        }

        public IList<PropertyAlert> GetAllProperties(int customerId,int userId, int duration)
        {
            IList<PropertyAlert> response = new List<PropertyAlert>();
            DateTime LastDate = DateTime.UtcNow.AddHours(-duration);
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                var RoleLevel = dbEntity.Set<User>().Where(user => user.ID.Equals(userId)).Select(x=> x.Role.RoleLevel).First();
                if (RoleLevel.Equals((byte)Enums.RoleLevelType.PortalAdmin) || RoleLevel.Equals((byte)Enums.RoleLevelType.CustomerAdmin))
                {
                    var properties = dbEntity.Set<Property>().Where(prop => prop.CustomerId.Equals(customerId) && prop.IsActive.Equals(true));

                    foreach (var property in properties)
                    {
                        PropertyAlert propertyAlertEntity = new PropertyAlert();
                        propertyAlertEntity.ID = property.ID;
                        propertyAlertEntity.ImageUrl = property.ImageUrl;

                        propertyAlertEntity.PropertyName = property.PropertyName;

                        var alertDetails = (from deviceAlert in dbEntity.DeviceAlerts
                                            join deviceWashroom in dbEntity.DeviceWashrooms on deviceAlert.DeviceId equals deviceWashroom.DeviceId
                                            join device in dbEntity.Devices on deviceWashroom.DeviceId equals device.ID
                                            join washroom in dbEntity.Washrooms on deviceWashroom.WashroomId equals washroom.ID
                                            join floors in dbEntity.Floors on washroom.FloorId equals floors.ID
                                            join building in dbEntity.Buildings on floors.BuildingId equals building.ID
                                            join dbproperty in dbEntity.Properties on building.PropertyId equals dbproperty.ID
                                            where dbproperty.ID.Equals(property.ID) && dbproperty.IsActive == true && device.IsActive.Equals(true) && floors.IsActive.Equals(true)
                                            && building.IsActive.Equals(true) && deviceWashroom.IsActive==true
                                            && ((duration>0)? deviceAlert.ReceivedOn >= LastDate : true)
                                            select new
                                            {
                                                deviceAlert.DeviceId
                                            }).ToList();

                        propertyAlertEntity.AlertCount = alertDetails.Count;
                        response.Add(propertyAlertEntity);
                    }
                }
                else if (RoleLevel.Equals((byte)Enums.RoleLevelType.BuildingAdmin))
                {
                    var properties = dbEntity.Set<Property>().Where(prop => prop.CustomerId.Equals(customerId) && prop.IsActive.Equals(true));

                    foreach (var property in properties)
                    {
                        PropertyAlert propertyAlertEntity = new PropertyAlert();
                        propertyAlertEntity.ID = property.ID;
                        propertyAlertEntity.ImageUrl = property.ImageUrl;

                        propertyAlertEntity.PropertyName = property.PropertyName;

                        var alertDetails = (from deviceAlert in dbEntity.DeviceAlerts
                                            join deviceWashroom in dbEntity.DeviceWashrooms on deviceAlert.DeviceId equals deviceWashroom.DeviceId
                                            join device in dbEntity.Devices on deviceWashroom.DeviceId equals device.ID
                                            join washroom in dbEntity.Washrooms on deviceWashroom.WashroomId equals washroom.ID
                                            join floors in dbEntity.Floors on washroom.FloorId equals floors.ID
                                            join building in dbEntity.Buildings on floors.BuildingId equals building.ID
                                            join userBuilding in dbEntity.UserBuildings on building.ID equals userBuilding.BuildingId
                                            join dbproperty in dbEntity.Properties on building.PropertyId equals dbproperty.ID
                                            where dbproperty.ID.Equals(property.ID) && dbproperty.IsActive == true && device.IsActive.Equals(true) && floors.IsActive.Equals(true)
                                            && building.IsActive.Equals(true) && userBuilding.UserId.Equals(userId) && washroom.IsActive.Equals(true) && deviceWashroom.IsActive == true
                                            && ((duration > 0) ? deviceAlert.ReceivedOn >= LastDate : true)
                                            select new
                                            {
                                                deviceAlert.DeviceId
                                            }).ToList();

                        propertyAlertEntity.AlertCount = alertDetails.Count;
                        response.Add(propertyAlertEntity);
                    }
                }
                else if (RoleLevel.Equals((byte)Enums.RoleLevelType.PropertyAdmin))
                {
                    var properties = dbEntity.Set<Property>().Where(prop => prop.CustomerId.Equals(customerId) && prop.IsActive.Equals(true));

                    foreach (var property in properties)
                    {
                        PropertyAlert propertyAlertEntity = new PropertyAlert();
                        propertyAlertEntity.ID = property.ID;
                        propertyAlertEntity.ImageUrl = property.ImageUrl;

                        propertyAlertEntity.PropertyName = property.PropertyName;

                        var alertDetails = (from deviceAlert in dbEntity.DeviceAlerts
                                            join deviceWashroom in dbEntity.DeviceWashrooms on deviceAlert.DeviceId equals deviceWashroom.DeviceId
                                            join device in dbEntity.Devices on deviceWashroom.DeviceId equals device.ID
                                            join washroom in dbEntity.Washrooms on deviceWashroom.WashroomId equals washroom.ID
                                            join floors in dbEntity.Floors on washroom.FloorId equals floors.ID
                                            join building in dbEntity.Buildings on floors.BuildingId equals building.ID
                                            join dbproperty in dbEntity.Properties on building.PropertyId equals dbproperty.ID
                                            join userProperty in dbEntity.UserProperties on dbproperty.ID equals userProperty.PropertyId
                                            where dbproperty.ID.Equals(property.ID) && dbproperty.IsActive == true && device.IsActive.Equals(true) && floors.IsActive.Equals(true)
                                            && building.IsActive.Equals(true) && userProperty.UserId.Equals(userId) && deviceWashroom.IsActive==true
                                            && ((duration > 0) ? deviceAlert.ReceivedOn >= LastDate : true)
                                            select new
                                            {
                                                deviceAlert.DeviceId
                                            }).ToList();

                        propertyAlertEntity.AlertCount = alertDetails.Count;
                        response.Add(propertyAlertEntity);
                    }
                }
                dbEntity.SaveChanges();
            }
            return response;
        }

        public string GetCustomerNameByID(int Id)
        {
            string Name = "";
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
               Name = dbEntity.Set<Customer>().Where(customer => customer.ID.Equals(Id) && customer.IsActive.Equals(true)).Single().Name;
            }
            return Name;
        }

        public List<Timezone> GetAllTimezones()
        {
            List<Timezone> timezones = null;
            try
            {
                using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                {
                    timezones = new List<Timezone>();
                    timezones = (from timezone in dbContext.TimeZones
                                    select new BusinessEntities.TenantApiEntities.Timezone
                                    {
                                        ID = timezone.ID,
                                        TimezoneName = timezone.Name
                                    }).ToList();
                    return timezones;
                }
            }
            catch (Exception dataException)
            {
                _errorDetail = dataException.Message;
                return timezones;

            }
        }
    }
}
