﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.DataAccess.Skeleton;
using System;
using System.Collections.Generic;
using System.Linq;

namespace KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers
{
    public class AzureSchedulerAuditWorker : IAzureSchedulerAuditWorker
    {
        public ProcessResponse InsertUpdateJob(AzureSchedulerLog Scheduler)
        {
            ProcessResponse response = new ProcessResponse();
            List<AzureSchedulerAudit> ListOldJobs = new List<AzureSchedulerAudit>();

            try
            {
                using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                {
                    //Check if any other jobs for same PropertyId already exists in database
                    ListOldJobs = (from scheduler in dbContext.AzureSchedulerAudits
                                   where scheduler.PropertyId == Scheduler.PropertyId && scheduler.IsActive == true
                                   select scheduler).ToList();
                    //Update the IsActive as false for old jobs
                    ListOldJobs.ForEach(o => o.IsActive = false);
                    //Insert new record
                    AzureSchedulerAudit dbScheduler = new AzureSchedulerAudit();
                    dbScheduler.SchedulerJobId = Scheduler.JobId;
                    dbScheduler.PropertyId = Scheduler.PropertyId;
                    dbScheduler.IsActive = true;
                    dbContext.AzureSchedulerAudits.Add(dbScheduler);
                    dbContext.SaveChanges();

                    //get customer details by id
                    //var CustomerDetail = (from CusDetails in dbContext.Customers
                    //                      where CusDetails.ID == Scheduler.CustomerId
                    //                      select CusDetails).FirstOrDefault();

                    // set the aggregation status as completed for one day before the customer was created
                    AggregationStatu dbAggregation = new AggregationStatu();
                    dbAggregation.PropertyId = Scheduler.PropertyId;
                    dbAggregation.Status = "Complete";
                    dbAggregation.ProcessedDate = DateTime.UtcNow.Date.AddDays(-1);

                    dbContext.AggregationStatus.Add(dbAggregation);
                    dbContext.SaveChanges();

                    response.Status = ResponseStatus.Success;
                    response.RefId = dbScheduler.Id;
                    response.Message = AlertEngineConstants.MESSAGE_SUCCESS;

                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.Error;
                response.Message = ex.Message;
            }
            return response;
        }

        public AzureSchedulerLog GetJob(int PropertyId)
        {
            AzureSchedulerLog Scheduler = new AzureSchedulerLog();
            try
            {
                using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                {
                    var Schedule = (from scheduler in dbContext.AzureSchedulerAudits
                                    where scheduler.PropertyId == PropertyId && scheduler.IsActive == true
                                    select scheduler).FirstOrDefault();
                    if (Schedule != null)
                    {
                        Scheduler.PropertyId = Schedule.PropertyId;
                        Scheduler.JobId = Schedule.SchedulerJobId;
                    }
                }
            }
            catch
            {

            }
            return Scheduler;
        }

        public ProcessResponse DeleteJob(int PropertyId)
        {
            ProcessResponse response = new ProcessResponse();

            try
            {
                using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                {
                    var Scheduler = (from scheduler in dbContext.AzureSchedulerAudits
                                     where scheduler.PropertyId == PropertyId
                                     select scheduler).FirstOrDefault();
                    if (Scheduler != null)
                    {
                        Scheduler.IsActive = false;
                        dbContext.SaveChanges();
                    }
                    response.Status = ResponseStatus.Success;
                    response.Message = AlertEngineConstants.MESSAGE_SUCCESS;
                    response.RefId = PropertyId;

                    return response;
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.Error;
                response.Message = ex.Message;
            }
            return response;
        }

    }
}
