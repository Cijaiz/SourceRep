﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers
{
    public partial class SmartWashroomEntities : DbContext
    {
        /// <summary>
        /// Initialize a new SmartWashroomEntities object.
        /// </summary>
        public SmartWashroomEntities(string connectionString)
            : base(connectionString)
        {
        }
    }
}
