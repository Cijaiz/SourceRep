﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.DataAccess.Skeleton;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers
{
    public class AlertMartWorker : IAlertMartWorker
    {
        public List<ReportGenericEntity> GetAlertDataWeekwise(ReportFilterEntity FilterValues)
        {
            List<ReportGenericEntity> newReportGenList = new List<ReportGenericEntity>();
            List<string> Days = new List<string>();
            List<string> AlertTypes = new List<string>();
            try
            {
                TimeZoneInfo PropTimeZoneInfo = GetPropertyTimezone(Convert.ToInt32(FilterValues.PropertyId));
                DateTime StartDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)FilterValues.StartDate, PropTimeZoneInfo);
                DateTime EndDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)FilterValues.EndDate, PropTimeZoneInfo);

                //Get All alert types from dataabse
                AlertTypes = GetAllAlertTypes();

                //Get all Days                
                Days = CommonHelper.GetDaysForWeek(StartDate, EndDate);

                //Get AlertType and Day combined data
                var ListAlertTypeDays = (from alertType in AlertTypes
                                         from day in Days
                                         select new
                                         {
                                             AlertDayOfWeek = day,
                                             AlertType = alertType
                                         }).ToList();

                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    var alertMart = dbEntity.Set<AlertMart>().ToList();
                    var alerts = (from a in alertMart
                                  where a.CustomerId == FilterValues.CustomerId &
                                  (FilterValues.PropertyId != "0" ? a.PropertyId == FilterValues.PropertyId : true) &
                                  (FilterValues.BuildingId != "0" ? a.BuildingId == FilterValues.BuildingId : true) &
                                  (FilterValues.FloorId != "0" ? a.FloorId == FilterValues.FloorId : true) &
                                  (FilterValues.RoomId != "0" ? a.WashRoomId == FilterValues.RoomId : true) &
                                  (FilterValues.StartDate != null ? a.AlertDate >= FilterValues.StartDate : true) &
                                  (FilterValues.EndDate != null ? a.AlertDate <= FilterValues.EndDate : true) &
                                  (FilterValues.Month != "0" ? a.AlertMonth == FilterValues.Month : true) &
                                  (FilterValues.Year != 0 ? a.AlertYear == FilterValues.Year : true)
                                  orderby a.AlertDate ascending
                                  group a by new
                                  {
                                      a.AlertDayOfWeek,
                                      a.AlertType
                                  } into a1
                                  select new
                                  {
                                      a1.Key.AlertDayOfWeek,
                                      a1.Key.AlertType,
                                      CountOfAlerts = a1.Sum(x => x.CountOfAlert)
                                  }).ToList();

                    var finalData = (from alertTypeDay in ListAlertTypeDays
                                     join data in alerts
                                         on new { Col1 = alertTypeDay.AlertDayOfWeek, Col2 = alertTypeDay.AlertType }
                                         equals new { Col1 = data.AlertDayOfWeek, Col2 = data.AlertType }
                                     into joinedData
                                     from report in joinedData.DefaultIfEmpty()
                                     select new
                                     {
                                         AlertDayOfWeek = alertTypeDay.AlertDayOfWeek,
                                         AlertType = alertTypeDay.AlertType,
                                         CountOfAlerts = report != null ? report.CountOfAlerts : 0
                                     }).ToList();

                    foreach (var alert in finalData)
                    {
                        ReportGenericEntity newEntity = new ReportGenericEntity();
                        newEntity[AlertChartConstants.XAxisWeek.ToString()] = alert.AlertDayOfWeek;
                        newEntity[AlertChartConstants.SecondaryAxis.ToString()] = alert.AlertType;
                        newEntity[AlertChartConstants.YAxis.ToString()] = alert.CountOfAlerts;
                        newReportGenList.Add(newEntity);
                    }
                }
            }
            catch
            {
                throw new Exception();
            }

            return newReportGenList;
        }

        public List<ReportGenericEntity> GetAlertDataMonthwise(ReportFilterEntity FilterValues)
        {
            List<ReportGenericEntity> newReportGenList = new List<ReportGenericEntity>();
            List<string> AlertTypes = new List<string>();
            List<string> Dates = new List<string>();
            try
            {
                //Get All alert types from dataabse
                AlertTypes = GetAllAlertTypes();
                //Check the filter, if it is for this month or last month
                if (FilterValues.PeriodId.Equals(CommonConstants.FilterThisMonth))
                {
                    Dates = CommonHelper.GetDatesThisMonth(GetPropertyTimezone(Convert.ToInt32(FilterValues.PropertyId)));
                }
                else if (FilterValues.PeriodId.Equals(CommonConstants.FilterLastMonth))
                {
                    Dates = CommonHelper.GetDatesLastMonth(GetPropertyTimezone(Convert.ToInt32(FilterValues.PropertyId)));
                }
                else
                {
                    Dates = CommonHelper.GetDatesForMonth(FilterValues.Month, FilterValues.Year, GetPropertyTimezoneFromBuilding(Convert.ToInt32(FilterValues.BuildingId)));
                }

                //Get AlertType and Day combined data
                var ListAlertTypeDays = (from alertType in AlertTypes
                                         from day in Dates
                                         select new
                                         {
                                             AlertDay = day,
                                             AlertType = alertType
                                         }).ToList();
                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    var alertMart = dbEntity.Set<AlertMart>().ToList();
                    var alerts = (from a in alertMart
                                  where a.CustomerId == FilterValues.CustomerId &
                                  (FilterValues.PropertyId != "0" ? a.PropertyId == FilterValues.PropertyId : true) &
                                  (FilterValues.BuildingId != "0" ? a.BuildingId == FilterValues.BuildingId : true) &
                                  (FilterValues.FloorId != "0" ? a.FloorId == FilterValues.FloorId : true) &
                                  (FilterValues.RoomId != "0" ? a.WashRoomId == FilterValues.RoomId : true) &
                                  (FilterValues.StartDate != null ? a.AlertDate >= FilterValues.StartDate : true) &
                                  (FilterValues.EndDate != null ? a.AlertDate <= FilterValues.EndDate : true) &
                                  (FilterValues.Month != "0" ? a.AlertMonth == FilterValues.Month : true) &
                                  (FilterValues.Year != 0 ? a.AlertYear == FilterValues.Year : true)
                                  orderby a.AlertDate ascending
                                  group a by new
                                  {
                                      a.AlertDay,
                                      a.AlertType
                                  } into a1
                                  select new
                                  {
                                      a1.Key.AlertDay,
                                      a1.Key.AlertType,
                                      CountOfAlerts = a1.Sum(x => x.CountOfAlert)
                                  }).ToList();

                    var finalData = (from alertTypeDay in ListAlertTypeDays
                                     join data in alerts
                                         on new { Col1 = alertTypeDay.AlertDay, Col2 = alertTypeDay.AlertType }
                                         equals new { Col1 = data.AlertDay.ToString(), Col2 = data.AlertType }
                                     into joinedData
                                     from report in joinedData.DefaultIfEmpty()
                                     select new
                                     {
                                         AlertDay = alertTypeDay.AlertDay,
                                         AlertType = alertTypeDay.AlertType,
                                         CountOfAlerts = report != null ? report.CountOfAlerts : 0
                                     }).ToList();

                    foreach (var alert in finalData)
                    {
                        ReportGenericEntity newEntity = new ReportGenericEntity();
                        newEntity[AlertChartConstants.XAxisMonth.ToString()] = alert.AlertDay;
                        newEntity[AlertChartConstants.SecondaryAxis.ToString()] = alert.AlertType;
                        newEntity[AlertChartConstants.YAxis.ToString()] = alert.CountOfAlerts;
                        newReportGenList.Add(newEntity);
                    }
                }
            }
            catch
            {
                throw new Exception();
            }

            return newReportGenList;
        }

        public List<ReportGenericEntity> GetAlertSummaryData(ReportFilterEntity FilterValues)
        {
            List<ReportGenericEntity> newReportGenList = new List<ReportGenericEntity>();
            List<string> AlertTypes = new List<string>();
            try
            {
                //Get All alert types from dataabse
                AlertTypes = GetAllAlertTypes();
                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    var alertMart = dbEntity.Set<AlertMart>().ToList();
                    var alerts = (from a in alertMart
                                  where a.CustomerId == FilterValues.CustomerId &
                                  (FilterValues.PropertyId != "0" ? a.PropertyId == FilterValues.PropertyId : true) &
                                  (FilterValues.BuildingId != "0" ? a.BuildingId == FilterValues.BuildingId : true) &
                                  (FilterValues.FloorId != "0" ? a.FloorId == FilterValues.FloorId : true) &
                                  (FilterValues.RoomId != "0" ? a.WashRoomId == FilterValues.RoomId : true) &
                                  (FilterValues.StartDate != null ? a.AlertDate >= FilterValues.StartDate : true) &
                                  (FilterValues.EndDate != null ? a.AlertDate <= FilterValues.EndDate : true) &
                                  (FilterValues.Month != "0" ? a.AlertMonth == FilterValues.Month : true) &
                                  (FilterValues.Year != 0 ? a.AlertYear == FilterValues.Year : true)
                                  orderby a.AlertDate ascending
                                  group a by new
                                  {
                                      a.AlertType
                                  } into a1
                                  select new
                                  {
                                      a1.Key.AlertType,
                                      Month = "Month",
                                      CountOfAlerts = a1.Sum(x => x.CountOfAlert)
                                  }).ToList();

                    var finalData = (from type in AlertTypes
                                     join data in alerts
                                         on type equals data.AlertType into joinedData
                                     from report in joinedData.DefaultIfEmpty()
                                     select new
                                     {
                                         AlertType = type,
                                         Month = "Month",
                                         CountOfAlerts = report != null ? report.CountOfAlerts : 0
                                     }).ToList();

                    foreach (var alert in finalData)
                    {
                        ReportGenericEntity newEntity = new ReportGenericEntity();
                        newEntity[AlertChartConstants.SecondaryAxis.ToString()] = alert.AlertType;
                        newEntity[AlertChartConstants.ProductSummaryMonth.ToString()] = alert.Month;
                        newEntity[AlertChartConstants.YAxis.ToString()] = alert.CountOfAlerts;
                        newReportGenList.Add(newEntity);
                    }
                }
            }
            catch
            {
                throw new Exception();
            }

            return newReportGenList;
        }

        public StoryboardReportEntity GetStoryBoardData(ReportFilterEntity FilterValues)
        {
            StoryboardReportEntity newEntity = new StoryboardReportEntity();
            try
            {
                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    var alertMart = dbEntity.Set<AlertMart>().ToList();
                    newEntity.TotalAlerts = (from a in alertMart
                                             where a.CustomerId == FilterValues.CustomerId &
                                            (FilterValues.PropertyId != "0" ? a.PropertyId == FilterValues.PropertyId : true) &
                                            (FilterValues.BuildingId != "0" ? a.BuildingId == FilterValues.BuildingId : true) &
                                            (FilterValues.Month != "0" ? a.AlertMonth == FilterValues.Month : true) &
                                            (FilterValues.Year != 0 ? a.AlertYear == FilterValues.Year : true)
                                             select (a.CountOfAlert)).Sum();

                    var usageMart = dbEntity.Set<UsageMart>().ToList();
                    newEntity.TotalVisits = ((from a in usageMart
                                              where a.CustomerId == FilterValues.CustomerId &
                                             (FilterValues.PropertyId != "0" ? a.PropertyId == FilterValues.PropertyId : true) &
                                            (FilterValues.BuildingId != "0" ? a.BuildingId == FilterValues.BuildingId : true) &
                                            (FilterValues.Month != "0" ? a.UsageMonth == FilterValues.Month : true) &
                                            (FilterValues.Year != 0 ? a.UsageYear == FilterValues.Year : true)
                                              select (a.CountOfPaperUsed)).Sum()) / 2;
                    newEntity.TotalPaperUsed = (from a in usageMart
                                                where a.CustomerId == FilterValues.CustomerId &
                                                (FilterValues.PropertyId != "0" ? a.PropertyId == FilterValues.PropertyId : true) &
                                            (FilterValues.BuildingId != "0" ? a.BuildingId == FilterValues.BuildingId : true) &
                                            (FilterValues.Month != "0" ? a.UsageMonth == FilterValues.Month : true) &
                                            (FilterValues.Year != 0 ? a.UsageYear == FilterValues.Year : true) &
                                                a.DeviceType == TrafficChartConstants.eHRT
                                                select (a.CountOfUsage)).Sum();
                    newEntity.TotalTissueUsed = (from a in usageMart
                                                 where a.CustomerId == FilterValues.CustomerId &
                                                 (FilterValues.PropertyId != "0" ? a.PropertyId == FilterValues.PropertyId : true) &
                                            (FilterValues.BuildingId != "0" ? a.BuildingId == FilterValues.BuildingId : true) &
                                            (FilterValues.Month != "0" ? a.UsageMonth == FilterValues.Month : true) &
                                            (FilterValues.Year != 0 ? a.UsageYear == FilterValues.Year : true) &
                                                 (a.DeviceType == TrafficChartConstants.JRT | a.DeviceType == TrafficChartConstants.SRB)
                                                 select (a.CountOfUsage)).Sum();
                    newEntity.TotalSoapBottlesUsed = (from a in usageMart
                                                      where a.CustomerId == FilterValues.CustomerId &
                                                      (FilterValues.PropertyId != "0" ? a.PropertyId == FilterValues.PropertyId : true) &
                                            (FilterValues.BuildingId != "0" ? a.BuildingId == FilterValues.BuildingId : true) &
                                            (FilterValues.Month != "0" ? a.UsageMonth == FilterValues.Month : true) &
                                            (FilterValues.Year != 0 ? a.UsageYear == FilterValues.Year : true) &
                                                      a.DeviceType == TrafficChartConstants.eSoap
                                                      select (a.CountOfUsage)).Sum();
                    newEntity.TotalBatteriesChanges = (from a in usageMart
                                                       where a.CustomerId == FilterValues.CustomerId &
                                                       (FilterValues.PropertyId != "0" ? a.PropertyId == FilterValues.PropertyId : true) &
                                            (FilterValues.BuildingId != "0" ? a.BuildingId == FilterValues.BuildingId : true) &
                                            (FilterValues.Month != "0" ? a.UsageMonth == FilterValues.Month : true) &
                                            (FilterValues.Year != 0 ? a.UsageYear == FilterValues.Year : true)
                                                       select (a.CountOfBattery)).Sum();

                }
            }
            catch
            {
                throw new Exception();
            }

            return newEntity;
        }

        private List<string> GetAllAlertTypes()
        {
            List<string> AlertTypes = new List<string>();
            try
            {
                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    var alertType = dbEntity.Set<AlertType>().ToList();
                    AlertTypes = (from alert in alertType
                                  select alert.Type).ToList();
                }
            }
            catch
            {
                throw new Exception();
            }
            return AlertTypes;
        }

        private TimeZoneInfo GetPropertyTimezone(int propertyId)
        {
            string timezone = string.Empty;
            try
            {
                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    timezone = (from prop in dbEntity.Properties
                                where prop.ID == propertyId
                                select prop.LocationTimeZone).FirstOrDefault();
                }
                if (!string.IsNullOrEmpty(timezone))
                {
                    return TimeZoneInfo.GetSystemTimeZones().Where(o => o.Id == timezone).FirstOrDefault();
                }
                else
                {
                    return TimeZoneInfo.GetSystemTimeZones().Where(o => o.Id == "UTC").FirstOrDefault();
                }
            }
            catch
            {                
                return TimeZoneInfo.GetSystemTimeZones().Where(o => o.Id == "UTC").FirstOrDefault();
            }
        }

        private TimeZoneInfo GetPropertyTimezoneFromBuilding(int buildingId)
        {
            string timezone = string.Empty;
            try
            {
                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    timezone = (from building in dbEntity.Buildings
                                join prop in dbEntity.Properties on building.PropertyId equals prop.ID
                                where building.ID == buildingId
                                select prop.LocationTimeZone).FirstOrDefault();
                }
                if (!string.IsNullOrEmpty(timezone))
                {
                    return TimeZoneInfo.GetSystemTimeZones().Where(o => o.Id == timezone).FirstOrDefault();
                }
                else
                {
                    return TimeZoneInfo.GetSystemTimeZones().Where(o => o.Id == "UTC").FirstOrDefault();
                }
            }
            catch
            {
                return TimeZoneInfo.GetSystemTimeZones().Where(o => o.Id == "UTC").FirstOrDefault();
            }
        }
    }
}
