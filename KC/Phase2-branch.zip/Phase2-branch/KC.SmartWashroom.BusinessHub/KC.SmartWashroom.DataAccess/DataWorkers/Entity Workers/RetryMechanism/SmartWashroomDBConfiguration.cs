﻿using System.Data.Entity;
using System.Data.Entity.SqlServer;

namespace KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers
{
    public partial class SmartWashroomDBConfiguration : DbConfiguration
    {
        public SmartWashroomDBConfiguration()
        {
            SetExecutionStrategy("System.Data.SqlClient",
                () => new CustomRetryExecutionstrategy
                    (
                        Core.Constants.CommonConstants.SQLAZURE_MAX_RETRIES
                    ));

        }
    }
}
