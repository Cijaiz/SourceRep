﻿using KC.SmartWashroom.Core.Log;
using System;
using System.Collections.Generic;
using System.Data.Entity.SqlServer;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers
{
    public class CustomRetryExecutionstrategy : SqlAzureExecutionStrategy
    {
        private int MaxReTryCount;
        private int currentRetryCount = 0;
        public CustomRetryExecutionstrategy(int maxRetryCount)
            : base(maxRetryCount, System.TimeSpan.FromSeconds(Core.Constants.CommonConstants.SQLAZURE_CONNECTION_RETRYINTERVAL))
        {
            this.MaxReTryCount = maxRetryCount;
        }

        protected override bool ShouldRetryOn(Exception exception)
        {
            bool isRetryAllowed = true;
            currentRetryCount++;

            //Retry 3 Times for SQL Exception..
            if (exception is System.Data.SqlClient.SqlException)
            {
                if (currentRetryCount >= Core.Constants.CommonConstants.SQL_EXCEPTION_RETRY)
                    isRetryAllowed = base.ShouldRetryOn(exception); //Let base handle more than manual retries..
            }
            else
            {
                isRetryAllowed = base.ShouldRetryOn(exception); //Let base handle more than manual retries..;
            }

            //Log the error for future reference..
            Logger.Error("Exception Occured... Retrying using Custom Retry Execution Strategy.." + "\n" + exception.Message);
            return isRetryAllowed;
        }
    }
}
