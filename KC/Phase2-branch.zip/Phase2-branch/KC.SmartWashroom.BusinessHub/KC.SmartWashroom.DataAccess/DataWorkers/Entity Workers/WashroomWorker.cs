﻿using KC.SmartWashroom.DataAccess.Skeleton;
using BusinessEntity = KC.SmartWashroom.BusinessEntities;
using System.Collections.Generic;
using System.Linq;
using KC.SmartWashroom.Core.Helper;
using System;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.Core.Constants;

namespace KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers
{
    public class WashroomWorker : IWashroomWorker
    {
        List<BusinessEntities.BusinessHubEntities.ProductRefillDetail> allDeviceRefillValues = new List<BusinessEntity.BusinessHubEntities.ProductRefillDetail>();
        List<BusinessEntities.BusinessHubEntities.ESoapShot> allESoapShotSizes = new List<BusinessEntity.BusinessHubEntities.ESoapShot>();

        public List<BusinessEntity.Gender> GetGenders()
        {
            List<BusinessEntity.Gender> Genders = null;
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {       
                Genders = (from gender in dbEntity.Genders
                           select new BusinessEntity.Gender { ID = gender.ID, Name = gender.Name }).ToList();
            }
            return Genders;
        }

        public List<BusinessEntity.Wing> GetWings()
        {
            List<BusinessEntity.Wing> Wings = null;
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                Wings = (from wing in dbEntity.Wings
                         select new BusinessEntity.Wing { ID = wing.ID, Name = wing.Name }).ToList();
            }
            return Wings;
        }
        public int GetCustomerId(int washroomId)
        {
            int customerId = 0;
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                customerId = (from property in dbEntity.Properties
                              join building in dbEntity.Buildings on property.ID equals building.PropertyId
                              join floor in dbEntity.Floors on building.ID equals floor.BuildingId
                              join washroom in dbEntity.Washrooms on floor.ID equals washroom.FloorId
                              where washroom.ID == washroomId
                              select property.CustomerId).FirstOrDefault();
            }
            return customerId;
        }
        public BusinessEntity.Washroom GetWashroomDetails(int washroomId)
        {
            BusinessEntity.Washroom washroom = null;
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                washroom = (from room in dbEntity.Washrooms
                            where room.ID == washroomId && room.IsActive == true
                            select new BusinessEntity.Washroom
                            {
                                ID = room.ID,
                                Name = room.Name,
                                FloorId = room.FloorId,
                                GenderId = room.GenderId,
                                WingId = room.WingId,
                                IsActive = room.IsActive,
                                KCIdentifier = room.KCIdentifier,
                                CreatedBy = room.CreatedBy,
                                CreatedOn = room.CreatedOn,
                                LastUpdatedBy = room.LastUpdatedBy,
                                LastUpdatedOn = room.LastUpdatedOn,
                                Devices = (from deviceRoom in room.DeviceWashrooms
                                           join device in dbEntity.Devices on deviceRoom.DeviceId equals device.ID
                                           join type in dbEntity.DeviceTypes on device.DeviceTypeId equals type.ID
                                           where device.IsActive == true && deviceRoom.IsActive == true
                                           select new BusinessEntity.TenantApiEntities.Device
                                           {
                                               ID = device.ID,
                                               Name = device.Name,
                                               ImageUrl = device.ImageUrl,
                                               DeviceTypeId = device.DeviceTypeId,
                                               DeviceType = type.Name,
                                               IsActive = device.IsActive,
                                               CreatedBy = device.CreatedBy,
                                               CreatedOn = device.CreatedOn,
                                               LastUpdatedBy = device.LastUpdatedBy,
                                               LastUpdatedOn = device.LastUpdatedOn
                                           }).ToList<BusinessEntity.TenantApiEntities.Device>()
                            }).FirstOrDefault();
                washroom.FloorLevel = (from room in dbEntity.Washrooms
                                       where room.ID == washroomId && room.IsActive == true
                                       select room).FirstOrDefault().Floor.FloorLevel.ToString();
            }
            return washroom;
        }

        public ProcessResponse<BusinessEntity.Washroom> Create(BusinessEntity.Washroom washroom)
        {
            ProcessResponse<BusinessEntity.Washroom> response = new ProcessResponse<BusinessEntity.Washroom>() { Status = ResponseStatus.Failed };
            try
            {
                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    Washroom washroomEntity = new Washroom();
                    washroomEntity.Name = washroom.Name;
                    washroomEntity.KCIdentifier = washroom.KCIdentifier;
                    washroomEntity.FloorId = washroom.FloorId;
                    washroomEntity.GenderId = washroom.GenderId;
                    washroomEntity.WingId = washroom.WingId;
                    washroomEntity.IsActive = washroom.IsActive;
                    washroomEntity.CreatedBy = washroom.CreatedBy;
                    washroomEntity.CreatedOn = DateTime.UtcNow;

                    dbEntity.Washrooms.Add(washroomEntity);
                    dbEntity.SaveChanges();
                    response.Status = ResponseStatus.Success;
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.Failed;
                response.Message = ex.Message;
            }
            return response;
        }

        public ProcessResponse<BusinessEntity.Washroom> Update(BusinessEntity.Washroom washroom)
        {
            ProcessResponse<BusinessEntity.Washroom> response = new ProcessResponse<BusinessEntity.Washroom>() { Status = ResponseStatus.Failed };
            try
            {
                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    Washroom editWashroom = null;
                    editWashroom = (from room in dbEntity.Washrooms
                                    where room.ID == washroom.ID
                                    select room).FirstOrDefault();
                    Guard.IsNotNull(editWashroom, "Washroom To Be Updated");
                    editWashroom.Name = washroom.Name;
                    editWashroom.KCIdentifier = washroom.KCIdentifier;
                    editWashroom.GenderId = washroom.GenderId;
                    editWashroom.WingId = washroom.WingId;
                    editWashroom.LastUpdatedBy = washroom.LastUpdatedBy != 0 ? washroom.LastUpdatedBy : null;
                    editWashroom.LastUpdatedOn = DateTime.UtcNow;
                    dbEntity.SaveChanges();
                    response.Status = ResponseStatus.Success;
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.Failed;
                response.Message = ex.Message;
            }
            return response;
        }

        public ProcessResponse<BusinessEntity.Washroom> Delete(BusinessEntity.Washroom washroom)
        {
            ProcessResponse<BusinessEntity.Washroom> response = new ProcessResponse<BusinessEntity.Washroom>() { Status = ResponseStatus.Failed };
            try
            {
                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    Washroom delWashroom = (from room in dbEntity.Washrooms
                                            where room.ID == washroom.ID
                                            select room).FirstOrDefault();
                    Guard.IsNotNull(delWashroom, "Washroom To Be Deleted");
                    delWashroom.IsActive = false;
                    delWashroom.LastUpdatedBy = washroom.LastUpdatedBy != 0 ? washroom.LastUpdatedBy : null;
                    delWashroom.LastUpdatedOn = DateTime.UtcNow;
                    dbEntity.SaveChanges();
                    response.Status = ResponseStatus.Success;
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.Failed;
                response.Message = ex.Message;
            }
            return response;
        }

        public List<BusinessEntity.Washroom> GetWashroomsByFloorIdGroupedByGender(int floorId)
        {
            List<BusinessEntity.Washroom> Washrooms = new List<BusinessEntity.Washroom>();
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                Washrooms = (from washroom in dbEntity.Washrooms
                             where washroom.FloorId == floorId && washroom.IsActive == true
                             select new
                             {
                                 washroom.ID,
                                 washroom.FloorId,
                                 washroom.Name,
                                 WingName = washroom.Wing.Name,
                                 GenderName = washroom.Gender.Name,
                                 washroom.GenderId

                             } into washroomResult
                             group washroomResult by new
                                   {
                                       washroomResult.GenderName,
                                       washroomResult.GenderId,
                                       washroomResult.ID,
                                       washroomResult.FloorId,
                                       washroomResult.Name,
                                       washroomResult.WingName
                                   } into groupedResults
                             select new BusinessEntity.Washroom
                             {
                                 ID = groupedResults.Key.ID,
                                 FloorId = groupedResults.Key.FloorId,
                                 Name = groupedResults.Key.Name,
                                 Wing = groupedResults.Key.WingName,
                                 Gender = groupedResults.Key.GenderName,
                                 GenderId = groupedResults.Key.GenderId

                             }).ToList();
            }
            return Washrooms;

        }

        public List<BusinessEntity.Washroom> GetWashroomsByFloorId(int floorId)
        {
            List<BusinessEntity.Washroom> Washrooms = new List<BusinessEntity.Washroom>();
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                Washrooms = (from washroom in dbEntity.Washrooms
                             where washroom.FloorId == floorId && washroom.IsActive == true
                             select new BusinessEntity.Washroom
                             {
                                 ID = washroom.ID,
                                 FloorId = washroom.FloorId,
                                 Name = washroom.Name,
                                 Wing = washroom.Wing.Name,
                                 Gender = washroom.Gender.Name,
                                 GenderId = washroom.GenderId
                             }).ToList();
                //} into washroomResult
                //group washroomResult by new
                //      {
                //          washroomResult.GenderName,
                //          washroomResult.GenderId,
                //          washroomResult.ID,
                //          washroomResult.FloorId,
                //          washroomResult.Name,
                //          washroomResult.WingName
                //      } into groupedResults
                //select new BusinessEntity.Washroom
                //{
                //    ID = groupedResults.Key.ID,
                //    FloorId = groupedResults.Key.FloorId,
                //    Name = groupedResults.Key.Name,
                //    Wing = groupedResults.Key.WingName,
                //    Gender = groupedResults.Key.GenderName,
                //    GenderId = groupedResults.Key.GenderId

                //}
                //).ToList();
            }
            return Washrooms;

        }
        public IList<BusinessEntity.Washroom> GetWashrromsByPropertyAndGeneder(int propertyId, byte genderId)
        {
            List<BusinessEntity.Washroom> Washrooms = new List<BusinessEntity.Washroom>();
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                Washrooms = (from washroom in dbEntity.Washrooms
                             join floor in dbEntity.Floors on washroom.FloorId equals floor.ID
                             join building in dbEntity.Buildings on floor.BuildingId equals building.ID
                             where building.PropertyId == propertyId && washroom.GenderId == genderId && washroom.IsActive == true && floor.IsActive == true && building.IsActive == true
                             select new BusinessEntity.Washroom
                             {
                                 ID = washroom.ID,
                                 FloorId = washroom.FloorId,
                                 Name = washroom.Name,
                                 Wing = washroom.Wing.Name,
                                 Gender = washroom.Gender.Name,
                                 GenderId = washroom.GenderId
                             }).ToList();
            }
            return Washrooms;
        }
        public List<BusinessEntity.DeviceStatus> GetDeviceStatusInWashrooms(int floorId, int washroomId)
        {
            List<BusinessEntity.DeviceStatus> deviceStatuses = new List<BusinessEntity.DeviceStatus>();

            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                deviceStatuses = (from deviceWashroom in dbEntity.DeviceWashrooms
                                  join washroom in dbEntity.Washrooms on deviceWashroom.WashroomId equals washroom.ID
                                  join device in dbEntity.Devices on deviceWashroom.DeviceId equals device.ID
                                  join deviceType in dbEntity.DeviceTypes on device.DeviceTypeId equals deviceType.ID
                                  where washroom.FloorId == floorId && washroom.ID == washroomId && washroom.IsActive == true && device.IsActive.Equals(true) && deviceWashroom.IsActive == true
                                  select new BusinessEntity.DeviceStatus
                                  {
                                      DeviceId = device.ID,
                                      DeviceName = device.Name,
                                      DeviceType = deviceType.Name.ToUpper(),

                                      ProductUsageBuffer = deviceType.ProductUsageBuffer.HasValue ? deviceType.ProductUsageBuffer : 0,
                                      MinBatteryVoltage = deviceType.MinimumVoltage.HasValue ? deviceType.MinimumVoltage.Value : 0,
                                      MaxBatteryVoltage = deviceType.MaximumVoltage.HasValue ? deviceType.MaximumVoltage.Value : 0
                                  }).ToList();

                foreach (var device in deviceStatuses)
                {
                    var deviceAlerts = (from deviceAlert in dbEntity.DeviceAlerts
                                        join alertType in dbEntity.AlertTypes on deviceAlert.AlertTypeId equals alertType.ID
                                        where deviceAlert.DeviceId.Equals(device.DeviceId)
                                        select new BusinessEntity.DeviceAlertInfo
                                        {
                                            AlertType = alertType.Type

                                        }).Distinct().ToList();
                    device.DeviceAlerts = deviceAlerts;



                }

            }

            return deviceStatuses;
        }

        private List<BusinessEntities.BusinessHubEntities.ProductRefillDetail> GetAllDeviceRefillValues()
        {
            var allDeviceRefillValues = new List<BusinessEntities.BusinessHubEntities.ProductRefillDetail>();
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                allDeviceRefillValues = (from deviceRefill in dbEntity.ProductRefillDetails
                                         join product in dbEntity.Products on deviceRefill.ProductId equals product.ID
                                         join deviceType in dbEntity.DeviceTypes on product.Type.ToUpper() equals deviceType.Name.ToUpper()
                                         select new BusinessEntities.BusinessHubEntities.ProductRefillDetail()
                                         {
                                             ProductId = deviceRefill.ProductId,
                                             RefillValue = deviceRefill.RefillValue,
                                             Size = deviceRefill.Size,

                                             DeviceType = product.Type.ToUpper(),
                                             ProductUsageBuffer = deviceType.ProductUsageBuffer
                                         }).ToList();
            }
            return allDeviceRefillValues;
        }

        public decimal GetDeviceRefillValue(string size, string DeviceType, out byte productUsageBuffer)
        {
            decimal value = 0;
            productUsageBuffer = 0;
            string refillSize = !string.IsNullOrEmpty(size) ? size.ToUpper() : size;

            //using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            //{
            //    var ProductId = dbEntity.Set<Product>().Where(product => product.Type.ToUpper().Equals(DeviceType.ToUpper())).Single().ID;
            //    if (!String.IsNullOrEmpty(size))
            //    {
            //        value = dbEntity.Set<ProductRefillDetail>().Where(product => product.Size.ToUpper().Equals(size.ToUpper()) && product.ProductId.Equals(ProductId)).Single().RefillValue;
            //    }

            //}

            if (allDeviceRefillValues.Count.Equals(0))
                allDeviceRefillValues = this.GetAllDeviceRefillValues();

            var deviceRefillSizeandUsage = (from deviceRefill in allDeviceRefillValues
                                            where deviceRefill.DeviceType.ToUpper().Equals(DeviceType.ToUpper())
                                            where deviceRefill.Size.Equals(refillSize)
                                            select new
                                            {
                                                RefillSize = deviceRefill.RefillValue,
                                                ProductUsageBuffer = deviceRefill.ProductUsageBuffer.HasValue ? deviceRefill.ProductUsageBuffer.Value : 0
                                            }).FirstOrDefault();

            if (deviceRefillSizeandUsage != null)
                value = deviceRefillSizeandUsage.RefillSize;

            productUsageBuffer = byte.TryParse(deviceRefillSizeandUsage.ProductUsageBuffer.ToString(), out productUsageBuffer)
                                                ? productUsageBuffer : productUsageBuffer;

            return value;
        }

        private List<BusinessEntities.BusinessHubEntities.ESoapShot> GetAllESoapShotSizes()
        {
            var allSoapShotSizes = new List<BusinessEntities.BusinessHubEntities.ESoapShot>();
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                allSoapShotSizes = (from deviceParameterValues in dbEntity.DeviceParameterValues
                                    join deviceParameter in dbEntity.DeviceParameters
                                    on deviceParameterValues.ParameterId equals deviceParameter.Id
                                    where deviceParameter.Name.ToUpper().Equals(AlertEngineConstants.ESOAP_SHOTSIZE.ToUpper())
                                    select new BusinessEntities.BusinessHubEntities.ESoapShot()
                                    {
                                        Size = deviceParameterValues.Value,
                                        Quantity = deviceParameterValues.ValueMapping
                                    }).ToList();
            }
            return allSoapShotSizes;
        }

        public decimal GetESoapShotSize(string size)
        {
            decimal value = 0;
            string shotSize = !string.IsNullOrEmpty(size) ? size.ToUpper() : size;

            if (allESoapShotSizes.Count.Equals(0))
                allESoapShotSizes = this.GetAllESoapShotSizes();

            value = (from esoapShotSize in allESoapShotSizes
                     where esoapShotSize.Size.Equals(shotSize)
                     select esoapShotSize.Quantity).FirstOrDefault();

            return value;
        }

        public Names GetNames(int floorId)
        {
            Names name = new Names();
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                name = (from dbfloor in dbEntity.Floors
                        join dbbuilding in dbEntity.Buildings on dbfloor.BuildingId equals dbbuilding.ID
                        join dbproperty in dbEntity.Properties on dbbuilding.PropertyId equals dbproperty.ID
                        join dbcustomer in dbEntity.Customers on dbproperty.CustomerId equals dbcustomer.ID
                        where dbfloor.ID == floorId
                        select new BusinessEntities.TenantApiEntities.Names
                        {
                            FloorLevel = dbfloor.FloorLevel,
                            BuildingName = dbbuilding.Name,
                            BuildingId = dbbuilding.ID,
                            PropertyName = dbproperty.PropertyName,
                            PropertyId = dbproperty.ID,
                            CustomerName = dbcustomer.Name,
                            CustomerId = dbcustomer.ID
                        }

                           ).ToList<BusinessEntities.TenantApiEntities.Names>().FirstOrDefault();
            }
            return name;

        }
    }
}
