﻿using KC.SmartWashroom.DataAccess.Skeleton;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Transactions;
using EntityFramework.BulkInsert.Extensions;
using BusinessEntity = KC.SmartWashroom.BusinessEntities;

namespace KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers
{
    public class AggregationWorker : IAggregationWorker
    {
        public List<Customer> GetCustomerDetails()
        {
            List<Customer> CustomerDetails = new List<Customer>();

            using (var db = EntityRepositoryManager.GetStoreEntity())
            {
                CustomerDetails = (from c in db.Customers
                                   where c.IsActive == true
                                   select c).Distinct().ToList();
            }

            return CustomerDetails;
        }

        public List<BusinessEntity.Property> GetAllProperties()
        {
            List<BusinessEntity.Property> Properties = new List<BusinessEntity.Property>();
            using (var db = EntityRepositoryManager.GetStoreEntity())
            {
                Properties = (from prop in db.Properties
                              where prop.IsActive == true
                              select new BusinessEntity.Property
                              {
                                  ID = prop.ID,
                                  PropertyName = prop.PropertyName,
                                  CustomerId = prop.CustomerId
                              }).ToList();
            }
            return Properties;
        }

        public BusinessEntity.Property GetPropertyDetails(int propertyId)
        {
            BusinessEntity.Property Property = new BusinessEntity.Property();
            using (var db = EntityRepositoryManager.GetStoreEntity())
            {
                Property = (from prop in db.Properties
                            where prop.IsActive == true && prop.ID == propertyId
                            select new BusinessEntity.Property
                            {
                                ID = prop.ID,
                                PropertyName = prop.PropertyName,
                                CustomerId = prop.CustomerId
                            }).FirstOrDefault();
            }
            return Property;
        }

        public Customer GetCustomerDetailsById(int CustomerId)
        {
            Customer CustomerDetail = new Customer();

            using (var db = EntityRepositoryManager.GetStoreEntity())
            {
                CustomerDetail = (from c in db.Customers
                                  where c.IsActive == true
                                  & c.ID == CustomerId
                                  select c).FirstOrDefault();
            }

            return CustomerDetail;
        }

        public AggregationStatu GetAggregationDetail(int PropertyId)
        {
            AggregationStatu Status = new AggregationStatu();
            using (var db = EntityRepositoryManager.GetStoreEntity())
            {
                var ifNull = db.AggregationStatus.Select(x => x).Where(x => x.PropertyId == PropertyId).ToList();
                if (ifNull.Count != 0)
                {
                    var MaxTime = db.AggregationStatus.Where(x => x.PropertyId == PropertyId).Max(x => x.ProcessedDate);

                    Status = (from a in db.AggregationStatus
                              where a.PropertyId == PropertyId & a.Status.Equals("Complete") & a.ProcessedDate == MaxTime
                              select a).FirstOrDefault();
                }
                else
                    Status = null;
            }

            return Status;
        }

        public List<UsageMart> GetAllDevice(List<string> DeviceIds, DateTime Date)
        {
            List<UsageMart> DeviceList = new List<UsageMart>();

            DateTime previousDate = Date.AddDays(-1);
            DateTimeFormatInfo dfi = DateTimeFormatInfo.CurrentInfo;
            Calendar cal = dfi.Calendar;
            int previousDay = previousDate.Day;
            int WeekOfYear = cal.GetWeekOfYear(previousDate, dfi.CalendarWeekRule, dfi.FirstDayOfWeek);
            int Year = previousDate.Year;

            using (var db = EntityRepositoryManager.GetStoreEntity())
            {
                DeviceList = (from u in db.UsageMarts
                              where DeviceIds.Contains(u.DeviceId) &
                              u.UsageDay == previousDay &
                              u.UsageWeek == WeekOfYear &
                              u.UsageYear == Year
                              select u).ToList();
            }

            return DeviceList;
        }

        public List<UsageMart> GetAllDeviceForJRTnSRBneSoap(List<BusinessEntity.Aggregation.DeviceWashroom> DeviceWashroomIds)
        {
            List<UsageMart> DeviceList = new List<UsageMart>();

            using (var db = EntityRepositoryManager.GetStoreEntity())
            {
                foreach (var item in DeviceWashroomIds)
                {
                    var device = (from u in db.UsageMarts
                                  where u.DeviceId == item.DeviceId
                                  && u.WashRoomId == item.WashroomId
                                  group u by u.DeviceId
                                      into u1
                                      let maxOf = u1.Max(e => e.TotalUsed)
                                      from u in u1
                                      where u.TotalUsed == maxOf
                                      group u by u.DeviceId
                                          into u2
                                          let maxbattery = u2.Max(b => b.TotalBatteryChange)
                                          from u in u2
                                          where u.TotalBatteryChange == maxbattery
                                          select u).FirstOrDefault();
                    if (device != null)
                    {
                        DeviceList.Add(device);
                    }
                }
            }

            return DeviceList;
        }

        public List<UsageMart> GetAllDeviceForeHRT(List<BusinessEntity.Aggregation.DeviceWashroom> DeviceWashroomIds)
        {
            List<UsageMart> DeviceList = new List<UsageMart>();

            using (var db = EntityRepositoryManager.GetStoreEntity())
            {
                foreach (var item in DeviceWashroomIds)
                {
                    var device = (from u in db.UsageMarts
                                  where u.DeviceId == item.DeviceId
                                  && u.WashRoomId == item.WashroomId
                                  group u by new
                                  {
                                      u.DeviceId,
                                      u.WashRoomId
                                  }
                                      into u1
                                      let maxOf = u1.Max(e => e.TotalPaperTowel)
                                      from u in u1
                                      where u.TotalPaperTowel == maxOf
                                      group u by new
                                      {
                                          u.DeviceId,
                                          u.WashRoomId
                                      }
                                          into u2
                                          let mxBattery = u2.Max(b => b.TotalBatteryChange)
                                          from u in u2
                                          where u.TotalBatteryChange == mxBattery
                                          select u).FirstOrDefault();
                    if (device != null)
                    {
                        DeviceList.Add(device);
                    }
                }
            }

            return DeviceList;
        }

        public void DeleteDeviceLogs(BusinessEntity.Property Property, DateTime Date)
        {
            DateTimeFormatInfo dfi = DateTimeFormatInfo.CurrentInfo;
            Calendar cal = dfi.Calendar;
            int presentDay = Date.Day;
            int WeekOfYear = cal.GetWeekOfYear(Date, dfi.CalendarWeekRule, dfi.FirstDayOfWeek);
            int Year = Date.Year;
            string customerId = Property.CustomerId.ToString();
            string propertyId = Property.ID.ToString();

            //List<UsageMart> UsageList = new List<UsageMart>();
            using (var db = EntityRepositoryManager.GetStoreEntity())
            {
                var UsageList = from u in db.UsageMarts
                                where u.UsageDay == presentDay & u.UsageWeek == WeekOfYear & u.UsageYear == Year & u.CustomerId==customerId & u.PropertyId == propertyId
                                select u;
                foreach (var item in UsageList)
                {
                    db.UsageMarts.Remove(item);
                    //db.Entry(item).State = System.Data.Entity.EntityState.Deleted;
                }

                db.SaveChanges();
            }
        }

        public void BulkInsertDeviceLogs(List<UsageMart> DeviceLogs)
        {
            using (var db = EntityRepositoryManager.GetStoreEntity())
            {
                using (var scope = new TransactionScope())
                {
                    db.BulkInsert(DeviceLogs);

                    db.SaveChanges();
                    scope.Complete();
                }
            }
        }

        public void DeleteAlertLogs(BusinessEntity.Property Property, DateTime Date)
        {
            DateTimeFormatInfo dfi = DateTimeFormatInfo.CurrentInfo;
            Calendar cal = dfi.Calendar;
            int presentDay = Date.Day;
            int WeekOfYear = cal.GetWeekOfYear(Date, dfi.CalendarWeekRule, dfi.FirstDayOfWeek);
            int Year = Date.Year;
            string customerId = Property.CustomerId.ToString();
            string propertyId = Property.ID.ToString();

            //List<AlertMart> AlertList = new List<AlertMart>();
            using (var db = EntityRepositoryManager.GetStoreEntity())
            {
                var AlertList = from a in db.AlertMarts
                                where a.AlertDay == presentDay & a.AlertWeek == WeekOfYear & a.AlertYear == Year & a.CustomerId == customerId & a.PropertyId == propertyId
                                select a;

                foreach (var item in AlertList)
                {
                    db.AlertMarts.Remove(item);
                    //db.Entry(item).State = System.Data.Entity.EntityState.Deleted;
                }

                db.SaveChanges();

            }
        }

        public void BulkInsertAlerts(List<AlertMart> Alerts)
        {
            using (var db = EntityRepositoryManager.GetStoreEntity())
            {
                using (var scope = new TransactionScope())
                {
                    db.BulkInsert(Alerts);

                    db.SaveChanges();
                    scope.Complete();
                }
            }
        }

        public void InsertSuccessMsg(DateTime Date, BusinessEntity.Property Property)
        {
            AggregationStatu Status = new AggregationStatu();
            Status.PropertyId = Property.ID;
            Status.ProcessedDate = Date;
            Status.Status = "Complete";
            using (var db = EntityRepositoryManager.GetStoreEntity())
            {
                db.AggregationStatus.Add(Status);

                db.SaveChanges();
            }
        }
    }
}
