﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.Core.Log;
using KC.SmartWashroom.DataAccess.Skeleton;
using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers
{
    public class DeviceTenantWorker : IDeviceTenantWorker
    {
        static ConnectionMultiplexer cacheCon;
        private string _errorDetail;
        private const string DEVICE_TYPE_PREFIX = "DeviceType_";

        public DeviceTenantWorker()
        {

        }

        string IDeviceTenantWorker.ErrorDetail
        {
            get { return _errorDetail; }
            set { _errorDetail = value; }
        }

        public ProcessResponse<BusinessEntities.TenantApiEntities.Device> Create(BusinessEntities.TenantApiEntities.Device device)
        {
            ProcessResponse<BusinessEntities.TenantApiEntities.Device> response = new ProcessResponse<BusinessEntities.TenantApiEntities.Device>();

            try
            {
                using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                {

                    Device dbDevice = new Device();
                    DeviceWashroom dbDeviceWashroom = new DeviceWashroom();

                    var deviceExists = (from dbdevice in dbContext.Devices
                                        where dbdevice.ID == device.ID
                                        select dbdevice
                                          );
                    if (deviceExists == null || deviceExists.Count() == 0)
                    {
                        dbDevice.ID = device.ID;
                        dbDevice.Name = device.Name;
                        if (device.ImageUrl != null)
                            dbDevice.ImageUrl = device.ImageUrl;
                        else
                            dbDevice.ImageUrl = "http://kcdevelopment.blob.core.windows.net/mediastore/no_image.png";
                        //dbDevice.ImageUrl = device.ImageUrl;
                        dbDevice.DeviceTypeId = device.DeviceTypeId;
                        dbDevice.CreatedBy = device.CreatedBy;
                        dbDevice.CreatedOn = device.CreatedOn;
                        dbDevice.LastUpdatedBy = device.CreatedBy;
                        dbDevice.LastUpdatedOn = device.CreatedOn;
                        dbDevice.IsActive = true;
                        if (device.DeviceTypeId == 2)
                            dbDevice.ProductRefillId = device.ProductRefillId;

                        dbDeviceWashroom.DeviceId = device.ID;
                        dbDeviceWashroom.WashroomId = device.WashroomId;
                        dbDeviceWashroom.StartDate = device.CreatedOn;

                        dbDeviceWashroom.EndDate = DateTime.MaxValue;
                        dbDeviceWashroom.IsActive = true;

                        dbContext.Devices.Add(dbDevice);
                        dbContext.DeviceWashrooms.Add(dbDeviceWashroom);

                        dbContext.SaveChanges();

                        response.Status = ResponseStatus.Success;
                        response.Message = AlertEngineConstants.CREATE_SUCCESS;
                    }

                    else
                    {
                        dbDevice = deviceExists.FirstOrDefault();
                        var dbDeviceWashroomExists = (from devicewashroom in dbContext.DeviceWashrooms
                                                      where devicewashroom.DeviceId == device.ID && devicewashroom.IsActive == true
                                                      select devicewashroom).FirstOrDefault();
                        if (dbDevice.IsActive == true || dbDeviceWashroomExists != null)
                        {
                            response.Status = ResponseStatus.Failed;
                            response.Message = "Device ID already exists";
                        }
                        else
                        {

                            dbDevice.IsActive = true;
                            dbDevice.Name = device.Name;
                            if (device.DeviceTypeId == 2)
                                dbDevice.ProductRefillId = device.ProductRefillId;
                            //Check for DeviceWashroom association for the same Device and Washroom
                            var dbDeviceWashroomAscn = (from devicewashroom in dbContext.DeviceWashrooms
                                                        where devicewashroom.DeviceId == device.ID && devicewashroom.WashroomId == device.WashroomId && devicewashroom.IsActive == false
                                                        select devicewashroom).FirstOrDefault();
                            if (dbDeviceWashroomAscn == null)
                            {
                                //Create new device washroom association
                                DeviceWashroom dbDeviceWashroomNew = new DeviceWashroom();
                                dbDeviceWashroomNew.DeviceId = device.ID;
                                dbDeviceWashroomNew.WashroomId = device.WashroomId;
                                dbDeviceWashroomNew.StartDate = device.CreatedOn;
                                dbDeviceWashroomNew.EndDate = DateTime.MaxValue;
                                dbDeviceWashroomNew.IsActive = true;
                                dbContext.DeviceWashrooms.Add(dbDeviceWashroomNew);
                            }
                            else
                            {
                                //Activate the Device Washroom Association
                                dbDeviceWashroomAscn.IsActive = true;
                                dbDeviceWashroomAscn.StartDate = device.CreatedOn;
                                dbDeviceWashroomAscn.EndDate = DateTime.MaxValue;
                            }

                            dbContext.SaveChanges();

                            response.Status = ResponseStatus.Success;
                            response.Message = "Device reactivated successfully";
                        }
                    }
                    //var devicewashroomExists = (from dbdevices in dbContext.Devices
                    //                    join dbdevicewashrooms in dbContext.DeviceWashrooms on dbdevices.ID equals dbdevicewashrooms.DeviceId
                    //                    where dbdevicewashrooms.DeviceId == device.ID && dbdevicewashrooms.WashroomId==device.WashroomId && dbdevices.IsActive == true
                    //                    select dbdevices);

                    //if ((deviceExists == null || deviceExists.Count() == 0) && (deviceInactiveExists == null || deviceInactiveExists.Count() == 0))
                    //{
                    //    dbDevice.ID = device.ID;
                    //    dbDevice.Name = device.Name;
                    //    if (device.ImageUrl != null)
                    //        dbDevice.ImageUrl = device.ImageUrl;
                    //    else
                    //        dbDevice.ImageUrl = "http://kcdevelopment.blob.core.windows.net/mediastore/no_image.png";
                    //    //dbDevice.ImageUrl = device.ImageUrl;
                    //    dbDevice.DeviceTypeId = device.DeviceTypeId;
                    //    dbDevice.CreatedBy = device.CreatedBy;
                    //    dbDevice.CreatedOn = device.CreatedOn;
                    //    dbDevice.LastUpdatedBy = device.CreatedBy;
                    //    dbDevice.LastUpdatedOn = device.CreatedOn;
                    //    dbDevice.IsActive = true;

                    //    dbDeviceWashroom.DeviceId = device.ID;
                    //    dbDeviceWashroom.WashroomId = device.WashroomId;
                    //    dbDeviceWashroom.StartDate = device.CreatedOn;
                    //    dbDeviceWashroom.EndDate = DateTime.UtcNow;

                    //    dbContext.Devices.Add(dbDevice);
                    //    dbContext.DeviceWashrooms.Add(dbDeviceWashroom);
                    //    dbContext.SaveChanges();

                    //    response.Status = ResponseStatus.Success;
                    //    response.Message = AlertEngineConstants.MESSAGE_SUCCESS;
                    //}
                    //else if (deviceInactiveExists != null && deviceInactiveExists.Count() != 0)
                    //{
                    //    deviceInactiveExists.FirstOrDefault().IsActive = true;
                    //    dbDeviceWashroom.EndDate = DateTime.UtcNow;
                    //    dbContext.SaveChanges();

                    //    response.Status = ResponseStatus.Success;
                    //    response.Message = AlertEngineConstants.MESSAGE_SUCCESS;
                    //}
                    //else if ((deviceExists != null || deviceExists.Count() != 0))
                    //{
                    //    response.Status = ResponseStatus.Failed;
                    //    response.Message = "Device ID already exists";
                    //}

                    ////else
                    ////{
                    ////    response.Status = ResponseStatus.Failed;
                    ////    response.Message = "Device ID already exists for the washroom";
                    ////}
                }

            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.Error;
                response.Message = ex.Message;
            }
            return response;
        }

        public ProcessResponse<BusinessEntities.TenantApiEntities.Device> Update(BusinessEntities.TenantApiEntities.Device deviceEntity)
        {
            ProcessResponse<BusinessEntities.TenantApiEntities.Device> response = new ProcessResponse<BusinessEntities.TenantApiEntities.Device>();

            try
            {
                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    var device = (from dbdevices in dbEntity.Devices
                                  join dbdevicewashrooms in dbEntity.DeviceWashrooms on dbdevices.ID equals dbdevicewashrooms.DeviceId
                                  where dbdevicewashrooms.DeviceId == deviceEntity.ID && dbdevicewashrooms.WashroomId == deviceEntity.WashroomId && dbdevices.IsActive == true && dbdevicewashrooms.IsActive == true
                                  select dbdevices).FirstOrDefault();
                    if (device != null)
                    {
                        device.Name = deviceEntity.Name;
                        if (deviceEntity.ImageUrl != null)
                            device.ImageUrl = deviceEntity.ImageUrl;
                        device.DeviceTypeId = deviceEntity.DeviceTypeId;

                        device.LastUpdatedBy = deviceEntity.LastUpdatedBy;
                        device.LastUpdatedOn = deviceEntity.LastUpdatedOn;
                        device.IsActive = true;
                        if (deviceEntity.DeviceTypeId == 2)
                            device.ProductRefillId = deviceEntity.ProductRefillId;

                        dbEntity.SaveChanges();
                        response.Status = ResponseStatus.Success;
                        response.Message = AlertEngineConstants.MESSAGE_SUCCESS;
                        return response;
                    }
                    else
                    {
                        response.Status = ResponseStatus.Failed;
                        response.Message = "DeviceId_doesnt_exists";
                        return response;
                    }
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.Failed;
                response.Message = ex.Message;
                return response;
            }
        }

        public BusinessEntities.TenantApiEntities.Device GetDevice(string deviceId)
        {
            BusinessEntities.TenantApiEntities.Device device = null;
            try
            {
                using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                {
                    var Device = (from dbDevice in dbContext.Devices
                                  join dbWashroom in dbContext.DeviceWashrooms on dbDevice.ID equals dbWashroom.DeviceId
                                  join type in dbContext.DeviceTypes on dbDevice.DeviceTypeId equals type.ID
                                  //join dbProductRefill in dbContext.ProductRefillDetails on dbDevice.ProductRefillId equals dbProductRefill.ID
                                  where dbDevice.ID.Equals(deviceId) && dbDevice.IsActive != false && dbWashroom.IsActive == true
                                  select new BusinessEntities.TenantApiEntities.Device
                                  {
                                      ID = dbDevice.ID,
                                      Name = dbDevice.Name,
                                      DeviceTypeId = dbDevice.DeviceTypeId,
                                      ProductRefillId = dbDevice.ProductRefillId,
                                      ImageUrl = dbDevice.ImageUrl,
                                      WashroomId = dbWashroom.WashroomId,
                                      DeviceType = type.Name
                                  });
                    if (Device != null)
                        device = Device.FirstOrDefault();
                    return device;
                }
            }
            catch (Exception dataException)
            {
                _errorDetail = dataException.Message;
                return device;
            }
        }

        public ProcessResponse Delete(string deviceId)
        {
            ProcessResponse response = new ProcessResponse();
            DeviceWashroom dbWashroom = new DeviceWashroom();
            try
            {
                using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                {
                    var Device = (from devices in dbContext.Devices
                                  where devices.ID == deviceId
                                  select devices
                                   ).FirstOrDefault();

                    if (Device != null)
                    {
                        //Deactivate device
                        Device.IsActive = false;

                        //Deactivate active Device Washroom association
                        var DeviceWashroom = (from devicewashroom in dbContext.DeviceWashrooms
                                              where devicewashroom.DeviceId == Device.ID && devicewashroom.IsActive == true
                                              select devicewashroom).FirstOrDefault();
                        if (DeviceWashroom != null)
                        {
                            DeviceWashroom.IsActive = false;
                            DeviceWashroom.EndDate = DateTime.UtcNow;
                        }

                        //Delete all record from DeviceAlert table for that device id
                        var DeviceAlerts = (from devicealert in dbContext.DeviceAlerts
                                            where devicealert.DeviceId == Device.ID
                                            select devicealert).ToList();
                        dbContext.DeviceAlerts.RemoveRange(DeviceAlerts);

                        //Delete all record from DeviceParameterValue table for that device id 
                        var DevicePrms = (from deviceprm in dbContext.DeviceParameterValues
                                          where deviceprm.DeviceId == Device.ID
                                          select deviceprm).ToList();
                        dbContext.DeviceParameterValues.RemoveRange(DevicePrms);

                        dbContext.SaveChanges();
                    }

                    response.Status = ResponseStatus.Success;
                    response.Message = AlertEngineConstants.MESSAGE_SUCCESS;
                    return response;
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.Error;
                response.Message = ex.Message;
                return response;
            }

        }

        public List<DeviceTypes> GetDeviceTypes()
        {
            List<DeviceTypes> deviceTypes = null;
            try
            {
                using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                {
                    deviceTypes = new List<DeviceTypes>();
                    deviceTypes = (from dbDeviceTypes in dbContext.DeviceTypes
                                   where dbDeviceTypes.IsActive == true
                                   select new BusinessEntities.TenantApiEntities.DeviceTypes
                                   {
                                       DeviceId = dbDeviceTypes.ID,
                                       DeviceName = dbDeviceTypes.Name,
                                       DbDeviceType = dbDeviceTypes.Name,

                                       MacFormat = dbDeviceTypes.DeviceFormat,
                                       BatteryScaleFactor = dbDeviceTypes.BatteryScaleFactor
                                   }).ToList();
                    return deviceTypes;
                }
            }
            catch (Exception dataException)
            {
                _errorDetail = dataException.Message;
                return deviceTypes;

            }
        }

        private IDatabase GetCache()
        {
            if (cacheCon == null)
                cacheCon = KC.SmartWashroom.Core.Helper.CloudHelper.CacheHelper.GetInstance().GetDefaultConnection();

            if (cacheCon.IsConnected)
                return cacheCon.GetDatabase();
            else
            {
                throw new ApplicationException("Cache connection is not connected. Find a workaround");
            }
        }

        public bool SaveToDeviceTypesCache()
        {
            IList<DeviceTypes> types = GetDeviceTypes();
            foreach (DeviceTypes t in types)
            {
                //Serialize to bytes
                Byte[] byteData = Core.Helper.SerializationHelper.SerializeToBytes(t);

                if (byteData != null)
                {
                    //Get string from bytes
                    string deviceData = System.Text.Encoding.Default.GetString(byteData);

                    //put in cache
                    GetCache().StringSet(DEVICE_TYPE_PREFIX + t.DbDeviceType.ToLower(), deviceData);
                }
                else
                {
                    throw new ApplicationException("An error occurred while serializing devicetype data to bytes for device type " + t.DbDeviceType);
                }
            }

            return true;
        }

        public DeviceTypes GetDeviceTypesFromCache(string deviceType)
        {
            DeviceTypes obj = null;

            string deviceData = GetCache().StringGet(DEVICE_TYPE_PREFIX + deviceType.ToLower());
            if (deviceData != null)
            {
                Byte[] byteData = System.Text.Encoding.Default.GetBytes(deviceData);
                obj = Core.Helper.SerializationHelper.Deserialize<DeviceTypes>(byteData);
                Logger.Debug("Device types reading from cache");
            }
            else
            {
                IList<DeviceTypes> deviceTypes = GetDeviceTypes();
                obj = deviceTypes.Where(item => item.DbDeviceType.ToLower().Equals(deviceType.ToLower())).First();
            }

            return obj;
        }


        public List<RefillSize> GetRefillSize()
        {
            List<RefillSize> refillSize = null;
            try
            {
                using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                {
                    refillSize = new List<RefillSize>();
                    refillSize = (from dbProductRefills in dbContext.ProductRefillDetails
                                  join dbProduct in dbContext.Products on dbProductRefills.ProductId equals dbProduct.ID
                                  where dbProduct.Type == "eHRT"
                                  select new BusinessEntities.TenantApiEntities.RefillSize
                                  {
                                      RefillId = dbProductRefills.ID,
                                      RefillValue = dbProductRefills.Size
                                  }).ToList();
                    return refillSize;
                }
            }
            catch (Exception dataException)
            {
                _errorDetail = dataException.Message;
                return refillSize;

            }
        }

        public Names GetNames(int washroomId)
        {
            Names name = new Names();
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                name = (from dbwashroom in dbEntity.Washrooms
                        join dbfloor in dbEntity.Floors on dbwashroom.FloorId equals dbfloor.ID
                        join dbbuilding in dbEntity.Buildings on dbfloor.BuildingId equals dbbuilding.ID
                        join dbproperty in dbEntity.Properties on dbbuilding.PropertyId equals dbproperty.ID
                        join dbcustomer in dbEntity.Customers on dbproperty.CustomerId equals dbcustomer.ID
                        where dbwashroom.ID == washroomId
                        select new BusinessEntities.TenantApiEntities.Names
                        {
                            Room = dbwashroom.Name,
                            FloorLevel = dbfloor.FloorLevel,
                            FloorId = dbfloor.ID,
                            BuildingName = dbbuilding.Name,
                            BuildingId = dbbuilding.ID,
                            PropertyName = dbproperty.PropertyName,
                            PropertyId = dbproperty.ID,
                            CustomerName = dbcustomer.Name,
                            CustomerId = dbcustomer.ID
                        }

                           ).ToList<BusinessEntities.TenantApiEntities.Names>().FirstOrDefault();
            }
            return name;
        }

        public ReturnParameterResponse RetriveReturnParametersForDevice(string deviceId, int customerId, List<DeviceParameterValueEntity> customerParameterValues)
        {
            Guard.IsNotBlank(deviceId, "DeviceID");

            ReturnParameterResponse response = new ReturnParameterResponse();

            //Get DeviceTYpe
            response.deviceTypes = GetDeviceType(deviceId);

            //Emergency Pick up of CUsotmer iD due to irregular coding...
            var property = GetCustomerIDByDeviceID(deviceId);
            customerId = property.CustomerId;

            //Get DeviceTYpeSpecific Parameters..
            List<DeviceParameterEntity> deviceParameterEntities = GetDeviceParameters(response.deviceTypes);

            //Retrive Parametervalues default and Device level overrides..
            List<DeviceParameterValueEntity> deviceParameterValueEntities = GetDeviceParameterValue(customerId, deviceId);

            List<DeviceParameterValueEntity> deviceParameterValueDefaultEntities = GetDeviceParameterValue();

            response.returnValueParameters = GetListOfParameterValuesForTheDeviceTypes(deviceParameterEntities,
                                                                                        deviceParameterValueEntities,
                                                                                        customerParameterValues,
                                                                                        deviceParameterValueDefaultEntities);
            response.LocationTimeZone = property.LocationTimeZone;

            return response;
        }

        private Property GetCustomerIDByDeviceID(string deviceId)
        {
            Property propertyDetail = new Property();
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                propertyDetail = (from property in dbEntity.Properties
                                  join building in dbEntity.Buildings on property.ID equals building.PropertyId
                                  join floor in dbEntity.Floors on building.ID equals floor.BuildingId
                                  join washroom in dbEntity.Washrooms on floor.ID equals washroom.FloorId
                                  join deviceWashroom in dbEntity.DeviceWashrooms on washroom.ID equals deviceWashroom.WashroomId
                                  where deviceWashroom.DeviceId.Equals(deviceId) && deviceWashroom.IsActive == true
                                  select property).FirstOrDefault();
            }
            return propertyDetail;
        }

        private DeviceTypes GetDeviceType(string deviceID)
        {
            var deviceType = new DeviceTypes();
            using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
            {
                deviceType = (from type in dbContext.DeviceTypes
                              join device in dbContext.Devices on type.ID equals device.DeviceTypeId
                              where device.ID.Equals(deviceID.Trim())
                              select new DeviceTypes
                              {
                                  DeviceId = type.ID,
                                  DeviceName = type.Name
                              }).FirstOrDefault();
            }
            return deviceType;
        }

        private List<DeviceParameterEntity> GetDeviceParameters(DeviceTypes deviceType)
        {
            Guard.IsNotNull(deviceType, "No Valid Device TYpe mapping Found..");

            var defaultByte = default(byte);
            var defaultInt = default(int);
            var deviceParameterEntities = new List<DeviceParameterEntity>();

            using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
            {
                deviceParameterEntities = (from deviceParam in dbContext.DeviceParameters
                                           where deviceParam.DeviceTypeId.HasValue
                                           where deviceParam.DeviceTypeId.Value == deviceType.DeviceId && deviceParam.IsActive.Equals(true) && deviceParam.IsReturnParameter.Equals(true)
                                           select new DeviceParameterEntity
                                           {
                                               DeviceParameterId = deviceParam.Id,
                                               Name = deviceParam.Name,
                                               Index = deviceParam.Index,

                                               FormatCode = deviceParam.FormatCode,
                                               IsReturnParameter = deviceParam.IsReturnParameter,
                                               IgnoreError = deviceParam.IgnoreError,

                                               IsAutoReset = deviceParam.IsAutoReset,
                                               IsActive = deviceParam.IsActive,
                                               DisplayName = deviceParam.DisplayName,

                                               Description = deviceParam.Description,
                                               DataTypeName = deviceParam.DataTypeName,
                                               FormatErrorMessage = deviceParam.FormatErrorMessage,

                                               CreatedTime = deviceParam.CreatedTime.Value,
                                               ModifiedTime = deviceParam.ModifiedTime.Value,
                                               DeviceTypeId = deviceParam.DeviceTypeId.HasValue ? deviceParam.DeviceTypeId.Value : defaultByte,

                                               CreatedById = deviceParam.CreatedById.HasValue ? deviceParam.CreatedById.Value : defaultInt,
                                               ModifiedById = deviceParam.ModifiedById.HasValue ? deviceParam.ModifiedById.Value : defaultInt,
                                               PropertyGroupId = deviceParam.PropertyGroupId.HasValue ? deviceParam.PropertyGroupId.Value : defaultInt
                                           }).ToList();
            }
            return deviceParameterEntities;
        }

        private List<DeviceParameterValueEntity> GetDeviceParameterValue(int customerId, string deviceId)
        {
            List<DeviceParameterValueEntity> deviceParameterValue = new List<DeviceParameterValueEntity>();
            using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
            {
                deviceParameterValue = (from Value in dbContext.DeviceParameterValues
                                        where Value.CustomerId.Value == customerId
                                        where Value.DeviceId == deviceId.Trim()
                                        select new DeviceParameterValueEntity
                                        {
                                            DeviceParameterValueId = Value.Id,
                                            Value = Value.Value,
                                            OldValue = Value.Value,
                                            IsReset = Value.IsReset,

                                            ResetTime = Value.ResetTime,
                                            CreatedTime = Value.CreatedTime,
                                            ModifiedTime = Value.ModifiedTime,

                                            ParameterId = Value.ParameterId,
                                            CustomerId = Value.CustomerId,
                                            DeviceId = Value.DeviceId,

                                            CreatedById = Value.CreatedById,
                                            ModifiedById = Value.ModifiedById
                                        }).ToList();
            }
            return deviceParameterValue;
        }

        private List<DeviceParameterValueEntity> GetDeviceParameterValue()
        {
            List<DeviceParameterValueEntity> deviceParameterDefaultValue = new List<DeviceParameterValueEntity>();
            using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
            {
                deviceParameterDefaultValue = (from Value in dbContext.DeviceParameterValues
                                               where Value.CustomerId == null
                                               where Value.DeviceId == null
                                               select new DeviceParameterValueEntity
                                               {
                                                   DeviceParameterValueId = Value.Id,
                                                   Value = Value.Value,
                                                   OldValue = Value.Value,
                                                   IsReset = Value.IsReset,

                                                   ResetTime = Value.ResetTime,
                                                   CreatedTime = Value.CreatedTime,
                                                   ModifiedTime = Value.ModifiedTime,

                                                   ParameterId = Value.ParameterId,
                                                   CustomerId = Value.CustomerId,
                                                   DeviceId = Value.DeviceId,

                                                   CreatedById = Value.CreatedById,
                                                   ModifiedById = Value.ModifiedById
                                               }).ToList();
            }
            return deviceParameterDefaultValue;
        }

        private List<ReturnValueParameter> GetListOfParameterValuesForTheDeviceTypes(List<DeviceParameterEntity> deviceParameterEntities,
                                                                                    List<DeviceParameterValueEntity> deviceParameterValueEntities,
                                                                                    List<DeviceParameterValueEntity> customerParameterValues,
                                                                                    List<DeviceParameterValueEntity> deviceParameterValueDefaultEntities)
        {
            List<ReturnValueParameter> returnParams = new List<ReturnValueParameter>();
            foreach (var item in deviceParameterEntities)
            {
                ReturnValueParameter returnParameter = new ReturnValueParameter();
                returnParameter.Parameter = new BusinessEntities.DeviceParameterEntity();
                returnParameter.Parameter = item;

                //Retrive Device Level Overrides..
                var devicelevelValue = deviceParameterValueEntities.Where(x => x.ParameterId == item.DeviceParameterId).Select(x => x);
                if (devicelevelValue.Count() > 0)
                {
                    returnParameter.ParameterValue = new DeviceParameterValueEntity();
                    returnParameter.ParameterValue = devicelevelValue.FirstOrDefault();
                }
                else
                {
                    //If not found then Probe through to get CUstomer Level Overrides are there..
                    var customerlevelValue = customerParameterValues.Where(x => x.ParameterId == item.DeviceParameterId).Select(x => x);
                    if (customerlevelValue.Count() > 0)
                    {
                        returnParameter.ParameterValue = new DeviceParameterValueEntity();
                        returnParameter.ParameterValue = customerlevelValue.FirstOrDefault();
                    }
                    else //If not found then Probe through Default Device Type level Overrides..
                    {
                        var deviceTypelevelValue = deviceParameterValueDefaultEntities.Where(x => x.ParameterId == item.DeviceParameterId).Select(x => x);
                        returnParameter.ParameterValue = new DeviceParameterValueEntity();
                        returnParameter.ParameterValue = deviceTypelevelValue.FirstOrDefault();
                    }
                }
                returnParams.Add(returnParameter);
            }
            return returnParams;
        }

        public ProcessResponse DeleteDeviceParameterValues(string deviceId, ReturnParameterDataTransfer dataTransfer)
        {
            using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
            {
                Guard.IsNotNull(dataTransfer.ParamterValueIds, "ReturnParametersID");
                ProcessResponse response = new ProcessResponse();
                var ParamterValueIds = dataTransfer.ReturnParameterResponse.returnValueParameters.Select(x => x.ParameterValue.DeviceParameterValueId).ToList();
                var paramterValueRecords = dbContext.DeviceParameterValues.Where(x => ParamterValueIds.Contains(x.Id)).Where(z => z.CustomerId == dataTransfer.customerId).Where(y => y.DeviceId.Equals(deviceId.Trim())).ToList();

                foreach (DeviceParameterValue item in paramterValueRecords)
                {
                    dbContext.DeviceParameterValues.Remove(item);
                }
                try
                {
                    dbContext.SaveChanges();
                    response.Status = ResponseStatus.Success;
                    response.Message = "Successfully Saved..";
                }
                catch (Exception ex)
                {
                    response.Status = ResponseStatus.Failed;
                    response.Message = ex.Message;
                }
                return response;
            }
        }


        public ProcessResponse<List<ReturnValueParameter>> DeviceUpsetReturnParameters(string deviceId, List<ReturnParameterResponse> returnValueParameters, int customerId)
        {
            Guard.IsNotNull(returnValueParameters, "ReturnValueParameters");

            ProcessResponse<List<ReturnValueParameter>> response = new ProcessResponse<List<ReturnValueParameter>>();
            response.Status = ResponseStatus.Success;
            response.Message = "Successfully Saved..";

            using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
            {
                List<DeviceParameter> deviceParameters;
                List<DeviceParameterValue> deviceOverrideParameterValues;

                //Retrive DeviceParametersAndValues..
                GetDeviceParametersAndParameterValues(deviceId, customerId, dbContext, out deviceParameters, out deviceOverrideParameterValues);

                foreach (ReturnParameterResponse parameter in returnValueParameters)
                {
                    int deviceTypeId = parameter.deviceTypes.DeviceId;

                    List<ReturnValueParameter> incommingParameterValue = parameter.returnValueParameters;
                    if (incommingParameterValue.Count > 0)
                    {
                        //Retrive Customer Overriden Device Parameter Values for Edit Mode Decision....
                        IEnumerable<DeviceParameterValue> existingDeviceOverridenDeviceParameterValues = RetriveDeviceOverridenParameterValues(
                                                                                                            deviceOverrideParameterValues,
                                                                                                            incommingParameterValue);
                        foreach (var incomming in incommingParameterValue)
                        {
                            var filteredExisting = (from existingDeviceValue in existingDeviceOverridenDeviceParameterValues
                                                    where existingDeviceValue.ParameterId.Equals(incomming.Parameter.DeviceParameterId)
                                                    select existingDeviceValue).FirstOrDefault();

                            //Edit Mode is applicable if there is an entry for such parameterid....
                            if (filteredExisting != null)
                            {
                                filteredExisting.Value = incomming.ParameterValue.Value;
                                filteredExisting.IsReset = incomming.ParameterValue.IsReset.HasValue ? incomming.ParameterValue.IsReset.Value : false;
                                filteredExisting.ModifiedTime = DateTime.UtcNow;
                            }
                            else //Insertion Mode..
                            {
                                Guard.IsNotBlank(incomming.ParameterValue.Value, "Invalid Return Parameter");

                                DeviceParameterValue newDeviceParameterValue = new DeviceParameterValue();
                                newDeviceParameterValue.CustomerId = incomming.ParameterValue.CustomerId;
                                newDeviceParameterValue.IsReset = incomming.ParameterValue.IsReset.HasValue ? incomming.ParameterValue.IsReset.Value : false;
                                newDeviceParameterValue.Value = incomming.ParameterValue.Value;

                                newDeviceParameterValue.ParameterId = incomming.Parameter.DeviceParameterId;
                                newDeviceParameterValue.DeviceId = deviceId;
                                newDeviceParameterValue.CreatedTime = DateTime.UtcNow;
                                newDeviceParameterValue.ModifiedTime = DateTime.UtcNow;

                                dbContext.DeviceParameterValues.Add(newDeviceParameterValue);
                            }
                        }
                        try
                        {
                            dbContext.SaveChanges();
                            response.Object = incommingParameterValue;
                        }
                        catch (Exception ex)
                        {
                            response.Status = ResponseStatus.Failed;
                            response.Message = ex.Message;
                        }
                    }
                }
            }
            return response;
        }

        private static void GetDeviceParametersAndParameterValues(string deviceId, int customerId, SmartWashroomEntities dbContext,
                                                                out List<DeviceParameter> deviceParameters,
                                                                out List<DeviceParameterValue> deviceOverrideParameterValues)
        {
            deviceParameters = (from deviceParams in dbContext.DeviceParameters
                                where deviceParams.IsActive.Equals(true) && deviceParams.IsReturnParameter.Equals(true)
                                select deviceParams
                                ).ToList();

            //Existing Values pickup for updation.. (Customer Overrides : Logic Match the customer id and retrive all parametervalues where device id is null)
            deviceOverrideParameterValues = (from deviceParameterValues in dbContext.DeviceParameterValues
                                             where deviceParameterValues.CustomerId.Value.Equals(customerId)
                                             where deviceParameterValues.DeviceId.Equals(deviceId)
                                             select deviceParameterValues).ToList();

        }

        private static IEnumerable<DeviceParameterValue> RetriveDeviceOverridenParameterValues(List<DeviceParameterValue> deviceOverrideParameterValues,
                                                                                                List<ReturnValueParameter> deviceParameterValue)
        {
            var existingDeviceParameterValues = from incommingParam in deviceParameterValue

                                                join deviceParamValue in deviceOverrideParameterValues on incommingParam.Parameter.DeviceParameterId
                                                equals
                                                deviceParamValue.ParameterId

                                                select deviceParamValue;
            return existingDeviceParameterValues;
        }

        public List<BusinessEntities.SearchDeviceDetailsEntity> GetDeviceDetails(string DeviceId)
        {
            List<BusinessEntities.SearchDeviceDetailsEntity> lstEntities = null;
            try
            {
                using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                {
                    lstEntities = new List<BusinessEntities.SearchDeviceDetailsEntity>();

                    var idParam = new SqlParameter
                    {
                        ParameterName = "DEVICEID",
                        Value = DeviceId
                    };

                    lstEntities = (from entry in dbContext.Database.SqlQuery<GETDEVICEDETAILS_Result>("exec GETDEVICEDETAILS @DEVICEID", idParam)
                                   select new BusinessEntities.SearchDeviceDetailsEntity
                                   {
                                       BUILDINGID = entry.BUILDINGID,
                                       BUILDINGNAME = entry.BUILDINGNAME,
                                       CUSTOMERID = entry.CUSTOMERID,
                                       CUSTOMERNAME = entry.CUSTOMERNAME,
                                       DEVICEID = entry.DEVICEID,
                                       DEVICENAME = entry.DEVICENAME,
                                       DEVICETYPE = entry.DEVICETYPE,
                                       FLOORID = entry.FLOORID,
                                       FLOORLEVEL = entry.FLOORLEVEL,
                                       GENDER = entry.GENDER,
                                       GENDERID = entry.GENDERID,
                                       PROPERTYID = entry.PROPERTYID,
                                       PROPERTYNAME = entry.PROPERTYNAME,
                                       WASHROOMID = entry.WASHROOMID,
                                       WASHROOMNAME = entry.WASHROOMNAME,
                                       WINGID = entry.WINGID,
                                       WINGNAME = entry.WINGNAME
                                   }).ToList();

                    return lstEntities;
                }
            }
            catch (Exception dataException)
            {
                _errorDetail = dataException.Message;
                return lstEntities;
            }
        }

    }
}
