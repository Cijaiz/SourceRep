﻿using KC.SmartWashroom.Core.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers
{
    public static class EntityRepositoryManager
    {
        public static readonly string connectionString = string.Empty;
        static EntityRepositoryManager()
        {
            if (string.IsNullOrEmpty(connectionString))
                connectionString = CommonHelper.GetConfigSetting("SmartWashroomEntities");
        }

        public static SmartWashroomEntities GetStoreEntity()
        {
            return new SmartWashroomEntities(connectionString);
        }
    }
}
