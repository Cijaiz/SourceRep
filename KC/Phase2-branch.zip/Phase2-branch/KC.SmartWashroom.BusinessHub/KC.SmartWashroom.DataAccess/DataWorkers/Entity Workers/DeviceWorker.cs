﻿using KC.SmartWashroom.BusinessEntities.BusinessHubEntities;
using KC.SmartWashroom.Core.Enumerations;
using KC.SmartWashroom.DataAccess.Skeleton;
using System;
using System.Collections.Generic;
using System.Linq;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.Core.Helper;

namespace KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers
{
    public class DeviceWorker : IDeviceWorker
    {
        public Core.Helper.ProcessResponseForGateway SaveDeviceLog(BusinessEntities.DeviceLog deviceEntity)
        {
            throw new NotImplementedException();
        }

        public Core.Helper.ProcessResponseForGateway SaveDeviceStatus(DeviceLog deviceLog)
        {
            throw new NotImplementedException();
        }
        public Core.Helper.ProcessResponseForGateway SaveDeviceAlert(string deviceAlerts)
        {
            throw new NotImplementedException();
        }

        public void LogIncomingDeviceDetail(DeviceAuditLog entity)
        {
            throw new NotImplementedException();
        }

        public DeviceAssociation GetDeviceAssociation(string deviceId)
        {
                DeviceAssociation deviceAssociation = null;

                using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                {
                   
                    var query = (from property in dbContext.Properties
                                 join building in dbContext.Buildings on property.ID equals building.PropertyId
                                 join floor in dbContext.Floors on building.ID equals floor.BuildingId
                                 join washroom in dbContext.Washrooms on floor.ID equals washroom.FloorId
                                 join devicewashroom in dbContext.DeviceWashrooms on washroom.ID equals devicewashroom.WashroomId
                                 join devices in dbContext.Devices on devicewashroom.DeviceId equals devices.ID
                                 where devices.ID == deviceId && devicewashroom.IsActive == true
                                 select new DeviceAssociation()
                                 {
                                     CustomerId = property.CustomerId,
                                     PropertyId = property.ID,
                                     BuildingId = building.ID,
                                     FloorLevel = floor.FloorLevel,
                                     FloorId = floor.ID,
                                     WashroomId = washroom.ID,
                                     DeviceId = deviceId,
                                     IsDeviceActive = devices.IsActive
                                 });

                   
                    deviceAssociation = query.FirstOrDefault();
                    return deviceAssociation;
                }
           
        }

        public List<DeviceResolutionDetail> GetAllDevicesForBuilding(int propertyId, int buildingId, int floorId, int washroomId)
        {
            List<DeviceResolutionDetail> devicesForBuilding = null;
            using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
            {
                devicesForBuilding = (from building in dbContext.Buildings
                                      join floors in dbContext.Floors on building.ID equals floors.BuildingId
                                      join washroom in dbContext.Washrooms on floors.ID equals washroom.FloorId
                                      join gender in dbContext.Genders on washroom.GenderId equals gender.ID
                                      join devicewashroom in dbContext.DeviceWashrooms on washroom.ID equals devicewashroom.WashroomId
                                      join device in dbContext.Devices on devicewashroom.DeviceId equals device.ID
                                      join property in dbContext.Properties on building.PropertyId equals property.ID
                                      join customer in dbContext.Customers on property.CustomerId equals customer.ID
                                      where building.PropertyId.Equals(propertyId) &&
                                            building.ID.Equals(buildingId) &&
                                            (floorId == 0 || floors.ID == floorId) &&
                                            (washroomId == 0 || washroom.ID == washroomId) &&
                                            device.IsActive.Equals(true) &&
                                            devicewashroom.IsActive == true
                                      select new DeviceResolutionDetail()
                                      {
                                          DeviceID = device.ID,
                                          DeviceName = device.Name,
                                          Floor = floors.FloorLevel,
                                          Wing = washroom.Wing.Name,
                                          Washroom = washroom.Name,
                                          WashroomGender = gender.Name,
                                          DeviceType = device.DeviceType.Name.Trim().ToUpper(),
                                          PropertyName = property.PropertyName,
                                          Building = building.Name,

                                          LocalTimeZone = property.LocationTimeZone,
                                          CustomerId = customer.ID,
                                          ProductRefillDetail = (from productRefillDetail in dbContext.ProductRefillDetails
                                                                 join product in dbContext.Products
                                                                 on productRefillDetail.ProductId equals product.ID
                                                                 where product.Type.ToUpper().Equals(device.DeviceType.Name.Trim().ToUpper())
                                                                 select new BusinessEntities.BusinessHubEntities.ProductRefillDetail()
                                                                 {
                                                                     ProductId = product.ID,
                                                                     RefillValue = productRefillDetail.RefillValue,
                                                                     Size = productRefillDetail.Size
                                                                 }).ToList()
                                      }).ToList();
            }
            return devicesForBuilding;
        }

        public List<DeviceResolutionDetail> GetAllDevicesForUser(int userId, int roleLevel, int customerId, int buildingId)
        {
            List<DeviceResolutionDetail> devices = null;
            //Property Admin
            if (roleLevel == (int)Enums.RoleLevelType.PropertyAdmin)
            {
                using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                {
                    devices = (from user in dbContext.Users
                               join customer in dbContext.Customers on user.CustomerId equals customer.ID
                               join prop in dbContext.Properties on customer.ID equals prop.CustomerId
                               join userProp in dbContext.UserProperties on prop.ID equals userProp.PropertyId
                               where userProp.UserId == userId
                               join building in dbContext.Buildings on prop.ID equals building.PropertyId
                               join floors in dbContext.Floors on building.ID equals floors.BuildingId
                               join washroom in dbContext.Washrooms on floors.ID equals washroom.FloorId
                               join gender in dbContext.Genders on washroom.GenderId equals gender.ID
                               join devicewashroom in dbContext.DeviceWashrooms on washroom.ID equals devicewashroom.WashroomId
                               join device in dbContext.Devices on devicewashroom.DeviceId equals device.ID
                               join type in dbContext.DeviceTypes on device.DeviceTypeId equals type.ID
                               //join deviceAlert in dbContext.DeviceAlerts on devicewashroom.DeviceId equals deviceAlert.DeviceId
                               //join deviceAlertType in dbContext.AlertTypes on device.AlertTypeId equals deviceAlertType.ID
                               where user.ID == userId && prop.IsActive == true && building.IsActive == true && floors.IsActive == true && washroom.IsActive == true
                                          && device.IsActive == true && devicewashroom.IsActive== true && (buildingId != 0 ? building.ID == buildingId : true)
                               select new DeviceResolutionDetail()
                               {
                                   DeviceID = device.ID,
                                   DeviceName = device.Name,
                                   Floor = floors.FloorLevel,
                                   Wing = washroom.Wing.Name,

                                   Washroom = washroom.Name,
                                   WashroomGender = gender.Name,
                                   PropertyId = prop.ID,
                                   PropertyName = prop.PropertyName,
                                   Building = building.Name,


                                   FloorId = floors.ID,
                                   DeviceTypeId = type.ID,
                                   RoomTypeId = gender.ID,

                                   LocalTimeZone = prop.LocationTimeZone,
                                   CustomerId = customer.ID,
                                   DeviceType = device.DeviceType.Name.Trim().ToUpper(),
                                   ProductRefillDetail = (from productRefillDetail in dbContext.ProductRefillDetails
                                                          join product in dbContext.Products
                                                          on productRefillDetail.ProductId equals product.ID
                                                          where product.Type.ToUpper().Equals(device.DeviceType.Name.Trim().ToUpper())
                                                          select new BusinessEntities.BusinessHubEntities.ProductRefillDetail() { ProductId = product.ID, RefillValue = productRefillDetail.RefillValue, Size = productRefillDetail.Size }).ToList()
                               }).ToList();
                }
            }
            else if (roleLevel == (int)Enums.RoleLevelType.BuildingAdmin)
            {
                using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                {
                    devices = (from user in dbContext.Users
                               join customer in dbContext.Customers on user.CustomerId equals customer.ID
                               join prop in dbContext.Properties on customer.ID equals prop.CustomerId
                               join building in dbContext.Buildings on prop.ID equals building.PropertyId
                               join userBuilding in dbContext.UserBuildings on building.ID equals userBuilding.BuildingId
                               where userBuilding.UserId == userId
                               join floors in dbContext.Floors on building.ID equals floors.BuildingId
                               join washroom in dbContext.Washrooms on floors.ID equals washroom.FloorId
                               join gender in dbContext.Genders on washroom.GenderId equals gender.ID
                               join devicewashroom in dbContext.DeviceWashrooms on washroom.ID equals devicewashroom.WashroomId
                               join device in dbContext.Devices on devicewashroom.DeviceId equals device.ID
                               join type in dbContext.DeviceTypes on device.DeviceTypeId equals type.ID
                               //join deviceAlert in dbContext.DeviceAlerts on devicewashroom.DeviceId equals deviceAlert.DeviceId
                               //join deviceAlertType in dbContext.AlertTypes on device.AlertTypeId equals deviceAlertType.ID
                               where user.ID == userId && prop.IsActive == true && building.IsActive == true && floors.IsActive == true && washroom.IsActive == true
                                          && device.IsActive == true && devicewashroom.IsActive==true && (buildingId != 0 ? building.ID == buildingId : true)
                               select new DeviceResolutionDetail()
                               {
                                   DeviceID = device.ID,
                                   DeviceName = device.Name,
                                   Floor = floors.FloorLevel,
                                   PropertyName = prop.PropertyName,
                                   Building = building.Name,

                                   Wing = washroom.Wing.Name,
                                   Washroom = washroom.Name,
                                   WashroomGender = gender.Name,
                                   PropertyId = prop.ID,

                                   FloorId = floors.ID,
                                   DeviceTypeId = type.ID,
                                   RoomTypeId = gender.ID,

                                   LocalTimeZone = prop.LocationTimeZone,
                                   CustomerId = customer.ID,
                                   DeviceType = device.DeviceType.Name.Trim().ToUpper(),
                                   ProductRefillDetail = (from productRefillDetail in dbContext.ProductRefillDetails
                                                          join product in dbContext.Products
                                                          on productRefillDetail.ProductId equals product.ID
                                                          where product.Type.ToUpper().Equals(device.DeviceType.Name.Trim().ToUpper())
                                                          select new BusinessEntities.BusinessHubEntities.ProductRefillDetail() { ProductId = product.ID, RefillValue = productRefillDetail.RefillValue, Size = productRefillDetail.Size }).ToList()
                               }).ToList();
                }
            }
            else
            {
                using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                {
                    devices = (from customer in dbContext.Customers
                               join prop in dbContext.Properties on customer.ID equals prop.CustomerId
                               join building in dbContext.Buildings on prop.ID equals building.PropertyId
                               join floors in dbContext.Floors on building.ID equals floors.BuildingId
                               join washroom in dbContext.Washrooms on floors.ID equals washroom.FloorId
                               join gender in dbContext.Genders on washroom.GenderId equals gender.ID
                               join devicewashroom in dbContext.DeviceWashrooms on washroom.ID equals devicewashroom.WashroomId
                               join device in dbContext.Devices on devicewashroom.DeviceId equals device.ID
                               join type in dbContext.DeviceTypes on device.DeviceTypeId equals type.ID
                               //join deviceAlert in dbContext.DeviceAlerts on devicewashroom.DeviceId equals deviceAlert.DeviceId
                               //join deviceAlertType in dbContext.AlertTypes on device.AlertTypeId equals deviceAlertType.ID
                               where customer.ID == customerId && prop.IsActive == true && building.IsActive == true && floors.IsActive == true && washroom.IsActive == true
                                      && device.IsActive == true && devicewashroom.IsActive== true && (buildingId != 0 ? building.ID == buildingId : true)
                               select new DeviceResolutionDetail()
                               {
                                   DeviceID = device.ID,
                                   DeviceName = device.Name,
                                   Floor = floors.FloorLevel,
                                   PropertyName = prop.PropertyName,
                                   Building = building.Name,

                                   Wing = washroom.Wing.Name,
                                   Washroom = washroom.Name,
                                   WashroomGender = gender.Name,
                                   PropertyId = prop.ID,

                                   FloorId = floors.ID,
                                   DeviceTypeId = type.ID,
                                   RoomTypeId = gender.ID,

                                   LocalTimeZone = prop.LocationTimeZone,
                                   CustomerId = customer.ID,
                                   DeviceType = device.DeviceType.Name.Trim().ToUpper(),
                                   ProductRefillDetail = (from productRefillDetail in dbContext.ProductRefillDetails
                                                          join product in dbContext.Products
                                                          on productRefillDetail.ProductId equals product.ID
                                                          where product.Type.ToUpper().Equals(device.DeviceType.Name.Trim().ToUpper())
                                                          select new BusinessEntities.BusinessHubEntities.ProductRefillDetail() { ProductId = product.ID, RefillValue = productRefillDetail.RefillValue, Size = productRefillDetail.Size }).ToList()
                               }).ToList();
                }
            }

            return devices;
        }

        public IList<DeviceResolutionDetail> GetDeviceInfo(int propertyId, IList<string> deviceIdList)
        {
            List<DeviceResolutionDetail> devices = null;
                using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                {
                    devices = (from prop in dbContext.Properties 
                               join building in dbContext.Buildings on prop.ID equals building.PropertyId
                               join floors in dbContext.Floors on building.ID equals floors.BuildingId
                               join washroom in dbContext.Washrooms on floors.ID equals washroom.FloorId
                               join gender in dbContext.Genders on washroom.GenderId equals gender.ID
                               join devicewashroom in dbContext.DeviceWashrooms on washroom.ID equals devicewashroom.WashroomId
                               join device in dbContext.Devices on devicewashroom.DeviceId equals device.ID
                               join type in dbContext.DeviceTypes on device.DeviceTypeId equals type.ID
                               join deviceId in deviceIdList on device.ID equals deviceId
                               where prop.ID == propertyId && prop.IsActive == true && building.IsActive == true && floors.IsActive == true && washroom.IsActive == true
                                          && device.IsActive == true && devicewashroom.IsActive == true 
                               select new DeviceResolutionDetail()
                               {
                                   DeviceID = device.ID,
                                   DeviceName = device.Name,
                                   Floor = floors.FloorLevel,

                                   Washroom = washroom.Name,
                                   WashroomGender = gender.Name,
                                   PropertyId = prop.ID,
                                   PropertyName = prop.PropertyName,
                                   Building = building.Name,

                                   Wing = washroom.Wing.Name,
                                   FloorId = floors.ID,
                                   DeviceTypeId = type.ID,
                                   RoomTypeId = gender.ID,

                                   LocalTimeZone = prop.LocationTimeZone,
                                   DeviceType = device.DeviceType.Name.Trim().ToUpper()
                               }).ToList();
                }
            

            return devices;
        }
        public List<DeviceResolutionDetail> GetAlleHRTDevicesForUser(int userId, int roleLevel, int customerId)
        {
            List<DeviceResolutionDetail> devices = new List<DeviceResolutionDetail>();
            //Property Admin
            if (roleLevel == (int)Enums.RoleLevelType.PropertyAdmin)
            {
                using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                {
                    devices = (from user in dbContext.Users
                               join customer in dbContext.Customers on user.CustomerId equals customer.ID
                               join prop in dbContext.Properties on customer.ID equals prop.CustomerId
                               join userProp in dbContext.UserProperties on prop.ID equals userProp.PropertyId
                               where userProp.UserId == userId
                               join building in dbContext.Buildings on prop.ID equals building.PropertyId
                               join floors in dbContext.Floors on building.ID equals floors.BuildingId
                               join washroom in dbContext.Washrooms on floors.ID equals washroom.FloorId
                               join gender in dbContext.Genders on washroom.GenderId equals gender.ID
                               join devicewashroom in dbContext.DeviceWashrooms on washroom.ID equals devicewashroom.WashroomId
                               join device in dbContext.Devices on devicewashroom.DeviceId equals device.ID
                               join type in dbContext.DeviceTypes on device.DeviceTypeId equals type.ID
                               //join deviceAlert in dbContext.DeviceAlerts on devicewashroom.DeviceId equals deviceAlert.DeviceId
                               //join deviceAlertType in dbContext.AlertTypes on device.AlertTypeId equals deviceAlertType.ID
                               where user.ID == userId && prop.IsActive == true && building.IsActive == true && floors.IsActive == true && washroom.IsActive == true
                                          && device.IsActive == true && devicewashroom.IsActive == true && type.Name.ToString().ToLower() == "ehrt"
                               select new DeviceResolutionDetail()
                               {
                                   DeviceID = device.ID,
                                   DeviceName = device.Name,
                                   Floor = floors.FloorLevel,
                                   Washroom = washroom.Name,
                                   WashroomGender = gender.Name,
                                   PropertyId = prop.ID,
                                   PropertyName = prop.PropertyName,
                                   Building = building.Name,
                                   Wing = washroom.Wing.Name,
                                   FloorId = floors.ID,
                                   DeviceTypeId = type.ID,
                                   RoomTypeId = gender.ID
                               }).ToList();
                }
            }
            else if (roleLevel == (int)Enums.RoleLevelType.BuildingAdmin)
            {
                using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                {
                    devices = (from user in dbContext.Users
                               join customer in dbContext.Customers on user.CustomerId equals customer.ID
                               join prop in dbContext.Properties on customer.ID equals prop.CustomerId
                               join building in dbContext.Buildings on prop.ID equals building.PropertyId
                               join userBuilding in dbContext.UserBuildings on building.ID equals userBuilding.BuildingId
                               where userBuilding.UserId == userId
                               join floors in dbContext.Floors on building.ID equals floors.BuildingId
                               join washroom in dbContext.Washrooms on floors.ID equals washroom.FloorId
                               join gender in dbContext.Genders on washroom.GenderId equals gender.ID
                               join devicewashroom in dbContext.DeviceWashrooms on washroom.ID equals devicewashroom.WashroomId
                               join device in dbContext.Devices on devicewashroom.DeviceId equals device.ID
                               join type in dbContext.DeviceTypes on device.DeviceTypeId equals type.ID
                               //join deviceAlert in dbContext.DeviceAlerts on devicewashroom.DeviceId equals deviceAlert.DeviceId
                               //join deviceAlertType in dbContext.AlertTypes on device.AlertTypeId equals deviceAlertType.ID
                               where user.ID == userId && prop.IsActive == true && building.IsActive == true && floors.IsActive == true && washroom.IsActive == true
                                          && device.IsActive == true && devicewashroom.IsActive == true && type.Name.ToString().ToLower() == "ehrt"
                               select new DeviceResolutionDetail()
                               {
                                   DeviceID = device.ID,
                                   DeviceName = device.Name,
                                   Floor = floors.FloorLevel,
                                   Washroom = washroom.Name,
                                   WashroomGender = gender.Name,
                                   PropertyId = prop.ID,
                                   Wing = washroom.Wing.Name,
                                   PropertyName = prop.PropertyName,
                                   Building = building.Name,
                                   FloorId = floors.ID,
                                   DeviceTypeId = type.ID,
                                   RoomTypeId = gender.ID
                               }).ToList();
                }
            }
            else
            {
                using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                {
                    devices = (from customer in dbContext.Customers
                               join prop in dbContext.Properties on customer.ID equals prop.CustomerId
                               join building in dbContext.Buildings on prop.ID equals building.PropertyId
                               join floors in dbContext.Floors on building.ID equals floors.BuildingId
                               join washroom in dbContext.Washrooms on floors.ID equals washroom.FloorId
                               join gender in dbContext.Genders on washroom.GenderId equals gender.ID
                               join devicewashroom in dbContext.DeviceWashrooms on washroom.ID equals devicewashroom.WashroomId
                               join device in dbContext.Devices on devicewashroom.DeviceId equals device.ID
                               join type in dbContext.DeviceTypes on device.DeviceTypeId equals type.ID
                               //join deviceAlert in dbContext.DeviceAlerts on devicewashroom.DeviceId equals deviceAlert.DeviceId
                               //join deviceAlertType in dbContext.AlertTypes on device.AlertTypeId equals deviceAlertType.ID
                               where customer.ID == customerId && prop.IsActive == true && building.IsActive == true && floors.IsActive == true && washroom.IsActive == true
                               && device.IsActive == true && devicewashroom.IsActive == true && type.Name.ToString().ToLower() == "ehrt"
                               select new DeviceResolutionDetail()
                               {
                                   DeviceID = device.ID,
                                   DeviceName = device.Name,
                                   Floor = floors.FloorLevel,
                                   Washroom = washroom.Name,
                                   WashroomGender = gender.Name,
                                   PropertyId = prop.ID,
                                   PropertyName = prop.PropertyName,
                                   Building = building.Name,
                                   FloorId = floors.ID,
                                   Wing = washroom.Wing.Name,
                                   DeviceTypeId = type.ID,
                                   RoomTypeId = gender.ID
                               }).ToList();
                }
            }
            return devices;
        }

        public List<DeviceRefillDetail> GetAllSoapDevicesForBuilding(int buildingId)
        {
            List<DeviceRefillDetail> devicesForBuilding = null;
            using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
            {
                devicesForBuilding = (from building in dbContext.Buildings
                                      join floors in dbContext.Floors on building.ID equals floors.BuildingId
                                      join washroom in dbContext.Washrooms on floors.ID equals washroom.FloorId
                                      join gender in dbContext.Genders on washroom.GenderId equals gender.ID
                                      join devicewashroom in dbContext.DeviceWashrooms on washroom.ID equals devicewashroom.WashroomId
                                      join device in dbContext.Devices on devicewashroom.DeviceId equals device.ID
                                      where device.ID.Contains("0000007")
                                      where building.ID.Equals(buildingId) && device.IsActive.Equals(true) && devicewashroom.IsActive == true 
                                      select new DeviceRefillDetail()
                                      {
                                          DeviceId = device.ID,
                                      }).ToList();
            }
            return devicesForBuilding;
        }

        public List<BusinessEntities.DeviceLog> GetAllDeviceLogsForDevice(string deviceId)
        {
            throw new NotImplementedException();
        }

        public bool IfAlertExists(string deviceID, string alertType)
        {
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {

                int alertId = (from alerts in dbEntity.AlertTypes
                               where alerts.Type == alertType
                               select alerts.ID
                              ).FirstOrDefault();
                var deviceAlert = (from devicealerts in dbEntity.DeviceAlerts
                                   where devicealerts.DeviceId == deviceID && devicealerts.AlertTypeId == alertId
                                   select devicealerts);

                if (deviceAlert == null || deviceAlert.Count() == 0)
                    return false;

                else
                    return true;

            }
        }

        public IList<DeviceAlertGroupInfo> GetDeviceAlertTypes(string deviceType)
        {
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {

                IList<DeviceAlertGroupInfo> alertGroupInfoList = (from alertsMapping in dbEntity.DeviceAlertMappings
                                                                  join dbdeviceTypes in dbEntity.DeviceTypes
                                                                      on alertsMapping.DeviceTypeId equals dbdeviceTypes.ID
                                                                  join dbalertName in dbEntity.DeviceAlertNames
                                                                      on alertsMapping.AlertNameId equals dbalertName.ID
                                                                  join alertcodes in dbEntity.AlertTypes
                                                                      on alertsMapping.AlertTypeId equals alertcodes.ID
                                                                  where dbdeviceTypes.Name.Equals(deviceType, StringComparison.OrdinalIgnoreCase)
                                                                  select new DeviceAlertGroupInfo()
                                                                  {
                                                                      AlertGroup = dbalertName.AlertName,
                                                                      AlertType = alertcodes.Type
                                                                  }).ToList();

                return alertGroupInfoList;
            }
        }
        public string GetDeviceAlertCode(string alertName, string deviceType)
        {
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {

                string alertCode = (from alertsMapping in dbEntity.DeviceAlertMappings
                                    join dbdeviceTypes in dbEntity.DeviceTypes
                                        on alertsMapping.DeviceTypeId equals dbdeviceTypes.ID
                                    join dbalertName in dbEntity.DeviceAlertNames
                                        on alertsMapping.AlertNameId equals dbalertName.ID
                                    join alertcodes in dbEntity.AlertTypes
                                        on alertsMapping.AlertTypeId equals alertcodes.ID
                                    where dbdeviceTypes.Name.Equals(deviceType, StringComparison.OrdinalIgnoreCase)
                                    && dbalertName.AlertName.Equals(alertName, StringComparison.OrdinalIgnoreCase)
                                    select alertcodes.Type).FirstOrDefault();

                return alertCode;
            }
        }
        public KeyValuePair<string, KeyValuePair<int, double>> GetDeviceSizeandLastDispensedValue(int customerId, string deviceId, Enums.DeviceType type)
        {
            throw new NotImplementedException();
        }

        public List<BusinessEntities.AlertEngineEntities.DeviceAlert> CheckUnresponsive(int customerId, List<DeviceResolutionDetail> Alldevices)
        {
            throw new NotImplementedException();
        }
        public bool IsAlertExists(int customerId, string deviceId, string alertCode)
        {
            throw new NotImplementedException();
        }
        public DeviceInformation GetDeviceAlertStatus(string deviceID)
        {
            DeviceInformation deviceAlertStatus = null;
            using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
            {
                deviceAlertStatus = (from device in dbContext.SPGETDEVICEPROPERTY(deviceID)
                                     select new BusinessEntities.DeviceInformation
                                     {
                                         DeviceId = device.ID,
                                         DeviceType = device.DeviceType,
                                         WashroomId = device.WashroomId,

                                         WashroomName = device.Washroom,
                                         FloorId = device.FloorId,
                                         FloorLevel = device.FloorLevel,

                                         BuildingId = device.BuildingID,
                                         BuildingName = device.BuildingName,
                                         PropertyID = device.PropertyID,

                                         PropertyName = device.PropertyName,
                                         CustomerID = device.CustomerID,
                                         CustomerName = device.CustomerName
                                     }).FirstOrDefault();
                return deviceAlertStatus;
            }
        }

        public ProcessResponse ClearAllDeviceOverrides(List<int?> parameterIds, int customerId)
        {
            ProcessResponse reponse = new ProcessResponse() { Status = ResponseStatus.Success, Message = "Successfully Removed the Device Overrides" };
            using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
            {
                //Retrive All the Customer Level Overrides for filteration adn deleteion.
                var customerOverrides = from deviceParameterValue in dbContext.DeviceParameterValues
                                        where deviceParameterValue.DeviceId != null
                                        where deviceParameterValue.CustomerId.HasValue
                                        where deviceParameterValue.CustomerId.Value.Equals(customerId)
                                        select deviceParameterValue;

                List<DeviceParameterValue> tobeDeletedList = new List<DeviceParameterValue>();
                foreach (int? parameterId in parameterIds)
                {
                    var parameterOverridesforAllDevices = customerOverrides.Where(a => a.ParameterId.Equals(parameterId.Value)).ToList();
                    foreach (var delete in parameterOverridesforAllDevices)
                        tobeDeletedList.Add(delete);
                }

                //Bulk Removal... For all the Devices..
                dbContext.DeviceParameterValues.RemoveRange(tobeDeletedList);

                try
                {
                    dbContext.SaveChanges();
                }
                catch (Exception ex)
                {
                    reponse.Status = ResponseStatus.Failed;
                    reponse.Message = ex.Message;
                }
            }
            return reponse;
        }

        public JRTParameters GetJRTDeviceStatus(int customerId, string deviceId)
        {
            throw new NotImplementedException();
        }

        public eHRTParameters GetEhrtDeviceStatus(int customerId, string deviceId)
        {
            throw new NotImplementedException();
        }

        public eSoapParameters GetEsoapDeviceStatus(int customerId, string deviceId)
        {
            throw new NotImplementedException();
        }

        public SRBParameters GetSRBDeviceStatus(int customerId, string deviceId)
        {
            throw new NotImplementedException();
        }

        DeviceSizeAndDispensedValue IDeviceWorker.GetDeviceSizeandLastDispensedValue(int customerId, string deviceId, Enums.DeviceType type)
        {
            DeviceSizeAndDispensedValue deviceSizeandDispensedValue;

            using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
            {
                deviceSizeandDispensedValue = (from device in dbContext.Devices
                                               join productRefill in dbContext.ProductRefillDetails on device.ProductRefillId equals productRefill.ID
                                               where device.ID.Equals(deviceId)
                                               select new DeviceSizeAndDispensedValue()
                                               {
                                                   DeviceSize = productRefill.Size
                                               }).FirstOrDefault();
            }
            return deviceSizeandDispensedValue;
        }

        public void DeleteDeviceStatus(string deviceId,int customerId)
        {
            throw new NotImplementedException();
        }

        public void DeleteAlertStatus(string deviceId, int customerId)
        {
            throw new NotImplementedException();
        }

        public ProcessResponseForGateway SaveDeviceForCache(string deviceId)
        {
            throw new NotImplementedException();
        }
    }
}
