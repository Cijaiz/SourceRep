﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.DataAccess.Skeleton;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers
{
    public class UsageMartWorker : IUsageMartWorker
    {
        public List<ReportGenericEntity> GetTrafficDataWeekwise(ReportFilterEntity FilterValues)
        {
            List<ReportGenericEntity> newReportGenList = new List<ReportGenericEntity>();
            List<string> Days = new List<string>();
            try
            {
                TimeZoneInfo PropTimeZoneInfo = GetPropertyTimezone(Convert.ToInt32(FilterValues.PropertyId));
                DateTime StartDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)FilterValues.StartDate, PropTimeZoneInfo);
                DateTime EndDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)FilterValues.EndDate, PropTimeZoneInfo);

                Days = CommonHelper.GetDaysForWeek(StartDate, EndDate);
                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    var UsageMart = dbEntity.Set<UsageMart>().ToList();
                    var TrafficData = (from u in UsageMart
                                       where u.CustomerId == FilterValues.CustomerId &
                                        (FilterValues.PropertyId != "0" ? u.PropertyId == FilterValues.PropertyId : true) &
                                        (FilterValues.BuildingId != "0" ? u.BuildingId == FilterValues.BuildingId : true) &
                                        (FilterValues.FloorId != "0" ? u.FloorId == FilterValues.FloorId : true) &
                                        (FilterValues.RoomId != "0" ? u.WashRoomId == FilterValues.RoomId : true) &
                                        (FilterValues.StartDate != null ? u.UsageDate >= FilterValues.StartDate : true) &
                                        (FilterValues.EndDate != null ? u.UsageDate <= FilterValues.EndDate : true) &
                                        (FilterValues.Month != "0" ? u.UsageMonth == FilterValues.Month : true) &
                                        (FilterValues.Year != 0 ? u.UsageYear == FilterValues.Year : true) &
                                        u.DeviceType == TrafficChartConstants.eHRT.ToString()
                                       orderby u.UsageDate ascending
                                       group u by new
                                       {
                                           u.UsageDayOfWeek
                                       } into u1
                                       select new
                                       {
                                           u1.Key.UsageDayOfWeek,
                                           Week = "Week",
                                           CountOfTraffic = u1.Sum(x => x.CountOfPaperUsed) / 2
                                       }).ToList();

                    var finalData = (from day in Days
                                     join data in TrafficData
                                         on day equals data.UsageDayOfWeek into joinedData
                                     from report in joinedData.DefaultIfEmpty()
                                     select new
                                     {
                                         UsageDayOfWeek = day,
                                         Week = "Week",
                                         CountOfTraffic = report != null ? report.CountOfTraffic : 0
                                     }).ToList();
                    if (finalData.Count != 0)
                    {
                        foreach (var Traffic in finalData)
                        {
                            ReportGenericEntity gen = new ReportGenericEntity();
                            gen[TrafficChartConstants.XAxisWeek.ToString()] = Traffic.UsageDayOfWeek;
                            gen[TrafficChartConstants.SecondaryAxisWeek.ToString()] = Traffic.Week;
                            gen[TrafficChartConstants.YAxisTraffic.ToString()] = Traffic.CountOfTraffic;
                            newReportGenList.Add(gen);
                        }
                    }

                }
            }
            catch
            {
                throw new Exception();
            }

            return newReportGenList;
        }

        public List<ReportGenericEntity> GetTrafficDataMonthWise(ReportFilterEntity FilterValues)
        {
            List<ReportGenericEntity> newReportGenList = new List<ReportGenericEntity>();
            List<string> Dates = new List<string>();
            try
            {
                //Check the filter, if it is for this month or last month
                if (FilterValues.PeriodId.Equals(CommonConstants.FilterThisMonth))
                {
                    Dates = CommonHelper.GetDatesThisMonth(GetPropertyTimezone(Convert.ToInt32(FilterValues.PropertyId)));
                }
                else if (FilterValues.PeriodId.Equals(CommonConstants.FilterLastMonth))
                {
                    Dates = CommonHelper.GetDatesLastMonth(GetPropertyTimezone(Convert.ToInt32(FilterValues.PropertyId)));
                }
                else
                {
                    Dates = CommonHelper.GetDatesForMonth(FilterValues.Month, FilterValues.Year, GetPropertyTimezoneFromBuilding(Convert.ToInt32(FilterValues.BuildingId)));
                }

                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    var UsageMart = dbEntity.Set<UsageMart>().ToList();
                    var TrafficData = (from u in UsageMart
                                       where u.CustomerId == FilterValues.CustomerId &
                                        (FilterValues.PropertyId != "0" ? u.PropertyId == FilterValues.PropertyId : true) &
                                        (FilterValues.BuildingId != "0" ? u.BuildingId == FilterValues.BuildingId : true) &
                                        (FilterValues.FloorId != "0" ? u.FloorId == FilterValues.FloorId : true) &
                                        (FilterValues.RoomId != "0" ? u.WashRoomId == FilterValues.RoomId : true) &
                                        (FilterValues.StartDate != null ? u.UsageDate >= FilterValues.StartDate : true) &
                                        (FilterValues.EndDate != null ? u.UsageDate <= FilterValues.EndDate : true) &
                                        (FilterValues.Month != "0" ? u.UsageMonth == FilterValues.Month : true) &
                                        (FilterValues.Year != 0 ? u.UsageYear == FilterValues.Year : true) &
                                        u.DeviceType == TrafficChartConstants.eHRT.ToString()
                                       orderby u.UsageDate ascending
                                       group u by new
                                       {
                                           u.UsageDay
                                       } into u1
                                       select new
                                       {
                                           u1.Key.UsageDay,
                                           Month = "Month",
                                           CountOfTraffic = u1.Sum(x => x.CountOfPaperUsed) / 2
                                       }).ToList();
                    var finalData = (from day in Dates
                                     join data in TrafficData
                                         on day equals data.UsageDay.ToString() into joinedData
                                     from report in joinedData.DefaultIfEmpty()
                                     select new
                                     {
                                         UsageDay = day,
                                         Month = "Month",
                                         CountOfTraffic = report != null ? report.CountOfTraffic : 0
                                     }).ToList();
                    if (finalData.Count != 0)
                    {
                        foreach (var Traffic in finalData)
                        {
                            ReportGenericEntity gen = new ReportGenericEntity();
                            gen[TrafficChartConstants.XAxisMonth.ToString()] = Traffic.UsageDay;
                            gen[TrafficChartConstants.SecondaryAxisMonth.ToString()] = Traffic.Month;
                            gen[TrafficChartConstants.YAxisTraffic.ToString()] = Traffic.CountOfTraffic;
                            newReportGenList.Add(gen);
                        }
                    }

                }
            }
            catch
            {
                throw new Exception();
            }

            return newReportGenList;
        }

        public List<ReportGenericEntity> GetProductUsageWeekwise(ReportFilterEntity FilterValues)
        {
            List<ReportGenericEntity> newReportGenList = new List<ReportGenericEntity>();
            List<string> Days = new List<string>();
            List<string> DeviceTypes = new List<string>();
            try
            {
                TimeZoneInfo PropTimeZoneInfo = GetPropertyTimezone(Convert.ToInt32(FilterValues.PropertyId));
                DateTime StartDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)FilterValues.StartDate, PropTimeZoneInfo);
                DateTime EndDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)FilterValues.EndDate, PropTimeZoneInfo);

                //Get All device types from database
                DeviceTypes = GetAllDeviceTypes();

                Days = CommonHelper.GetDaysForWeek(StartDate, EndDate);

                //Get Device Types and Day combined data
                var ListDeviceTypeDays = (from deviceType in DeviceTypes
                                          from day in Days
                                          select new
                                          {
                                              UsageDayOfWeek = day,
                                              DeviceType = deviceType
                                          }).ToList();

                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    var UsageMart = dbEntity.Set<UsageMart>().ToList();
                    var UsageData = (from u in UsageMart
                                     where u.CustomerId == FilterValues.CustomerId &
                                      (FilterValues.PropertyId != "0" ? u.PropertyId == FilterValues.PropertyId : true) &
                                      (FilterValues.BuildingId != "0" ? u.BuildingId == FilterValues.BuildingId : true) &
                                      (FilterValues.FloorId != "0" ? u.FloorId == FilterValues.FloorId : true) &
                                      (FilterValues.RoomId != "0" ? u.WashRoomId == FilterValues.RoomId : true) &
                                      (FilterValues.StartDate != null ? u.UsageDate >= FilterValues.StartDate : true) &
                                      (FilterValues.EndDate != null ? u.UsageDate <= FilterValues.EndDate : true) &
                                      (FilterValues.Month != "0" ? u.UsageMonth == FilterValues.Month : true) &
                                      (FilterValues.Year != 0 ? u.UsageYear == FilterValues.Year : true)
                                     orderby u.UsageDate ascending
                                     group u by new
                                     {
                                         u.UsageDayOfWeek,
                                         u.DeviceType
                                     } into u1
                                     select new
                                     {
                                         u1.Key.UsageDayOfWeek,
                                         u1.Key.DeviceType,
                                         CountOfUsage = u1.Sum(x => x.CountOfUsage)
                                     }).ToList();

                    var finalData = (from deviceTypeDay in ListDeviceTypeDays
                                     join data in UsageData
                                         on new { Col1 = deviceTypeDay.UsageDayOfWeek, Col2 = deviceTypeDay.DeviceType }
                                         equals new { Col1 = data.UsageDayOfWeek, Col2 = data.DeviceType }
                                     into joinedData
                                     from report in joinedData.DefaultIfEmpty()
                                     select new
                                     {
                                         UsageDayOfWeek = deviceTypeDay.UsageDayOfWeek,
                                         DeviceType = deviceTypeDay.DeviceType,
                                         CountOfUsage = report != null ? report.CountOfUsage : 0
                                     }).ToList();

                    foreach (var Usage in finalData)
                    {
                        ReportGenericEntity gen = new ReportGenericEntity();
                        gen[TrafficChartConstants.XAxisWeek.ToString()] = Usage.UsageDayOfWeek;
                        gen[TrafficChartConstants.SecondaryAxisSupplyWeekAndMonth.ToString()] = Usage.DeviceType;
                        gen[TrafficChartConstants.YAxisProductUsage.ToString()] = Usage.CountOfUsage;
                        newReportGenList.Add(gen);
                    }

                }
            }
            catch
            {
                throw new Exception();
            }

            return newReportGenList;
        }

        public List<ReportGenericEntity> GetProductUsageMonthwise(ReportFilterEntity FilterValues)
        {
            List<ReportGenericEntity> newReportGenList = new List<ReportGenericEntity>();
            List<string> Dates = new List<string>();
            List<string> DeviceTypes = new List<string>();
            try
            {
                //Get All device types from database
                DeviceTypes = GetAllDeviceTypes();
                //Check the filter, if it is for this month or last month
                if (FilterValues.PeriodId.Equals(CommonConstants.FilterThisMonth))
                {
                    Dates = CommonHelper.GetDatesThisMonth(GetPropertyTimezone(Convert.ToInt32(FilterValues.PropertyId)));
                }
                else if (FilterValues.PeriodId.Equals(CommonConstants.FilterLastMonth))
                {
                    Dates = CommonHelper.GetDatesLastMonth(GetPropertyTimezone(Convert.ToInt32(FilterValues.PropertyId)));
                }
                else
                {
                    Dates = CommonHelper.GetDatesForMonth(FilterValues.Month, FilterValues.Year, GetPropertyTimezoneFromBuilding(Convert.ToInt32(FilterValues.BuildingId)));
                }

                //Get Device Types and Day combined data
                var ListDeviceTypeDays = (from deviceType in DeviceTypes
                                          from day in Dates
                                          select new
                                          {
                                              UsageDay = day,
                                              DeviceType = deviceType
                                          }).ToList();

                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    var UsageMart = dbEntity.Set<UsageMart>().ToList();
                    var UsageData = (from u in UsageMart
                                     where u.CustomerId == FilterValues.CustomerId &
                                      (FilterValues.PropertyId != "0" ? u.PropertyId == FilterValues.PropertyId : true) &
                                      (FilterValues.BuildingId != "0" ? u.BuildingId == FilterValues.BuildingId : true) &
                                      (FilterValues.FloorId != "0" ? u.FloorId == FilterValues.FloorId : true) &
                                      (FilterValues.RoomId != "0" ? u.WashRoomId == FilterValues.RoomId : true) &
                                      (FilterValues.StartDate != null ? u.UsageDate >= FilterValues.StartDate : true) &
                                      (FilterValues.EndDate != null ? u.UsageDate <= FilterValues.EndDate : true) &
                                      (FilterValues.Month != "0" ? u.UsageMonth == FilterValues.Month : true) &
                                      (FilterValues.Year != 0 ? u.UsageYear == FilterValues.Year : true)
                                     orderby u.UsageDate ascending
                                     group u by new
                                     {
                                         u.UsageDay,
                                         u.DeviceType
                                     } into u1
                                     select new
                                     {
                                         u1.Key.UsageDay,
                                         u1.Key.DeviceType,
                                         CountOfUsage = u1.Sum(x => x.CountOfUsage)
                                     }).ToList();

                    var finalData = (from deviceTypeDay in ListDeviceTypeDays
                                     join data in UsageData
                                         on new { Col1 = deviceTypeDay.UsageDay, Col2 = deviceTypeDay.DeviceType }
                                         equals new { Col1 = data.UsageDay.ToString(), Col2 = data.DeviceType }
                                     into joinedData
                                     from report in joinedData.DefaultIfEmpty()
                                     select new
                                     {
                                         UsageDay = deviceTypeDay.UsageDay,
                                         DeviceType = deviceTypeDay.DeviceType,
                                         CountOfUsage = report != null ? report.CountOfUsage : 0
                                     }).ToList();


                    foreach (var Usage in finalData)
                    {
                        ReportGenericEntity gen = new ReportGenericEntity();
                        gen[TrafficChartConstants.XAxisMonth.ToString()] = Usage.UsageDay;
                        gen[TrafficChartConstants.SecondaryAxisSupplyWeekAndMonth.ToString()] = Usage.DeviceType;
                        gen[TrafficChartConstants.YAxisProductUsage.ToString()] = Usage.CountOfUsage;
                        newReportGenList.Add(gen);
                    }

                }
            }
            catch
            {
                throw new Exception();
            }

            return newReportGenList;
        }

        public List<ReportGenericEntity> GetProductSummaryData(ReportFilterEntity FilterValues)
        {
            List<ReportGenericEntity> newReportGenList = new List<ReportGenericEntity>();
            List<string> DeviceTypes = new List<string>();
            try
            {
                //Get All device types from database
                DeviceTypes = GetAllDeviceTypes();
                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    var UsageMart = dbEntity.Set<UsageMart>().ToList();
                    var UsageData = (from u in UsageMart
                                     where u.CustomerId == FilterValues.CustomerId &
                                      (FilterValues.PropertyId != "0" ? u.PropertyId == FilterValues.PropertyId : true) &
                                      (FilterValues.BuildingId != "0" ? u.BuildingId == FilterValues.BuildingId : true) &
                                      (FilterValues.FloorId != "0" ? u.FloorId == FilterValues.FloorId : true) &
                                      (FilterValues.RoomId != "0" ? u.WashRoomId == FilterValues.RoomId : true) &
                                      (FilterValues.StartDate != null ? u.UsageDate >= FilterValues.StartDate : true) &
                                      (FilterValues.EndDate != null ? u.UsageDate <= FilterValues.EndDate : true) &
                                      (FilterValues.Month != "0" ? u.UsageMonth == FilterValues.Month : true) &
                                      (FilterValues.Year != 0 ? u.UsageYear == FilterValues.Year : true)
                                     group u by new
                                     {
                                         u.DeviceType
                                     } into u1
                                     select new
                                     {
                                         Type = u1.Key.DeviceType,
                                         Month = "Month",
                                         CountOfUsage = u1.Sum(x => x.CountOfUsage)
                                     }).ToList();

                    var finalData = (from type in DeviceTypes
                                     join data in UsageData
                                         on type equals data.Type into joinedData
                                     from report in joinedData.DefaultIfEmpty()
                                     select new
                                     {
                                         Type = type,
                                         Month = "Month",
                                         CountOfUsage = report != null ? report.CountOfUsage : 0
                                     }).ToList();

                    foreach (var Usage in finalData)
                    {
                        ReportGenericEntity gen = new ReportGenericEntity();
                        gen[TrafficChartConstants.SecondaryAxisSupplyWeekAndMonth.ToString()] = Usage.Type;
                        gen[TrafficChartConstants.SecondaryAxisMonth.ToString()] = Usage.Month;
                        gen[TrafficChartConstants.YAxisProductUsage.ToString()] = Usage.CountOfUsage;
                        newReportGenList.Add(gen);
                    }


                    var batteryChange = (from u in UsageMart
                                         where u.CustomerId == FilterValues.CustomerId &
                                        (FilterValues.PropertyId != "0" ? u.PropertyId == FilterValues.PropertyId : true) &
                                        (FilterValues.BuildingId != "0" ? u.BuildingId == FilterValues.BuildingId : true) &
                                        (FilterValues.FloorId != "0" ? u.FloorId == FilterValues.FloorId : true) &
                                        (FilterValues.RoomId != "0" ? u.WashRoomId == FilterValues.RoomId : true) &
                                        (FilterValues.StartDate != null ? u.UsageDate >= FilterValues.StartDate : true) &
                                        (FilterValues.EndDate != null ? u.UsageDate <= FilterValues.EndDate : true) &
                                        (FilterValues.Month != "0" ? u.UsageMonth == FilterValues.Month : true) &
                                        (FilterValues.Year != 0 ? u.UsageYear == FilterValues.Year : true)
                                         group u by new
                                         {
                                             u.DeviceType
                                         } into u1
                                         select new
                                         {
                                             Type = TrafficChartConstants.Batteries,
                                             Month = TrafficChartConstants.SecondaryAxisMonth,
                                             CountOfUsage = u1.Sum(x => x.CountOfBattery)
                                         }).ToList();
                    if (batteryChange.Count != 0)
                    {
                        foreach (var battery in batteryChange)
                        {
                            ReportGenericEntity gen = new ReportGenericEntity();
                            gen[TrafficChartConstants.SecondaryAxisSupplyWeekAndMonth.ToString()] = battery.Type;
                            gen[TrafficChartConstants.SecondaryAxisMonth.ToString()] = battery.Month;
                            gen[TrafficChartConstants.YAxisProductUsage.ToString()] = battery.CountOfUsage;
                            newReportGenList.Add(gen);
                        }
                    }
                    else
                    {
                        ReportGenericEntity gen = new ReportGenericEntity();
                        gen[TrafficChartConstants.SecondaryAxisSupplyWeekAndMonth.ToString()] = TrafficChartConstants.Batteries;
                        gen[TrafficChartConstants.SecondaryAxisMonth.ToString()] = TrafficChartConstants.SecondaryAxisMonth;
                        gen[TrafficChartConstants.YAxisProductUsage.ToString()] = 0;
                        newReportGenList.Add(gen);
                    }
                }
            }
            catch
            {
                throw new Exception();
            }

            return newReportGenList;
        }

        public int GetRefillBeforeThreshold(ReportFilterEntity FilterValues)
        {
            int RefillBeforeThreshold = 0;

            try
            {
                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    var UsageMart = dbEntity.Set<UsageMart>().ToList();
                    var reFill = (from u in UsageMart
                                  where u.CustomerId == FilterValues.CustomerId &
                                    (FilterValues.PropertyId != "0" ? u.PropertyId == FilterValues.PropertyId : true) &
                                    (FilterValues.BuildingId != "0" ? u.BuildingId == FilterValues.BuildingId : true) &
                                    (FilterValues.FloorId != "0" ? u.FloorId == FilterValues.FloorId : true) &
                                    (FilterValues.RoomId != "0" ? u.WashRoomId == FilterValues.RoomId : true) &
                                    (FilterValues.StartDate != null ? u.UsageDate >= FilterValues.StartDate : true) &
                                    (FilterValues.EndDate != null ? u.UsageDate <= FilterValues.EndDate : true) &
                                    (FilterValues.Month != "0" ? u.UsageMonth == FilterValues.Month : true) &
                                    (FilterValues.Year != 0 ? u.UsageYear == FilterValues.Year : true)
                                  group u by 1 into u1
                                  select new
                                  {
                                      BatteryRefill = (int)u1.Sum(b => b.BatteryRefillBeforeThres),
                                      TowelRefill = (int)u1.Sum(t => t.TowelRefillBeforeThres)
                                  }
                                      ).FirstOrDefault();

                    RefillBeforeThreshold = reFill != null ? reFill.BatteryRefill + reFill.TowelRefill : 0;
                }
            }
            catch
            {
                throw new Exception();
            }

            return RefillBeforeThreshold;
        }

        private List<string> GetAllDeviceTypes()
        {
            List<string> DeviceTypes = new List<string>();
            try
            {
                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    var deviceType = dbEntity.Set<DeviceType>().ToList();
                    DeviceTypes = (from type in deviceType
                                   select type.ID.ToString()).ToList();
                }
            }
            catch
            {
                throw new Exception();
            }
            return DeviceTypes;
        }

        private TimeZoneInfo GetPropertyTimezone(int propertyId)
        {
            string timezone = string.Empty;
            try
            {
                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    timezone = (from prop in dbEntity.Properties
                                where prop.ID == propertyId
                                select prop.LocationTimeZone).FirstOrDefault();
                }
                if (!string.IsNullOrEmpty(timezone))
                {
                    return TimeZoneInfo.GetSystemTimeZones().Where(o => o.Id == timezone).FirstOrDefault();
                }
                else
                {
                    return TimeZoneInfo.GetSystemTimeZones().Where(o => o.Id == "UTC").FirstOrDefault();
                }
            }
            catch
            {
                return TimeZoneInfo.GetSystemTimeZones().Where(o => o.Id == "UTC").FirstOrDefault();
            }
        }

        private TimeZoneInfo GetPropertyTimezoneFromBuilding(int buildingId)
        {
            string timezone = string.Empty;
            try
            {
                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    timezone = (from building in dbEntity.Buildings
                                join prop in dbEntity.Properties on building.PropertyId equals prop.ID
                                where building.ID == buildingId
                                select prop.LocationTimeZone).FirstOrDefault();
                }
                if (!string.IsNullOrEmpty(timezone))
                {
                    return TimeZoneInfo.GetSystemTimeZones().Where(o => o.Id == timezone).FirstOrDefault();
                }
                else
                {
                    return TimeZoneInfo.GetSystemTimeZones().Where(o => o.Id == "UTC").FirstOrDefault();
                }
            }
            catch
            {
                return TimeZoneInfo.GetSystemTimeZones().Where(o => o.Id == "UTC").FirstOrDefault();
            }
        }
    }
}
