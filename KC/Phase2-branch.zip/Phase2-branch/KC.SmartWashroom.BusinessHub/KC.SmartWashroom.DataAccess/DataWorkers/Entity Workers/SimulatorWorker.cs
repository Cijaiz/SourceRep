﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.Simulator;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.DataAccess.DataWorkers.Table_Workers;
using KC.SmartWashroom.DataAccess.Skeleton;
using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers
{
    public class SimulatorWorker : WorkerBase, ISimulatorWorker
    {
        public const string DATE_FORMAT = "dd'-'MM'-'yyyy  HH:mm:ss:fff tt";
        public List<DeviceSimulator> FetchDevices()
        {
            List<DeviceSimulator> DeviceSimulators = null;
            using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
            {
                //Need to add joining condition once DeviceType is added to edmx
                DeviceSimulators = (from device in dbContext.Devices
                                    join deviceType in dbContext.DeviceTypes on device.DeviceTypeId equals deviceType.ID
                                    where device.IsActive == true && device.IsActive.Equals(true)
                                    select new DeviceSimulator
                                    {
                                        DeviceID = device.ID,
                                        Type = deviceType.Name
                                    }).ToList<DeviceSimulator>();
            }
            return DeviceSimulators;
        }

        public void DeleteInactiveDevices()
        {
            using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
           {
              var inactiveDevicesTempLog= (from device in dbContext.Devices
                                join simulatorTempLog in dbContext.SimulatorTempDeviceLogs on device.ID equals simulatorTempLog.DeviceId
                                where device.IsActive==false
                                select simulatorTempLog
                                    ).ToList();

              var inactiveSimulatorDeviceAlert = (from device in dbContext.Devices
                                                  join simulatorDeviceAlert in dbContext.SimulatorDeviceAlerts on device.ID equals simulatorDeviceAlert.DeviceId
                                                  where device.IsActive == false
                                                  select simulatorDeviceAlert
                                  ).ToList();

              var inactiveSimulatorRaisedAlert = (from device in dbContext.Devices
                                                  join simulatorRaisedAlert in dbContext.SimulatorRaisedAlerts on device.ID equals simulatorRaisedAlert.DeviceId
                                                  where device.IsActive == false
                                                  select simulatorRaisedAlert
                                   ).ToList();

              dbContext.SimulatorTempDeviceLogs.RemoveRange(inactiveDevicesTempLog);
              dbContext.SimulatorDeviceAlerts.RemoveRange(inactiveSimulatorDeviceAlert);
              dbContext.SimulatorRaisedAlerts.RemoveRange(inactiveSimulatorRaisedAlert);
              dbContext.SaveChanges();
                                
            }
        }


        public List<string> FetchUpdateFixAlertForDevice(string DeviceId)
        {
            List<string> FixAlerts = new List<string>();
            try
            {

                using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                {
                    FixAlerts = (from simDeviceAlert in dbContext.SimulatorDeviceAlerts
                                 join alertType in dbContext.AlertTypes on simDeviceAlert.AlertTypeId equals alertType.ID
                                 where simDeviceAlert.IsAlert == false &&
                                 simDeviceAlert.DeviceId == DeviceId
                                 select alertType.Type).ToList();

                    //Remove the alerts
                    List<SimulatorDeviceAlert> simDeviceAlerts = (from simDeviceAlert in dbContext.SimulatorDeviceAlerts
                                                                  join alertType in dbContext.AlertTypes on simDeviceAlert.AlertTypeId equals alertType.ID
                                                                  join type in FixAlerts on alertType.Type equals type
                                                                  where simDeviceAlert.DeviceId == DeviceId
                                                                  select simDeviceAlert).ToList();
                    dbContext.SimulatorDeviceAlerts.RemoveRange(simDeviceAlerts);
                    dbContext.SaveChanges();
                }
            }
            catch (Exception)
            {
                return FixAlerts;
            }
            return FixAlerts;
        }

        public DateTime FetchDeviceLogTimeStamp(DeviceSimulator devicePrm, int customerId)
        {
            TableQuery<DeviceEntity> query = new TableQuery<DeviceEntity>().Where(
                                                TableQuery.CombineFilters(
                                                    TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, customerId.ToString()),
                                                    TableOperators.And,
                                                    TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.Equal, devicePrm.DeviceID)
                                                )
                                            );
            IEnumerable<DeviceEntity> devices = this.tableRepositoryManager.GetDevicesForSimulator(query);


            if (devices==null || devices.Count().Equals(0))
            {
                return DateTime.MinValue;
            }
            else
            {
                return devices.First().Timestamp.DateTime;
            }

        }

        public DeviceSimulator FetchTempDeviceLog(DeviceSimulator devicePrm)
        {
            string deviceLog = string.Empty;
            using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
            {

                deviceLog = (from devicelog in dbContext.SimulatorTempDeviceLogs
                             where devicelog.DeviceId == devicePrm.DeviceID
                             select devicelog.DeviceLog).ToList().FirstOrDefault();
            }

            var deviceSimulator = new DeviceSimulator();
            deviceSimulator.DeviceID = devicePrm.DeviceID;
            deviceSimulator.Type = devicePrm.Type;

            if (string.IsNullOrEmpty(deviceLog))
            {
                deviceSimulator.IsNewDevice = true;
                deviceSimulator.DeviceParameter = string.Empty;
                return deviceSimulator;
            }

            deviceSimulator.IsNewDevice = false;
            deviceSimulator.DeviceParameter = deviceLog;
            return deviceSimulator;
        }

        public ProcessResponse InsertTempDeviceLog(List<DeviceSimulator> Devices)
        {
            ProcessResponse response = new ProcessResponse();
            try
            {
                if (Devices.Count > 0)
                {
                    using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                    {
                        foreach (DeviceSimulator device in Devices)
                        {
                            SimulatorTempDeviceLog dbTempDeviceLog = new SimulatorTempDeviceLog();
                            dbTempDeviceLog.DeviceId = device.DeviceID;
                            dbTempDeviceLog.DeviceLog = device.DeviceParameter;

                            dbContext.SimulatorTempDeviceLogs.Add(dbTempDeviceLog);
                            dbContext.SaveChanges();
                        }
                    }
                }
                response.Status = ResponseStatus.Success;
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.Error;
                response.Message = ex.Message;
            }
            return response;
        }

        public ProcessResponse UpdateTempDeviceLog(List<DeviceSimulator> Devices)
        {
            ProcessResponse response = new ProcessResponse();
            try
            {
                if (Devices.Count > 0)
                {
                    using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                    {
                        foreach (DeviceSimulator device in Devices)
                        {
                            SimulatorTempDeviceLog dbTempDeviceLog = dbContext.SimulatorTempDeviceLogs.First(o => o.DeviceId == device.DeviceID);
                            dbTempDeviceLog.DeviceLog = device.DeviceParameter;
                            dbContext.SaveChanges();
                        }
                    }
                }
                response.Status = ResponseStatus.Success;
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.Error;
                response.Message = ex.Message;
            }
            return response;
        }

        public DateTime FetchTimeStampForAlert(string deviceId, string alertType)
        {
            DateTime TimeStamp = DateTime.UtcNow;
            using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
            {
                TimeStamp = (from alertLog in dbContext.SimulatorRaisedAlerts
                             join altType in dbContext.AlertTypes on alertLog.AlertTypeId equals altType.ID
                             where alertLog.DeviceId == deviceId && altType.Type == alertType
                             select alertLog.LogTime).FirstOrDefault();

            }
            return TimeStamp;
        }

        public bool CheckDeviceAlertFirstRaise(string deviceId, string alertType)
        {
            string DeviceId = string.Empty;
            using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
            {
                DeviceId = (from alertTimeStamp in dbContext.SimulatorRaisedAlerts
                            join altType in dbContext.AlertTypes on alertTimeStamp.AlertTypeId equals altType.ID
                            where alertTimeStamp.DeviceId == deviceId && altType.Type == alertType
                            select alertTimeStamp.DeviceId).FirstOrDefault();
            }
            if (string.IsNullOrEmpty(DeviceId))
            {
                return true;
            }
            return false;
        }

        public ProcessResponse InsertTimeStampForAlert(List<DeviceSimulator> Devices)
        {
            ProcessResponse response = new ProcessResponse();

            try
            {
                if (Devices.Count > 0)
                {
                    using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                    {
                        foreach (DeviceSimulator device in Devices)
                        {
                            string DeviceId = string.Empty;
                            foreach (AlertSimulator alert in device.Alerts)
                            {
                                //Check if the device exists in the database
                                DeviceId = (from alertTimeStamp in dbContext.SimulatorRaisedAlerts
                                            join altType in dbContext.AlertTypes on alertTimeStamp.AlertTypeId equals altType.ID
                                            where alertTimeStamp.DeviceId == device.DeviceID && altType.Type == alert.AlertCode
                                            select alertTimeStamp.DeviceId).FirstOrDefault();
                                if (string.IsNullOrEmpty(DeviceId))
                                {
                                    //Insert log time for alert
                                    SimulatorRaisedAlert dbAlertTimeStamp = new SimulatorRaisedAlert();
                                    dbAlertTimeStamp.DeviceId = device.DeviceID;
                                    dbAlertTimeStamp.AlertTypeId = (from altType in dbContext.AlertTypes
                                                                    where altType.Type == alert.AlertCode
                                                                    select altType.ID).FirstOrDefault();
                                    dbAlertTimeStamp.LogTime = DateTime.UtcNow;
                                    dbContext.SimulatorRaisedAlerts.Add(dbAlertTimeStamp);
                                }
                            }
                        }
                        dbContext.SaveChanges();
                    }
                    response.Status = ResponseStatus.Success;
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.Error;
                response.Message = ex.Message;
            }
            return response;
        }

        public ProcessResponse UpdateTimeStampForAlert(string DeviceId, string AlertCode)
        {
            ProcessResponse response = new ProcessResponse();
            try
            {
                using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                {
                    SimulatorRaisedAlert dbRaisedAlert = (from alertTimeStamp in dbContext.SimulatorRaisedAlerts
                                                          join altType in dbContext.AlertTypes on alertTimeStamp.AlertTypeId equals altType.ID
                                                          where alertTimeStamp.DeviceId == DeviceId && altType.Type == AlertCode
                                                          select alertTimeStamp).FirstOrDefault();
                    dbRaisedAlert.LogTime = DateTime.UtcNow;
                    dbContext.SaveChanges();
                    response.Status = ResponseStatus.Success;
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.Error;
                response.Message = ex.Message;
            }
            return response;
        }

        public ProcessResponse DeleteTimeStampForAlert(string DeviceId, List<string> FixAlertCodes)
        {
            ProcessResponse response = new ProcessResponse();
            try
            {
                if (FixAlertCodes.Count() > 0)
                {
                    using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                    {
                        foreach (string alertCode in FixAlertCodes)
                        {
                            //Delete logged alert time stamps
                            List<SimulatorRaisedAlert> dbRaisedAlert = (from alertTimeStamp in dbContext.SimulatorRaisedAlerts
                                                                        join altType in dbContext.AlertTypes on alertTimeStamp.AlertTypeId equals altType.ID
                                                                        where alertTimeStamp.DeviceId == DeviceId && altType.Type == alertCode
                                                                        select alertTimeStamp).ToList();
                            //Check if it is a S1 (low soap) or S4 (very low soap) alert then delete both of them
                            if (alertCode.Equals("S1"))
                            {
                                dbRaisedAlert.AddRange((from alertTimeStamp in dbContext.SimulatorRaisedAlerts
                                                        join altType in dbContext.AlertTypes on alertTimeStamp.AlertTypeId equals altType.ID
                                                        where alertTimeStamp.DeviceId == DeviceId && altType.Type == "S4"
                                                        select alertTimeStamp).ToList());
                            }
                            else if (alertCode.Equals("S4"))
                            {
                                dbRaisedAlert.AddRange((from alertTimeStamp in dbContext.SimulatorRaisedAlerts
                                                        join altType in dbContext.AlertTypes on alertTimeStamp.AlertTypeId equals altType.ID
                                                        where alertTimeStamp.DeviceId == DeviceId && altType.Type == "S1"
                                                        select alertTimeStamp).ToList());
                            }
                            dbContext.SimulatorRaisedAlerts.RemoveRange(dbRaisedAlert);
                        }
                        dbContext.SaveChanges();
                    }
                    response.Status = ResponseStatus.Success;
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.Error;
                response.Message = ex.Message;
            }
            return response;
        }
    }
}
