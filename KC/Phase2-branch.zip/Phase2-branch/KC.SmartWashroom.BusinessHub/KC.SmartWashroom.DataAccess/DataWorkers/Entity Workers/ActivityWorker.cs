﻿using BusinessEntities = KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.DataAccess.Skeleton;
using System.Linq;
using System;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.BusinessEntities.DashboardApiEntities;
using System.Collections.Generic;
using KC.SmartWashroom.BusinessEntities.BusinessHubEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.Core.Enumerations;
using KC.SmartWashroom.Core.Constants;

namespace KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers
{
    public class ActivityWorker : IActivityWorker
    {
        public ProcessResponse<BusinessEntities.Activity> CreateActivity(BusinessEntities.Activity activity)
        {
            ProcessResponse<BusinessEntities.Activity> response = new ProcessResponse<BusinessEntities.Activity>();
            try
            {
                using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                {
                    Activity dbActivity = new Activity();
                    dbActivity.Name = activity.Name;

                    dbContext.Activities.Add(dbActivity);
                    dbContext.SaveChanges();

                    response.Status = ResponseStatus.Success;
                    activity.ID = dbActivity.ID;
                    response.Object = activity;
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.Error;
                response.Message = ex.Message;
            }
            return response;
        }

        public BusinessEntities.Activity GetActivity(int activityId)
        {
            BusinessEntities.Activity responseActivity = null;
            using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
            {
                responseActivity = (from activiti in dbContext.Activities
                                    where activiti.ID.Equals(activityId)
                                    select new BusinessEntities.Activity
                                    {
                                        ID = activiti.ID,
                                        Name = activiti.Name
                                    }).FirstOrDefault();
            }
            return responseActivity;
        }

        public BuildingEntity GetActivities(int customerId)
        {
            BuildingEntity buildingEntity = new BuildingEntity();
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                buildingEntity.buildings = (from building in dbEntity.Buildings
                                            join prop in dbEntity.Properties on building.PropertyId equals prop.ID
                                            where prop.CustomerId == customerId && prop.IsActive == true && building.IsActive == true
                                            select new BusinessEntities.Building
                                            {
                                                ID = building.ID,
                                                Name = building.Name,
                                                PropertyId = building.PropertyId,
                                                floors = (from flr in building.Floors
                                                          where flr.IsActive == true
                                                          select new BusinessEntities.Floor
                                                          {
                                                              ID = flr.ID,
                                                              FloorLevel = flr.FloorLevel,
                                                              BuildingId = flr.BuildingId,
                                                              Alerts = (from alertTypes in dbEntity.AlertTypes
                                                                        join deviceAlert in dbEntity.DeviceAlerts on alertTypes.ID equals deviceAlert.AlertTypeId
                                                                        join deviceWashroom in dbEntity.DeviceWashrooms on deviceAlert.DeviceId equals deviceWashroom.DeviceId
                                                                        join device in dbEntity.Devices on deviceAlert.DeviceId equals device.ID
                                                                        join washroom in dbEntity.Washrooms on deviceWashroom.WashroomId equals washroom.ID
                                                                        join wing in dbEntity.Wings on washroom.WingId equals wing.ID
                                                                        join gender in dbEntity.Genders on washroom.GenderId equals gender.ID
                                                                        join floor in dbEntity.Floors on washroom.FloorId equals floor.ID
                                                                        where washroom.FloorId.Equals(flr.ID) && washroom.IsActive == true && device.IsActive.Equals(true) && deviceWashroom.IsActive==true
                                                                        select new KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert
                                                                        {
                                                                            AlertTypeId = alertTypes.ID,
                                                                            AlertType = alertTypes.Type,
                                                                            DateTime = deviceAlert.ReceivedOn,
                                                                            Gender = gender.Name,
                                                                            FloorLevel = floor.FloorLevel,
                                                                            FloorID = floor.ID,
                                                                            DeviceId = deviceAlert.DeviceId,
                                                                            DeviceName = device.Name,
                                                                            Wing = wing.Name,
                                                                            WashroomId = washroom.ID,
                                                                            WashroomName = washroom.Name
                                                                        }).ToList<KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert>()
                                                          }).ToList<BusinessEntities.Floor>()
                                            }).ToList<BusinessEntities.Building>();
            }
            return buildingEntity;
        }

        public BuildingEntity GetActivitiesByFilter(int customerId, string alertType, DateTime fromDate, DateTime toDate)
        {
            BuildingEntity buildingEntity = new BuildingEntity();
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                buildingEntity.buildings = (from building in dbEntity.Buildings
                                            join prop in dbEntity.Properties on building.PropertyId equals prop.ID
                                            where prop.CustomerId == customerId && prop.IsActive == true && building.IsActive == true
                                            select new BusinessEntities.Building
                                            {
                                                ID = building.ID,
                                                Name = building.Name,
                                                PropertyId = building.PropertyId,
                                                floors = (from flr in building.Floors
                                                          where flr.IsActive == true
                                                          select new BusinessEntities.Floor
                                                          {
                                                              ID = flr.ID,
                                                              FloorLevel = flr.FloorLevel,
                                                              BuildingId = flr.BuildingId,
                                                              Alerts = (from alertTypes in dbEntity.AlertTypes
                                                                        join deviceAlert in dbEntity.DeviceAlerts on alertTypes.ID equals deviceAlert.AlertTypeId
                                                                        join deviceWashroom in dbEntity.DeviceWashrooms on deviceAlert.DeviceId equals deviceWashroom.DeviceId
                                                                        join device in dbEntity.Devices on deviceAlert.DeviceId equals device.ID
                                                                        join washroom in dbEntity.Washrooms on deviceWashroom.WashroomId equals washroom.ID
                                                                        join wing in dbEntity.Wings on washroom.WingId equals wing.ID
                                                                        join gender in dbEntity.Genders on washroom.GenderId equals gender.ID
                                                                        join floor in dbEntity.Floors on washroom.FloorId equals floor.ID
                                                                        where washroom.FloorId.Equals(flr.ID) && washroom.IsActive == true && alertTypes.Type == alertType && device.IsActive.Equals(true) && deviceWashroom.IsActive==true
                                                                        && (fromDate != DateTime.MinValue ? deviceAlert.ReceivedOn >= fromDate : true)
                                                                        && (toDate != DateTime.MinValue ? deviceAlert.ReceivedOn <= toDate : true)
                                                                        select new KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert
                                                                        {
                                                                            AlertTypeId = alertTypes.ID,
                                                                            AlertType = alertTypes.Type,
                                                                            DateTime = deviceAlert.ReceivedOn,
                                                                            Gender = gender.Name,
                                                                            FloorLevel = floor.FloorLevel,
                                                                            FloorID = floor.ID,
                                                                            DeviceId = deviceAlert.DeviceId,
                                                                            DeviceName = device.Name,
                                                                            Wing = wing.Name,
                                                                            WashroomId = washroom.ID,
                                                                            WashroomName = washroom.Name
                                                                        }).ToList<KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert>()
                                                          }).ToList<BusinessEntities.Floor>()
                                            }).ToList<BusinessEntities.Building>();
            }
            return buildingEntity;
        }

        public List<string> GetAllAlertTypes()
        {
            List<string> AlertTypes = new List<string>();
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                AlertTypes = (from alertType in dbEntity.AlertTypes
                              select alertType.Type).ToList();
            }
            return AlertTypes;

        }

        public List<string> GetAlertTypesForDeviceType(byte deviceTypeId)
        {
            List<string> AlertTypes = new List<string>();
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                AlertTypes = (from dam in dbEntity.DeviceAlertMappings
                              join alertType in dbEntity.AlertTypes on dam.AlertTypeId equals alertType.ID
                              where dam.DeviceTypeId == deviceTypeId
                              select alertType.Type).ToList();
            }
            return AlertTypes;

        }

        public List<DeviceTypes> GetAllDeviceTypes()
        {
            List<DeviceTypes> DeviceTypes = new List<DeviceTypes>();
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                DeviceTypes = (from deviceType in dbEntity.DeviceTypes
                               where deviceType.IsActive == true
                               select new DeviceTypes { DeviceId = deviceType.ID, DeviceName = deviceType.Name }).ToList<DeviceTypes>();
            }
            return DeviceTypes;
        }

        public List<BusinessEntities.Gender> GetAllRoomTypes()
        {
            List<BusinessEntities.Gender> RoomTypes = new List<BusinessEntities.Gender>();
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                RoomTypes = (from gender in dbEntity.Genders
                             select new BusinessEntities.Gender { ID = gender.ID, Name = gender.Name }).ToList<BusinessEntities.Gender>();
            }
            return RoomTypes;
        }

        public List<BusinessEntities.Property> GetAllProperties(int customerId)
        {
            List<BusinessEntities.Property> Properties = new List<BusinessEntities.Property>();
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                Properties = (from property in dbEntity.Properties
                              where property.CustomerId == customerId && property.IsActive == true
                              select new BusinessEntities.Property { ID = property.ID, PropertyName = property.PropertyName }).ToList<BusinessEntities.Property>();
            }
            return Properties;
        }

        public List<BusinessEntities.Building> GetAllBuildings(int customerId, int propertyId)
        {
            List<BusinessEntities.Building> Buildings = new List<BusinessEntities.Building>();
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                Buildings = (from building in dbEntity.Buildings
                             join property in dbEntity.Properties on building.PropertyId equals property.ID
                             where property.CustomerId == customerId && property.ID==propertyId && building.IsActive == true && property.IsActive == true
                             select new BusinessEntities.Building { ID = building.ID, Name = building.Name, PropertyId=building.PropertyId }).ToList<BusinessEntities.Building>();
            }
            return Buildings;
        }

        public List<BusinessEntities.Floor> GetAllFloors(int buildingId)
        {
            List<BusinessEntities.Floor> Floors = new List<BusinessEntities.Floor>();
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                Floors = (from floor in dbEntity.Floors
                          where floor.BuildingId == buildingId && floor.IsActive == true
                          select new BusinessEntities.Floor { ID = floor.ID, FloorLevel = floor.FloorLevel }).ToList<BusinessEntities.Floor>();
            }
            return Floors;
        }

        public int CountOutstandingDeviceAlerts(int userId, int roleLevel)
        {
            int countOutstandingAlerts = 0;
            if (roleLevel == (int)Enums.RoleLevelType.PropertyAdmin)
            {
                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    countOutstandingAlerts = (from user in dbEntity.Users
                                              join customer in dbEntity.Customers on user.CustomerId equals customer.ID
                                              join prop in dbEntity.Properties on customer.ID equals prop.CustomerId
                                              join userProp in dbEntity.UserProperties on prop.ID equals userProp.PropertyId
                                              where userProp.UserId == userId
                                              join building in dbEntity.Buildings on prop.ID equals building.PropertyId
                                              join floors in dbEntity.Floors on building.ID equals floors.BuildingId
                                              join washroom in dbEntity.Washrooms on floors.ID equals washroom.FloorId
                                              join gender in dbEntity.Genders on washroom.GenderId equals gender.ID
                                              join devicewashroom in dbEntity.DeviceWashrooms on washroom.ID equals devicewashroom.WashroomId
                                              join device in dbEntity.Devices on devicewashroom.DeviceId equals device.ID
                                              join deviceAlert in dbEntity.DeviceAlerts on device.ID equals deviceAlert.DeviceId
                                              where device.IsActive.Equals(true) && deviceAlert.ReceivedOn >= DateTime.UtcNow.AddHours(-24)
                                              select deviceAlert).ToList().Count();
                }
            }
            else if (roleLevel == (int)Enums.RoleLevelType.BuildingAdmin)
            {
                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    countOutstandingAlerts = (from user in dbEntity.Users
                                              join customer in dbEntity.Customers on user.CustomerId equals customer.ID
                                              join prop in dbEntity.Properties on customer.ID equals prop.CustomerId
                                              join building in dbEntity.Buildings on prop.ID equals building.PropertyId
                                              join userBuilding in dbEntity.UserBuildings on building.ID equals userBuilding.BuildingId
                                              where userBuilding.UserId == userId
                                              join floors in dbEntity.Floors on building.ID equals floors.BuildingId
                                              join washroom in dbEntity.Washrooms on floors.ID equals washroom.FloorId
                                              join gender in dbEntity.Genders on washroom.GenderId equals gender.ID
                                              join devicewashroom in dbEntity.DeviceWashrooms on washroom.ID equals devicewashroom.WashroomId
                                              join device in dbEntity.Devices on devicewashroom.DeviceId equals device.ID
                                              join deviceAlert in dbEntity.DeviceAlerts on device.ID equals deviceAlert.DeviceId
                                              where device.IsActive.Equals(true) && deviceAlert.ReceivedOn >= DateTime.UtcNow.AddHours(-24)
                                              select deviceAlert).ToList().Count();
                }
            }
            else
            {
                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    countOutstandingAlerts = (from prop in dbEntity.Properties
                                              join building in dbEntity.Buildings on prop.ID equals building.PropertyId
                                              join floors in dbEntity.Floors on building.ID equals floors.BuildingId
                                              join washroom in dbEntity.Washrooms on floors.ID equals washroom.FloorId
                                              join gender in dbEntity.Genders on washroom.GenderId equals gender.ID
                                              join devicewashroom in dbEntity.DeviceWashrooms on washroom.ID equals devicewashroom.WashroomId
                                              join device in dbEntity.Devices on devicewashroom.DeviceId equals device.ID
                                              join deviceAlert in dbEntity.DeviceAlerts on device.ID equals deviceAlert.DeviceId
                                              where device.IsActive.Equals(true) && deviceAlert.ReceivedOn >= DateTime.UtcNow.AddHours(-24)
                                              select deviceAlert).ToList().Count();
                }
            }
            return countOutstandingAlerts;
        }

        public int CountOutstandingDeviceAlertsFilter(int customerId, string alertTypeCode, DateTime fromDate, DateTime toDate)
        {
            int countOutstandingAlerts = 0;
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                countOutstandingAlerts = (from prop in dbEntity.Properties
                                          join building in dbEntity.Buildings on prop.ID equals building.PropertyId
                                          join floors in dbEntity.Floors on building.ID equals floors.BuildingId
                                          join washroom in dbEntity.Washrooms on floors.ID equals washroom.FloorId
                                          join gender in dbEntity.Genders on washroom.GenderId equals gender.ID
                                          join devicewashroom in dbEntity.DeviceWashrooms on washroom.ID equals devicewashroom.WashroomId
                                          join device in dbEntity.Devices on devicewashroom.DeviceId equals device.ID
                                          join deviceAlert in dbEntity.DeviceAlerts on device.ID equals deviceAlert.DeviceId
                                          join alertType in dbEntity.AlertTypes on deviceAlert.AlertTypeId equals alertType.ID
                                          where alertType.Type == alertTypeCode && (fromDate != DateTime.MinValue ? deviceAlert.ReceivedOn >= fromDate : true) && device.IsActive.Equals(true)
                                          && (toDate != DateTime.MinValue ? deviceAlert.ReceivedOn <= toDate : true)
                                          select deviceAlert).ToList().Count();
            }
            return countOutstandingAlerts;
        }

        public int SumEhrtDevices(SearchCriteria searchCriteria)
        {
            DateTime filterDate = DateTime.UtcNow.AddDays(CommonConstants.DEFAULT_SEARCH_DURATION_DAYS);
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {

                IQueryable<UsageMart> query = (from dbusagemart in dbEntity.UsageMarts
                                               where dbusagemart.DeviceType == ((int)Enums.DeviceType.eHRT).ToString() && dbusagemart.CustomerId == searchCriteria.CustomerId.ToString() &&
                                               dbusagemart.PropertyId == searchCriteria.PropertyId.ToString() &&
                                        dbusagemart.UsageDate >= filterDate && dbusagemart.CountOfPaperUsed > 0
                                                                select dbusagemart);

                if (searchCriteria.FloorId > 0)
                {
                    query = (from usageMart in query
                             where usageMart.FloorId == searchCriteria.FloorId.ToString()
                             select usageMart);
                }
                else if (searchCriteria.BuildingList != null && searchCriteria.BuildingList.Count > 0)
                {
                    query = (from usageMart in query
                             join buildingId in searchCriteria.BuildingList on usageMart.BuildingId equals buildingId.ToString() 
                                 select usageMart); 
                }
                if (searchCriteria.WashroomGenderId > 0)
                {
                    query = (from washroom in dbEntity.Washrooms
                             join usageMart in query on washroom.ID.ToString() equals usageMart.WashRoomId
                             where washroom.GenderId == searchCriteria.WashroomGenderId
                             select usageMart);
                }
                int? count = query.Sum(item => (int?) item.CountOfPaperUsed);

                return (count!=null? count.Value : 0);

                
            }
        }
        public int SumDispenseseHRTDevice(int customerId, List<DeviceResolutionDetail> Devices, int days)
        {
            throw new NotImplementedException();
        }
    }
}
