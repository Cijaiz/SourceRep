﻿

namespace KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers
{
    using KC.SmartWashroom.BusinessEntities.DeviceUpdate;
    using KC.SmartWashroom.BusinessEntities.Linq;
    using KC.SmartWashroom.Core.Helper;
    using KC.SmartWashroom.Core.Linq;
    using KC.SmartWashroom.Core.Log;
    using KC.SmartWashroom.DataAccess.Skeleton;
    using StackExchange.Redis;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    /* Note: No subclassing is planned */
    // TODO: There are repeated queries; aspired to clean up later
    /// <summary>
    /// The EF implementation of the device paramter store abstraction
    /// </summary>
    //[Obsolete("Please use the DeviceMetadataWorker instead")]
    public class DeviceParameterWorker : IDeviceParameterWorker
    {
        #region Work in progress - do not delete

        /// <summary>
        /// Gets the return parameter based on the input criteria
        /// </summary>
        /// <param name="deviceId">The device identified, usually string representation of 48 bit HEX value</param>
        /// <param name="deviceTypeName">The device type name</param>
        /// <param name="deviceTypeId">The device type id</param>
        /// <param name="customerId">The customer id</param>
        /// <returns>An enumerable of the parameter values using iterator patttern</returns>
        /// <remarks>Really heavy operation; must be properly parameterized</remarks>
        public IEnumerable<DeviceUpdateDetails> GetDeviceDetails(string deviceId = ""
            , string deviceTypeName = ""
            , int deviceTypeId = 0
            , int customerId = 0
            , bool isTurnedOff = true)
        {
            /*Work in progress*/
            using (var context = EntityRepositoryManager.GetStoreEntity())
            {
                // The below query takes ages for the first time :)

                var groupQuery = from customer in context.Customers
                                 join property in context.Properties
                                     on customer equals property.Customer
                                 join building in context.Buildings
                                     on property equals building.Property
                                 join floor in context.Floors
                                     on building equals floor.Building
                                 join restroom in context.Washrooms
                                     on floor equals restroom.Floor
                                 join restroomType in context.Genders
                                     on restroom.Gender equals restroomType
                                 join deviceRestroomMap in context.DeviceWashrooms
                                     on restroom equals deviceRestroomMap.Washroom
                                 join device in context.Devices
                                     on deviceRestroomMap.Device equals device
                                 join deviceType in context.DeviceTypes
                                     on device.DeviceType equals deviceType
                                 join parameter in context.DeviceParameters
                                     on deviceType equals parameter.DeviceType
                                 join parameterValue in context.DeviceParameterValues
                                     on parameter equals parameterValue.DeviceParameter
                                 where (parameterValue.DeviceId == device.ID || parameterValue.DeviceId == "" || parameterValue.DeviceId == null)
                                    && (!parameterValue.CustomerId.HasValue || parameterValue.CustomerId.Value == customer.ID)
                                    && (device.ID == deviceId || deviceId == null || deviceId == "") // device id filtering
                                    && (deviceType.ID == deviceTypeId || deviceTypeId <= 0
                                        || deviceType.Name == deviceTypeName || deviceTypeName == null || deviceTypeName == "") // device type filtering
                                    && (customer.ID == customerId || customerId <= 0) // customer id filtering
                                    && customer.IsActive
                                    && property.IsActive
                                    && building.IsActive
                                    && floor.IsActive
                                    && restroom.IsActive
                                    && device.IsActive
                                    && parameter.IsActive
                                 /* The front end does not respect the start date
                                  * Hence commenting this out, till it is resolved
                                 && deviceRestroomMap.StartDate <= DateTime.UtcNow
                                 && deviceRestroomMap.EndDate >= DateTime.UtcNow
                                 */
                                 // orderby parameter.Index ascending
                                 group new DeviceUpdateValue()
                                 {
                                     CustomerId = parameterValue.CustomerId,
                                     DeviceId = parameterValue.DeviceId,
                                     Id = parameterValue.Id,
                                     IsReset = parameterValue.IsReset,
                                     ModifiedTime = parameterValue.ModifiedTime,
                                     ResetTime = parameterValue.ResetTime,
                                     Value = parameterValue.Value,
                                     ParameterId = parameter.Id,
                                 }
                                     by new
                                     {
                                         DeviceUpdateData = new DeviceUpdateDetails()
                                         {
                                             BuildingId = building.ID,
                                             BuildingName = building.Name,
                                             CustomerId = customer.ID,
                                             CustomerName = customer.Name,
                                             DeviceId = device.ID,
                                             DeviceName = device.Name,
                                             DeviceTypeId = deviceType.ID,
                                             DeviceTypeName = deviceType.Name,
                                             FloorId = floor.ID,
                                             FloorLevel = floor.FloorLevel,
                                             PropertyId = property.ID,
                                             PropertyName = property.PropertyName,
                                             RestroomId = restroom.ID,
                                             RestroomName = restroom.Name,
                                             RestroomTypeId = restroomType.ID,
                                             RestroomTypeName = restroomType.Name,
                                         },
                                         Parameter = new DeviceUpdateParameter()
                                         {
                                             FormatCode = parameter.FormatCode,
                                             Id = parameter.Id,
                                             Index = parameter.Index,
                                             IsAutoReset = parameter.IsAutoReset,
                                             IsReturn = parameter.IsReturnParameter,
                                             Name = parameter.Name,
                                         },
                                     }
                                     into ParameterGrouping
                                     from parameterGroup in ParameterGrouping.DefaultIfEmpty()
                                     group new
                                     {
                                         Parameter = ParameterGrouping.Key.Parameter,
                                         Values = ParameterGrouping.Distinct()
                                     }
                                    by ParameterGrouping.Key.DeviceUpdateData
                                         into DeviceGrouping
                                         select DeviceGrouping;



                // pure iterator pattern
                // no need of double iteration

                // Temp fix for duplicates from query
                var processedData = new Dictionary<string, IDictionary<int, IList<int>>>(StringComparer.OrdinalIgnoreCase);

                foreach (var deviceLevel in groupQuery)
                {
                    var deviceData = deviceLevel.Key;

                    if (!processedData.ContainsKey(deviceData.DeviceId))
                    {
                        var parameters = new Dictionary<int, IList<int>>();

                        processedData.Add(deviceData.DeviceId, parameters);

                        foreach (var parameterLevel in deviceLevel)
                        {
                            var parameterData = parameterLevel.Parameter;

                            if (!parameters.ContainsKey(parameterData.Id))
                            {
                                var values = new List<int>();
                                parameters.Add(parameterData.Id, values);

                                deviceData.Parameters.Add(parameterData);
                                parameterData.Device = deviceData;
                                parameterData.DeviceTypeId = deviceData.DeviceTypeId;

                                foreach (var value in parameterLevel.Values)
                                {
                                    if (!values.Contains(value.Id))
                                    {
                                        values.Add(value.Id);
                                        value.Parameter = parameterData;
                                        parameterData.Values.Add(value);
                                    }
                                }
                            }
                        }
                        yield return deviceData;
                    }
                }
            }

            yield break;

        }

        #endregion

        static ConnectionMultiplexer cacheCon;
        private const string CACHE_DEVICE_PREFIX = "DeviceMetadata_";

        public DeviceParameterWorker()
        {
            try
            {
                cacheCon = KC.SmartWashroom.Core.Helper.CloudHelper.CacheHelper.GetInstance().GetDefaultConnection();
            }
            catch { } //Silent catch not to disturb the overall process.
        }

        /// <summary>
        /// Gets the return parameter based on the input criteria
        /// </summary>
        /// <param name="deviceId">The device identified, usually string representation of 48 bit HEX value</param>
        /// <param name="deviceTypeName">The device type name</param>
        /// <param name="deviceTypeId">The device type id</param>
        /// <param name="customerId">The customer id</param>
        /// <returns>An enumerable of the parameter values using iterator patttern</returns>
        /// <remarks>Really heavy operation; must be properly parameterized</remarks>
        public IEnumerable<DeviceUpdateDetails> GetDeviceDetails(string deviceId = ""
            , string deviceTypeName = ""
            , int deviceTypeId = 0
            , int customerId = 0)
        {
            var deviceDetails = default(IEnumerable<DeviceUpdateDetails>);

            using (var context = EntityRepositoryManager.GetStoreEntity())
            {

                var records = this.GetDeviceDetails(context
                    , deviceId
                    , deviceTypeName
                    , deviceTypeId
                    , customerId);

                var processedData = new Dictionary<string, DeviceUpdateDetails>(StringComparer.OrdinalIgnoreCase);

                var unprocessedValueMap = new Dictionary<int, IList<DeviceUpdateValue>>();

                foreach (var row in records)
                {

                    var deviceInfo = this.FindOrAppend(processedData, row.Item1);

                    var parameterInfo = this.FindOrAppend(deviceInfo, row.Item2);

                    this.FindOrMarkFallout(row.Item3, deviceInfo, unprocessedValueMap);

                }

                foreach (var unprocessed in unprocessedValueMap)
                {
                    var parameter = processedData.Select(device => device.Value.Parameters.Where(p => p.Id == unprocessed.Key)).Combine().FirstOrDefault();

                    if (parameter != null)
                    {
                        var values = unprocessed.Value.Where(v => !parameter.Values.Select(pv => pv.Id).Contains(v.Id));

                        foreach (var value in values)
                        {
                            parameter.Values.Add(value);
                            value.Parameter = parameter;
                        }
                    }
                }

                deviceDetails = processedData.Values.ToList();

                unprocessedValueMap.Clear();
                processedData.Clear();
            }

            return deviceDetails ?? Enumerable.Empty<DeviceUpdateDetails>();

        }

        /// <summary>
        /// Finds an item or marks for fallouts
        /// </summary>
        /// <param name="input">Device Parameter Value</param>
        /// <param name="device">Device</param>
        /// <param name="fallouts">Fallouts</param>
        /// <returns>The boolean status whether input is a fallout or not</returns>

        protected bool FindOrMarkFallout(DeviceUpdateValue input
            , DeviceUpdateDetails device
            , Dictionary<int, IList<DeviceUpdateValue>> fallouts)
        {
            bool isFallout = true;

            if (device != null)
            {
                var parameterForValue = device.Parameters.Where(p => p.Id == input.ParameterId
                    && p.Values.Select(v => v.Id).Contains(input.Id));

                if (!parameterForValue.Any())
                {
                    if (!fallouts.ContainsKey(input.ParameterId))
                    {
                        fallouts.Add(input.ParameterId, new List<DeviceUpdateValue>());
                    }
                    var unprocessedValues = fallouts[input.ParameterId];

                    if (!unprocessedValues.Any(v => v.Id == input.Id))
                    {
                        unprocessedValues.Add(input);
                    }
                }
                else
                {
                    foreach (var parameter in parameterForValue)
                    {
                        if (parameter.Id == input.ParameterId)
                        {
                            var value = parameter.Values.Select(v => v.Id == input.Id);

                            if (!value.Any())
                            {
                                parameter.Values.Add(input);
                                input.Parameter = parameter;
                                isFallout = false;
                                break;

                            }
                        }
                    }


                }
            }


            return isFallout;
        }



        private DeviceUpdateParameter FindOrAppend(DeviceUpdateDetails deviceInfo, DeviceUpdateParameter input)
        {
            var parameterInfo = default(DeviceUpdateParameter);

            if (deviceInfo != null && input != null)
            {
                parameterInfo = deviceInfo.Parameters.Where(p => p.Id == input.Id).FirstOrDefault();

                if (parameterInfo == null)
                {
                    parameterInfo = input;
                    deviceInfo.Parameters.Add(parameterInfo);
                    parameterInfo.Device = deviceInfo;
                }
            }
            return parameterInfo;
        }

        /// <summary>
        /// Finds or appends the device information from the temporary lookup
        /// </summary>
        /// <param name="lookup">The lookup</param>
        /// <param name="input">The device details</param>
        /// <returns>The matching device details</returns>
        protected DeviceUpdateDetails FindOrAppend(Dictionary<string, DeviceUpdateDetails> lookup, DeviceUpdateDetails input)
        {
            var deviceInfo = default(DeviceUpdateDetails);

            if (lookup != null && input != null)
            {
                if (!lookup.ContainsKey(input.DeviceId))
                {
                    lookup.Add(input.DeviceId, input);
                    deviceInfo = input;
                }
                else
                {
                    deviceInfo = lookup[input.DeviceId];
                }
            }

            return deviceInfo;
        }

        /// <summary>
        /// Reads the tuples one by one
        /// </summary>
        /// <param name="context">Context</param>
        /// <param name="deviceId">Device Id</param>
        /// <param name="deviceTypeName">Device Type Name</param>
        /// <param name="deviceTypeId">Device Type Id</param>
        /// <param name="customerId">Customer Id</param>
        /// <returns>An enumerable of identified objects, without the relaion set</returns>

        protected IEnumerable<Tuple<DeviceUpdateDetails, DeviceUpdateParameter, DeviceUpdateValue>> GetDeviceDetails(SmartWashroomEntities context
            , string deviceId = ""
            , string deviceTypeName = ""
            , int deviceTypeId = 0
            , int customerId = 0)
        {
            if (context != null
                && (!string.IsNullOrWhiteSpace(deviceId)
                || !string.IsNullOrWhiteSpace(deviceTypeName)
                || deviceTypeId > 0
                || customerId > 0))
            {
                /*back to old school, I had connection timeouts with group by joins*/
                var query = from customer in context.Customers
                            join property in context.Properties
                                on customer equals property.Customer
                            join building in context.Buildings
                                on property equals building.Property
                            join floor in context.Floors
                                on building equals floor.Building
                            join restroom in context.Washrooms
                                on floor equals restroom.Floor
                            join restroomType in context.Genders
                                on restroom.Gender equals restroomType
                            join deviceRestroomMap in context.DeviceWashrooms
                                on restroom equals deviceRestroomMap.Washroom
                            join device in context.Devices
                                on deviceRestroomMap.Device equals device
                            join deviceType in context.DeviceTypes
                                on device.DeviceType equals deviceType
                            join parameter in context.DeviceParameters
                                on deviceType equals parameter.DeviceType
                            join parameterValue in context.DeviceParameterValues
                                on parameter equals parameterValue.DeviceParameter
                            where (parameterValue.DeviceId == device.ID || parameterValue.DeviceId == "" || parameterValue.DeviceId == null)
                                && (!parameterValue.CustomerId.HasValue || parameterValue.CustomerId.Value == customer.ID)
                                && (device.ID == deviceId || deviceId == null || deviceId == "") // device id filtering
                                && (deviceType.ID == deviceTypeId || deviceTypeId <= 0
                                    || deviceType.Name == deviceTypeName || deviceTypeName == null || deviceTypeName == "") // device type filtering
                                && (customer.ID == customerId || customerId <= 0) // customer id filtering
                                && customer.IsActive
                                && property.IsActive
                                && building.IsActive
                                && floor.IsActive
                                && restroom.IsActive
                                && device.IsActive
                                && deviceRestroomMap.IsActive == true
                                && parameter.IsActive
                            /* The front end does not respect the start date
                             * Hence commenting this out, till it is resolved
                            && deviceRestroomMap.StartDate <= DateTime.UtcNow
                            && deviceRestroomMap.EndDate >= DateTime.UtcNow
                            */
                            select new
                            {
                                Device = new DeviceUpdateDetails()
                                {
                                    BuildingId = building.ID,
                                    BuildingName = building.Name,
                                    CustomerId = customer.ID,
                                    CustomerName = customer.Name,
                                    DeviceId = device.ID,
                                    DeviceName = device.Name,
                                    DeviceTypeId = deviceType.ID,
                                    DeviceTypeName = deviceType.Name,
                                    FloorId = floor.ID,
                                    FloorLevel = floor.FloorLevel,
                                    PropertyId = property.ID,
                                    PropertyName = property.PropertyName,
                                    RestroomId = restroom.ID,
                                    RestroomName = restroom.Name,
                                    RestroomTypeId = restroomType.ID,
                                    RestroomTypeName = restroomType.Name,
                                },

                                Parameter = new DeviceUpdateParameter()
                                {
                                    Id = parameter.Id,
                                    Name = parameter.Name,
                                    FormatCode = parameter.FormatCode,
                                    Index = parameter.Index,
                                    IsAutoReset = parameter.IsAutoReset,
                                    IsReturn = parameter.IsReturnParameter,
                                    DeviceTypeId = deviceType.ID,
                                    IgnoreErrors = parameter.IgnoreError,
                                },

                                Value = new DeviceUpdateValue()
                                {
                                    CustomerId = parameterValue.CustomerId,
                                    DeviceId = parameterValue.DeviceId,
                                    Id = parameterValue.Id,
                                    IsReset = parameterValue.IsReset,
                                    ModifiedTime = parameterValue.ModifiedTime,
                                    ResetTime = parameterValue.ResetTime,
                                    Value = parameterValue.Value,
                                    ParameterId = parameterValue.ParameterId,
                                },
                            };


                foreach (var item in query)
                {

                    yield return new Tuple<DeviceUpdateDetails, DeviceUpdateParameter, DeviceUpdateValue>(item.Device
                        , item.Parameter
                        , item.Value);

                }

                yield break;



            }
        }

        /// <summary>
        /// Sets the auto reset parameter values back to the store, when implemented
        /// </summary>
        /// <param name="deviceInfo">The list of auto reset parameters</param>
        /// <returns>The filtered enumerable with the updated values</returns>
        public int OverwriteAutoResetParameterValues(IEnumerable<DeviceUpdateParameter> parameters)
        {
            int recordsAffected = 0;
            // Tradeoff: immediate (eager) execution is better than opening the connection
            var autoResetParameters = parameters.AutoReset();

            var overrides = autoResetParameters.Where(p => p.DeviceOverride() != null || p.CustomerOverride() != null);

            // Note 1: No way the above method call will return null
            // hence a null check is not required here
            // Note 2: no need to open the connection, if everything are reset already

            if (overrides.Any())
            {
                using (var context = EntityRepositoryManager.GetStoreEntity())
                {
                    if (this.AutoResetDeviceOverrides(context, autoResetParameters) > 0)
                    {
                        recordsAffected = context.SaveChanges();
                    }

                    if (this.AutoResetCustomerOverrides(context, autoResetParameters) > 0)
                    {
                        recordsAffected += context.SaveChanges();
                    }


                }
            }

            return recordsAffected;
        }

        /// <summary>
        /// Resets the customer overrides for the given parameters
        /// </summary>
        /// <param name="context">Instance of the context</param>
        /// <param name="autoResetParameters">Parameters</param>
        /// <returns>The object updated count</returns>
        protected int AutoResetCustomerOverrides(SmartWashroomEntities context, IEnumerable<DeviceUpdateParameter> autoResetParameters)
        {
            int updateCount = 0;
            var customerId = autoResetParameters
                .Where(p => p.Device != null && p.Device.CustomerId > 0)
                .Select(p => p.Device.CustomerId).FirstOrDefault();

            var deviceTypeId = autoResetParameters
                .Where(p => p.Device != null && p.Device.DeviceTypeId > 0)
                .Select(p => p.Device.DeviceTypeId).FirstOrDefault();

            var devicesForCustomer = this.FindDeviceCount(context
                , customerId
                , deviceTypeId);

            var parameterIds = autoResetParameters.Select(item => item.Id).Distinct();

            #region Apologies, Unable to decouple/break-down below codeblock because of dynamic typing

            // find the completion status for the current customer for each device for each parameter
            var completionStatus = (from dp in context.DeviceParameters
                                    join dpv in context.DeviceParameterValues
                                        on dp equals dpv.DeviceParameter
                                    where parameterIds.Contains(dp.Id)
                                        && dpv.CustomerId == customerId // the default value is skipped! Do not worry :)
                                    group dpv by dp into gp
                                    select new
                                    {
                                        Id = gp.Key.Id,
                                        CustomerOverrides = gp.Where(p => p.DeviceId == null),
                                        DeviceOverrideCount = gp.Where(p => p.DeviceId != null && p.IsReset.HasValue && p.IsReset.Value).Distinct().Count()
                                    });

            // iterate
            foreach (var status in completionStatus)
            {
                int iterationUpdateCount = 0;
                // the device override reset count matches total number of the current
                // device type for the current customer
                if (status.DeviceOverrideCount >= devicesForCustomer)
                {
                    // take the customer override values
                    // theoretically there will be only one value
                    foreach (var storeValue in status.CustomerOverrides)
                    {
                        // update
                        if (!storeValue.IsReset.HasValue || !storeValue.IsReset.Value)
                        {
                            // update flags
                            storeValue.IsReset = true;
                            storeValue.ResetTime = DateTime.UtcNow;
                            iterationUpdateCount += 2;
                        }

                        // take the current value from in memory collection
                        var parameter = autoResetParameters.Where(p => p.Id == storeValue.ParameterId
                            && p.Values.Select(v => v.Id).Contains(storeValue.Id)).FirstOrDefault();

                        // update the in memory object
                        if (parameter != null)
                        {
                            var defaultValue = parameter.DefaultValue();

                            if (defaultValue != null && defaultValue.Value != storeValue.Value)
                            {
                                storeValue.Value = defaultValue.Value;
                                iterationUpdateCount++;
                            }

                            var customerOverride = parameter.CustomerOverride();

                            if (customerOverride != null)
                            {
                                customerOverride.IsReset = storeValue.IsReset;
                                customerOverride.ResetTime = storeValue.ResetTime;
                                customerOverride.Value = storeValue.Value;
                            }
                        }

                        if (iterationUpdateCount > 0)
                        {
                            updateCount++;
                        }
                    }
                }
            }

            #endregion

            return updateCount;
        }

        /// <summary>
        /// Finds the device count for the given device type for the given customer
        /// </summary>
        /// <param name="context">The instance of the context</param>
        /// <param name="customerId">Customer id</param>
        /// <param name="deviceTypeId">Device type id</param>
        /// <returns>Device count in integer</returns>
        protected int FindDeviceCount(SmartWashroomEntities context, int customerId, int deviceTypeId)
        {
            int deviceCount = 0;

            if (context != null
                && customerId > 0
                && deviceTypeId > 0)
            {
                // find the device count for the given device type for given customer
                deviceCount = (from customer in context.Customers
                               join property in context.Properties
                                   on customer equals property.Customer
                               join building in context.Buildings
                                   on property equals building.Property
                               join floor in context.Floors
                                   on building equals floor.Building
                               join restroom in context.Washrooms
                                   on floor equals restroom.Floor
                               join floorSection in context.Genders
                                   on restroom.Gender equals floorSection
                               join deviceRestroomMap in context.DeviceWashrooms
                                   on restroom equals deviceRestroomMap.Washroom
                               join device in context.Devices
                                   on deviceRestroomMap.Device equals device
                               join deviceType in context.DeviceTypes
                                   on device.DeviceType equals deviceType
                               where customer.ID == customerId // customer id filtering
                                  && deviceType.ID == deviceTypeId
                                  && customer.IsActive
                                  && property.IsActive
                                  && building.IsActive
                                  && floor.IsActive
                                  && restroom.IsActive
                                  && device.IsActive
                                  && deviceRestroomMap.IsActive == true
                               /* The front end does not respect the start date
                                * Hence commenting this out, till it is resolved
                               && deviceRestroomMap.StartDate <= DateTime.UtcNow
                               && deviceRestroomMap.EndDate >= DateTime.UtcNow
                               */
                               select device.ID).Distinct().Count();
            }

            return deviceCount;
        }

        /// <summary>
        /// Autoresets the device overrides
        /// </summary>
        /// <param name="context">context</param>
        /// <param name="autoResetParameters">parameters</param>
        /// <returns>Upsert count</returns>
        protected int AutoResetDeviceOverrides(SmartWashroomEntities context, IEnumerable<DeviceUpdateParameter> autoResetParameters)
        {
            int upsertCount = 0;

            if (context != null
                && autoResetParameters != null)
            {
                // Find the store values

                var storeValues = this.FindMatch(context.DeviceParameterValues
                    , autoResetParameters);


                foreach (var parameter in autoResetParameters)
                {
                    var storeOverrides = 0;

                    var deviceOverride = parameter.DeviceOverride();

                    if (deviceOverride != null)
                    {
                        // update the existing device override
                        foreach (var storeValue in this.FindMatch(storeValues, deviceOverride))
                        {
                            storeOverrides++;
                            if (this.SetAutoResetFlag(storeValue, deviceOverride, parameter.DefaultValue()))
                            {
                                upsertCount++;
                            }
                        }
                    }

                    // insert
                    if (storeOverrides <= 0)
                    {
                        var storeValue = this.CreateStoreParameterValue(parameter);

                        if (storeValue != null)
                        {
                            context.DeviceParameterValues.Add(storeValue);
                            upsertCount++;
                            var deviceParameter = new DeviceUpdateValue()
                            {
                                CustomerId = storeValue.CustomerId,
                                DeviceId = storeValue.DeviceId,
                                Value = storeValue.Value,
                                IsReset = storeValue.IsReset,
                                ResetTime = storeValue.ResetTime,
                                Id = storeValue.Id,
                                Parameter = parameter
                            };
                            parameter.Values.Add(deviceParameter);
                        }

                    }

                }
            }

            return upsertCount;
        }

        /// <summary>
        /// Instantiate the store parameter values
        /// </summary>
        /// <param name="parameter">Parameter</param>
        /// <param name="defaultValue">Default value</param>
        /// <returns>The instance of the device parameter value</returns>
        protected DeviceParameterValue CreateStoreParameterValue(DeviceUpdateParameter parameter)
        {
            var newParameterValue = default(DeviceParameterValue);

            if (parameter != null)
            {
                var defaultValue = parameter.DefaultValue();

                if (defaultValue != null)
                {
                    newParameterValue = new DeviceParameterValue()
                    {
                        CustomerId = parameter.Device.CustomerId,
                        DeviceId = parameter.Device.DeviceId,
                        ParameterId = parameter.Id,
                        Value = defaultValue.Value,
                        IsReset = true,
                        ResetTime = DateTime.UtcNow,
                        CreatedTime = DateTime.UtcNow,
                    };
                }
            }

            return newParameterValue;

        }



        /// <summary>
        /// Finds the matching store values for the given inputs
        /// </summary>
        /// <param name="storeValues">The input store values</param>
        /// <param name="parameters">Parameter ids</param>
        /// <returns>The matching store values as an enumerable</returns>
        protected IEnumerable<DeviceParameterValue> FindMatch(IEnumerable<DeviceParameterValue> storeValues
            , IEnumerable<DeviceUpdateParameter> parameters)
        {
            var matchingValues = default(IEnumerable<DeviceParameterValue>);

            if (storeValues != null
                && parameters != null)
            {
                var deviceOverrides = parameters.Select(p => p.DeviceOverride()).Where(v => v != null);
                var deviceIds = parameters.Where(p => p.Device != null && !string.IsNullOrWhiteSpace(p.Device.DeviceId)).Select(p => p.Device.DeviceId);
                var customerId = parameters.Where(p => p.Device != null && p.Device.CustomerId > 0).Select(p => p.Device.CustomerId);

                matchingValues = storeValues.Where(pv => deviceOverrides.Select(value => value.Id).Contains(pv.Id)
                      && pv.DeviceId != null
                      && pv.DeviceId != ""
                      && pv.CustomerId.HasValue
                      && deviceIds.Contains(pv.DeviceId)
                      && customerId.Contains(pv.CustomerId.Value));
            }

            return matchingValues ?? Enumerable.Empty<DeviceParameterValue>();
        }


        /// <summary>
        /// Find the matching store values for the given parameter 
        /// </summary>
        /// <param name="storeValues">The enumerable of store values</param>
        /// <param name="deviceOverride">The parameter</param>
        /// <returns>An enumerable of matching store values</returns>
        protected IEnumerable<DeviceParameterValue> FindMatch(IEnumerable<DeviceParameterValue> storeValues, DeviceUpdateValue deviceOverride)
        {
            var matchingValues = default(IEnumerable<DeviceParameterValue>);

            if (storeValues != null
                && deviceOverride != null)
            {
                matchingValues = storeValues.Where(sv => sv.ParameterId == deviceOverride.ParameterId
                                    && sv.CustomerId == deviceOverride.CustomerId
                                    && sv.DeviceId == deviceOverride.DeviceId);
            }
            return matchingValues ?? Enumerable.Empty<DeviceParameterValue>();
        }


        /// <summary>
        /// Updates the store value for the auto reset parameter from the matching default value
        /// </summary>
        /// <param name="storeValue">The instance of the store value</param>
        /// <param name="parameters">An enumerable of the parameters</param>
        /// <returns>The boolean status</returns>
        protected bool SetAutoResetFlag(DeviceParameterValue storeValue, DeviceUpdateValue matchingValue, DeviceUpdateValue defaultValue)
        {
            var status = false;

            if (storeValue != null
                && matchingValue != null)
            {
                // TODO: review this condition
                if (!storeValue.IsReset.HasValue
                    || !storeValue.IsReset.Value
                    || (defaultValue != null && storeValue.Value != defaultValue.Value))
                {
                    storeValue.IsReset = matchingValue.IsReset = true;
                    storeValue.ResetTime = matchingValue.ResetTime = DateTime.UtcNow;

                    if (defaultValue != null)
                    {
                        storeValue.Value = matchingValue.Value = defaultValue.Value;
                    }
                    status = true;
                }
            }

            return status;
        }

        public IEnumerable<DeviceUpdateDetails> RetrieveFromCache(string deviceId)
        {

            IList<DeviceUpdateDetails> deviceList = new List<DeviceUpdateDetails>();
            try
            {
                Logger.Debug("Retrieving device with device id {0}", deviceId);
                DeviceUpdateDetails d = this.GetFromCache(deviceId);
                deviceList.Add(d);
              //  return deviceList;
            }


            catch (Exception ex)
            {
                //Log exception, don't throw it again
                Logger.Error( string.Format("Error occurred while retrieving device with device id {0}", deviceId),ex);
                
            }

            return deviceList;
        }


        private IDatabase GetCache()
        {
            if (cacheCon.IsConnected)
                return cacheCon.GetDatabase();
            else
            {
                throw new ApplicationException("Cache connection is not connected. Find a workaround");
            }
        }

        public BusinessEntities.DeviceUpdate.DeviceUpdateDetails GetFromCache(string deviceId)
        {
            DeviceUpdateDetails obj = null;
            try
            {
                string deviceData = GetCache().StringGet(GetDeviceCacheKey(deviceId));
                if (deviceData != null)
                {
                    Byte[] byteData = System.Text.Encoding.Default.GetBytes(deviceData);
                    obj = Core.Helper.SerializationHelper.Deserialize<DeviceUpdateDetails>(byteData);
                }

                //Hyderate object
                foreach (DeviceUpdateParameter p in obj.Parameters)
                {
                    p.Device = obj;
                    foreach (DeviceUpdateValue v in p.Values)
                    {
                        v.Parameter = p;
                        v.ParameterId = p.Id;
                    }
                }

                return obj;
            }
            catch (Exception ex)
            {
                Logger.Error(string.Format("DeviceParameterWorker.GetFromCache(deviceid {0}): An error occurred", deviceId), ex);
                throw new ApplicationException(String.Format("Error occurred which getting device with device id {0} from cache", deviceId), ex);
            }
        }

        public bool SaveToCache(DeviceUpdateDetails obj)
        {
            try
            {
                //Avoid cyclic references
                foreach (DeviceUpdateParameter p in obj.Parameters)
                {
                    p.Device = null;
                    foreach (DeviceUpdateValue v in p.Values)
                    {
                        v.Parameter = null;
                    }
                }

                //Serialize to bytes
                Byte[] byteData = Core.Helper.SerializationHelper.SerializeToBytes(obj);

                if (byteData != null)
                {
                    //Get string from bytes
                    string deviceData = System.Text.Encoding.Default.GetString(byteData);

                    //put in cache
                    GetCache().StringSet(GetDeviceCacheKey(obj.DeviceId), deviceData);

                    return true;
                }
                else
                {
                    throw new ApplicationException("An error occurred while serializing deviceupdatedetails data to bytes for device id " + obj.DeviceId);
                }

            }
            catch (Exception ex)
            {
                Logger.Error(string.Format("DeviceParameterWorker.SaveToCache(deviceid {0}): An error occurred", obj.DeviceId), ex);
                throw new ApplicationException(String.Format("Error occurred which getting device with device id {0} from cache", obj.DeviceId), ex);
            }
        }

        public void Dispose()
        {
            cacheCon = null;
        }

        public bool RemoveFromCache(string deviceId = "")
        {
            IDatabase cache = GetCache();
            try
            {
                //Delete the entr(ies) if it exists
                if (String.IsNullOrWhiteSpace(deviceId))
                {//Remove all inactive devices
                    //Get list of inactive devices
                    using (var context = EntityRepositoryManager.GetStoreEntity())
                    {
                        //Get all inactive devices
                        List<Device> inactiveDevices = context.Devices.Where(d => (d.IsActive == false)).ToList<Device>();

                        foreach (Device d in inactiveDevices)
                        {
                            cache.KeyDelete(GetDeviceCacheKey(deviceId));
                        }
                    }
                }
                else
                {
                    //Remove specific inactive device
                    cache.KeyDelete(GetDeviceCacheKey(deviceId));
                }
                return true;
            }
            catch (Exception ex)
            {
                Logger.Error(string.Format("DeviceParameterWorker.RemoveFromCache(deviceid {0}): An error occurred", deviceId), ex);
                throw new ApplicationException(String.Format("Error occurred which deleting device with device id {0} from cache", deviceId), ex);
            }
            finally
            {
                cache = null;
            }
        }

        private string GetDeviceCacheKey(string deviceId)
        {
            return CACHE_DEVICE_PREFIX + deviceId.ToLower();
        }

    }
}
