﻿using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.Enumerations;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.DataAccess.Skeleton;
using System;
using System.Collections.Generic;
using System.Linq;
using BusinessEntity = KC.SmartWashroom.BusinessEntities;

namespace KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers
{
    public class UserWorker : IUserWorker
    {
        internal const string VIOLATION_OF_PRIMARY_KEY = "Violation of PRIMARY KEY constraint";
        public DeviceDetail GetUserDetails(string deviceId)
        {
            DeviceDetail deviceLog = null;

            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                var Users = new List<User>();

                var userDetails = (from user in dbEntity.Users

                                   join role in dbEntity.Roles on user.RoleId equals role.ID
                                   join customer in dbEntity.Customers on user.CustomerId equals customer.ID
                                   join property in dbEntity.Properties on user.CustomerId equals property.CustomerId

                                   join building in dbEntity.Buildings on property.ID equals building.PropertyId
                                   join floors in dbEntity.Floors on building.ID equals floors.BuildingId
                                   join washroom in dbEntity.Washrooms on floors.ID equals washroom.FloorId

                                   join wing in dbEntity.Wings on washroom.WingId equals wing.ID
                                   join device in dbEntity.DeviceWashrooms on washroom.ID equals device.WashroomId
                                   join devices in dbEntity.Devices on device.DeviceId equals devices.ID
                                   join gender in dbEntity.Genders on washroom.GenderId equals gender.ID

                                   where device.DeviceId.Equals(deviceId) && device.IsActive == true
                                   && user.Role.RoleLevel != (byte)Enums.RoleLevelType.PortalAdmin
                                   && user.IsDelete.Equals(false)
                                   && customer.IsActive.Equals(true)
                                   && property.IsActive.Equals(true)
                                   select new
                                   {
                                       user.ID,
                                       user.FirstName,
                                       user.LastName,
                                       user.RoleId,

                                       role.RoleLevel,
                                       user.Email,
                                       user.MobileNo,
                                       user.CustomerId,

                                       user.IsEmailAlert,
                                       user.IsMobileAlert,
                                       devices.Name,

                                       floors.FloorLevel,
                                       Washroom = washroom.Name,
                                       Gender = gender.Name,

                                       Building = building.Name,
                                       Wing = wing.Name,
                                       BuildingId = building.ID,

                                       PropertyId = property.ID,
                                       PropertyName = property.PropertyName,
                                       LocalTimeZone = property.LocationTimeZone

                                   } into userResult
                                   group userResult by new
                                   {
                                       userResult.ID,
                                       userResult.FirstName,
                                       userResult.LastName,

                                       userResult.RoleId,
                                       userResult.RoleLevel,
                                       userResult.Email,

                                       userResult.MobileNo,
                                       userResult.CustomerId,
                                       userResult.IsEmailAlert,

                                       userResult.IsMobileAlert,
                                       userResult.Name,
                                       userResult.FloorLevel,

                                       userResult.Washroom,
                                       userResult.Gender,
                                       userResult.Building,

                                       userResult.Wing,
                                       userResult.BuildingId,
                                       userResult.PropertyId,
                                       userResult.PropertyName,

                                       userResult.LocalTimeZone
                                   } into groupedUser
                                   select new UserEntity
                                   {
                                       ID = groupedUser.Key.ID,
                                       Name = groupedUser.Key.FirstName,
                                       RoleID = groupedUser.Key.RoleId,

                                       RoleLevel = groupedUser.Key.RoleLevel,
                                       Email = groupedUser.Key.IsEmailAlert ? groupedUser.Key.Email : null,
                                       MobileNo = groupedUser.Key.IsMobileAlert ? groupedUser.Key.MobileNo : null,
                                       DeviceName = groupedUser.Key.Name,

                                       FloorID = groupedUser.Key.FloorLevel,
                                       Gender = groupedUser.Key.Gender,
                                       Washroom = groupedUser.Key.Washroom,
                                       // PropertyName = groupedUser.Key.PropertyName,

                                       Building = groupedUser.Key.Building,
                                       IsEmailAlert = groupedUser.Key.IsEmailAlert,
                                       IsMobileAlert = groupedUser.Key.IsMobileAlert,

                                       LastName = groupedUser.Key.LastName,
                                       Wing = groupedUser.Key.Wing,
                                       UserAccessBuildingID = groupedUser.Key.BuildingId,
                                       UserAccessPropertyID = groupedUser.Key.PropertyId,

                                       LocalTimeZone = groupedUser.Key.LocalTimeZone ?? "India Standard Time"
                                   }).Distinct().ToList();

                var deviceDetails = (from device in dbEntity.Devices
                                     where device.ID.Equals(deviceId)
                                     select new DeviceDetail
                                      {
                                          DeviceName = device.Name
                                      }).SingleOrDefault();

                deviceLog = new DeviceDetail();
                deviceLog.DeviceID = deviceId;
                deviceLog.DeviceName = deviceDetails == null ? string.Empty : deviceDetails.DeviceName;
                deviceLog.UserDetails = userDetails;

                deviceLog.Floor = userDetails.Select(x => x.FloorID).FirstOrDefault();
                deviceLog.Gender = userDetails.Select(x => x.Gender).FirstOrDefault();
                deviceLog.Washroom = userDetails.Select(x => x.Washroom).FirstOrDefault();
                // TODO : deviceLog.PropertyName = userDetails.Select(x=> x.)

                deviceLog.LocalTimeZone = userDetails.Select(x => x.LocalTimeZone).FirstOrDefault() ?? "UTC";
                deviceLog.Building = userDetails.Select(x => x.Building).FirstOrDefault();
                deviceLog.Wing = userDetails.Select(x => x.Wing).FirstOrDefault();
            }
            return deviceLog;
        }

        public DeviceDetail GetErrorAdminDetails()
        {
            DeviceDetail deviceLog = null;

            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                var Users = new List<User>();

                var userDetails = (from errorAdmins in dbEntity.Users
                                   where errorAdmins.RoleId.Equals(2) && errorAdmins.IsDelete.Equals(false)
                                   select new UserEntity
                                   {
                                       Email = errorAdmins.Email,
                                       MobileNo = errorAdmins.MobileNo,
                                       LastName = errorAdmins.LastName,
                                       IsEmailAlert = errorAdmins.IsEmailAlert,
                                       IsMobileAlert = errorAdmins.IsMobileAlert

                                   }).ToList();

                deviceLog = new DeviceDetail();
                deviceLog.UserDetails = userDetails;
            }
            return deviceLog;
        }

        public ProcessResponse<KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert> SaveDeviceAlert(KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert deviceAlert)
        {
            ProcessResponse<KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert> response = new ProcessResponse<KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert>();
            response.Status = ResponseStatus.Success;
            response.Message = AlertEngineConstants.MESSAGE_SUCCESS;

            try
            {
                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    var alerts = (from alertTypes in dbEntity.AlertTypes
                                  where alertTypes.Type.Equals(deviceAlert.AlertType)
                                  select new KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert
                           {
                               AlertTypeId = alertTypes.ID

                           }).SingleOrDefault();

                    deviceAlert.AlertTypeId = alerts == null ? 0 : alerts.AlertTypeId;

                    var deviceAlerts = dbEntity.Set<DeviceAlert>();

                    deviceAlerts.Add(new DeviceAlert { DeviceId = deviceAlert.DeviceId, AlertTypeId = Convert.ToByte(deviceAlert.AlertTypeId), ReceivedOn = DateTime.UtcNow });

                    dbEntity.SaveChanges();
                }
            }
            catch (Exception ex) // VIJay: This silent catch is mandatory as duplicates should be avoided for device alerts by having double check on constraints in DB>>
            {
                bool isCompositeViolation = false;
                if (ex.Message.StartsWith(VIOLATION_OF_PRIMARY_KEY))
                {
                    isCompositeViolation = true;
                }
                else if (ex.InnerException != null)
                {
                    if (ex.InnerException.Message.StartsWith(VIOLATION_OF_PRIMARY_KEY))
                    {
                        isCompositeViolation = true;
                    }
                    else if (ex.InnerException.InnerException != null)
                    {
                        if (ex.InnerException.InnerException.Message.StartsWith(VIOLATION_OF_PRIMARY_KEY))
                            isCompositeViolation = true;
                        else if (ex.InnerException.InnerException.InnerException != null)
                        {
                            if (ex.InnerException.InnerException.InnerException.Message.StartsWith(VIOLATION_OF_PRIMARY_KEY))
                                isCompositeViolation = true;
                        }
                    }
                }

                if (isCompositeViolation)
                {
                    response.Status = ResponseStatus.Failed;
                    response.Message = ex.Message;
                }
                else
                {
                    response.Status = ResponseStatus.Error;
                    response.Message = ex.Message;
                }
            }
            return response;
        }

        public ProcessResponse<KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert> RemoveDeviceAlert(KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert deviceAlert)
        {
            ProcessResponse<KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert> response = new ProcessResponse<KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert>();

            try
            {
                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    var alerts = (from alertTypes in dbEntity.AlertTypes
                                  where alertTypes.Type.Equals(deviceAlert.AlertType)
                                  select new KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert
                                  {
                                      AlertTypeId = alertTypes.ID

                                  }).SingleOrDefault();

                    deviceAlert.AlertTypeId = alerts == null ? 0 : alerts.AlertTypeId;

                    var deviceAlerts = dbEntity.Set<DeviceAlert>();

                    deviceAlerts.RemoveRange(dbEntity.DeviceAlerts.Where(alert => alert.DeviceId == deviceAlert.DeviceId && alert.AlertTypeId == deviceAlert.AlertTypeId));

                    dbEntity.SaveChanges();
                }

                response.Status = ResponseStatus.Success;
                response.Message = AlertEngineConstants.MESSAGE_REMOVE_SUCCESS;
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.Failed;
                response.Message = ex.Message;
            }

            return response;
        }

        public List<UserEntity> GetContactsForCustomer(int customerID, int buildingId)
        {
            var contactsForCustomer = new List<UserEntity>();
            var filteredContacts = new List<UserEntity>();
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                #region //Quick fix for "If multiple browser windows opened contacts section is not getting updated " ,since the customerID is coming from cookie

                customerID = (from customer in dbEntity.Customers
                              join property in dbEntity.Properties
                                  on customer.ID equals property.CustomerId
                              join building in dbEntity.Buildings
                                  on property.ID equals building.PropertyId
                              where building.ID.Equals(buildingId)
                              select customer.ID).FirstOrDefault();
                #endregion
                contactsForCustomer = (from user in dbEntity.Users
                                       join customer in dbEntity.Customers on user.CustomerId equals customer.ID
                                       where customer.ID.Equals(customerID) && user.Role.RoleLevel != (byte)Enums.RoleLevelType.PortalAdmin && user.IsDelete.Equals(false) && customer.IsActive.Equals(true)
                                       select new UserEntity
                                        {
                                            ID = user.ID,
                                            Email = user.Email,
                                            RoleLevel = user.Role.RoleLevel,
                                            LastName = user.LastName,
                                            MobileNo = user.MobileNo,
                                            Name = user.FirstName,
                                            IsEmailAlert = user.IsEmailAlert,
                                            IsMobileAlert = user.IsMobileAlert,
                                            CustomerID =user.CustomerId.Value
                                        }).ToList();

                foreach (var item in contactsForCustomer)
                {
                    item.buildingIds = (from userBuildings in dbEntity.UserBuildings where userBuildings.UserId.Equals(item.ID) select userBuildings.BuildingId).ToList();
                    //Only add the users who are  mapped to the particular building .
                    if (item.buildingIds.Count == 0)
                    {
                        if (!item.RoleLevel.Equals((int)Enums.RoleLevelType.BuildingAdmin) && !item.RoleLevel.Equals((int)Enums.RoleLevelType.Cleaner))
                        {
                            if (item.RoleLevel.Equals((int)Enums.RoleLevelType.PropertyAdmin))
                            {
                                List<int> buildings = new List<int>();
                                buildings = (from dbuserProperties in dbEntity.UserProperties
                                             join dbproperties in dbEntity.Properties on dbuserProperties.PropertyId equals dbproperties.ID
                                             join dbbuildings in dbEntity.Buildings on dbproperties.ID equals dbbuildings.PropertyId
                                             where dbuserProperties.UserId == item.ID && dbproperties.IsActive == true && dbbuildings.IsActive == true
                                             select dbbuildings.ID
                                                ).ToList();
                                if (buildings.Contains(buildingId))
                                {
                                    filteredContacts.Add(item);
                                }
                            }
                            else if (item.RoleLevel.Equals((int)Enums.RoleLevelType.CustomerAdmin))
                            {
                                if (item.CustomerID.Equals(customerID))
                                {
                                    filteredContacts.Add(item);
                                }
                            }
                            else
                            {
                                filteredContacts.Add(item);
                            }
                        }
                    }
                    else
                    {
                        if (item.buildingIds.Contains(buildingId))
                        {
                            filteredContacts.Add(item);
                        }
                    }

                }



                //contactsForCustomer.RemoveAll(x => x.buildingIds.Count > 0 ? x.buildingIds.Where(y => y.Equals(buildingId)).Count() == 0 :false);

            }
            return filteredContacts;
        }

        public List<BusinessEntity.TenantApiEntities.Role> GetRoles()
        {
            List<BusinessEntity.TenantApiEntities.Role> Roles = null;
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                Roles = (from role in dbEntity.Roles
                         where !role.ID.Equals(1)
                         select new BusinessEntity.TenantApiEntities.Role
                         {
                             RoleId = role.ID,
                             RoleName = role.Name,
                             RoleLevel = role.RoleLevel
                         }).ToList();
            }
            return Roles;
        }

        public List<BusinessEntity.RolePermission> GetRolePermissions(short roleId)
        {
            List<BusinessEntity.RolePermission> rolePermissions = null;
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                rolePermissions = (from role in dbEntity.Roles
                                   join permission in dbEntity.RolePermissions on role.ID equals permission.RoleId
                                   join feature in dbEntity.Features on permission.FeatureId equals feature.ID
                                   where role.ID.Equals(roleId)
                                   select new BusinessEntity.RolePermission
                                   {
                                       RoleId = role.ID,
                                       FeatureId = feature.ID,
                                       FeatureDescription = feature.Name
                                   }).ToList();
            }
            return rolePermissions;
        }

        public List<BusinessEntity.Property> GetProperties(int customerId)
        {
            List<BusinessEntity.Property> Properties = null;
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                Properties = (from property in dbEntity.Properties
                              where property.IsActive == true && property.CustomerId == customerId
                              select new BusinessEntity.Property
                              {
                                  ID = property.ID,
                                  CustomerId = property.CustomerId,
                                  PropertyName = property.PropertyName,
                                  TimeZone = property.LocationTimeZone,
                                  AddressId = property.AddressId,
                                  ImageUrl = property.ImageUrl,
                                  CreatedBy = property.CreatedBy,
                                  CreatedDate = property.CreatedOn
                              }).OrderBy(o => o.PropertyName).ToList();
            }
            return Properties;
        }

        public List<BusinessEntity.Building> GetBuildings(int customerId)
        {
            List<BusinessEntity.Building> buildings = null;
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                buildings = (from building in dbEntity.Buildings
                             join property in dbEntity.Properties on building.PropertyId equals property.ID
                             where building.IsActive == true && property.CustomerId == customerId
                             select new BusinessEntity.Building
                             {
                                 ID = building.ID,
                                 Name = building.Name,
                                 PropertyId = building.PropertyId
                             }).ToList();
            }
            return buildings;
        }

        /// <summary>
        /// TO DO - Need to include joining with properties table
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public BusinessEntity.TenantApiEntities.User GetUserDetails(int userId)
        {
            BusinessEntity.TenantApiEntities.User User = new BusinessEntity.TenantApiEntities.User();
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                User = (from user in dbEntity.Users
                        where user.ID == userId && user.IsDelete == false
                        select new BusinessEntity.TenantApiEntities.User
                        {
                            UserId = user.ID,
                            CustomerName = user.Customer.Name,
                            FirstName = user.FirstName,
                            LastName = user.LastName,
                            Email = user.Email,
                            Mobile = user.MobileNo,
                            RoleId = user.RoleId,
                            RoleLevel = (from roles in dbEntity.Roles
                                         where roles.ID == user.RoleId
                                         select roles.RoleLevel).FirstOrDefault(),
                            EmailAlert = user.IsEmailAlert,
                            TextAlert = user.IsMobileAlert,
                            Properties = (from userProp in dbEntity.UserProperties
                                          join property in dbEntity.Properties on userProp.PropertyId equals property.ID
                                          where userProp.UserId == userId && property.IsActive == true
                                          select new BusinessEntity.Property
                                          {
                                              ID = property.ID,
                                              CustomerId = property.CustomerId,
                                              PropertyName = property.PropertyName,
                                              TimeZone = property.LocationTimeZone,
                                              AddressId = property.AddressId,
                                              ImageUrl = property.ImageUrl,
                                              IsDelete = !property.IsActive,
                                              CreatedBy = property.CreatedBy,
                                              CreatedDate = property.CreatedOn,
                                              LastUpdatedBy = property.LastUpdatedBy,
                                              LastUpdatedOn = property.LastUpdatedOn
                                          }).ToList<BusinessEntity.Property>(),
                            Buildings = (from userbuild in dbEntity.UserBuildings
                                         join building in dbEntity.Buildings on userbuild.BuildingId equals building.ID
                                         where userbuild.UserId == userId && building.IsActive == true
                                         select new BusinessEntity.Building
                                         {
                                             ID = building.ID,
                                             Name = building.Name,
                                             PropertyName = building.Property.PropertyName,
                                             PropertyId = building.PropertyId
                                         }
                                           ).ToList<BusinessEntity.Building>()
                        }).FirstOrDefault();
                if (User != null)
                {
                    User.CustomerId = Convert.ToInt32((from user in dbEntity.Users
                                                       where user.ID == userId && user.IsDelete == false
                                                       select user).FirstOrDefault().CustomerId);
                }


            }
            return User;
        }

        /// <summary>
        /// TO DO - Need to check same user should not be added multiple times
        /// TO DO - Need to include properties
        /// </summary>
        /// <param name="userApi"></param>
        /// <returns></returns>
        public ProcessResponse<BusinessEntity.TenantApiEntities.User> CreateUser(BusinessEntity.TenantApiEntities.User userApi)
        {
            ProcessResponse<BusinessEntity.TenantApiEntities.User> response = new ProcessResponse<BusinessEntity.TenantApiEntities.User>() { Status = ResponseStatus.Failed };
            try
            {
                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    User user = new User();
                    var userExists = (from dbusers in dbEntity.Users
                                      where dbusers.Email.ToUpper() == userApi.Email.ToUpper() && (!string.IsNullOrEmpty(userApi.Email)) //&& dbusers.IsDelete == false
                                      select dbusers);

                    if (userExists == null || userExists.Count() == 0)
                    {
                        user.FirstName = userApi.FirstName;
                        user.LastName = userApi.LastName;
                        user.Email = userApi.Email;
                        user.MobileNo = userApi.Mobile;
                        user.RoleId = (from role in dbEntity.Roles
                                       where role.RoleLevel == userApi.RoleLevel
                                       select role.ID).FirstOrDefault();
                        //user.RoleId = (byte)(userApi.RoleId);
                        user.IsEmailAlert = userApi.EmailAlert;

                        user.IsMobileAlert = userApi.TextAlert;
                        user.IsFirstLogin = true;
                        user.CreatedBy = userApi.UpdatedBy;
                        user.CreatedOn = DateTime.UtcNow;
                        user.CustomerId = userApi.CustomerId;

                        dbEntity.Users.Add(user);
                        dbEntity.SaveChanges();

                        if (userApi.Properties != null && userApi.RoleLevel == 10)
                            userApi.Properties.ForEach(o => dbEntity.UserProperties.Add(new UserProperty
                            {
                                PropertyId = o.ID,
                                UserId = user.ID,
                                CreatedBy = userApi.UpdatedBy,
                                CreatedOn = DateTime.UtcNow
                            }));

                        if (userApi.Buildings != null && userApi.RoleLevel == 20)
                            userApi.Buildings.ForEach(o => dbEntity.UserBuildings.Add(new UserBuilding
                            {
                                BuildingId = o.ID,
                                UserId = user.ID,
                                CreatedBy = userApi.UpdatedBy,
                                CreatedOn = DateTime.UtcNow
                            }));
                        if (userApi.Buildings != null && userApi.RoleLevel == 40)
                            userApi.Buildings.ForEach(o => dbEntity.UserBuildings.Add(new UserBuilding
                            {
                                BuildingId = o.ID,
                                UserId = user.ID,
                                CreatedBy = userApi.UpdatedBy,
                                CreatedOn = DateTime.UtcNow
                            }));

                        dbEntity.SaveChanges();
                        response.Status = ResponseStatus.Success;
                    }

                    else
                    {
                        response.Status = ResponseStatus.Failed;
                        response.Message = "Email ID already exists";
                    }

                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.Error;
                response.Message = ex.Message;
            }
            return response;
        }

        public ProcessResponse<BusinessEntity.TenantApiEntities.User> UpdateUser(BusinessEntity.TenantApiEntities.User userApi)
        {
            ProcessResponse<BusinessEntity.TenantApiEntities.User> response = new ProcessResponse<BusinessEntity.TenantApiEntities.User>() { Status = ResponseStatus.Failed };
            try
            {
                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    User editUser = null;
                    var userExists = (from dbusers in dbEntity.Users
                                      where dbusers.ID == userApi.UserId //&& //dbusers.ID != userApi.UserId && dbusers.IsDelete == false Fix for Duplicate user in system..
                                      select dbusers);

                    if (userExists != null || userExists.Count() > 0)
                    {
                        editUser = (from user in dbEntity.Users
                                    where user.ID == userApi.UserId && user.IsDelete == false
                                    select user).FirstOrDefault();
                        Guard.IsNotNull(editUser, "User To Be Updated");

                        editUser.FirstName = userApi.FirstName;
                        editUser.LastName = userApi.LastName;
                        editUser.Email = userApi.Email;
                        editUser.MobileNo = userApi.Mobile;
                        editUser.RoleId = (from role in dbEntity.Roles
                                           where role.RoleLevel == userApi.RoleLevel
                                           select role.ID).FirstOrDefault();
                        editUser.IsEmailAlert = userApi.EmailAlert;
                        editUser.IsMobileAlert = userApi.TextAlert;
                        //editUser.IsFirstLogin = true; Fix for Updates Defect....
                        editUser.LastUpdatedBy = userApi.UpdatedBy;
                        editUser.LastUpdatedOn = DateTime.UtcNow;
                        //Delete all the entries related to the User from UserProperty table  
                        //if (userApi.RoleLevel == 10)
                        //{
                        dbEntity.UserProperties.RemoveRange((from userProp in dbEntity.UserProperties
                                                             where userProp.UserId == userApi.UserId
                                                             select userProp).ToList());
                        //Add the entries
                        if (userApi.Properties != null && userApi.RoleLevel == (int)Enums.RoleLevelType.PropertyAdmin)
                        {
                            userApi.Properties.ForEach(o => dbEntity.UserProperties.Add(new UserProperty
                            {
                                PropertyId = o.ID,
                                UserId = userApi.UserId,
                                CreatedBy = userApi.UpdatedBy,
                                CreatedOn = DateTime.UtcNow
                            }));
                        }
                        //}

                        //if (userApi.RoleLevel == 20)
                        //{
                        dbEntity.UserBuildings.RemoveRange((from userbuild in dbEntity.UserBuildings
                                                            where userbuild.UserId == userApi.UserId
                                                            select userbuild).ToList());
                        //Add the entries
                        if (userApi.Buildings != null && userApi.RoleLevel == (int)Enums.RoleLevelType.BuildingAdmin)
                        {
                            userApi.Buildings.ForEach(o => dbEntity.UserBuildings.Add(new UserBuilding
                            {
                                BuildingId = o.ID,
                                UserId = userApi.UserId,
                                CreatedBy = userApi.UpdatedBy,
                                CreatedOn = DateTime.UtcNow
                            }));
                        }
                        //}
                        //Add for UserApi.RoleLevel == 40

                        if (userApi.Buildings != null && userApi.RoleLevel == (int)Enums.RoleLevelType.Cleaner)
                        {
                            userApi.Buildings.ForEach(o => dbEntity.UserBuildings.Add(new UserBuilding
                            {
                                BuildingId = o.ID,
                                UserId = userApi.UserId,
                                CreatedBy = userApi.UpdatedBy,
                                CreatedOn = DateTime.UtcNow
                            }));

                        }

                        dbEntity.SaveChanges();
                        response.Status = ResponseStatus.Success;
                    }
                    else
                    {
                        response.Status = ResponseStatus.Failed;
                        response.Message = "Unable to Find User Information to perform updation..";
                    }
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.Error;
                response.Message = ex.Message;
            }
            return response;
        }

        public ProcessResponse<BusinessEntity.TenantApiEntities.User> DeleteUser(BusinessEntity.TenantApiEntities.User User)
        {
            ProcessResponse<BusinessEntity.TenantApiEntities.User> response = new ProcessResponse<BusinessEntity.TenantApiEntities.User>() { Status = ResponseStatus.Failed };
            try
            {
                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    User delUser = (from user in dbEntity.Users
                                    where user.ID == User.UserId
                                    select user).FirstOrDefault();
                    Guard.IsNotNull(delUser, "User To Be Deleted");
                    delUser.IsDelete = true;
                    delUser.LastUpdatedBy = User.UpdatedBy;
                    delUser.LastUpdatedOn = DateTime.UtcNow;
                    dbEntity.SaveChanges();
                    response.Status = ResponseStatus.Success;
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.Failed;
                response.Message = ex.Message;
            }
            return response;
        }

        public ProcessResponseForGateway SaveAccountInfo(string accountInfo)
        {
            throw new NotImplementedException();
        }

        public string GetUserContactInfo(string UserName)
        {
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                User userContact = (from user in dbEntity.Users
                                    where user.Email.ToUpper() == UserName.ToUpper() && user.IsDelete == false
                                    select user).FirstOrDefault();
                Guard.IsNotNull(userContact, "User contact");
                return userContact.MobileNo;
            }
        }
    }
}

