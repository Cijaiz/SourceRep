﻿using KC.SmartWashroom.BusinessEntities.DashboardApiEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.Enumerations;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.DataAccess.Skeleton;
using System;
using System.Collections.Generic;
using System.Linq;
using BusinessEntity = KC.SmartWashroom.BusinessEntities;

namespace KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers
{
    public class BuildingWorker : IBuildingWorker
    {

        public int GetCustomerId(int buildingId)
        {
            int customerId = 0;
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                customerId = (from property in dbEntity.Properties
                              join building in dbEntity.Buildings on property.ID equals building.PropertyId
                              where building.ID == buildingId
                              select property.CustomerId).FirstOrDefault();
            }
            return customerId;
        }

        public BuildingEntity GetBuildingDetailsByPropertyId(int propertyID)
        {
            BuildingEntity buildingEntity = new BuildingEntity();

            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                var buildings = dbEntity.Set<Building>().ToList();

                buildingEntity.buildings = buildings.Where(building => building.PropertyId.Equals(propertyID) && building.IsActive.Equals(true)).Select(x => new KC.SmartWashroom.BusinessEntities.Building { ID = x.ID, Name = x.Name, PropertyId = x.PropertyId , ImageUrl =x.ImageUrl}).ToList();


                var dbProperty = dbEntity.Set<Property>().Where(property => property.ID.Equals(propertyID)).Single();

                buildingEntity.PropertyName = dbProperty.PropertyName;
                buildingEntity.ImageUrl = dbProperty.ImageUrl;
                buildingEntity.CustomerName = dbProperty.Customer.Name;

                //dbEntity.SaveChanges();
            }

            return buildingEntity;

        }

        public List<BusinessEntities.Floor> GetFloorsByBuildingId(int buildingId)
        {
            List<BusinessEntities.Floor> floors = new List<BusinessEntities.Floor>();

            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                floors = dbEntity.Set<Floor>().Where(floor => floor.BuildingId.Equals(buildingId) && floor.IsActive.Equals(true)).ToList().
                        Select(x => new KC.SmartWashroom.BusinessEntities.Floor { ID = x.ID, FloorLevel = x.FloorLevel, BuildingId = x.BuildingId }).ToList().OrderByDescending(x => x.FloorLevel).ToList();
                foreach (var item in floors)
                {
                    var alerts = (from alertTypes in dbEntity.AlertTypes
                                  join deviceAlert in dbEntity.DeviceAlerts on alertTypes.ID equals deviceAlert.AlertTypeId
                                  join deviceWashroom in dbEntity.DeviceWashrooms on deviceAlert.DeviceId equals deviceWashroom.DeviceId
                                  join device in dbEntity.Devices on deviceAlert.DeviceId equals device.ID
                                  join washroom in dbEntity.Washrooms on deviceWashroom.WashroomId equals washroom.ID
                                  join wing in dbEntity.Wings on washroom.WingId equals wing.ID
                                  join gender in dbEntity.Genders on washroom.GenderId equals gender.ID
                                  join floor in dbEntity.Floors on washroom.FloorId equals floor.ID
                                  where washroom.FloorId.Equals(item.ID) && floor.IsActive == true && device.IsActive.Equals(true)
                                  && washroom.IsActive.Equals(true) && deviceWashroom.IsActive==true
                                  select new KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert
                                  {
                                      AlertTypeId = alertTypes.ID,
                                      AlertType = alertTypes.Type,
                                      DateTime = deviceAlert.ReceivedOn,
                                      Gender = gender.Name,
                                      FloorLevel = floor.FloorLevel,
                                      FloorID = floor.ID,
                                      DeviceId = deviceAlert.DeviceId,
                                      DeviceName = device.Name,
                                      Wing = wing.Name,
                                      WashroomName = washroom.Name,
                                      WashroomId = washroom.ID,

                                  }).ToList();
                    item.Alerts = alerts;
                    // var groupedResult = alerts.GroupBy(x => new { x.AlertTypeId, x.AlertType });
                    // item.Alerts = groupedResult;
                }



            }

            return floors;

        }



        public ProcessResponse<BusinessEntity.Building> CreateBuilding(BusinessEntity.Building building)
        {
            ProcessResponse<BusinessEntity.Building> response = new ProcessResponse<BusinessEntity.Building>() { Status = ResponseStatus.Failed };
            try
            {
                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    Building buildingEntity = new Building();
                    buildingEntity.PropertyId = building.PropertyId;
                    buildingEntity.Name = building.Name;
                    buildingEntity.IsActive = building.IsActive;
                    buildingEntity.CreatedBy = building.CreatedBy;
                    buildingEntity.CreatedOn = DateTime.UtcNow;

                    if (building.ImageUrl != null)
                        buildingEntity.ImageUrl = building.ImageUrl;
                    else
                        buildingEntity.ImageUrl = string.Empty;

                    dbEntity.Buildings.Add(buildingEntity);
                    dbEntity.SaveChanges();
                    response.Status = ResponseStatus.Success;
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.Failed;
                response.Message = ex.Message;
            }
            return response;
        }

        public ProcessResponse<BusinessEntity.Building> UpdateBuilding(BusinessEntity.Building buildingEntity)
        {
            ProcessResponse<BusinessEntity.Building> response = new ProcessResponse<BusinessEntity.Building>() { Status = ResponseStatus.Failed };
            try
            {
                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    Building editBuilding = null;
                    editBuilding = (from building in dbEntity.Buildings where building.ID == buildingEntity.ID select building).FirstOrDefault();
                    Guard.IsNotNull(editBuilding, "Building To Be Updated");
                    editBuilding.Name = buildingEntity.Name;
                    editBuilding.LastUpdatedBy = buildingEntity.LastUpdatedBy != 0 ? buildingEntity.LastUpdatedBy : null;
                    editBuilding.LastUpdatedOn = DateTime.UtcNow;

                    if (buildingEntity.ImageUrl != null)
                        editBuilding.ImageUrl = buildingEntity.ImageUrl;

                    dbEntity.SaveChanges();
                    response.Status = ResponseStatus.Success;
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.Failed;
                response.Message = ex.Message;
            }
            return response;
        }

        public ProcessResponse<BusinessEntity.Building> DeleteBuilding(BusinessEntity.Building building)
        {
            ProcessResponse<BusinessEntity.Building> response = new ProcessResponse<BusinessEntity.Building>() { Status = ResponseStatus.Failed };
            try
            {
                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    Building delBuilding = null;
                    delBuilding = (from buildingEntity in dbEntity.Buildings where buildingEntity.ID == building.ID select buildingEntity).FirstOrDefault();
                    Guard.IsNotNull(delBuilding, "Building To Be Deleted");
                    delBuilding.IsActive = false;
                    delBuilding.LastUpdatedBy = building.LastUpdatedBy != 0 ? building.LastUpdatedBy : null;
                    delBuilding.LastUpdatedOn = DateTime.UtcNow;
                    dbEntity.SaveChanges();
                    response.Status = ResponseStatus.Success;
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.Failed;
                response.Message = ex.Message;
            }
            return response;
        }

        /// <summary>
        /// TO DO - Need to include joining with Floor table
        /// </summary>
        /// <param name="buildingId"></param>
        /// <returns></returns>
        public BusinessEntity.Building GetBuildingDetails(int buildingId)
        {
            BusinessEntity.Building building;
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                building = (from buildingEntity in dbEntity.Buildings
                            //join floor in dbEntity.Floors on buildingEntity.ID equals floor.BuildingId into buildingFloor
                            //from bf in buildingFloor.DefaultIfEmpty()
                            where buildingEntity.ID == buildingId && buildingEntity.IsActive == true
                            select new BusinessEntity.Building
                            {
                                ID = buildingEntity.ID,
                                Name = buildingEntity.Name,
                                PropertyId = buildingEntity.PropertyId,
                                PropertyName = buildingEntity.Property.PropertyName,
                                CustomerId = buildingEntity.Property.CustomerId,
                                CreatedBy = buildingEntity.CreatedBy,
                                IsActive = buildingEntity.IsActive,
                                ImageUrl =buildingEntity.ImageUrl,
                                floors = buildingEntity.Floors.OrderBy(o => o.FloorLevel).Select(o => new BusinessEntity.Floor
                                {
                                    ID = o.ID,
                                    FloorLevel = o.FloorLevel,
                                    BuildingId = o.BuildingId,
                                    IsActive = o.IsActive,
                                    CreatedBy = o.CreatedBy,
                                    CreatedOn = o.CreatedOn
                                }).Where(o => o.IsActive).ToList<BusinessEntity.Floor>()
                            }).FirstOrDefault();
            }
            return building;
        }
        public List<KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert> GetAlertDetailsByAlertGroup(string alertGroupName, int floorId, byte genderId)
        {
            List<KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert> response = new List<KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert>();
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {

                var alerts = (from alertTypes in dbEntity.AlertTypes
                              join deviceAlert in dbEntity.DeviceAlerts on alertTypes.ID equals deviceAlert.AlertTypeId
                              join deviceWashroom in dbEntity.DeviceWashrooms on deviceAlert.DeviceId equals deviceWashroom.DeviceId
                              join device in dbEntity.Devices on deviceAlert.DeviceId equals device.ID
                              join deviceAlertMapping in dbEntity.DeviceAlertMappings on new { device.DeviceTypeId, deviceAlert.AlertTypeId } equals new { deviceAlertMapping.DeviceTypeId, deviceAlertMapping.AlertTypeId }
                              join deviceAlertGroup in dbEntity.DeviceAlertNames on deviceAlertMapping.AlertNameId equals deviceAlertGroup.ID
                              join washroom in dbEntity.Washrooms on deviceWashroom.WashroomId equals washroom.ID
                              join wing in dbEntity.Wings on washroom.WingId equals wing.ID
                              join gender in dbEntity.Genders on washroom.GenderId equals gender.ID
                              join floor in dbEntity.Floors on washroom.FloorId equals floor.ID
                              join building in dbEntity.Buildings on floor.BuildingId equals building.ID
                              join property in dbEntity.Properties on building.PropertyId equals property.ID
                              where washroom.FloorId.Equals(floorId) && deviceAlertGroup.AlertName.Equals(alertGroupName, StringComparison.OrdinalIgnoreCase) 
                              && floor.IsActive == true && (genderId == 0 || gender.ID == genderId) && device.IsActive.Equals(true) && washroom.IsActive.Equals(true)
                              && deviceWashroom.IsActive == true
                              select new KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert
                              {
                                  AlertTypeId = alertTypes.ID,
                                  AlertType = alertTypes.Type,
                                  AlertTypeName = deviceAlertGroup.AlertName,
                                  DateTime = deviceAlert.ReceivedOn,
                                  Gender = gender.Name,
                                  FloorLevel = floor.FloorLevel,
                                  FloorID = floor.ID,
                                  DeviceId = deviceAlert.DeviceId,
                                  DeviceName = device.Name,
                                  Wing = wing.Name,
                                  WashroomName = washroom.Name,
                                  WashroomId = washroom.ID,
                                  LocalTimeZone = property.LocationTimeZone

                              }).OrderBy(item =>  item.DateTime) .ToList();

                response = alerts;
            }

            return response;

        }
        public List<KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert> GetAlertDetailsByAlertType(byte alertTypeId, int floorId, byte genderId)
        {
            List<KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert> response = new List<KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert>();
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {

                var alerts = (from alertTypes in dbEntity.AlertTypes
                              join deviceAlert in dbEntity.DeviceAlerts on alertTypes.ID equals deviceAlert.AlertTypeId
                              join deviceWashroom in dbEntity.DeviceWashrooms on deviceAlert.DeviceId equals deviceWashroom.DeviceId
                              join device in dbEntity.Devices on deviceAlert.DeviceId equals device.ID
                              join washroom in dbEntity.Washrooms on deviceWashroom.WashroomId equals washroom.ID
                              join wing in dbEntity.Wings on washroom.WingId equals wing.ID
                              join gender in dbEntity.Genders on washroom.GenderId equals gender.ID
                              join floor in dbEntity.Floors on washroom.FloorId equals floor.ID
                              join building in dbEntity.Buildings on floor.BuildingId equals building.ID
                              join property in dbEntity.Properties on building.PropertyId equals property.ID
                              where washroom.FloorId.Equals(floorId) && alertTypes.ID.Equals(alertTypeId) && floor.IsActive == true && (genderId == 0 || gender.ID == genderId) && device.IsActive.Equals(true) && washroom.IsActive.Equals(true) && deviceWashroom.IsActive==true
                              select new KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert
                              {
                                  AlertTypeId = alertTypes.ID,
                                  AlertType = alertTypes.Type,
                                  DateTime = deviceAlert.ReceivedOn,
                                  Gender = gender.Name,
                                  FloorLevel = floor.FloorLevel,
                                  FloorID = floor.ID,
                                  DeviceId = deviceAlert.DeviceId,
                                  DeviceName = device.Name,
                                  Wing = wing.Name,
                                  WashroomName = washroom.Name,
                                  WashroomId = washroom.ID,
                                  LocalTimeZone = property.LocationTimeZone

                              }).ToList();
                
                response = alerts;
            }

            return response;

        }

        public List<BusinessEntity.Floor> GetFloors(int buildingId)
        {
            List<BusinessEntity.Floor> floors = new List<BusinessEntity.Floor>();
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                floors = (from floor in dbEntity.Floors
                          where floor.BuildingId == buildingId && floor.IsActive == true
                          select new BusinessEntity.Floor
                          {
                              ID = floor.ID,
                              FloorLevel = floor.FloorLevel,
                              BuildingId = floor.BuildingId,
                              IsActive = floor.IsActive,
                              CreatedBy = floor.CreatedBy,
                              CreatedOn = floor.CreatedOn
                          }).ToList();
            }
            return floors;

        }

        public Names GetNames(int propertyId)
        {
            Names name = new Names();
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                name = (from dbproperty in dbEntity.Properties
                        join dbcustomer in dbEntity.Customers on dbproperty.CustomerId equals dbcustomer.ID
                        where dbproperty.ID == propertyId
                        select new BusinessEntities.TenantApiEntities.Names
                        {
                            PropertyName = dbproperty.PropertyName,
                            PropertyId = dbproperty.ID,
                            CustomerName = dbcustomer.Name,
                            CustomerId = dbcustomer.ID
                        }

                           ).ToList<BusinessEntities.TenantApiEntities.Names>().FirstOrDefault();
            }
            return name;
        }

        public KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert GetDeviceDetails(string deviceID)
        {
            KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert response = new KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert();
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                var deviceDetail = (from device in dbEntity.Devices
                                    join deviceWashroom in dbEntity.DeviceWashrooms on device.ID equals deviceWashroom.DeviceId
                                    join washroom in dbEntity.Washrooms on deviceWashroom.WashroomId equals washroom.ID
                                    join wing in dbEntity.Wings on washroom.WingId equals wing.ID
                                    join gender in dbEntity.Genders on washroom.GenderId equals gender.ID
                                    join floor in dbEntity.Floors on washroom.FloorId equals floor.ID
                                    where floor.IsActive == true && device.ID.Equals(deviceID) && washroom.IsActive.Equals(true) && deviceWashroom.IsActive==true
                                    select new KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert
                                    {
                                        Gender = gender.Name,
                                        FloorLevel = floor.FloorLevel,
                                        FloorID = floor.ID,
                                        DeviceName = device.Name,
                                        Wing = wing.Name

                                    }).First();
                response = deviceDetail;
            }

            return response;

        }

        public List<BusinessEntity.Building> GetAllBuildings(int customerId,int userId, int roleLevel)
        {
            List<BusinessEntity.Building> Buildings = new List<BusinessEntity.Building>();
            //Property Admin
            if (roleLevel == (int)Enums.RoleLevelType.PropertyAdmin)
            {
                using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                {
                    Buildings = (from user in dbContext.Users
                                 join customer in dbContext.Customers on user.CustomerId equals customer.ID
                                 join prop in dbContext.Properties on customer.ID equals prop.CustomerId
                                 join userProp in dbContext.UserProperties on prop.ID equals userProp.PropertyId
                                 where user.ID == userId && userProp.UserId == userId
                                 join building in dbContext.Buildings on prop.ID equals building.PropertyId
                                 where customer.ID == customerId && customer.IsActive == true && prop.IsActive == true && building.IsActive == true
                                 select new BusinessEntity.Building
                                 {
                                     ID = building.ID,
                                     Name = building.Name,
                                     PropertyId = building.PropertyId,
                                     PropertyName = building.Property.PropertyName,
                                     CustomerId = building.Property.CustomerId,
                                     CreatedBy = building.CreatedBy,
                                     IsActive = building.IsActive,
                                     ImageUrl= building.ImageUrl
                                 }).ToList();
                }
            }
            else if (roleLevel == (int)Enums.RoleLevelType.BuildingAdmin)
            {
                using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                {
                    Buildings = (from user in dbContext.Users
                                 join customer in dbContext.Customers on user.CustomerId equals customer.ID
                                 join prop in dbContext.Properties on customer.ID equals prop.CustomerId
                                 join building in dbContext.Buildings on prop.ID equals building.PropertyId
                                 join userBuilding in dbContext.UserBuildings on building.ID equals userBuilding.BuildingId
                                 where user.ID == userId && userBuilding.UserId == userId
                                 && customer.ID == customerId && customer.IsActive == true && prop.IsActive == true && building.IsActive == true
                                 select new BusinessEntity.Building
                                 {
                                     ID = building.ID,
                                     Name = building.Name,
                                     PropertyId = building.PropertyId,
                                     PropertyName = building.Property.PropertyName,
                                     CustomerId = building.Property.CustomerId,
                                     CreatedBy = building.CreatedBy,
                                     IsActive = building.IsActive,
                                     ImageUrl = building.ImageUrl
                                 }).ToList();
                }
            }
            else
            {
                using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                {
                    Buildings = (from building in dbContext.Buildings
                                 join prop in dbContext.Properties on building.PropertyId equals prop.ID
                                 join cust in dbContext.Customers on prop.CustomerId equals cust.ID
                                 where cust.ID == customerId && cust.IsActive == true && prop.IsActive == true && building.IsActive == true
                                 select new BusinessEntity.Building
                                 {
                                     ID = building.ID,
                                     Name = building.Name,
                                     PropertyId = building.PropertyId,
                                     PropertyName = building.Property.PropertyName,
                                     CustomerId = building.Property.CustomerId,
                                     CreatedBy = building.CreatedBy,
                                     IsActive = building.IsActive,
                                     ImageUrl = building.ImageUrl
                                 }).ToList();
                }
            }
            return Buildings;
        }
    }

}
