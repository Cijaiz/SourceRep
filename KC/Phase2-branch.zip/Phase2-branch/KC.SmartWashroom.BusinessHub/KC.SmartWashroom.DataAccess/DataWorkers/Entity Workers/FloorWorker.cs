﻿using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.DataAccess.Skeleton;
using System;
using System.Collections.Generic;
using BusinessEntity = KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using System.Linq;

namespace KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers
{
    public class FloorWorker : IFloorWorker
    {
        /// <summary>
        /// TO DO - Need to check if Floor level is already present in the Building
        /// </summary>
        /// <param name="floors"></param>
        /// <returns></returns>
        public ProcessResponse<BusinessEntity.Floor> CreateFloorRange(List<BusinessEntity.Floor> floors)
        {
            ProcessResponse<BusinessEntity.Floor> response = new ProcessResponse<BusinessEntity.Floor>() { Status = ResponseStatus.Failed };
            try
            {
                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    int count = 0;
                    foreach (BusinessEntity.Floor floor in floors)
                    {
                        var floorexists = (from dbfloor in dbEntity.Floors
                                           where dbfloor.FloorLevel == floor.FloorLevel && dbfloor.BuildingId == floor.BuildingId && dbfloor.IsActive == true
                                           select dbfloor);

                        if (floorexists != null && floorexists.Count() != 0)
                        {
                            count++;
                            response.Status = ResponseStatus.Failed;
                            response.Message = "Floor already exists.";
                            break;
                        }

                    }
                    if (count == 0)
                    {
                        foreach (BusinessEntity.Floor floor in floors)
                        {
                            Floor flr = new Floor();
                            flr.BuildingId = floor.BuildingId;
                            flr.FloorLevel = floor.FloorLevel;
                            flr.IsActive = floor.IsActive;
                            flr.CreatedBy = floor.CreatedBy;
                            flr.CreatedOn = DateTime.UtcNow;
                            dbEntity.Floors.Add(flr);
                        }
                        dbEntity.SaveChanges();
                        response.Status = ResponseStatus.Success;
                    }
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.Error;
                response.Message = ex.Message;
            }
            return response;
        }

        public BusinessEntity.Floor GetFloorDetails(Int32 floorId)
        {
            BusinessEntity.Floor flr;
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                flr = (from floor in dbEntity.Floors
                       where floor.ID == floorId && floor.IsActive == true
                       select new BusinessEntity.Floor
                       {
                           ID = floor.ID,
                           BuildingId = floor.BuildingId,
                           BuildingName = floor.Building.Name,
                           FloorLevel = floor.FloorLevel,
                           IsActive = floor.IsActive,
                           CreatedBy = floor.CreatedBy,
                           Washrooms = (from washroom in floor.Washrooms
                                        join gender in dbEntity.Genders on washroom.GenderId equals gender.ID
                                        join wing in dbEntity.Wings on washroom.WingId equals wing.ID
                                        where washroom.IsActive == true
                                        select new BusinessEntity.Washroom
                                        {
                                            ID = washroom.ID,
                                            Name = washroom.Name,
                                            FloorId = washroom.FloorId,
                                            GenderId = washroom.GenderId,
                                            WingId = washroom.WingId,
                                            Gender = gender.Name,
                                            Wing = wing.Name,
                                            KCIdentifier = washroom.KCIdentifier,
                                            IsActive = washroom.IsActive,
                                            CreatedBy = washroom.CreatedBy,
                                            CreatedOn = washroom.CreatedOn,
                                            LastUpdatedBy = washroom.LastUpdatedBy,
                                            LastUpdatedOn = washroom.LastUpdatedOn
                                        }
                                            ).ToList<BusinessEntity.Washroom>()
                       }).FirstOrDefault();
            }
            return flr;
        }

        public ProcessResponse<BusinessEntity.Floor> Delete(Int32 floorId, int? userId)
        {
            ProcessResponse<BusinessEntity.Floor> response = new ProcessResponse<BusinessEntity.Floor>() { Status = ResponseStatus.Failed };
            try
            {
                using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                {
                    Floor floor = (from flr in dbContext.Floors
                                   where flr.ID == floorId
                                   select flr).FirstOrDefault();
                    Guard.IsNotNull(floor, "Floor To Be Deleted");
                    floor.IsActive = false;
                    floor.LastUpdatedBy = userId != 0 ? userId : null;
                    floor.LastUpdatedOn = DateTime.UtcNow;
                    dbContext.SaveChanges();
                    response.Status = ResponseStatus.Success;

                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.Failed;
                response.Message = ex.Message;
            }
            return response;
        }

        public ProcessResponse<BusinessEntity.Floor> Update(BusinessEntity.Floor floor)
        {
            ProcessResponse<BusinessEntity.Floor> response = new ProcessResponse<BusinessEntity.Floor>() { Status = ResponseStatus.Failed };
            try
            {
                using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
                {
                    Floor editFloor = null;
                    editFloor = (from flr in dbEntity.Floors
                                 where flr.ID == floor.ID
                                 select flr).FirstOrDefault();
                    Guard.IsNotNull(editFloor, "Floor To Be Updated");
                    var floorexists = (from dbfloor in dbEntity.Floors
                                       where dbfloor.FloorLevel == floor.FloorLevel && dbfloor.BuildingId == floor.BuildingId && dbfloor.IsActive != false
                                       select dbfloor);
                    if (floorexists == null || floorexists.Count() == 0)
                    {
                        editFloor.FloorLevel = floor.FloorLevel;
                        editFloor.LastUpdatedBy = floor.LastUpdatedBy;
                        editFloor.LastUpdatedOn = DateTime.UtcNow;
                        dbEntity.SaveChanges();
                        response.Status = ResponseStatus.Success;
                    }
                    else
                    {
                        response.Status = ResponseStatus.Failed;
                        response.Message = "Floor already exists for the building";
                    }
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.Error;
                response.Message = ex.Message;
            }
            return response;
        }

        public BusinessEntity.Floor GetFloorAlerts(Int32 floorId, Int32 buildingId, byte genderId, Int32 washroomId)
        {
            BusinessEntity.Floor floor = new BusinessEntity.Floor();
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {

                floor = dbEntity.Set<Floor>().Where(fl => fl.BuildingId.Equals(buildingId) && fl.ID.Equals(floorId) && fl.IsActive.Equals(true)).
                        Select(x => new KC.SmartWashroom.BusinessEntities.Floor
                        {
                            ID = x.ID,
                            FloorLevel = x.FloorLevel,
                            BuildingId = x.BuildingId,
                            IsActive = x.IsActive
                        }).SingleOrDefault();

                var alerts = (from alertTypes in dbEntity.AlertTypes
                              join deviceAlert in dbEntity.DeviceAlerts on alertTypes.ID equals deviceAlert.AlertTypeId
                              join deviceWashroom in dbEntity.DeviceWashrooms on deviceAlert.DeviceId equals deviceWashroom.DeviceId
                              join device in dbEntity.Devices on deviceAlert.DeviceId equals device.ID
                              join washroom in dbEntity.Washrooms on deviceWashroom.WashroomId equals washroom.ID
                              join wing in dbEntity.Wings on washroom.WingId equals wing.ID
                              join gender in dbEntity.Genders on washroom.GenderId equals gender.ID
                              join dbfloor in dbEntity.Floors on washroom.FloorId equals dbfloor.ID
                              join building in dbEntity.Buildings on dbfloor.BuildingId equals building.ID
                              join property in dbEntity.Properties on building.PropertyId equals property.ID
                              where washroom.FloorId.Equals(floor.ID) && floor.IsActive == true && (genderId == 0 || gender.ID == genderId) && (washroomId == 0 || washroom.ID == washroomId) && device.IsActive.Equals(true) && washroom.IsActive.Equals(true) && deviceWashroom.IsActive == true
                              select new KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert
                              {
                                  AlertTypeId = alertTypes.ID,
                                  AlertType = alertTypes.Type,
                                  DateTime = deviceAlert.ReceivedOn,
                                  Gender = gender.Name,
                                  FloorLevel = floor.FloorLevel,
                                  FloorID = floor.ID,
                                  DeviceId = deviceAlert.DeviceId,
                                  DeviceName = device.Name,
                                  Wing = wing.Name,
                                  WashroomName = washroom.Name,
                                  WashroomId = washroom.ID,
                                  LocalTimeZone = property.LocationTimeZone

                              } into alertResult
                              group alertResult by new
                                   {
                                       alertResult.Gender,
                                       alertResult.WashroomName,
                                       alertResult.WashroomId,
                                       alertResult.AlertTypeId,
                                       alertResult.AlertType,
                                       alertResult.DateTime,
                                       alertResult.FloorLevel,
                                       alertResult.FloorID,
                                       alertResult.DeviceId,
                                       alertResult.DeviceName,
                                       alertResult.Wing,
                                       alertResult.LocalTimeZone
                                   } into groupedAlerts
                              select new KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert
                              {
                                  AlertTypeId = groupedAlerts.Key.AlertTypeId,
                                  AlertType = groupedAlerts.Key.AlertType,
                                  DateTime = groupedAlerts.Key.DateTime,
                                  Gender = groupedAlerts.Key.Gender,
                                  FloorLevel = groupedAlerts.Key.FloorLevel,
                                  FloorID = groupedAlerts.Key.FloorID,
                                  DeviceId = groupedAlerts.Key.DeviceId,
                                  DeviceName = groupedAlerts.Key.DeviceName,
                                  Wing = groupedAlerts.Key.Wing,
                                  WashroomName = groupedAlerts.Key.WashroomName,
                                  WashroomId = groupedAlerts.Key.WashroomId,
                                  LocalTimeZone = groupedAlerts.Key.LocalTimeZone
                              }).ToList();


                floor.Alerts = alerts;
                floor.BuildingName = dbEntity.Set<Building>().Where(building => building.ID.Equals(buildingId)).Single().Name;
                var propertyID = dbEntity.Set<Building>().Where(building => building.ID.Equals(buildingId)).Single().PropertyId;
                floor.PropertyName = dbEntity.Set<Property>().Where(property => property.ID.Equals(propertyID)).Single().PropertyName;
                floor.CustomerName = dbEntity.Set<Property>().Where(property => property.ID.Equals(propertyID)).Single().Customer.Name;
            }

            return floor;
        }

        public Names GetNames(Int32 buildingId)
        {
            Names name = new Names();
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                name = (from dbbuilding in dbEntity.Buildings
                        join dbproperty in dbEntity.Properties on dbbuilding.PropertyId equals dbproperty.ID
                        join dbcustomer in dbEntity.Customers on dbproperty.CustomerId equals dbcustomer.ID
                        where dbbuilding.ID == buildingId && dbbuilding.IsActive.Equals(true)
                        select new BusinessEntities.TenantApiEntities.Names
                        {
                            BuildingName = dbbuilding.Name,
                            PropertyName = dbproperty.PropertyName,
                            PropertyId = dbproperty.ID,
                            CustomerName = dbcustomer.Name,
                            CustomerId = dbcustomer.ID
                        }

                           ).ToList<BusinessEntities.TenantApiEntities.Names>().FirstOrDefault();
            }
            return name;

        }
    }
}
