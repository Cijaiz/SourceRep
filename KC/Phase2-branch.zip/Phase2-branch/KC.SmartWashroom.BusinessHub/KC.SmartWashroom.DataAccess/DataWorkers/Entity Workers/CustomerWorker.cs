﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.DataAccess.Skeleton;
using System;
using System.Collections.Generic;
using System.Linq;

namespace KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers
{
    public class CustomerWorker : ICustomerWorker
    {
        private string _errorDetail;
        byte countryId;
        byte defaultbyte = 0;

        string ICustomerWorker.ErrorDetail
        {
            get { return _errorDetail; }
            set { _errorDetail = value; }
        }

        public ProcessResponse CreateCustomer(string customerName, string Street, string buildingAddress, string City, string State, string Country, string Zip, int createdBy, DateTime createdOn)
        {
            ProcessResponse response = new ProcessResponse();
            try
            {

                int addressId;
                using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                {

                    Address dbAddress = new Address();
                    Customer dbCustomer = new Customer();
                    countryId = byte.TryParse(Country, out defaultbyte) ? defaultbyte : defaultbyte;

                    dbAddress.City = City;
                    dbAddress.CountryId = countryId;
                    dbAddress.State = State;

                    dbAddress.Street = Street;
                    dbAddress.BuildingAddress = buildingAddress;
                    dbAddress.Zip = Zip;

                    dbContext.Addresses.Add(dbAddress);
                    dbContext.SaveChanges();
                    addressId = dbAddress.ID;

                    dbCustomer.Name = customerName;
                    dbCustomer.AddressId = addressId;
                    dbCustomer.IsActive = true;

                    dbCustomer.CreatedBy = createdBy;
                    dbCustomer.CreatedOn = createdOn;
                    dbCustomer.LastUpdatedBy = createdBy;
                    dbCustomer.LastUpdatedOn = createdOn;

                    dbContext.Customers.Add(dbCustomer);
                    dbContext.SaveChanges();

                    response.Status = ResponseStatus.Success;
                    response.RefId = dbCustomer.ID;
                    response.Message = AlertEngineConstants.MESSAGE_SUCCESS;
                }

            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.Error;
                response.Message = ex.Message;
            }
            return response;
        }

        public List<CustomerDetail> GetAllCustomers()
        {
            List<CustomerDetail> customers = null;
            try
            {
                using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                {
                    customers = new List<CustomerDetail>();
                    customers = (from dbcustomer in dbContext.Customers
                                 join dbaddress in dbContext.Addresses on dbcustomer.AddressId equals dbaddress.ID
                                 join dbcountry in dbContext.Countries on dbaddress.CountryId equals dbcountry.ID
                                 where dbcustomer.IsActive != false
                                 orderby dbcustomer.Name
                                 select new BusinessEntities.TenantApiEntities.CustomerDetail
                                 {
                                     CustomerId = dbcustomer.ID,
                                     CustomerName = dbcustomer.Name,
                                     City = dbaddress.City,
                                     Country = dbcountry.Name
                                 }).ToList();
                    return customers;
                }
            }
            catch (Exception dataException)
            {
                _errorDetail = dataException.Message;
                return customers;
            }
        }

        public CustomerDetail GetCustomer(int customerId)
        {
            CustomerDetail customerDetail = null;
            try
            {
                using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                {
                    var customer = (from dbcustomer in dbContext.Customers
                                    join dbaddress in dbContext.Addresses on dbcustomer.AddressId equals dbaddress.ID
                                    join dbcountry in dbContext.Countries on dbaddress.CountryId equals dbcountry.ID
                                    where dbcustomer.ID.Equals(customerId) && dbcustomer.IsActive != false
                                    select new BusinessEntities.TenantApiEntities.CustomerDetail
                                    {
                                        CustomerId = dbcustomer.ID,
                                        CustomerName = dbcustomer.Name,
                                        Street = dbaddress.Street,
                                        BuildingAddress = dbaddress.BuildingAddress,
                                        City = dbaddress.City,
                                        State = dbaddress.State,
                                        Country = dbcountry.Name,
                                        CountryId = dbcountry.ID,
                                        Pincode = dbaddress.Zip
                                    });
                    var properties = (from dbproperties in dbContext.Properties
                                      join dbcustomer in dbContext.Customers on dbproperties.CustomerId equals dbcustomer.ID
                                      join dbaddress in dbContext.Addresses on dbproperties.AddressId equals dbaddress.ID
                                      join dbcountry in dbContext.Countries on dbaddress.CountryId equals dbcountry.ID
                                      where dbproperties.CustomerId.Equals(customerId) && dbproperties.IsActive == true
                                      select new BusinessEntities.Property
                                      {
                                          ID = dbproperties.ID,
                                          PropertyName = dbproperties.PropertyName,
                                          City = dbaddress.City,
                                          Country = dbcountry.Name,

                                      }
                                         ).ToList();
                    var users = (from dbusers in dbContext.Users
                                 join dbcustomer in dbContext.Customers on dbusers.CustomerId equals dbcustomer.ID
                                 join dbrole in dbContext.Roles on dbusers.RoleId equals dbrole.ID
                                 where dbusers.CustomerId == customerId && dbusers.IsDelete == false
                                 select new BusinessEntities.TenantApiEntities.User
                                 {
                                     UserId = dbusers.ID,
                                     FirstName = dbusers.FirstName,
                                     Email = dbusers.Email,
                                     Mobile = dbusers.MobileNo,
                                     Role = dbrole.Name,
                                     RoleLevel = dbrole.RoleLevel
                                 }
                                   ).ToList();

                    if (customer != null)
                    {
                        customerDetail = customer.FirstOrDefault();
                        if (properties != null)
                            customerDetail.Properties = properties;
                        if (users != null)
                            customerDetail.Users = users;
                    }
                    return customerDetail;
                }
            }
            catch (Exception dataException)
            {
                _errorDetail = dataException.Message;
                return customerDetail;
            }
        }

        public string GetCustomerName(int propertyId)
        {
            string Name = "";
            using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
            {
                //Name = (from dbcustomer in dbContext.Customers
                //        where dbcustomer.ID == customerId && dbcustomer.IsActive != false
                //        select dbcustomer.Name).FirstOrDefault();
                Name = (from dbproperty in dbContext.Properties
                        where dbproperty.ID == propertyId
                        select dbproperty.Customer.Name).FirstOrDefault();
            }
            return Name;

        }

        public ProcessResponse UpdateCustomer(CustomerDetail customerDetail)
        {
            ProcessResponse response = new ProcessResponse();

            try
            {
                int addressId = 0;
                using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                {
                    Address dbAddress = new Address();
                    Customer dbCustomer = new Customer();
                    countryId = byte.TryParse(customerDetail.Country, out defaultbyte) ? defaultbyte : defaultbyte;

                    var Customer = (from customer in dbContext.Customers
                                    where customer.ID.Equals(customerDetail.CustomerId)
                                    select customer
                                   ).FirstOrDefault();
                    if (Customer != null)
                    {
                        addressId = Customer.AddressId;

                        var Address = (from dbaddress in dbContext.Addresses
                                       where dbaddress.ID == addressId
                                       select dbaddress).FirstOrDefault();
                        if (Address != null)
                        {
                            Address.Street = customerDetail.Street;
                            Address.BuildingAddress = customerDetail.BuildingAddress;
                            Address.City = customerDetail.City;
                            Address.State = customerDetail.State;
                            Address.CountryId = countryId;
                            Address.Zip = customerDetail.Pincode;

                            dbContext.SaveChanges();
                        }
                        Customer.Name = customerDetail.CustomerName;
                        Customer.LastUpdatedBy = customerDetail.LastUpdatedBy;
                        Customer.LastUpdatedOn = customerDetail.LastUpdatedOn;
                        dbContext.SaveChanges();
                    }
                    response.Status = ResponseStatus.Success;
                    response.Message = AlertEngineConstants.MESSAGE_SUCCESS;
                    response.RefId = customerDetail.CustomerId;

                    return response;
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.Error;
                response.Message = ex.Message;
                return response;
            }
        }

        public ProcessResponse DeleteCustomer(int customerIdToDelete)
        {
            ProcessResponse response = new ProcessResponse();
            try
            {
                using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                {
                    var Customer = (from customers in dbContext.Customers
                                    where customers.ID == customerIdToDelete
                                    select customers
                                   ).FirstOrDefault();
                    if (Customer != null)
                    {
                        Customer.IsActive = false;
                        dbContext.SaveChanges();
                    }
                    response.Status = ResponseStatus.Success;
                    response.Message = AlertEngineConstants.MESSAGE_SUCCESS;
                    response.RefId = customerIdToDelete;

                    return response;
                }
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.Error;
                response.Message = ex.Message;
                return response;
            }

        }

        public List<Countries> GetAllCountries()
        {
            List<Countries> AllCountries = null;
            try
            {
                using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
                {
                    AllCountries = new List<Countries>();
                    AllCountries = (from countries in dbContext.Countries
                                    select new BusinessEntities.TenantApiEntities.Countries
                                    {
                                        CountryId = countries.ID,
                                        CountryName = countries.Name
                                    }).ToList();
                    return AllCountries;
                }
            }
            catch (Exception dataException)
            {
                _errorDetail = dataException.Message;
                return AllCountries;

            }
        }

        public Dictionary<DeviceTypes, List<ReturnValueParameter>> GetDeviceParameters(int customerId)
        {
            Dictionary<DeviceTypes, List<ReturnValueParameter>> AllParameters = new Dictionary<DeviceTypes, List<ReturnValueParameter>>();
            using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
            {
                List<DeviceParameterEntity> deviceTypeSpecificParameter = new List<DeviceParameterEntity>();
                List<DeviceTypes> deviceTypes = new List<DeviceTypes>();
                List<ReturnValueParameter> returnParams = null;
                List<DeviceParameterValueEntity> deviceParameterValue = new List<DeviceParameterValueEntity>();
                List<DeviceParameterEntity> deviceParameter = new List<DeviceParameterEntity>();
                List<DeviceParameterValueEntity> deviceValParamWithoutCustomerAndDeviceID = new List<DeviceParameterValueEntity>();

                deviceTypes = GetDeviceTypes(dbContext, deviceTypes);
                deviceParameterValue = GetDeviceParameterValue(dbContext, deviceParameterValue, customerId);
                deviceValParamWithoutCustomerAndDeviceID = GetDeviceParameterValue(dbContext, deviceValParamWithoutCustomerAndDeviceID);

                deviceParameter = GetDeviceParameters(dbContext, deviceParameter);

                foreach (DeviceTypes type in deviceTypes)
                {
                    returnParams = new List<BusinessEntities.ReturnValueParameter>();

                    deviceTypeSpecificParameter = GetDeviceSpecificParameters(type, deviceParameter, deviceTypeSpecificParameter);
                    //retrive all the values 
                    returnParams = GetListOfParameterValuesForTheDeviceTypes(deviceTypeSpecificParameter, deviceParameterValue,
                                                                             deviceValParamWithoutCustomerAndDeviceID, returnParams);

                    AllParameters.Add(type, returnParams);
                }
                return AllParameters;
            }
        }

        private List<DeviceTypes> GetDeviceTypes(SmartWashroomEntities dbContext, List<DeviceTypes> deviceTypes)
        {
            deviceTypes = (from type in dbContext.DeviceTypes
                           select new BusinessEntities.TenantApiEntities.DeviceTypes
                           {
                               DeviceId = type.ID,
                               DeviceName = type.Name
                           }).ToList();
            return deviceTypes;
        }

        private List<DeviceParameterEntity> GetDeviceParameters(SmartWashroomEntities dbContext, List<DeviceParameterEntity> deviceParameter)
        {
            var defaultByte = default(byte);
            var defaultInt = default(int);
            deviceParameter = (from deviceParam in dbContext.DeviceParameters
                               where deviceParam.IsActive.Equals(true) && deviceParam.IsReturnParameter.Equals(true)
                               select new DeviceParameterEntity
                               {
                                   DeviceParameterId = deviceParam.Id,
                                   Name = deviceParam.Name,
                                   Index = deviceParam.Index,

                                   FormatCode = deviceParam.FormatCode,
                                   IsReturnParameter = deviceParam.IsReturnParameter,
                                   IgnoreError = deviceParam.IgnoreError,

                                   IsAutoReset = deviceParam.IsAutoReset,
                                   IsActive = deviceParam.IsActive,
                                   DisplayName = deviceParam.DisplayName,

                                   Description = deviceParam.Description,
                                   DataTypeName = deviceParam.DataTypeName,
                                   FormatErrorMessage = deviceParam.FormatErrorMessage,

                                   CreatedTime = deviceParam.CreatedTime,
                                   ModifiedTime = deviceParam.ModifiedTime,
                                   DeviceTypeId = deviceParam.DeviceTypeId.HasValue ? deviceParam.DeviceTypeId.Value : defaultByte,

                                   CreatedById = deviceParam.CreatedById.HasValue ? deviceParam.CreatedById.Value : defaultInt,
                                   ModifiedById = deviceParam.ModifiedById.HasValue ? deviceParam.ModifiedById.Value : defaultInt,
                                   PropertyGroupId = deviceParam.PropertyGroupId.HasValue ? deviceParam.PropertyGroupId.Value : defaultInt
                               }).ToList();
            return deviceParameter;
        }

        private List<DeviceParameterValueEntity> GetDeviceParameterValue(SmartWashroomEntities dbContext,
                                                                         List<DeviceParameterValueEntity> deviceParameterValue,
                                                                         int customerId)
        {
            deviceParameterValue = (from Value in dbContext.DeviceParameterValues
                                    where Value.CustomerId == customerId
                                    where Value.DeviceId == null
                                    select new DeviceParameterValueEntity
                                    {
                                        DeviceParameterValueId = Value.Id,
                                        Value = Value.Value,
                                        OldValue = Value.Value,
                                        IsReset = Value.IsReset,

                                        ResetTime = Value.ResetTime,
                                        CreatedTime = Value.CreatedTime,
                                        ModifiedTime = Value.ModifiedTime,

                                        ParameterId = Value.ParameterId,
                                        CustomerId = Value.CustomerId,
                                        DeviceId = Value.DeviceId,

                                        CreatedById = Value.CreatedById,
                                        ModifiedById = Value.ModifiedById
                                    }).ToList();
            return deviceParameterValue;
        }

        public List<DeviceParameterValueEntity> GetCustermerLevelDeviceParameterValue(int customerId)
        {
            List<DeviceParameterValueEntity> customerOverrideDeviceParameterValue = null;
            using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
            {
                customerOverrideDeviceParameterValue = (from Value in dbContext.DeviceParameterValues
                                                        where Value.CustomerId == customerId
                                                        where Value.DeviceId == null
                                                        select new DeviceParameterValueEntity
                                                        {
                                                            DeviceParameterValueId = Value.Id,
                                                            Value = Value.Value,
                                                            OldValue = Value.Value,
                                                            IsReset = Value.IsReset,

                                                            ResetTime = Value.ResetTime,
                                                            CreatedTime = Value.CreatedTime,
                                                            ModifiedTime = Value.ModifiedTime,

                                                            ParameterId = Value.ParameterId,
                                                            CustomerId = Value.CustomerId,
                                                            DeviceId = Value.DeviceId,

                                                            CreatedById = Value.CreatedById,
                                                            ModifiedById = Value.ModifiedById
                                                        }).ToList();

            }
            return customerOverrideDeviceParameterValue;
        }
        private List<DeviceParameterEntity> GetDeviceSpecificParameters(DeviceTypes item, List<DeviceParameterEntity> deviceParameter, List<DeviceParameterEntity> deviceTypeSpecificParameter)
        {
            deviceTypeSpecificParameter = (from deviceParam in deviceParameter.Where(x => x.DeviceTypeId == item.DeviceId)
                                           select deviceParam).ToList();
            return deviceTypeSpecificParameter;
        }

        private List<DeviceParameterValueEntity> GetDeviceParameterValue(SmartWashroomEntities dbContext, List<DeviceParameterValueEntity> deviceValParamWithoutCustomerAndDeviceID)
        {
            deviceValParamWithoutCustomerAndDeviceID = (from Value in dbContext.DeviceParameterValues
                                                        where Value.CustomerId == null
                                                        where Value.DeviceId == null
                                                        select new DeviceParameterValueEntity
                                                        {
                                                            DeviceParameterValueId = Value.Id,
                                                            Value = Value.Value,
                                                            OldValue = Value.Value,
                                                            IsReset = Value.IsReset,

                                                            ResetTime = Value.ResetTime,
                                                            CreatedTime = Value.CreatedTime,
                                                            ModifiedTime = Value.ModifiedTime,

                                                            ParameterId = Value.ParameterId,
                                                            CustomerId = Value.CustomerId,
                                                            DeviceId = Value.DeviceId,

                                                            CreatedById = Value.CreatedById,
                                                            ModifiedById = Value.ModifiedById
                                                        }).ToList();
            return deviceValParamWithoutCustomerAndDeviceID;
        }

        private List<ReturnValueParameter> GetListOfParameterValuesForTheDeviceTypes(List<DeviceParameterEntity> deviceParameter,
            List<DeviceParameterValueEntity> deviceParameterValue, List<DeviceParameterValueEntity> deviceValParamWithoutCustomerAndDeviceID,
            List<ReturnValueParameter> returnParams)
        {
            foreach (var item in deviceParameter)
            {
                ReturnValueParameter returnParameter = new ReturnValueParameter();
                returnParameter.Parameter = new BusinessEntities.DeviceParameterEntity();
                returnParameter.Parameter = item;
                var subValue = deviceParameterValue.Where(x => x.ParameterId == item.DeviceParameterId).Select(x => x.ParameterId);
                if (subValue.Count() > 0)
                {

                    foreach (var values in deviceParameterValue)
                    {
                        if (values.ParameterId == item.DeviceParameterId)
                        {
                            returnParameter.ParameterValue = new DeviceParameterValueEntity();
                            returnParameter.ParameterValue = values;
                            break;
                        }

                    }
                }
                else
                {
                    foreach (var values in deviceValParamWithoutCustomerAndDeviceID)
                    {
                        if (values.ParameterId == item.DeviceParameterId)
                        {
                            returnParameter.ParameterValue = new DeviceParameterValueEntity();
                            returnParameter.ParameterValue = values;
                            break;
                        }
                    }
                }

                returnParams.Add(returnParameter);
            }
            return returnParams;
        }

        public ProcessResponse<List<ReturnValueParameter>> UpsetReturnParameters(List<ReturnParameterResponse> returnValueParameters, int customerId)
        {
            Guard.IsNotNull(returnValueParameters, "ReturnValueParameters");

            ProcessResponse<List<ReturnValueParameter>> response = new ProcessResponse<List<ReturnValueParameter>>();
            response.Status = ResponseStatus.Success;
            response.Message = "Successfully Saved..";

            using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
            {
                List<DeviceParameter> deviceParameters;
                List<DeviceParameterValue> customerOverrideParameterValues;

                //Retrive DeviceParametersAndValues..
                GetDeviceParametersAndParameterValues(customerId, dbContext, out deviceParameters, out customerOverrideParameterValues);

                foreach (ReturnParameterResponse parameter in returnValueParameters)
                {
                    int deviceTypeId = parameter.deviceTypes.DeviceId;

                    List<ReturnValueParameter> incommingParameterValue = parameter.returnValueParameters;
                    if (incommingParameterValue.Count > 0)
                    {
                        //Retrive Customer Overriden Device Parameter Values for Edit Mode Decision....
                        IEnumerable<DeviceParameterValue> existingCustomerOverridenDeviceParameterValues = RetriveCustomerOverridenParameterValues(
                                                                                                            customerOverrideParameterValues,
                                                                                                            incommingParameterValue);
                        foreach (var incomming in incommingParameterValue)
                        {
                            var filteredExisting = (from existingDeviceValue in existingCustomerOverridenDeviceParameterValues
                                                    where existingDeviceValue.ParameterId.Equals(incomming.Parameter.DeviceParameterId)
                                                    select existingDeviceValue).FirstOrDefault();

                            //Edit Mode is applicable if there is an entry for such parameterid....
                            if (filteredExisting != null)
                            {
                                filteredExisting.Value = incomming.ParameterValue.Value;
                                filteredExisting.IsReset = incomming.ParameterValue.IsReset.HasValue ? incomming.ParameterValue.IsReset.Value : false;
                                filteredExisting.ModifiedTime = DateTime.UtcNow;
                            }
                            else //Insertion Mode..
                            {
                                Guard.IsNotBlank(incomming.ParameterValue.Value, "Invalid Return Parameter");

                                DeviceParameterValue newDeviceParameterValue = new DeviceParameterValue();
                                newDeviceParameterValue.CustomerId = incomming.ParameterValue.CustomerId;
                                newDeviceParameterValue.IsReset = incomming.ParameterValue.IsReset.HasValue ? incomming.ParameterValue.IsReset.Value : false;
                                newDeviceParameterValue.Value = incomming.ParameterValue.Value;

                                newDeviceParameterValue.ParameterId = incomming.ParameterValue.ParameterId.Value;
                                newDeviceParameterValue.DeviceId = null;
                                newDeviceParameterValue.CreatedTime = DateTime.UtcNow;
                                newDeviceParameterValue.ModifiedTime = DateTime.UtcNow;

                                dbContext.DeviceParameterValues.Add(newDeviceParameterValue);
                            }
                        }
                        try
                        {
                            dbContext.SaveChanges();
                            response.Object = incommingParameterValue;
                        }
                        catch (Exception ex)
                        {
                            response.Status = ResponseStatus.Failed;
                            response.Message = ex.Message;
                        }
                    }
                }
            }
            return response;
        }

        public ProcessResponse DeleteDeviceParameterValues(List<Nullable<int>> paramterValueId)
        {
            using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
            {
                Guard.IsNotNull(paramterValueId, "ReturnValueParametersID");

                ProcessResponse response = new ProcessResponse();
                var paramterValueRecords = dbContext.DeviceParameterValues.Where(x => paramterValueId.Contains(x.Id) && x.CustomerId != null).ToList();
                foreach (DeviceParameterValue item in paramterValueRecords)
                {
                    dbContext.DeviceParameterValues.Remove(item);
                }
                try
                {
                    dbContext.SaveChanges();
                    response.Status = ResponseStatus.Success;
                    response.Message = "Successfully Saved..";
                }
                catch (Exception ex)
                {
                    response.Status = ResponseStatus.Failed;
                    response.Message = ex.Message;
                }
                return response;
            }
        }

        private static IEnumerable<DeviceParameterValue> RetriveCustomerOverridenParameterValues(List<DeviceParameterValue> customerOverrideParameterValues,
                                                                                                List<ReturnValueParameter> customerParameterValue)
        {
            var existingDeviceParameterValues = from incommingParam in customerParameterValue

                                                join deviceParamValue in customerOverrideParameterValues on incommingParam.Parameter.DeviceParameterId
                                                equals
                                                deviceParamValue.ParameterId

                                                select deviceParamValue;
            return existingDeviceParameterValues;
        }

        private static void GetDeviceParametersAndParameterValues(int customerId, SmartWashroomEntities dbContext,
                                                                out List<DeviceParameter> deviceParameters,
                                                                out List<DeviceParameterValue> customerOverrideParameterValues)
        {
            deviceParameters = (from deviceParams in dbContext.DeviceParameters
                                where deviceParams.IsActive.Equals(true) && deviceParams.IsReturnParameter.Equals(true)
                                select deviceParams).ToList();

            //Existing Values pickup for updation.. (Customer Overrides : Logic Match the customer id and retrive all parametervalues where device id is null)
            customerOverrideParameterValues = (from deviceParameterValues in dbContext.DeviceParameterValues
                                               where deviceParameterValues.CustomerId.Value.Equals(customerId)
                                               where deviceParameterValues.DeviceId == null || deviceParameterValues.DeviceId == string.Empty
                                               select deviceParameterValues).ToList();
        }
    }
}
