﻿using System.Linq;
using System.Collections.Generic;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.Core.Security.Authorization.Structure;
using KC.SmartWashroom.DataAccess.Skeleton;
using System;
using KC.SmartWashroom.Core.Log;
using KC.SmartWashroom.Core.Enumerations;
using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
using KC.SmartWashroom.BusinessEntities.BusinessHubEntities;

namespace KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers
{
    public class MembershipWorker : IMembershipWorker
    {
        const string PORTAL_ADMIN = "Portal Admin";

        public Core.Helper.ProcessResponse<UserContext> GetUserContext(string userName)
        {
            Guard.IsNotBlank(userName, "UserName");

            ProcessResponse<UserContext> response = new ProcessResponse<UserContext>();
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                //Pickup the corresponding Customer Name..
                var customerName = from user in dbEntity.Users
                                   join customer in dbEntity.Customers on user.CustomerId equals customer.ID
                                   where user.Email.Equals(userName) && customer.IsActive
                                   select customer.Name;


                var userRolePermission = from user in dbEntity.Users
                                         where user.IsDelete.Equals(false)
                                         where user.Email.Equals(userName)
                                         select new UserContext()
                                         {
                                             UserId = user.ID,
                                             UserName = user.Email,
                                             LastName = user.LastName,

                                             FirstName = user.FirstName,
                                             CustomerId = user.CustomerId.HasValue ? user.CustomerId.Value : 0,
                                             IsFirstLogin = user.IsFirstLogin.HasValue ? user.IsFirstLogin.Value : false,

                                             SaltedPassword = user.Password,
                                             RoleId = user.RoleId,
                                             RoleLevel = user.Role.RoleLevel,
                                             FeaturePermissions = dbEntity.RolePermissions.Where(role => role.RoleId.Equals(user.RoleId))
                                                                                            .Select(rolePermission => rolePermission.FeatureId)
                                                                                            .ToList()
                                         };



                //Assigne CUstomer Name to the outgoing response..
                var userCOntext = userRolePermission.FirstOrDefault();
                if (userCOntext.RoleLevel != (int)Enums.RoleLevelType.PortalAdmin)
                {
                    if (customerName != null && string.IsNullOrEmpty(customerName.FirstOrDefault()))
                    {
                        response.Object = null;
                        response.Status = ResponseStatus.Failed;
                        return response;
                    }
                }
                userCOntext.CustomerName = string.IsNullOrEmpty(customerName.FirstOrDefault()) ? PORTAL_ADMIN : customerName.FirstOrDefault();

                response.Object = userCOntext;
                response.Status = ResponseStatus.Success;
            }
            return response;
        }
        //getusersaltedpsw phone
        public KeyValuePair<string, string>? RetriveUserCredentials(string userName, string password)
        {
            KeyValuePair<string, string>? originalUserPasswordSalt = null;
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                var passwordSaltPair = (from user in dbEntity.Users
                                        where user.Email.Equals(userName)
                                        select new
                                        {
                                            Password = user.Password,
                                            PasswordSalt = user.PasswordSalt
                                        }).FirstOrDefault();

                if (passwordSaltPair != null)
                    originalUserPasswordSalt = new KeyValuePair<string, string>(passwordSaltPair.Password, passwordSaltPair.PasswordSalt);
            }
            return originalUserPasswordSalt;
        }

        public bool ResetUserCredentials(string userName, string newPassword, string newPasswordSalt)
        {
            bool isResetSuccessfull = false;
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                try
                {
                    var userCredential = (from user in dbEntity.Users
                                          where user.Email.Equals(userName)
                                          select user).FirstOrDefault();

                    //Update the Password and Salt..
                    userCredential.PasswordSalt = newPasswordSalt;
                    userCredential.Password = newPassword;
                    userCredential.IsFirstLogin = false;

                    dbEntity.SaveChanges();
                    isResetSuccessfull = true;
                }
                catch (Exception exception)
                {
                    Logger.Error(exception.Message);
                }
            }
            return isResetSuccessfull;
        }

        public bool GenerateUserCredentials(string userName, string password, string passwordSalt)
        {
            bool isPasswordGenerated = false;
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                try
                {
                    var userCredential = (from user in dbEntity.Users
                                          where user.Email.Equals(userName)
                                          select user).FirstOrDefault();

                    if (userCredential == null)
                        return isPasswordGenerated;

                    //Update the Password and Salt..
                    userCredential.PasswordSalt = passwordSalt;
                    userCredential.Password = password;

                    dbEntity.SaveChanges();
                    isPasswordGenerated = true;
                }
                catch (Exception exception)
                {
                    Logger.Error(exception.Message);
                }
                return isPasswordGenerated;
            }
        }

        public List<BusinessEntities.RolePermission> GetUserPermissions(int userId)
        {
            List<BusinessEntities.RolePermission> userPermissions = null;
            using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
            {
                userPermissions = (from rolepermission in dbContext.RolePermissions
                                   join feature in dbContext.Features on rolepermission.FeatureId equals feature.ID
                                   join role in dbContext.Roles on rolepermission.RoleId equals role.ID
                                   join user in dbContext.Users on role.ID equals user.RoleId
                                   where user.ID.Equals(userId)
                                   select new BusinessEntities.RolePermission
                                   {
                                       FeatureId = rolepermission.FeatureId,
                                       FeatureDescription = feature.Name
                                   }).ToList();
            }
            return userPermissions;
        }

        public bool ValidateUserName(string userName, ref string saltedPassword)
        {
            bool isUserNameValid = false;
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                var userEmail = (from user in dbEntity.Users
                                 join role in dbEntity.Roles on user.RoleId equals role.ID
                                 where role.RoleLevel != (int)Enums.RoleLevelType.Cleaner
                                 where user.Email.Equals(userName) && user.IsDelete.Equals(false)
                                 select user).FirstOrDefault();

                if (userEmail != null)
                {
                    isUserNameValid = (userEmail != null);

                    //REtrive the Salted Passwrod....
                    saltedPassword = userEmail.Password;
                }
            }
            return isUserNameValid;
        }

        public bool ValidateCustomer(string userName)
        {
            bool isCustomerValid = false;
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                var loggedUser = (from user in dbEntity.Users
                                  where user.Email.Equals(userName)
                                  select user).FirstOrDefault();
                if (loggedUser!= null)
                {
                    if (loggedUser.Role.RoleLevel != (int)Enums.RoleLevelType.PortalAdmin)
                    {
                        var userEmail = (from user in dbEntity.Users
                                         join customer in dbEntity.Customers on user.CustomerId equals customer.ID
                                         where customer.IsActive.Equals(true) && user.Email.Equals(userName)
                                         select user).ToList();

                        if (userEmail != null)
                        {
                            if (userEmail.Count > 0)
                                isCustomerValid = true;
                        }
                    }
                    else
                    {
                        isCustomerValid = true;
                    }
                }
                
                
            }
            return isCustomerValid;
        }
        

        public bool CreateFeature(BusinessEntities.RolePermission newFeature)
        {
            bool isFeatureCreated = false;
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                var availableFeature = (from feature in dbEntity.Features
                                        where feature.Name.Equals(newFeature.FeatureDescription)
                                        select feature).FirstOrDefault();

                if (availableFeature == null)
                    dbEntity.Features.Add(new Feature() { Name = newFeature.FeatureDescription });

                isFeatureCreated = dbEntity.SaveChanges().Equals(1);
            }
            return isFeatureCreated;
        }

        public List<BusinessEntities.RolePermission> GetFeatures()
        {
            List<BusinessEntities.RolePermission> features = new List<BusinessEntities.RolePermission>();
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                features = (from feature in dbEntity.Features
                            select new
                            BusinessEntities.RolePermission()
                            {
                                FeatureId = feature.ID,
                                FeatureDescription = feature.Name
                            }).ToList();
            }
            return features;
        }

        public BusinessEntities.UserAssetEntity GetUserAssets(int userId)
        {
            BusinessEntities.UserAssetEntity userAssets = new BusinessEntities.UserAssetEntity();

            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                var result = dbEntity.SPGETUSERPROPERTITYIDANDBUILDINGID(userId);
                userAssets.PropertyIDs = new List<Int32>();
                userAssets.BuildingIDs = new List<Int32>();

                List<GETPROPERTYID_Result> list1 = new List<GETPROPERTYID_Result>();
                List<GETBUILDINGID_Result> list2 = new List<GETBUILDINGID_Result>();

                list1.AddRange(result);

                userAssets.PropertyIDs = list1.Select(p => p.PropertyID).ToList();

                var buildings = result.GetNextResult<GETBUILDINGID_Result>();
                list2.AddRange(buildings);

                userAssets.BuildingIDs = list2.Select(b => b.BuildingID).ToList();

            }
            return userAssets;
        }

        /// <summary>
        /// This method is used to pull out all the buildings and properties for which all users has access.
        /// </summary>
        /// <returns>User Assert Entity List</returns>
        public BusinessEntities.BusinessHubEntities.UserAccessAsserts GetAllUserAcessAsserts()
        {
            var userAccessAsserts = new UserAccessAsserts();

            using (SmartWashroomEntities dbContext = EntityRepositoryManager.GetStoreEntity())
            {
                //Retrive All REcords from User Building.
                userAccessAsserts.UserAccessBuildings = (from useraccessbuilding in dbContext.UserBuildings
                                                         select new UserAssertRelationship()
                                                         {
                                                             UserId = useraccessbuilding.UserId,
                                                             AssertId = useraccessbuilding.BuildingId
                                                         }).ToList();

                //REtrive all Records from User Property.
                userAccessAsserts.UserAccessProperties = (from useraccessProperty in dbContext.UserProperties
                                                          select new UserAssertRelationship()
                                                          {
                                                              UserId = useraccessProperty.UserId,
                                                              AssertId = useraccessProperty.PropertyId
                                                          }).ToList();
            }

            return userAccessAsserts;
        }

        public int GetUserRoleLevel(string email)
        {
            int Role = 0;
            ProcessResponse<UserContext> response = new ProcessResponse<UserContext>();
            using (SmartWashroomEntities dbEntity = EntityRepositoryManager.GetStoreEntity())
            {
                Role = (from user in dbEntity.Users
                        join role in dbEntity.Roles on user.RoleId equals role.ID
                        where user.Email.Equals(email) && user.IsDelete == false
                        select role.RoleLevel).FirstOrDefault();

            }
            return Role;
        }
    }
}
