﻿using KC.SmartWashroom.DataAccess.Skeleton;
using System;
using System.Linq;

namespace KC.SmartWashroom.DataAccess.DataWorkers.Table_Workers
{
    using KC.SmartWashroom.BusinessEntities;
    using KC.SmartWashroom.BusinessEntities.DashboardApiEntities;
    using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
    using KC.SmartWashroom.Core.Helper;
    using KC.SmartWashroom.DataAccess.DataWorkers.Table_Workers;
    using Microsoft.WindowsAzure.Storage.Table;
    using System.Collections.Generic;

    /// <summary>
    /// Worker used to retrive data from datastore using Entity framework (ORM)
    /// </summary>
    /// 

    public class PropertyWorker : WorkerBase, IPropertyWorker
    {
        private string _errorDetail;

        string IPropertyWorker.ErrorDetail
        {
            get { return _errorDetail; }
            set { _errorDetail = value; }
        }

        public void CreateProperty(Property property)
        {
            var propertyEntity = new PropertyTableEntity("Property" + property.ID.ToString(), "Property");
            propertyEntity.PropertyID = "Property" + property.ID.ToString();
            propertyEntity.PropertyName = "Property_" + property.ID.ToString();
            propertyEntity.Timestamp = DateTime.UtcNow;

            this.tableRepositoryManager.CreateProperty(propertyEntity);
        }

        public BusinessEntities.Property GetProperty(int propertyID)
        {
            //Coding to retrive property from Store using Entity Framework..
            TableQuery<PropertyTableEntity> query = new TableQuery<PropertyTableEntity>().Where(TableQuery.GenerateFilterCondition(
                                                                                                                "PartitionKey", QueryComparisons.Equal, "Property" + propertyID.ToString()));
            var properties = this.tableRepositoryManager.GetProperty(query);

            Property property = new Property();
            if (properties.Count() == 1)
            {
                property = new Property(1, ((PropertyTableEntity)properties.Take(1).FirstOrDefault()).PartitionKey);
            }
            return property;
        }

        public ProcessResponse<Property> Create(Property property)
        {
            throw new NotImplementedException();
        }

        public ProcessResponse<Property> Update(Property property)
        {
            throw new NotImplementedException();
        }

        public ProcessResponse<Property> Delete(int propertyID)
        {
            throw new NotImplementedException();
        }

        public IList<PropertyAlert> GetAllProperties(int customerId, int userId, int duration)
        {
            throw new NotImplementedException();
        }
        public string GetCustomerNameByID(int Id)
        {
            throw new NotImplementedException();
        }

        public List<Timezone> GetAllTimezones()
        {
            throw new NotImplementedException();
        }
    }
}
