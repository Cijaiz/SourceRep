﻿

namespace KC.SmartWashroom.DataAccess.DataWorkers.Table_Workers
{
    using KC.SmartWashroom.BusinessEntities;
    using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
    using KC.SmartWashroom.BusinessEntities.BusinessHubEntities;
    using Microsoft.WindowsAzure.Storage.Table.Queryable;
    using KC.SmartWashroom.Core.Constants;
    using KC.SmartWashroom.Core.Helper;
    using KC.SmartWashroom.DataAccess.Skeleton;
    using Microsoft.WindowsAzure.Storage.Table;
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Linq;
    using System.Text;
    public class RecentUpdatesWorker : WorkerBase, IRecentUpdatesWorker
    {
        private const string SOAP_REFILL_ALERT = "S1";
        private const string JRT_LOWPAPER_ALERT = "J3";
        private const string EHRT_LOWPAPER_ALERT = "H4";
        private const string SRB_LOWPAPER_ALERT = "SR3";

        private const string RESOLUTIONTIME_DAYS = "d";
        private const string RESOLUTIONTIME_HOURS = "h";
        private const string RESOLUTIONTIME_MINS = "mins";
        public const string DATE_FORMAT = "dd'-'MM'-'yyyy  HH:mm:ss:fff tt";

        private const string BLANKSPACE = " ";

        public CloudTable TableReference { get; set; }

        public List<DeviceAlertsResolutionDetail> FetchDeviceAlertsWithResolution(List<DeviceResolutionDetail> devices, int noOfRecentAlerts, SearchCriteria criteria)
        {
            criteria.PageSize = noOfRecentAlerts; //Set 5 for Recent Updates..

            //Pullout all the deviceAlertLogs based on page size
            List<DeviceAlertDetail> allDeviceAlertStatus = CollectAllDeviceAlertStatus(devices, criteria);
            //IEnumerable<DeviceAlertDetail> mostRecentAlertsResolved = GetAllRecentResolvedAlerts(allDeviceAlertStatus); No more required.. As this is done in the Storage itself.

            return PrepareDeviceAlertsForResolved(devices, allDeviceAlertStatus);
        }

        private List<DeviceAlertDetail> CollectAllDeviceAlertStatus(List<DeviceResolutionDetail> devicesForBuilding, SearchCriteria criteria)
        {
            List<DeviceAlertDetail> allDeviceAlertStatus = new List<DeviceAlertDetail>();

            if (devicesForBuilding.Count.Equals(0))
                return allDeviceAlertStatus;

            //Set the Customer Id to the criteria as we dont have this in the upper level..
            criteria.CustomerId = devicesForBuilding.FirstOrDefault().CustomerId;

            // No More required as this is handled in the Table level..
            ////Query All Alerts for A Customer for all Devices..
            //TableQuery<AlertStatusEntity> query = new TableQuery<AlertStatusEntity>().Where(
            //                        TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal,
            //                                                    devicesForBuilding.FirstOrDefault().CustomerId.ToString()));

            IEnumerable<AlertStatusEntity> deviceAlerts = this.SearchRecent(criteria); //this.tableRepositoryManager.GetDeviceAlertStatus(query);

            //Construct appropriate information from the retrived Alerts..
            ExtractDeviceAlertStatus(devicesForBuilding, ref allDeviceAlertStatus, deviceAlerts);
            return allDeviceAlertStatus;
        }

        private List<DeviceAlertDetail> CollectAllDeviceAlertStatusLastDay(List<DeviceResolutionDetail> devicesForBuilding)
        {
            List<DeviceAlertDetail> allDeviceAlertStatus = new List<DeviceAlertDetail>();

            if (devicesForBuilding.Count.Equals(0))
                return allDeviceAlertStatus;

            //Query All Alerts for A Customer for all Devices..
            //TableQuery<AlertStatusEntity> query = new TableQuery<AlertStatusEntity>().Where(
            //                        TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal,
            //                                                    devicesForBuilding.FirstOrDefault().CustomerId.ToString()));

            TableQuery<AlertStatusEntity> query = new TableQuery<AlertStatusEntity>().Where(TableQuery.CombineFilters(
                                                   TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, devicesForBuilding.FirstOrDefault().CustomerId.ToString()),
                                                   TableOperators.And,
                                                   TableQuery.GenerateFilterCondition("AlertResolvedOn", QueryComparisons.GreaterThanOrEqual, DateTime.UtcNow.AddHours(-24).ToString("MM/dd/yyyy hh:mm:ss"))
                                               ));

            IEnumerable<AlertStatusEntity> deviceAlerts = this.tableRepositoryManager.GetDeviceAlertStatus(query);

            //Construct appropriate information from the retrived Alerts..
            ExtractDeviceAlertStatus(devicesForBuilding, ref allDeviceAlertStatus, deviceAlerts);
            return allDeviceAlertStatus;
        }

        private static void ExtractDeviceAlertStatus(List<DeviceResolutionDetail> devicesForBuilding,
                                                    ref List<DeviceAlertDetail> allDeviceAlertStatus,
                                                    IEnumerable<AlertStatusEntity> deviceAlerts)
        {
            decimal defaultDecimal = 0;

            //Pull Alerts specific to that particular Building or Washroom..
            allDeviceAlertStatus = (from deviceAlert in deviceAlerts
                                    //where devicesForBuilding.Where(device => device.DeviceID.Equals(deviceAlert.RowKey
                                    //                                            .Substring(0, deviceAlert.RowKey.IndexOf(CommonConstants.SEPERATOR))))
                                    //                                            .FirstOrDefault() != null
                                    where devicesForBuilding.Where(device => device.DeviceID.Equals(deviceAlert.DeviceId))
                                                                                .FirstOrDefault() != null
                                    select new DeviceAlertDetail
                                    {
                                        DeviceId = deviceAlert.DeviceId,//RowKey.Substring(0, deviceAlert.RowKey.IndexOf(CommonConstants.SEPERATOR)),
                                        ReceivedOn = deviceAlert.AlertIssuedOn,
                                        ResolvedOn = deviceAlert.AlertResolvedOn,

                                        AlertType = deviceAlert.AlertType,
                                        IsAlert = deviceAlert.IsAlert.Equals(1) ? true : false,
                                        CustomerID = deviceAlert.CustomerID,

                                        RefillPercentage = decimal.TryParse(deviceAlert.RefillPercentage, out defaultDecimal).Equals(true) ?
                                                            defaultDecimal : defaultDecimal,

                                        ProductRefillDetail = (devicesForBuilding.Where(device => device.DeviceID.Equals(deviceAlert.DeviceId)))
                                            //.Substring(0, deviceAlert.RowKey.IndexOf(CommonConstants.SEPERATOR)))))
                                                                                .FirstOrDefault().ProductRefillDetail,

                                        PropertyId = (devicesForBuilding.Where(device => device.DeviceID.Equals(deviceAlert.DeviceId)))
                                            //.Substring(0, deviceAlert.RowKey.IndexOf(CommonConstants.SEPERATOR)))))
                                                                            .FirstOrDefault().PropertyId,

                                        FloorId = (devicesForBuilding.Where(device => device.DeviceID.Equals(deviceAlert.DeviceId)))
                                            //.Substring(0, deviceAlert.RowKey.IndexOf(CommonConstants.SEPERATOR)))))
                                                                            .FirstOrDefault().FloorId,

                                        DeviceTypeId = (devicesForBuilding.Where(device => device.DeviceID.Equals(deviceAlert.DeviceId)))
                                            //.Substring(0, deviceAlert.RowKey.IndexOf(CommonConstants.SEPERATOR)))))
                                                                                .FirstOrDefault().DeviceTypeId,

                                        RoomTypeId = (devicesForBuilding.Where(device => device.DeviceID.Equals(deviceAlert.DeviceId)))
                                            //.Substring(0, deviceAlert.RowKey.IndexOf(CommonConstants.SEPERATOR)))))
                                                                                .FirstOrDefault().RoomTypeId,

                                        DeviceType = (devicesForBuilding.Where(device => device.DeviceID.Equals(deviceAlert.DeviceId)))
                                            //.Substring(0, deviceAlert.RowKey.IndexOf(CommonConstants.SEPERATOR)))))
                                                                                .FirstOrDefault().DeviceType,

                                        LocalTimeZone = (devicesForBuilding.Where(device => device.DeviceID.Equals(deviceAlert.DeviceId)))
                                            //.Substring(0, deviceAlert.RowKey.IndexOf(CommonConstants.SEPERATOR)))))
                                                        .FirstOrDefault().LocalTimeZone
                                    }).ToList();
        }

        public List<DeviceAlertsResolutionDetail> GetDeviceAlertResolution(SearchCriteria searchCriteria)
        {

            int defaultInt= 0;
            IEnumerable<AlertStatusEntity> deviceAlerts = this.SearchRecent(searchCriteria);
            var deviceAlertsResolutionDetails = new List<DeviceAlertsResolutionDetail>();
            //Pull Alerts specific to that particular Building or Washroom..
            foreach(AlertStatusEntity deviceAlert in deviceAlerts)
            {
                var resolutionInfo = new DeviceAlertsResolutionDetail();
                var alertReceivedTime = CommonHelper.TryParseDateTime(deviceAlert.AlertIssuedOn
                    , CommonConstants.SHORT_DATE_TIME_FORMAT
                    , CommonConstants.SHORT_DATE_TIME_FORMAT_WITH_MERIDIAN);
                resolutionInfo.DeviceId = deviceAlert.DeviceId;
                resolutionInfo.AlertReceivedOn = alertReceivedTime.ToString();

                resolutionInfo.AlertType = deviceAlert.AlertType;
                resolutionInfo.CustomerID = deviceAlert.CustomerID;
                resolutionInfo.DeviceType = deviceAlert.DeviceType;
                resolutionInfo.RefillPercentage = int.TryParse(deviceAlert.RefillPercentage, out defaultInt).Equals(true) ?defaultInt : defaultInt;
                resolutionInfo.AlertDescription = this.GetAlertDescription(deviceAlert.AlertType);
                if (!string.IsNullOrEmpty(deviceAlert.AlertResolvedOn))
                {
                    ComputeResolutionTime(deviceAlert.AlertResolvedOn, resolutionInfo, alertReceivedTime);
                }

                if (SOAP_REFILL_ALERT.Equals(deviceAlert.AlertType, StringComparison.OrdinalIgnoreCase)
                    || JRT_LOWPAPER_ALERT.Equals(deviceAlert.AlertType, StringComparison.OrdinalIgnoreCase)
                    || SRB_LOWPAPER_ALERT.Equals(deviceAlert.AlertType, StringComparison.OrdinalIgnoreCase)
                    || EHRT_LOWPAPER_ALERT.Equals(deviceAlert.AlertType, StringComparison.OrdinalIgnoreCase))
                {
                    resolutionInfo.IsRefillHappened = resolutionInfo.RefillPercentage >= 0;
                }
                deviceAlertsResolutionDetails.Add(resolutionInfo);
            }
            var distinctResolutions = new List<DeviceAlertsResolutionDetail>(); 
            if(deviceAlertsResolutionDetails!=null && deviceAlertsResolutionDetails.Count>0) 
            { 
                distinctResolutions = deviceAlertsResolutionDetails.Distinct().ToList(); 
            }
            var distinctResults = from distinctAlertResolutions in deviceAlertsResolutionDetails
                                 group distinctAlertResolutions by new
                                    {
                                        distinctAlertResolutions.AlertResolvedOn,
                                        distinctAlertResolutions.AlertType,
                                        distinctAlertResolutions.DeviceId
                                    } into grp
                                    select grp.First();

            distinctResolutions = distinctResults.ToList();

            return distinctResolutions;
          
        }
        private static IEnumerable<DeviceAlertDetail> GetMostRecentResolvedAlerts(List<DeviceAlertDetail> allDeviceAlerts, int noOfRecentAlerts)
        {
            //Pick the N number of Most recent Resolution alerts..
            return GetAllRecentResolvedAlerts(allDeviceAlerts).Take(noOfRecentAlerts);
        }


        private List<DeviceAlertsResolutionDetail> PrepareDeviceAlertsForResolved(List<DeviceResolutionDetail> devices, IEnumerable<DeviceAlertDetail> mostRecentAlertsResolved)
        {
            var deviceAlertsResolutionDetails = new List<DeviceAlertsResolutionDetail>();

            DateTime defaultTime = DateTime.MinValue;
            foreach (var alertInfo in mostRecentAlertsResolved)
            {
                var alertReceivedTime = CommonHelper.TryParseDateTime(alertInfo.ReceivedOn
                    , CommonConstants.SHORT_DATE_TIME_FORMAT
                    , CommonConstants.SHORT_DATE_TIME_FORMAT_WITH_MERIDIAN);

                var resolutionInfo = new DeviceAlertsResolutionDetail();
                resolutionInfo.CustomerID = alertInfo.CustomerID;
                resolutionInfo.DeviceId = alertInfo.DeviceId;
                resolutionInfo.DeviceType = alertInfo.DeviceType;
                resolutionInfo.AlertType = alertInfo.AlertType;
                resolutionInfo.LocalTimeZone = alertInfo.LocalTimeZone;
                resolutionInfo.AlertReceivedOn = alertReceivedTime.ToString();
                resolutionInfo.AlertDescription = this.GetAlertDescription(alertInfo.AlertType);
                ComputeResolutionTime(alertInfo.ResolvedOn, resolutionInfo, alertReceivedTime);

                if (SOAP_REFILL_ALERT.Equals(alertInfo.AlertType, StringComparison.OrdinalIgnoreCase)
                    || JRT_LOWPAPER_ALERT.Equals(alertInfo.AlertType, StringComparison.OrdinalIgnoreCase)
                    || SRB_LOWPAPER_ALERT.Equals(alertInfo.AlertType, StringComparison.OrdinalIgnoreCase)
                    || EHRT_LOWPAPER_ALERT.Equals(alertInfo.AlertType, StringComparison.OrdinalIgnoreCase))
                {
                    resolutionInfo.IsRefillHappened = alertInfo.RefillPercentage >= 0;
                    if (resolutionInfo.IsRefillHappened)
                        resolutionInfo.RefillPercentage = (int)alertInfo.RefillPercentage;

                }


                //Commonly set the Floor Detail and Washroom...

                var device = devices
                    .Where(d => string.Equals(d.DeviceID, alertInfo.DeviceId, StringComparison.OrdinalIgnoreCase))
                    .FirstOrDefault();

                if (device != null)
                {
                    resolutionInfo.Floor = device.Floor;
                    resolutionInfo.PropertyName = device.PropertyName;
                    resolutionInfo.BuildingName = device.Building;
                    resolutionInfo.Wing = device.Wing;
                    resolutionInfo.WashroomGender = device.WashroomGender;
                    resolutionInfo.DeviceName = device.DeviceName;
                    resolutionInfo.DeviceType = device.DeviceType;
                }
                deviceAlertsResolutionDetails.Add(resolutionInfo);
            }
            return deviceAlertsResolutionDetails;
        }

        private static void ComputeResolutionTime(string resolvedOn, DeviceAlertsResolutionDetail resolutionDetails, DateTime initialAlertTime)
        {
            // Review Comment from Kiran Chand: move this code to user interface
            // Business API should not worry about how the data is displayed
            // just send the information; let the UI to deal with the presentation

            var resolvedTime = CommonHelper.TryParseDateTime(resolvedOn
                , CommonConstants.SHORT_DATE_TIME_FORMAT
                , CommonConstants.SHORT_DATE_TIME_FORMAT_WITH_MERIDIAN);

            resolutionDetails.AlertResolvedOn = resolvedTime.ToString();


            #region Commenting out the repeated code
            /*

            var resolvedTime = DateTime.MinValue;

            if (!DateTime.TryParseExact(alertDetails.ResolvedOn,
                                    CommonConstants.SHORT_DATE_TIME_FORMAT,
                                    CultureInfo.InvariantCulture,
                                    DateTimeStyles.AdjustToUniversal, out resolvedTime))
            {
              
                DateTime.TryParseExact(alertDetails.ResolvedOn,
                                    CommonConstants.SHORT_DATE_TIME_FORMAT_WITH_MERIDIAN,
                                    CultureInfo.InvariantCulture,
                                    DateTimeStyles.AdjustToUniversal, out resolvedTime);
            }
            */
            #endregion


            //Find the REsolution Time...
            TimeSpan resolutionTime = resolvedTime.Subtract(initialAlertTime);

            StringBuilder resolutionBuilder = new StringBuilder();
            if (resolutionTime.Days > 0)
            {
                resolutionBuilder.Append(resolutionTime.Days);
                resolutionBuilder.Append(RESOLUTIONTIME_DAYS);
                resolutionBuilder.Append(BLANKSPACE);
            }

            if (resolutionTime.Hours > 0)
            {
                resolutionBuilder.Append(resolutionTime.Hours);
                resolutionBuilder.Append(RESOLUTIONTIME_HOURS);
                resolutionBuilder.Append(BLANKSPACE);
            }

            resolutionBuilder.Append(resolutionTime.Minutes);
            resolutionBuilder.Append(RESOLUTIONTIME_MINS);

            // Review comments from Kiran Chand - why are we doing this?
            // Why do not we use the resolutionTime.TotalMinutes property?

            //Get the TimeSpan
            resolutionDetails.ResolutionTimeSpanMinutes = resolutionTime.Days * 24 * 60 + resolutionTime.Hours * 60 + resolutionTime.Minutes;
            resolutionDetails.ResolutionTime = resolutionBuilder.ToString();
        }

        public ActivityResult FetchAllActivitiesWithFilter(List<DeviceResolutionDetail> devices, string alertTypeCode, DateTime fromDate, DateTime toDate, int propertyId, int floorId, byte deviceTypeId, byte roomTypeId, int noOfRecentAlerts)
        {

            ActivityResult activityResult = new ActivityResult();
            var deviceAlertsResolutionDetails = new List<DeviceAlertsResolutionDetail>();
            List<DeviceAlertDetail> RecentAlertsResolved = new List<DeviceAlertDetail>();

            List<DeviceAlertDetail> allDeviceAlertStatus = CollectAllDeviceAlertStatus(devices, null);
            IEnumerable<DeviceAlertDetail> mostRecentAlertsResolved = GetAllRecentResolvedAlerts(allDeviceAlertStatus);

            RecentAlertsResolved = ApplyFilter(mostRecentAlertsResolved.ToList(), alertTypeCode, fromDate, toDate, propertyId, floorId, deviceTypeId, roomTypeId);
            activityResult.TotalResolvedAlertsCount = mostRecentAlertsResolved.Count();
            activityResult.Activities = PrepareDeviceAlertsForResolved(devices, RecentAlertsResolved.Take(noOfRecentAlerts));

            return activityResult;
        }

        private static IEnumerable<DeviceAlertDetail> GetAllRecentResolvedAlerts(List<DeviceAlertDetail> allDeviceAlerts)
        {
            //Arrange in Descending order to pick the most recent...
            var mostRecentResolvedRaw = from alert in allDeviceAlerts
                                        where alert.IsAlert.Equals(false)
                                        //orderby alert.ResolvedOn descending
                                        select alert;

            //Filter out the duplicated resolved alerts.. based on alert type..
            var mostRecentDistinctAlerts = mostRecentResolvedRaw.GroupBy(raw => new
            {
                DeviceId = raw.DeviceId,
                alertType = raw.AlertType

            }).Select(g => g.First());


            var mostRecentAlertsResolved = (from alert in mostRecentDistinctAlerts
                                            where alert.IsAlert.Equals(false)
                                            orderby alert.ResolvedOn descending
                                            select alert);
            return mostRecentAlertsResolved;
        }

        private List<DeviceAlertDetail> ApplyFilter(List<DeviceAlertDetail> allDeviceAlerts, string alertTypeCode, DateTime fromDate, DateTime toDate, int propertyId, int floorId, byte deviceTypeId, byte roomTypeId)
        {
            List<DeviceAlertDetail> RecentAlertsResolved = new List<DeviceAlertDetail>();
            RecentAlertsResolved = (from alert in allDeviceAlerts
                                    orderby alert.ReceivedOn descending
                                    where alert.IsAlert.Equals(false)
                                    && (alertTypeCode != "0" ? alert.AlertType == alertTypeCode : true)
                                    && (fromDate != DateTime.MinValue ? !string.IsNullOrEmpty(alert.ResolvedOn) ? CommonHelper.TryParseDateTime(alert.ResolvedOn
                                    , CommonConstants.SHORT_DATE_TIME_FORMAT
                                    , CommonConstants.SHORT_DATE_TIME_PREVIOUS_FORMAT).Date >= fromDate.Date : false : true)
                                    && (toDate != DateTime.MinValue ? !string.IsNullOrEmpty(alert.ResolvedOn) ? CommonHelper.TryParseDateTime(alert.ResolvedOn
                                    , CommonConstants.SHORT_DATE_TIME_FORMAT
                                    , CommonConstants.SHORT_DATE_TIME_PREVIOUS_FORMAT).Date <= toDate.Date : false : true)
                                    && (propertyId != 0 ? alert.PropertyId == propertyId : true)
                                    && (floorId != 0 ? alert.FloorId == floorId : true)
                                    && (deviceTypeId != 0 ? alert.DeviceTypeId == deviceTypeId : true)
                                    && (roomTypeId != 0 ? alert.RoomTypeId == roomTypeId : true)
                                    select alert).ToList();
            return RecentAlertsResolved;
        }

        private string GetAlertDescription(string alertType)
        {
            string alertDescription = string.Empty;
            switch (alertType.ToUpper())
            {
                case "J1":
                case "SR1":
                    alertDescription = "Low Battery";
                    break;
                case "J2":
                case "SR2":
                    alertDescription = "Paper Transfer";
                    break;
                case "J3":
                case "SR3":
                    alertDescription = "Low Paper";
                    break;
                case "S1":
                    alertDescription = "Low Soap";
                    break;
                case "S2":
                    alertDescription = "Low Battery";
                    break;
                case "S3":
                    alertDescription = "Motor OverCurrent";
                    break;
                case "S4":
                    alertDescription = "Very Low Soap";
                    break;
                case "H1":
                    alertDescription = "Paper Transfer";
                    break;
                case "H2":
                    alertDescription = "Low Battery";
                    break;
                case "H3":
                    alertDescription = "Paper Jam";
                    break;
                case "H4":
                    alertDescription = "Low Paper";
                    break;
                case "H5":
                    alertDescription = "Trash Full";
                    break;
                default:
                    alertDescription = "NA";
                    break;
            }
            return alertDescription;
        }

        public ActivityResult FetchAllActivities(List<DeviceResolutionDetail> devices, int noOfRecentAlerts)
        {
            //Pullout all the deviceAlertStatus for devices retrived for a washroom. 
            ActivityResult activityResult = new ActivityResult();
            List<DeviceAlertDetail> allDeviceAlertStatus = CollectAllDeviceAlertStatus(devices, null);

            IEnumerable<DeviceAlertDetail> mostRecentAlertsResolved = GetAllRecentResolvedAlerts(allDeviceAlertStatus);

            activityResult.TotalResolvedAlertsCount = mostRecentAlertsResolved.Count();
            activityResult.Activities = PrepareDeviceAlertsForResolved(devices, mostRecentAlertsResolved.Take(noOfRecentAlerts));

            return activityResult;
        }

        public ActivityResult FetchActivitiesLastDay(List<DeviceResolutionDetail> devices)
        {
            //Pullout all the deviceAlertStatus for devices retrived for a washroom. 
            ActivityResult activityResult = new ActivityResult();
            List<DeviceAlertDetail> allDeviceAlertStatus = CollectAllDeviceAlertStatusLastDay(devices);

            IEnumerable<DeviceAlertDetail> mostRecentAlertsResolved = GetAllRecentResolvedAlerts(allDeviceAlertStatus);

            activityResult.TotalResolvedAlertsCount = mostRecentAlertsResolved.Count();
            activityResult.Activities = PrepareDeviceAlertsForResolved(devices, mostRecentAlertsResolved);

            return activityResult;
        }


        public IEnumerable<AlertStatusEntity> SearchRecent(SearchCriteria filter = null)
        {
            this.TableReference = this.tableRepositoryManager.GetTableReference(KC.SmartWashroom.Core.Constants.AlertEngineConstants.ENGINE_ALERT_LOG_TABLE);

            if (filter == null)
            {
                filter = new SearchCriteria();
            }

            var rowFrom = (DateTime.MaxValue.ToUniversalTime() - filter.ToDate.ToUniversalTime()).Ticks.ToString().TrimEnd('9');
            var rowTo = (DateTime.MaxValue.ToUniversalTime() - filter.FromDate.ToUniversalTime()).Ticks.ToString().TrimEnd('9');

            var query = from alert in this.TableReference.CreateQuery<AlertStatusEntity>()
                        where alert.RowKey.CompareTo(rowFrom) >= 0
                        && alert.RowKey.CompareTo(rowTo) < 0
                        select alert;

            if (filter.ResolutionOnly)
            {
                query = from alert in query
                        where alert.AlertResolvedOn.CompareTo("") > 0
                        select alert;
            }
            if (filter.WashroomList != null && filter.WashroomList.Count > 0)
            {
                var expression = this.Contains<AlertStatusEntity, int>(alert => alert.WashroomId, filter.WashroomList);
                query = query.Where(expression);

            }

            if (filter.FloorId > 0)
            {
                query = from alert in query
                        where alert.FloorId == filter.FloorId
                        select alert;
            }

            else if (filter.BuildingList != null && filter.BuildingList.Count > 0)
            {
                var expression = this.Contains<AlertStatusEntity, int>(alert => alert.BuildingId, filter.BuildingList);
                query = query.Where(expression);

            }
            else if (filter.PropertyId > 0)
            {
                query = from alert in query
                        where alert.PropertyID == filter.PropertyId
                        select alert;
            }

            else if (filter.CustomerId > 0)
            {
                query = from alert in query
                        where alert.CustomerID == filter.CustomerId
                        select alert;
            }
            if (!string.IsNullOrEmpty(filter.AlertCode))
            {
                query = from alert in query
                        where alert.AlertType == filter.AlertCode
                        select alert;
            }
            if (filter.DeviceTypeId > 0)
            {
                query = from alert in query
                        where alert.DeviceType == filter.DeviceTypeId.ToString()
                        select alert;
            }
            var range = filter.ToDate - filter.FromDate;

            if (filter.SearchByPartition)
            {
                if (range.TotalDays <= 60)
                {
                    var date = filter.FromDate.Date;
                    var toDate = filter.ToDate.Date;
                    var partitions = new List<string>();

                    while (date <= toDate)
                    {
                        partitions.Add(string.Format("{0}_{1}_{2}", date.InverseDays(), filter.CustomerId, filter.PropertyId));
                        date = date.AddDays(1);
                    }

                    var expression = this.Contains<AlertStatusEntity, string>(alert => alert.PartitionKey, partitions);

                    query = query.Where(expression);
                }
                else
                {
                    var rangeFrom = filter.FromDate.ToString("yyyyMMdd");
                    var rangeTo = filter.ToDate.AddDays(1).ToString("yyyyMMdd");

                    query = from alert in query
                            where alert.PartitionKey.CompareTo(rangeFrom) >= 0
                            && alert.PartitionKey.CompareTo(rangeTo) < 0
                            select alert;
                }
            }

            if (filter.PageSize > 0 && filter.PageSize < 1000)
            {
                query = query.Take(filter.PageSize);
            }

            var token = default(TableContinuationToken);

            if (!string.IsNullOrWhiteSpace(filter.NextPartitionKey)
                && !string.IsNullOrWhiteSpace(filter.NextRowKey))
            {
                token = new TableContinuationToken() { NextPartitionKey = filter.NextPartitionKey, NextRowKey = filter.NextRowKey };
            }

            var tableQuery = query.AsTableQuery();

            filter.StartTime = DateTime.Now;

            var results = tableQuery.ExecuteSegmented(token);

            filter.EndTime = DateTime.Now;

            if (results.ContinuationToken != null)
            {
                filter.NextRowKey = results.ContinuationToken.NextRowKey;
                filter.NextPartitionKey = results.ContinuationToken.NextPartitionKey;
            }
            else
            {
                filter.NextRowKey = filter.NextPartitionKey = null;
            }
            filter.FilterString = tableQuery.FilterString;
            filter.Results = results.Results;

            return filter.Results;
        }
    }
}