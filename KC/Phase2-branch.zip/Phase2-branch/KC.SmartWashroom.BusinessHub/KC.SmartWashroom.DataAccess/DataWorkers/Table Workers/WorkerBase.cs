﻿
using System;
using System.Linq;
using System.Collections.Generic;
using System.Linq.Expressions;
namespace KC.SmartWashroom.DataAccess.DataWorkers.Table_Workers
{
    public class WorkerBase
    {
        internal TableRepositoryManager tableRepositoryManager { get; private set; }

        public WorkerBase()
        {
            this.tableRepositoryManager = new TableRepositoryManager();
        }

        protected Expression<Func<TEntity, bool>> Contains<TEntity, TValue>(Expression<Func<TEntity, TValue>> expression, IEnumerable<TValue> values)
        {
            Expression<Func<TEntity, bool>> filter = null;

            if (expression != null
                && values != null)
            {
                foreach (var value in values.Distinct())
                {
                    var constantExpression = Expression.Constant(value, typeof(TValue));

                    var equalityExpression = Expression.Equal(expression.Body, constantExpression);

                    Expression<Func<TEntity, bool>> exp = Expression.Lambda<Func<TEntity, bool>>(equalityExpression, expression.Parameters);

                    if (filter == null)
                        filter = exp;
                    else
                    {
                        filter = Expression.Lambda<Func<TEntity, bool>>(Expression<Func<TEntity, bool>>.OrElse(filter.Body, exp.Body), expression.Parameters);
                    }

                }
            }
            return filter;
        }
    }
}
