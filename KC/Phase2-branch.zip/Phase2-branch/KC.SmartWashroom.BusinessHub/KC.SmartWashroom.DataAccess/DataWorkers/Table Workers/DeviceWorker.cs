﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
using KC.SmartWashroom.BusinessEntities.BusinessHubEntities;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.Core.Log;
using KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers;
using KC.SmartWashroom.DataAccess.Skeleton;
using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Reflection;
using KC.SmartWashroom.Core.Enumerations;
using KC.SmartWashroom.Core.Attributes;

namespace KC.SmartWashroom.DataAccess.DataWorkers.Table_Workers
{
    public class DeviceWorker : WorkerBase, IDeviceWorker
    {
        private QueueRepositoryManager queueManager;
        public const string DATE_FORMAT = "dd'-'MM'-'yyyy  HH:mm:ss:fff tt";

        public ProcessResponseForGateway SaveDeviceLog(DeviceLog deviceLog)
        {
            ProcessResponseForGateway response = new ProcessResponseForGateway();

            try
            {
                string partitionKey = string.Format(CommonConstants.DEVICE_LOG_PARTITION_KEY_FORMAT_WITHPROPERTY, DateTime.UtcNow.ToString(CommonConstants.PARTITION_DATE_FORMAT), deviceLog.CustomerId.ToString(), deviceLog.PropertyId.ToString());
                string rowKey = string.Format(CommonConstants.DEVICE_LOG_ROW_KEY_FORMAT, CommonHelper.GetInverseTimestamp(), deviceLog.DeviceId, Guid.NewGuid().ToString());
                DeviceEntity deviceEntity = Activator.CreateInstance(GetDeviceType(deviceLog.Parameter, true));
                deviceEntity.PartitionKey = partitionKey;
                deviceEntity.RowKey = rowKey;

                //deviceEntity.DeviceParameter = deviceLog.DeviceParameter;
                // deviceEntity.Parameter = deviceLog.Parameter;
                CopyToDeviceEntity(ref deviceEntity, deviceLog, true);
                UpdateCreatedOn(ref deviceEntity);
                this.tableRepositoryManager.SaveDeviceLog(deviceEntity);

                response.status = AlertEngineConstants.STATUS_SUCCESS;
                response.message = AlertEngineConstants.MESSAGE_SUCCESS;
            }
            catch (Exception ex)
            {
                response.status = AlertEngineConstants.STATUS_FAIL;
                response.message = ex.Message;
            }

            return response;
        }
        private void UpdateCreatedOn(ref DeviceEntity deviceEntity)
        {
            Type entityType = deviceEntity.GetType();
            PropertyInfo[] properties = entityType.GetProperties();
            if (properties != null && properties.Count() > 0)
            {
                PropertyInfo sourceProperty = properties.Where(item => item.Name == "CreatedOn").First();
                if(sourceProperty!=null)
                {
                    sourceProperty.SetValue(deviceEntity, DateTime.UtcNow.ToString(CommonConstants.LONG_DATE_TIME_FORMAT));
                }
            }
        }

        public ProcessResponseForGateway SaveDeviceStatus(DeviceLog deviceLog)
        {
            ProcessResponseForGateway response = new ProcessResponseForGateway();

            try
            {
                string partitionKey = deviceLog.CustomerId.ToString();
                string rowKey = deviceLog.DeviceId;
                DeviceEntity deviceEntity = Activator.CreateInstance(GetDeviceType(deviceLog.Parameter, false));
                deviceEntity.PartitionKey = partitionKey;
                deviceEntity.RowKey = rowKey;


                CopyToDeviceEntity(ref deviceEntity, deviceLog, false);
                this.tableRepositoryManager.SaveDeviceStatus(deviceEntity);

                response.status = AlertEngineConstants.STATUS_SUCCESS;
                response.message = AlertEngineConstants.MESSAGE_SUCCESS;
            }
            catch (Exception ex)
            {
                response.status = AlertEngineConstants.STATUS_FAIL;
                response.message = ex.Message;
            }

            return response;
        }
        public bool IsAlertExists(int customerId, string deviceId, string alertCode)
        {
            bool isAlertExists = false;

            TableQuery<AlertStatusEntity> query = new TableQuery<AlertStatusEntity>().Where(
                                              TableQuery.CombineFilters(
                                                  TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, customerId.ToString()),
                                                  TableOperators.And,
                                                  TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.Equal, string.Format(AlertEngineConstants.KEYS_FORMATTER, deviceId, alertCode))
                                              )
                                          );

            IEnumerable<AlertStatusEntity> deviceAlerts = this.tableRepositoryManager.GetDeviceAlertStatus(query);
            if (deviceAlerts != null && deviceAlerts.Count() > 0)
            {
                isAlertExists = string.IsNullOrEmpty(deviceAlerts.First().AlertResolvedOn);
            }
            return isAlertExists;
        }
        private Type GetDeviceType(dynamic parameter, bool isDeviceLog)
        {
            Type specificEntity = null;
            if (parameter is JRTParameters)
            {
                if (isDeviceLog)
                {
                    specificEntity = typeof(JRTEntityLog);
                }
                else
                {
                    specificEntity = typeof(JRTEntity);
                }
            }
            else if (parameter is SRBParameters)
            {
                if (isDeviceLog)
                {
                    specificEntity = typeof(SRBEntityLog);
                }
                else
                {
                    specificEntity = typeof(SRBEntity);
                }
            }
            else if (parameter is eHRTParameters)
            {
                if (isDeviceLog)
                {
                    specificEntity = typeof(eHRTEntityLog);
                }
                else
                {
                    specificEntity = typeof(eHRTEntity);
                }
            }
            else if (parameter is eSoapParameters)
            {
                if (isDeviceLog)
                {
                    specificEntity = typeof(eSoapEntityLog);
                }
                else
                {
                    specificEntity = typeof(eSoapEntity);
                }
            }
            return specificEntity;
        }
        private void CopyToDeviceEntity(ref DeviceEntity deviceEntity, DeviceLog deviceLog, bool isDeviceLog)
        {
            Type entityType = deviceEntity.GetType();
            PropertyInfo[] entityAllProperties = entityType.GetProperties();

            PropertyInfo[] entityProperties = null;
            if (entityAllProperties != null)
            {
                entityProperties = entityAllProperties.Where(item => item.GetCustomAttribute<DeviceEntityAttribute>() != null &&
                            item.GetCustomAttribute<DeviceEntityAttribute>().DeviceEntityType == Enums.DeviceEntityType.Base).ToArray();
            }
            Type deviceLogType = typeof(DeviceLog);
            PropertyInfo[] deviceLogProperties = deviceLogType.GetProperties();

            CopyToEntity(ref deviceEntity, entityProperties, deviceLog, deviceLogProperties);


            PropertyInfo[] paramProperties = deviceLog.Parameter.GetType().GetProperties();

            Type specificEntity = GetDeviceType(deviceLog.Parameter, isDeviceLog);


            if (entityAllProperties != null)
            {
                entityProperties = entityAllProperties.Where(item => item.GetCustomAttribute<DeviceEntityAttribute>() != null &&
                            item.GetCustomAttribute<DeviceEntityAttribute>().DeviceEntityType == Enums.DeviceEntityType.Specific).ToArray();
            }

            CopyToEntity(ref deviceEntity, entityProperties, deviceLog.Parameter, paramProperties);

        }
        private void CopyToEntity(ref DeviceEntity deviceEntity, PropertyInfo[] entityProperties, object sourceObj, PropertyInfo[] sourceProperties)
        {
            if (entityProperties != null)
            {
                foreach (PropertyInfo entityProperty in entityProperties)
                {
                    PropertyInfo sourceProperty = sourceProperties.Where(item => item.Name == entityProperty.Name).First();
                    if (sourceProperty != null)
                    {
                        object value = sourceProperty.GetValue(sourceObj);
                        if (value is decimal)
                        {
                            double dblValue;
                            double.TryParse(value.ToString(), out dblValue);
                            entityProperty.SetValue(deviceEntity, dblValue);
                        }
                        else if (value is char)
                        {
                            entityProperty.SetValue(deviceEntity, value.ToString());
                        }
                        else
                        {
                            entityProperty.SetValue(deviceEntity, value);
                        }
                    }
                }
            }
        }
        public void LogIncomingDeviceDetail(DeviceAuditLog entity)
        {
            try
            {
                string partitionKey = string.Format("{0}_{1}"
                    , DateTime.UtcNow.ToString(CommonConstants.PARTITION_DATE_FORMAT)
                    , ((entity.ResponseCode == (int)System.Net.HttpStatusCode.OK) ? CommonConstants.VALID_DATA : CommonConstants.INVALID_DATA));

                string rowKey = string.Format("{0}_{1}_{2}", CommonHelper.GetInverseTimestamp(), entity.DeviceId ?? "", Guid.NewGuid().ToString("N"));
                DeviceAuditLogEntity logEntity = new DeviceAuditLogEntity(partitionKey, rowKey);
                logEntity.InTime = entity.InTime.ToString(CommonConstants.LONG_DATE_TIME_FORMAT);
                logEntity.OutTime = entity.OutTime.ToString(CommonConstants.LONG_DATE_TIME_FORMAT);
                logEntity.ResponseBody = entity.ResponseBody;
                logEntity.ResponseCode = entity.ResponseCode;
                logEntity.RequestBody = entity.RequestBody;
                logEntity.RequestHeaders = entity.RequestHeaders;
                logEntity.ResponseHeaders = entity.ResponseHeaders;
                logEntity.DeviceId = entity.DeviceId;
                logEntity.SourceIP = entity.SourceIP;

                this.tableRepositoryManager.SaveIncomingDeviceDetail(logEntity);
            }
            catch (Exception exp)
            {
                Logger.Error(exp.Message);
            }
        }



        public DeviceAssociation GetDeviceAssociation(string deviceId)
        {
            throw new NotImplementedException();
        }

        public ProcessResponseForGateway SaveDeviceAlert(string deviceAlerts)
        {
#if DEBUG
            DeviceTrafficTrace traceEntity = new DeviceTrafficTrace() 
            {
                PartitionKey = DateTime.UtcNow.ToString(CommonConstants.PARTITION_DATE_FORMAT),
                DeviceId = deviceAlerts,
                InTime = DateTime.UtcNow,
                Section = "DataWorker.SaveDeviceAlert"
            };
#endif
            ProcessResponseForGateway response = new ProcessResponseForGateway();

            try
            {
                if (queueManager == null)
                    queueManager = QueueRepositoryManager.ManagerInstance();

                queueManager.InsertDeviceAlert(deviceAlerts);
                response.status = AlertEngineConstants.STATUS_SUCCESS;
                response.message = AlertEngineConstants.MESSAGE_SUCCESS;
            }
            catch (Exception ex)
            {
                response.status = AlertEngineConstants.STATUS_FAIL;
                response.message = ex.Message;
            }
#if DEBUG
            traceEntity.OutTime = DateTime.UtcNow;
            traceEntity.Duration = traceEntity.OutTime.Subtract(traceEntity.InTime);
            new AuditWorker().TraceDeviceTraffic(traceEntity);
#endif
            return response;
        }


        public ProcessResponseForGateway SaveDeviceForCache(string deviceId)
        {
            ProcessResponseForGateway response = new ProcessResponseForGateway();

            try
            {
                if (queueManager == null)
                    queueManager = QueueRepositoryManager.ManagerInstance();
#if DEBUG
                DeviceTrafficTrace traceEntity = new DeviceTrafficTrace()
                {
                    PartitionKey = DateTime.UtcNow.ToString(CommonConstants.PARTITION_DATE_FORMAT),
                    DeviceId = deviceId,
                    InTime = DateTime.UtcNow,
                    Section = "DataWorker.SaveDeviceForCache"
                };
#endif
                queueManager.InsertDeviceUpdate(deviceId);
#if DEBUG
                traceEntity.OutTime = DateTime.UtcNow;
                traceEntity.Duration = traceEntity.OutTime.Subtract(traceEntity.InTime);
                new AuditWorker().TraceDeviceTraffic(traceEntity);
#endif
                response.status = AlertEngineConstants.STATUS_SUCCESS;
                response.message = AlertEngineConstants.MESSAGE_SUCCESS;
            }
            catch (Exception ex)
            {
                response.status = AlertEngineConstants.STATUS_FAIL;
                response.message = ex.Message;
            }

            return response;
        }

        public System.Collections.Generic.List<DeviceResolutionDetail> GetAllDevicesForBuilding(int buildingId)
        {
            throw new NotImplementedException();
        }

        public List<DeviceResolutionDetail> GetAlleHRTDevicesForUser(int userId, int roleLevel, int customerId)
        {
            throw new NotImplementedException();
        }

        List<DeviceLog> IDeviceWorker.GetAllDeviceLogsForDevice(string deviceId)
        {
            throw new NotImplementedException();
        }

        public bool IfAlertExists(string deviceID, string alertType)
        {
            throw new NotImplementedException();
        }

        public string GetDeviceAlertCode(string alertName, string deviceType)
        {
            throw new NotImplementedException();
        }

        public List<DeviceResolutionDetail> GetAllDevicesForBuilding(int propertyId, int buildingId, int floorId, int washroomId)
        {
            throw new NotImplementedException();
        }

        public List<DeviceRefillDetail> GetAllSoapDevicesForBuilding(int buildingId)
        {
            throw new NotImplementedException();
        }

        public List<DeviceResolutionDetail> GetAllDevicesForUser(int userId, int roleLevel, int customerId, int buildingId)
        {
            throw new NotImplementedException();
        }

        public DeviceSizeAndDispensedValue GetDeviceSizeandLastDispensedValue(int customerId, string deviceId, Enums.DeviceType type)
        {
            //KeyValuePair<string, KeyValuePair<int, double>> deviceSizeandDispensedValue = new KeyValuePair<string, KeyValuePair<int, double>>();
            DeviceSizeAndDispensedValue deviceSizeandDispensedValue = null;
            var deviceRefills = new List<DeviceRefillDetail>();
            string query = TableQuery.CombineFilters(
                                                    TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, customerId.ToString()),
                                                    TableOperators.And,
                                                    TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.Equal, deviceId)
                                                );

            switch (type)
            {
                case Enums.DeviceType.eSoap:
                    IEnumerable<eSoapEntity> eSoapDevices = this.tableRepositoryManager.GetDeviceStatuseSoapEntity(new TableQuery<eSoapEntity>().Where(query));
                    if (eSoapDevices != null && eSoapDevices.Count() > 0)
                    {
                        //deviceSizeandDispensedValue = new KeyValuePair<string, KeyValuePair<int, double>>(eSoapDevices.First().RefillSize.ToString(), new KeyValuePair<int, double>(eSoapDevices.First().NoOfDispensesSinceLastRefill, eSoapDevices.First().CurrentBatteryVoltage));
                        deviceSizeandDispensedValue = new DeviceSizeAndDispensedValue();
                        deviceSizeandDispensedValue.DeviceSize = eSoapDevices.FirstOrDefault().RefillSize;
                        deviceSizeandDispensedValue.ShotSize = eSoapDevices.FirstOrDefault().Shot;
                        deviceSizeandDispensedValue.DeviceSinceLastDispensed = eSoapDevices.FirstOrDefault().NoOfDispensesSinceLastRefill;

                        deviceSizeandDispensedValue.CurrentBatteryVoltage = eSoapDevices.FirstOrDefault().CurrentBatteryVoltage;
                    }
                    break;

                case Enums.DeviceType.JRT:
                    IEnumerable<JRTEntity> jrtDevices = this.tableRepositoryManager.GetDeviceStatusJRTEntity(new TableQuery<JRTEntity>().Where(query));
                    if (jrtDevices != null && jrtDevices.Count() > 0)
                    {
                        //deviceSizeandDispensedValue = new KeyValuePair<string, KeyValuePair<int, double>>("S", new KeyValuePair<int, double>((int)jrtDevices.First().PaperRollRemainingPercent, jrtDevices.First().BatteryVoltage));
                        deviceSizeandDispensedValue = new DeviceSizeAndDispensedValue();
                        deviceSizeandDispensedValue.DeviceSize = "S";
                        deviceSizeandDispensedValue.DeviceSinceLastDispensed = (int)jrtDevices.FirstOrDefault().PaperRollRemainingPercent;
                        deviceSizeandDispensedValue.CurrentBatteryVoltage = jrtDevices.FirstOrDefault().BatteryVoltage;
                    }
                    break;

                case Enums.DeviceType.SRB:
                    IEnumerable<SRBEntity> srbDevices = this.tableRepositoryManager.GetDeviceStatusJRTEntity(new TableQuery<SRBEntity>().Where(query));
                    if (srbDevices != null && srbDevices.Count() > 0)
                    {
                        //deviceSizeandDispensedValue = new KeyValuePair<string, KeyValuePair<int, double>>("S", new KeyValuePair<int, double>((int)srbDevices.First().PaperRollRemainingPercent, srbDevices.First().BatteryVoltage));
                        deviceSizeandDispensedValue = new DeviceSizeAndDispensedValue();

                        deviceSizeandDispensedValue.DeviceSize = "S";
                        deviceSizeandDispensedValue.DeviceSinceLastDispensed = (int)srbDevices.FirstOrDefault().PaperRollRemainingPercent;
                        deviceSizeandDispensedValue.CurrentBatteryVoltage = srbDevices.FirstOrDefault().BatteryVoltage;
                    }
                    break;
                case Enums.DeviceType.eHRT:
                    IEnumerable<eHRTEntity> eHRTDevices = this.tableRepositoryManager.GetDeviceStatuseHRTEntity(new TableQuery<eHRTEntity>().Where(query));
                    if (eHRTDevices != null && eHRTDevices.Count() > 0)
                    {
                        //deviceSizeandDispensedValue = new KeyValuePair<string, KeyValuePair<int, double>>(eHRTDevices.First().DispenseLength.ToString(), new KeyValuePair<int, double>(eHRTDevices.First().PaperDispensedSinceLastRefill, eHRTDevices.First().CurrentBatteryVoltage));
                        deviceSizeandDispensedValue = new DeviceSizeAndDispensedValue();
                        //deviceSizeandDispensedValue.DeviceSize = "S"; // Pick this from DEvice SPecific preference stored in SQL Azure..
                        deviceSizeandDispensedValue.DeviceSinceLastDispensed = eHRTDevices.FirstOrDefault().PaperDispensedSinceLastRefill;
                        deviceSizeandDispensedValue.CurrentBatteryVoltage = eHRTDevices.FirstOrDefault().CurrentBatteryVoltage;
                    }
                    break;

            }

            return deviceSizeandDispensedValue;
        }

        public JRTParameters GetJRTDeviceStatus(int customerId, string deviceId)
        {
            JRTParameters deviceBatteryAndPaper = new JRTParameters();
            string query = TableQuery.CombineFilters(
                                                   TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, customerId.ToString()),
                                                   TableOperators.And,
                                                   TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.Equal, deviceId)
                                               );
            IEnumerable<JRTEntity> jrtDevices = this.tableRepositoryManager.GetDeviceStatusJRTEntity(new TableQuery<JRTEntity>().Where(query));
            if (jrtDevices != null && jrtDevices.Count() > 0)
            {
                deviceBatteryAndPaper.BatteryVoltage = (decimal)jrtDevices.FirstOrDefault().BatteryVoltage;
                deviceBatteryAndPaper.PaperRollRemainingPercent = (decimal)jrtDevices.FirstOrDefault().PaperRollRemainingPercent;
            }
            return deviceBatteryAndPaper;
        }

        public eHRTParameters GetEhrtDeviceStatus(int customerId, string deviceId)
        {
            eHRTParameters deviceBatteryAndPaper = new eHRTParameters();
            string query = TableQuery.CombineFilters(
                                                               TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, customerId.ToString()),
                                                               TableOperators.And,
                                                               TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.Equal, deviceId)
                                                           );
            IEnumerable<eHRTEntity> ehrtDevices = this.tableRepositoryManager.GetDeviceStatuseHRTEntity(new TableQuery<eHRTEntity>().Where(query));
            if (ehrtDevices != null && ehrtDevices.Count() > 0)
            {
                deviceBatteryAndPaper.CurrentBatteryVoltage = (decimal)ehrtDevices.FirstOrDefault().CurrentBatteryVoltage;
                deviceBatteryAndPaper.PaperDispensedSinceLastRefill = ehrtDevices.FirstOrDefault().PaperDispensedSinceLastRefill;
            }
            return deviceBatteryAndPaper;
        }

        public eSoapParameters GetEsoapDeviceStatus(int customerId, string deviceId)
        {
            eSoapParameters deviceBatteryAndPaper = new eSoapParameters();
            string query = TableQuery.CombineFilters(
                                                   TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, customerId.ToString()),
                                                   TableOperators.And,
                                                   TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.Equal, deviceId)
                                               );
            IEnumerable<eSoapEntity> esoapDevices = this.tableRepositoryManager.GetDeviceStatuseSoapEntity(new TableQuery<eSoapEntity>().Where(query));
            if (esoapDevices != null && esoapDevices.Count() > 0)
            {
                deviceBatteryAndPaper.CurrentBatteryVoltage = (decimal)esoapDevices.FirstOrDefault().CurrentBatteryVoltage;
                deviceBatteryAndPaper.NoOfDispensesSinceLastRefill = esoapDevices.FirstOrDefault().NoOfDispensesSinceLastRefill;
            }
            return deviceBatteryAndPaper;
        }

        public SRBParameters GetSRBDeviceStatus(int customerId, string deviceId)
        {
            SRBParameters deviceBatteryAndPaper = new SRBParameters();
            string query = TableQuery.CombineFilters(
                                                   TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, customerId.ToString()),
                                                   TableOperators.And,
                                                   TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.Equal, deviceId)
                                               );
            IEnumerable<SRBEntity> srbDevices = this.tableRepositoryManager.GetDeviceStatusJRTEntity(new TableQuery<SRBEntity>().Where(query));
            if (srbDevices != null && srbDevices.Count() > 0)
            {
                deviceBatteryAndPaper.BatteryVoltage = (decimal)srbDevices.FirstOrDefault().BatteryVoltage;
                deviceBatteryAndPaper.PaperRollRemainingPercent = (decimal)srbDevices.FirstOrDefault().PaperRollRemainingPercent;
            }
            return deviceBatteryAndPaper;
        }

        public List<BusinessEntities.AlertEngineEntities.DeviceAlert> CheckUnresponsive(int customerId, List<DeviceResolutionDetail> Alldevices)
        {

            BusinessEntities.AlertEngineEntities.DeviceAlert unresponsiveDevice = new BusinessEntities.AlertEngineEntities.DeviceAlert();

            TableQuery<DeviceEntity> query = new TableQuery<DeviceEntity>().Where(
                                                   TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, customerId.ToString())
                                           );

            IEnumerable<DeviceEntity> devices = this.tableRepositoryManager.GetDeviceStatusEntity(query);
            double minutesToDeduct = double.Parse(CommonHelper.GetConfigSetting("UnresponsiveDevicesDurationInMin"));

            var unresponsiveDevices = (from Alldevice in Alldevices
                                       join device in devices
                                       on
                                       Alldevice.DeviceID equals device.DeviceId
                                       where device.Timestamp.DateTime < DateTime.UtcNow.AddMinutes(0 - minutesToDeduct)
                                       select new KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert
                                       {
                                           DeviceId = device.DeviceId,
                                           DeviceName = Alldevice.DeviceName,

                                           FloorLevel = Alldevice.Floor,
                                           WashroomName = Alldevice.Washroom,

                                           Gender = Alldevice.WashroomGender,
                                           DateTime = device.Timestamp.UtcDateTime,
                                           LocalTimeZone = Alldevice.LocalTimeZone

                                       }).ToList<KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert>();


            return unresponsiveDevices;
        }
        public IList<DeviceAlertGroupInfo> GetDeviceAlertTypes(string deviceType)
        {
            throw new NotImplementedException();
        }
        public DeviceInformation GetDeviceAlertStatus(string deviceID)
        {
            throw new NotImplementedException();
        }

        public ProcessResponse ClearAllDeviceOverrides(List<int?> parameterIds, int customerId)
        {
            throw new NotImplementedException();
        }
        public IList<DeviceResolutionDetail> GetDeviceInfo(int propertyId, IList<string> deviceIdList)
        {
            throw new NotImplementedException();
        }

        public void DeleteDeviceStatus(string deviceId, int customerId)
        {
            TableQuery<DeviceEntity> query = new TableQuery<DeviceEntity>().Where(TableQuery.CombineFilters(
                                                   TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, customerId.ToString()),
                                                   TableOperators.And,
                                                   TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.Equal, deviceId)
                                               ));

            IEnumerable<DeviceEntity> devices = this.tableRepositoryManager.GetDeviceStatusEntity(query);
            devices.ToList().ForEach(d => this.tableRepositoryManager.DeleteDeviceStatus(d));
            //this.tableRepositoryManager.DeleteDeviceStatus(new DeviceEntity(customerId.ToString(), deviceId));           
        }

        public void DeleteAlertStatus(string deviceId, int customerId)
        {
            //TableQuery<AlertStatusEntity> query = new TableQuery<AlertStatusEntity>().Where(
            //                                  TableQuery.CombineFilters(
            //                                      TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, customerId.ToString()),
            //                                      TableOperators.And,
            //                                      TableQuery.GenerateFilterCondition("DeviceId", QueryComparisons.GreaterThan, deviceId)
            //                                  )
            //                              );
            TableQuery<AlertStatusEntity> query = new TableQuery<AlertStatusEntity>().Where(
                                                  TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, customerId.ToString())
                                          );
            IEnumerable<AlertStatusEntity> AllAlertStatus = this.tableRepositoryManager.GetDeviceAlertStatus(query);
            IEnumerable<AlertStatusEntity> alertStatus = (from audit in AllAlertStatus
                                                          where audit.RowKey.Contains(deviceId)
                                                          select audit).ToList();

            alertStatus.ToList().ForEach(d => this.tableRepositoryManager.DeleteAlertStatus(d));
            //IEnumerable<AlertStatusEntity> alertStatus = this.tableRepositoryManager.GetDeviceStatusEntity(query);
        }
    }
}
