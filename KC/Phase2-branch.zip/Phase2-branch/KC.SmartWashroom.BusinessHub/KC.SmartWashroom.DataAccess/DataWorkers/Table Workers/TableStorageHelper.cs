﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers;
using KC.SmartWashroom.DataAccess.Skeleton;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;

namespace KC.SmartWashroom.DataAccess.DataWorkers.Table_Workers
{
    public class TableStorageHelper : ITableStorageHelper
    {
        private CloudStorageAccount storageAccount;
        private CloudTableClient tableClient;
        private CloudTable table;

        public TableStorageHelper()
        {
            storageAccount = CloudStorageAccount.Parse(CommonHelper.GetConfigSetting("Microsoft.WindowsAzure.Plugins.Diagnostics.ConnectionString").ToString());
            tableClient = storageAccount.CreateCloudTableClient();
        }

        private static string GetPartitionKey(DateTime Date, int CustomerId, int PropertyId)
        {
            String PartitionKey = String.Format("{0:yyyyMMdd}", Date) + "_" + CustomerId + "_" + PropertyId;
            return PartitionKey;
        }

        private static string GetPartitionKeyAlertLog(DateTime Date, int CustomerId, int PropertyId)
        {
            String PartitionKey = Date.InverseDays() + "_" + CustomerId + "_" + PropertyId;
            return PartitionKey;
        }

        public List<AlertEntity> ReadAlertData(DateTime date, BusinessEntities.Property Property)
        {
            table = tableClient.GetTableReference(CommonHelper.GetConfigSetting("AlertTableName").ToString());
            table.CreateIfNotExists();

            String PartitionKey = GetPartitionKeyAlertLog(date, Property.CustomerId, Property.ID);
            TableQuery<AlertEntity> query = new TableQuery<AlertEntity>().Where(
                TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, PartitionKey));

            List<AlertEntity> AlertList = new List<AlertEntity>();
            TableQuerySegment<AlertEntity> currentSegment = null;
            while (currentSegment == null || currentSegment.ContinuationToken != null)
            {
                currentSegment = table.ExecuteQuerySegmented(query, currentSegment != null ? currentSegment.ContinuationToken : null);
                AlertList.AddRange(currentSegment.Results);
            }

            return AlertList;
        }

        public List<eHRTEntityLog> EHRTData(DateTime date, BusinessEntities.Property Property)
        {
            table = tableClient.GetTableReference(CommonHelper.GetConfigSetting("DeviceLogsTableName").ToString());
            table.CreateIfNotExists();

            String PartitionKey = GetPartitionKey(date, Property.CustomerId, Property.ID);
            //TableQuery<Common.eHRTEntity> query = new TableQuery<Common.eHRTEntity>().Where(TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, PartitionKey));
            TableQuery<eHRTEntityLog> query = new TableQuery<eHRTEntityLog>().Where(
                TableQuery.CombineFilters(TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, PartitionKey),
                TableOperators.And, TableQuery.GenerateFilterConditionForInt("DeviceType", QueryComparisons.Equal, Convert.ToInt32(TrafficChartConstants.eHRT))));

            List<eHRTEntityLog> eHRTList = new List<eHRTEntityLog>();

            TableQuerySegment<eHRTEntityLog> currentSegment = null;
            while (currentSegment == null || currentSegment.ContinuationToken != null)
            {
                currentSegment = table.ExecuteQuerySegmented(query, currentSegment != null ? currentSegment.ContinuationToken : null);
                eHRTList.AddRange(currentSegment.Results);
            }

            return eHRTList;
        }

        public List<JRTEntityLog> JRTData(DateTime date, BusinessEntities.Property Property)
        {
            table = tableClient.GetTableReference(CommonHelper.GetConfigSetting("DeviceLogsTableName").ToString());
            table.CreateIfNotExists();

            String PartitionKey = GetPartitionKey(date, Property.CustomerId, Property.ID);
            //TableQuery<Common.eHRTEntity> query = new TableQuery<Common.eHRTEntity>().Where(TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, PartitionKey));
            TableQuery<JRTEntityLog> query = new TableQuery<JRTEntityLog>().Where(
                TableQuery.CombineFilters(TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, PartitionKey),
                TableOperators.And, TableQuery.GenerateFilterConditionForInt("DeviceType",
                QueryComparisons.Equal, Convert.ToInt32(TrafficChartConstants.JRT))));

            List<JRTEntityLog> JRTList = new List<JRTEntityLog>();

            TableQuerySegment<JRTEntityLog> currentSegment = null;
            while (currentSegment == null || currentSegment.ContinuationToken != null)
            {
                currentSegment = table.ExecuteQuerySegmented(query, currentSegment != null ? currentSegment.ContinuationToken : null);
                JRTList.AddRange(currentSegment.Results);
            }

            return JRTList;
        }

        public List<SRBEntityLog> SRBData(DateTime date, BusinessEntities.Property Property)
        {
            table = tableClient.GetTableReference(CommonHelper.GetConfigSetting("DeviceLogsTableName").ToString());
            table.CreateIfNotExists();

            String PartitionKey = GetPartitionKey(date, Property.CustomerId, Property.ID);
            //TableQuery<Common.eHRTEntity> query = new TableQuery<Common.eHRTEntity>().Where(TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, PartitionKey));
            TableQuery<SRBEntityLog> query = new TableQuery<SRBEntityLog>().Where(
                TableQuery.CombineFilters(TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, PartitionKey),
                TableOperators.And, TableQuery.GenerateFilterConditionForInt("DeviceType",
                QueryComparisons.Equal, Convert.ToInt32(TrafficChartConstants.SRB))));

            List<SRBEntityLog> SRBList = new List<SRBEntityLog>();

            TableQuerySegment<SRBEntityLog> currentSegment = null;
            while (currentSegment == null || currentSegment.ContinuationToken != null)
            {
                currentSegment = table.ExecuteQuerySegmented(query, currentSegment != null ? currentSegment.ContinuationToken : null);
                SRBList.AddRange(currentSegment.Results);
            }

            return SRBList;
        }

        public List<eSoapEntityLog> ESOAPData(DateTime date, BusinessEntities.Property Property)
        {
            table = tableClient.GetTableReference(CommonHelper.GetConfigSetting("DeviceLogsTableName").ToString());
            table.CreateIfNotExists();

            String PartitionKey = GetPartitionKey(date, Property.CustomerId, Property.ID);
            //TableQuery<Common.eHRTEntity> query = new TableQuery<Common.eHRTEntity>().Where(TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, PartitionKey));
            TableQuery<eSoapEntityLog> query = new TableQuery<eSoapEntityLog>().Where(
                TableQuery.CombineFilters(TableQuery.GenerateFilterCondition("PartitionKey",
                QueryComparisons.Equal, PartitionKey), TableOperators.And,
                TableQuery.GenerateFilterConditionForInt("DeviceType", QueryComparisons.Equal, Convert.ToInt32(TrafficChartConstants.eSoap))));

            List<eSoapEntityLog> eSoapList = new List<eSoapEntityLog>();

            TableQuerySegment<eSoapEntityLog> currentSegment = null;
            while (currentSegment == null || currentSegment.ContinuationToken != null)
            {
                currentSegment = table.ExecuteQuerySegmented(query, currentSegment != null ? currentSegment.ContinuationToken : null);
                eSoapList.AddRange(currentSegment.Results);
            }

            return eSoapList;
        }

        public List<AlertEntity> GetBatteryResolvedAlertsForSRB(DateTime Date, BusinessEntities.Property Property)
        {
            table = tableClient.GetTableReference(CommonHelper.GetConfigSetting("AlertTableName").ToString());
            table.CreateIfNotExists();

            String PartitionKey = GetPartitionKeyAlertLog(Date, Property.CustomerId, Property.ID);
            TableQuery<AlertEntity> query = new TableQuery<AlertEntity>().Where(
                TableQuery.CombineFilters((TableQuery.CombineFilters((TableQuery.CombineFilters((TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, PartitionKey))
                , TableOperators.And, TableQuery.GenerateFilterCondition("DeviceType", QueryComparisons.Equal, TrafficChartConstants.SRB)))
                , TableOperators.And, TableQuery.GenerateFilterCondition("AlertType", QueryComparisons.Equal, AlertChartConstants.SRBLowBatteryCode)))
                , TableOperators.And, TableQuery.GenerateFilterConditionForInt("IsAlert", QueryComparisons.Equal, 0)));

            List<AlertEntity> AlertList = new List<AlertEntity>();
            TableQuerySegment<AlertEntity> currentSegment = null;
            while (currentSegment == null || currentSegment.ContinuationToken != null)
            {
                currentSegment = table.ExecuteQuerySegmented(query, currentSegment != null ? currentSegment.ContinuationToken : null);
                AlertList.AddRange(currentSegment.Results);
            }

            return AlertList;
        }

        public List<AlertEntity> GetBatteryResolvedAlertsForJRT(DateTime Date, BusinessEntities.Property Property)
        {
            table = tableClient.GetTableReference(CommonHelper.GetConfigSetting("AlertTableName").ToString());
            table.CreateIfNotExists();

            String PartitionKey = GetPartitionKeyAlertLog(Date, Property.CustomerId, Property.ID);
            TableQuery<AlertEntity> query = new TableQuery<AlertEntity>().Where(
                TableQuery.CombineFilters((TableQuery.CombineFilters((TableQuery.CombineFilters((TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, PartitionKey))
                , TableOperators.And, TableQuery.GenerateFilterCondition("DeviceType", QueryComparisons.Equal, TrafficChartConstants.JRT)))
                , TableOperators.And, TableQuery.GenerateFilterCondition("AlertType", QueryComparisons.Equal, AlertChartConstants.JRTLowBatteryCode)))
                , TableOperators.And, TableQuery.GenerateFilterConditionForInt("IsAlert", QueryComparisons.Equal, 0)));

            List<AlertEntity> AlertList = new List<AlertEntity>();
            TableQuerySegment<AlertEntity> currentSegment = null;
            while (currentSegment == null || currentSegment.ContinuationToken != null)
            {
                currentSegment = table.ExecuteQuerySegmented(query, currentSegment != null ? currentSegment.ContinuationToken : null);
                AlertList.AddRange(currentSegment.Results);
            }

            return AlertList;
        }
    }
}
