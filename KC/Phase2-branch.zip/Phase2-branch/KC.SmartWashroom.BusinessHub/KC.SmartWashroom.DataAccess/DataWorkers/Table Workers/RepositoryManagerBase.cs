﻿using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.Core.Helper.CloudHelper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.DataAccess.DataWorkers.Table_Workers
{
    internal class RepositoryManagerBase
    {
        private static readonly string connectionString = string.Empty;
        internal static Table tableStore { get; private set; }
        protected static Queue queueStore { get; private set; }

        static RepositoryManagerBase()
        {
            connectionString = CommonHelper.GetConfigSetting("Microsoft.WindowsAzure.Plugins.Diagnostics.ConnectionString");
            tableStore = Table.GetInstance(connectionString);
            queueStore = Queue.GetInstance(connectionString);
        }
    }
}
