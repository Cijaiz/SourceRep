﻿using KC.SmartWashroom.DataAccess.Skeleton;
using System;
using System.Linq;

namespace KC.SmartWashroom.DataAccess.DataWorkers.Table_Workers
{
    using BusinessEntity = KC.SmartWashroom.BusinessEntities;
    using KC.SmartWashroom.BusinessEntities.DashboardApiEntities;
    using KC.SmartWashroom.Core.Helper;
    using KC.SmartWashroom.DataAccess.DataWorkers.Table_Workers;
    using Microsoft.WindowsAzure.Storage.Table;
    using System.Collections.Generic;
    using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
    using KC.SmartWashroom.Core.Constants;

    public class UserWorker :WorkerBase, IUserWorker
    {
          public DeviceDetail GetUserDetails(string deviceId)
        {
            throw new NotImplementedException();
        }

        public DeviceDetail GetErrorAdminDetails()
        {
            throw new NotImplementedException();
        }

        public ProcessResponse<KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert> SaveDeviceAlert(KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert deviceAlert)
        {
            throw new NotImplementedException();
        }

        public ProcessResponse<KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert> RemoveDeviceAlert(KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert deviceAlert)
        {
            throw new NotImplementedException();
        }

        public List<BusinessEntity.TenantApiEntities.Role> GetRoles()
        {
            throw new NotImplementedException();
        }

        public List<BusinessEntity.Property> GetProperties(int customerId)
        {
            throw new NotImplementedException();
        }

        public List<BusinessEntity.Building> GetBuildings(int customerId)
        {
            throw new NotImplementedException();
        }


        public BusinessEntity.TenantApiEntities.User GetUserDetails(int userId)
        {
            throw new NotImplementedException();
        }

        public System.Collections.Generic.List<UserEntity> GetContactsForCustomer(int customerID, int buildingId)
        {
            throw new NotImplementedException();
        }

        public ProcessResponse<BusinessEntity.TenantApiEntities.User> CreateUser(BusinessEntity.TenantApiEntities.User User)
        {
            throw new NotImplementedException();
        }

        public ProcessResponse<BusinessEntity.TenantApiEntities.User> UpdateUser(BusinessEntity.TenantApiEntities.User User)
        {
            throw new NotImplementedException();
        }

        public ProcessResponse<BusinessEntity.TenantApiEntities.User> DeleteUser(BusinessEntity.TenantApiEntities.User User)
        {
            throw new NotImplementedException();
        }


        public List<BusinessEntity.RolePermission> GetRolePermissions(short roleId)
        {
            throw new NotImplementedException();
        }

        public ProcessResponseForGateway SaveAccountInfo(string accountInfo)
        {
            ProcessResponseForGateway response = new ProcessResponseForGateway();

            try
            {
                QueueRepositoryManager.ManagerInstance().InsertEmergencyqueueInfo(accountInfo);
                response.status = AlertEngineConstants.STATUS_SUCCESS;
                response.message = AlertEngineConstants.MESSAGE_SUCCESS;
            }
            catch (Exception ex)
            {
                response.status = AlertEngineConstants.STATUS_FAIL;
                response.message = ex.Message;
            }

            return response;
        }

        public string GetUserContactInfo(string UserName)
        {
            throw new NotImplementedException();
        }


    }
}
