﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.DataAccess.Skeleton;
using System;

namespace KC.SmartWashroom.DataAccess.DataWorkers.Table_Workers
{
    public class AuditWorker : WorkerBase, IAuditWorker
    {
        public Core.Helper.ProcessResponse LogAuditActivity(BusinessEntities.Audit auditDetail)
        {
            ProcessResponse response = new ProcessResponse();
            try
            {
                string rowKey = string.Format("{0}_{1}_{2}", CommonHelper.GetInverseTimestamp(), auditDetail.PerformedBy, Guid.NewGuid().ToString("N"));
                string partitionKey = string.Format("{0}_{1}", DateTime.UtcNow.ToString(CommonConstants.PARTITION_DATE_FORMAT), auditDetail.AuditActivityType.ToString());
                AuditEntity auditEntity = new AuditEntity(partitionKey, rowKey);
                auditEntity.AuditInfo = auditDetail.AuditInfo;
                auditEntity.PerformedBy = auditDetail.PerformedBy;
                auditEntity.CreatedOn = DateTime.UtcNow.ToString(CommonConstants.LONG_DATE_TIME_FORMAT);
                this.tableRepositoryManager.SaveAuditLog(auditEntity);

                response.Status = ResponseStatus.Success;
                response.Message = AlertEngineConstants.MESSAGE_SUCCESS;
            }
            catch (Exception ex)
            {
                response.Status = ResponseStatus.Error;
                response.Message = ex.Message;
            }
            return response;
        }

        public void TraceDeviceTraffic(DeviceTrafficTrace entity)
        {
            string rowKey = string.Format("{0}_{1}", CommonHelper.GetInverseTimestamp(), Guid.NewGuid().ToString("N"));
            DeviceTrafficTraceEntity traceEntity = new DeviceTrafficTraceEntity(entity.PartitionKey, rowKey);
            traceEntity.Correlation = entity.DeviceId;
            traceEntity.InTime = entity.InTime.ToString(CommonConstants.LONG_DATE_TIME_FORMAT);
            traceEntity.OutTime = entity.OutTime.ToString(CommonConstants.LONG_DATE_TIME_FORMAT);
            traceEntity.Section = entity.Section;

            traceEntity.Duration = entity.Duration.ToString();
            this.tableRepositoryManager.TraceDeviceTraffic(traceEntity);
        }
    }
}
