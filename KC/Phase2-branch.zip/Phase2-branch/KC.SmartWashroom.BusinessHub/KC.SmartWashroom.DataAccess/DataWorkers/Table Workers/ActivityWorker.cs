﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.BusinessHubEntities;
using KC.SmartWashroom.BusinessEntities.DashboardApiEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.DataAccess.Skeleton;
using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.DataAccess.DataWorkers.Table_Workers
{
    public class ActivityWorker : WorkerBase, IActivityWorker
    {
        public const string DATE_FORMAT = "dd'-'MM'-'yyyy  HH:mm:ss:fff tt";
        public ProcessResponse<Activity> CreateActivity(Activity activity)
        {
            throw new NotImplementedException();
        }
        public Activity GetActivity(int activity)
        {
            throw new NotImplementedException();
        }

        public BuildingEntity GetActivities(int customerId)
        {
            throw new NotImplementedException();
        }
        public BuildingEntity GetActivitiesByFilter(int customerId, string alertType, DateTime fromDate, DateTime toDate)
        {
            throw new NotImplementedException();
        }

        public List<string> GetAllAlertTypes()
        {
            throw new NotImplementedException();
        }

        public List<string> GetAlertTypesForDeviceType(byte deviceTypeId)
        {
            throw new NotImplementedException();
        }

        public List<DeviceTypes> GetAllDeviceTypes()
        {
            throw new NotImplementedException();
        }

        public List<Gender> GetAllRoomTypes()
        {
            throw new NotImplementedException();
        }

        public List<Property> GetAllProperties(int customerId)
        {
            throw new NotImplementedException();
        }

        public List<Floor> GetAllFloors(int buildingId)
        {
            throw new NotImplementedException();
        }

        public List<Building> GetAllBuildings(int customerId, int propertyId)
        {
            throw new NotImplementedException();
        }

        public int CountOutstandingDeviceAlerts(int userId, int roleLevel)
        {
            throw new NotImplementedException();
        }
        public int CountOutstandingDeviceAlertsFilter(int customerId, string alertType, DateTime fromDate, DateTime toDate)
        {
            throw new NotImplementedException();
        }

        public int SumEhrtDevices(SearchCriteria searchCriteria)
        {
            throw new NotImplementedException();
        }

        public int SumDispenseseHRTDevice(int customerId, List<DeviceResolutionDetail> Devices,int days)
        {
            int sumDispenseseHRT=0;
            foreach (DeviceResolutionDetail device in Devices)
            {
                string deviceDetail=string.Empty;
                TableQuery<eHRTEntity> query = new TableQuery<eHRTEntity>().Where(
                                                    TableQuery.CombineFilters(
                                                        TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, customerId.ToString()),
                                                        TableOperators.And,
                                                        TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.Equal, device.DeviceID)
                                                    )
                                                );
                IEnumerable<eHRTEntity> devices = this.tableRepositoryManager.GetDeviceStatuseHRTEntity(query);
                if (devices.Count() > 0)
                {
                    //Get the devicedetail within last 30 days depending on the value passed
                    //deviceDetail = devices.OrderByDescending(o => o.RowKey).Where(o => (DateTime.ParseExact(o.RowKey, DATE_FORMAT, CultureInfo.InvariantCulture)).Subtract(DateTime.UtcNow).Days <= days).FirstOrDefault().DeviceParameter;
                    eHRTEntity entity = devices.First();
                    sumDispenseseHRT = sumDispenseseHRT + entity.TotalDispenseCount + entity.PaperDispensedSinceLastRefill;
                }
            }
            return sumDispenseseHRT;
        }
    }
}
