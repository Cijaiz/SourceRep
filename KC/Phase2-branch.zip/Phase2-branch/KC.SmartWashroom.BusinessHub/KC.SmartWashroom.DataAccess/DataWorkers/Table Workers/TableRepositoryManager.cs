﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.Enumerations;
using KC.SmartWashroom.Core.Helper.CloudHelper;
using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;

namespace KC.SmartWashroom.DataAccess.DataWorkers.Table_Workers
{
    internal class TableRepositoryManager : RepositoryManagerBase
    {
        const string DEVICELOG_TABLE = "Devicelog";
        const string DEVICETRAFFICTRACE_TABLE = "DeviceTrafficTrace";
        const string DEVICESTATUS_TABLE = "DeviceStatus";
        const string ALERTLOG_TABLE = "AlertLog";
        const string INCOMINGDEVICELOG_TABLE = "DeviceAuditLog";
        const string AUDITLOG_TABLE = "AuditLog";

        internal TableRepositoryManager()
        {
            RepositoryManagerBase.tableStore.Create(DEVICELOG_TABLE);
            RepositoryManagerBase.tableStore.Create(DEVICESTATUS_TABLE);

            RepositoryManagerBase.tableStore.Create(ALERTLOG_TABLE);
            RepositoryManagerBase.tableStore.Create(AUDITLOG_TABLE);

            RepositoryManagerBase.tableStore.Create(DEVICETRAFFICTRACE_TABLE);
            RepositoryManagerBase.tableStore.Create(KC.SmartWashroom.Core.Constants.AlertEngineConstants.ENGINE_ALERT_STATUS_TABLE);
        }

        public CloudTable GetTableReference(string tableName)
        {
            if (RepositoryManagerBase.tableStore == null)
                throw new InvalidOperationException("TableStore cannot be null. Please initialize..");

            return RepositoryManagerBase.tableStore.GetTableReference(tableName);
        }

        public void CreateProperty(PropertyTableEntity property)
        {
            RepositoryManagerBase.tableStore.Create(ALERTLOG_TABLE);
            RepositoryManagerBase.tableStore.InsertRow<PropertyTableEntity>(property, ALERTLOG_TABLE);
        }

        public IEnumerable<PropertyTableEntity> GetProperty(TableQuery<PropertyTableEntity> query)
        {
            return RepositoryManagerBase.tableStore.Query<PropertyTableEntity>(ALERTLOG_TABLE, query);
        }

        public void SaveDeviceLog(DeviceEntity deviceEntity)
        {
            RepositoryManagerBase.tableStore.InsertRow<DeviceEntity>(deviceEntity, DEVICELOG_TABLE);
        }

        public void SaveDeviceStatus(DeviceEntity deviceEntity)
        {
            RepositoryManagerBase.tableStore.UpsertRow<DeviceEntity>(deviceEntity, DEVICESTATUS_TABLE);
        }
        public void SaveAuditLog(AuditEntity auditEntity)
        {
            RepositoryManagerBase.tableStore.InsertRow<AuditEntity>(auditEntity, AUDITLOG_TABLE);
        }

        public void SaveIncomingDeviceDetail(DeviceAuditLogEntity entity)
        {
            RepositoryManagerBase.tableStore.Create(INCOMINGDEVICELOG_TABLE);
            RepositoryManagerBase.tableStore.InsertRow<DeviceAuditLogEntity>(entity, INCOMINGDEVICELOG_TABLE);
        }

        public void TraceDeviceTraffic(DeviceTrafficTraceEntity entity)
        {
            RepositoryManagerBase.tableStore.Create(DEVICETRAFFICTRACE_TABLE);
            RepositoryManagerBase.tableStore.InsertRow<DeviceTrafficTraceEntity>(entity, DEVICETRAFFICTRACE_TABLE);
        }

        public dynamic GetDeviceStatusForEachDeviceType(int customerID, string deviceType, string deviceId)
        {
            switch (deviceType)
            {
                case KC.SmartWashroom.Core.Constants.CommonConstants.eSoap:
                    // Create the table query.
                    TableQuery<eSoapEntity> esoapStatusQuery = new TableQuery<eSoapEntity>().Where(
                                                            TableQuery.CombineFilters(
                                                                                    TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, customerID.ToString()),
                                                                                    TableOperators.And,
                                                                                    TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.Equal, deviceId)));
                    return this.GetDeviceStatuseSoapEntity(esoapStatusQuery);
                case KC.SmartWashroom.Core.Constants.CommonConstants.eHRT:
                    // Create the table query.
                    TableQuery<eHRTEntity> eHRTStatusQuery = new TableQuery<eHRTEntity>().Where(
                                                            TableQuery.CombineFilters(
                                                                                    TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, customerID.ToString()),
                                                                                    TableOperators.And,
                                                                                    TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.Equal, deviceId)));
                    return this.GetDeviceStatuseHRTEntity(eHRTStatusQuery);
                case KC.SmartWashroom.Core.Constants.CommonConstants.JRT:
                    // Create the table query.
                    TableQuery<JRTEntity> JRTStatusQuery = new TableQuery<JRTEntity>().Where(
                                                            TableQuery.CombineFilters(
                                                                                    TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, customerID.ToString()),
                                                                                    TableOperators.And,
                                                                                    TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.Equal, deviceId)));
                    return this.GetDeviceStatusJRTEntity(JRTStatusQuery);
                default:
                    throw new InvalidOperationException("Unsupported Device TYpe");
            }
        }

        public IEnumerable<DeviceEntity> GetDeviceStatusEntity(TableQuery<DeviceEntity> query)
        {
            return RepositoryManagerBase.tableStore.Query<DeviceEntity>(DEVICESTATUS_TABLE, query);
        }
        public IEnumerable<eSoapEntity> GetDeviceStatuseSoapEntity(TableQuery<eSoapEntity> query)
        {
            return RepositoryManagerBase.tableStore.Query<eSoapEntity>(DEVICESTATUS_TABLE, query);
        }

        public IEnumerable<eHRTEntity> GetDeviceStatuseHRTEntity(TableQuery<eHRTEntity> query)
        {
            return RepositoryManagerBase.tableStore.Query<eHRTEntity>(DEVICESTATUS_TABLE, query);
        }

        public IEnumerable<JRTEntity> GetDeviceStatusJRTEntity(TableQuery<JRTEntity> query)
        {
            return RepositoryManagerBase.tableStore.Query<JRTEntity>(DEVICESTATUS_TABLE, query);
        }

        public IEnumerable<SRBEntity> GetDeviceStatusJRTEntity(TableQuery<SRBEntity> query)
        {
            return RepositoryManagerBase.tableStore.Query<SRBEntity>(DEVICESTATUS_TABLE, query);
        }

        public IEnumerable<DeviceEntity> GetDevicesForSimulator(TableQuery<DeviceEntity> query)
        {
            return RepositoryManagerBase.tableStore.Query<DeviceEntity>(DEVICESTATUS_TABLE, query);
        }

        public IEnumerable<AlertStatusEntity> GetDeviceAlertStatus(TableQuery<AlertStatusEntity> query)
        {
            return RepositoryManagerBase.tableStore.Query<AlertStatusEntity>(AlertEngineConstants.ENGINE_ALERT_STATUS_TABLE, query);
        }

        public void DeleteDeviceStatus(DeviceEntity deviceEntity)
        {
            RepositoryManagerBase.tableStore.DeleteRow<DeviceEntity>(deviceEntity, DEVICESTATUS_TABLE);
        }

        public void DeleteAlertStatus(AlertStatusEntity alertEntity)
        {
            RepositoryManagerBase.tableStore.DeleteRow<AlertStatusEntity>(alertEntity, AlertEngineConstants.ENGINE_ALERT_STATUS_TABLE);
        }
    }
}