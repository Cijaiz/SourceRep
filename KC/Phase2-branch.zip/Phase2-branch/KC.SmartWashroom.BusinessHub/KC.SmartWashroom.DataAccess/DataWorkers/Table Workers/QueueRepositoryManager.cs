﻿using Microsoft.WindowsAzure.Storage.Queue;

namespace KC.SmartWashroom.DataAccess.DataWorkers.Table_Workers
{
    internal class QueueRepositoryManager : RepositoryManagerBase
    {
        private static readonly QueueRepositoryManager queueRepositoryManager;
        const string ALERT_QUEUE = "lowpriorityqueue";
        const string EMERGENCY_QUEUE = "highpriorityqueue";

        static QueueRepositoryManager()
        {
            if (queueRepositoryManager == null)
                queueRepositoryManager = new QueueRepositoryManager();

            RepositoryManagerBase.queueStore.Create(ALERT_QUEUE);
        }

        internal static QueueRepositoryManager ManagerInstance()
        {
            return queueRepositoryManager;
        }

        public void InsertDeviceAlert(string QueueMessage)
        {
            CloudQueueMessage message = new CloudQueueMessage(QueueMessage);
            RepositoryManagerBase.queueStore.Push(ALERT_QUEUE, message);
        }

        public void InsertDeviceUpdate(string QueueMessage)
        {
#if DEBUG
            KC.SmartWashroom.BusinessEntities.DeviceTrafficTrace traceEntity = new KC.SmartWashroom.BusinessEntities.DeviceTrafficTrace()
            {
                //Asdf
                DeviceId = QueueMessage,
                InTime = System.DateTime.UtcNow,
                Section = "DataWorker.SaveDeviceForCache"
            };
#endif
            CloudQueueMessage message = new CloudQueueMessage(QueueMessage);
            RepositoryManagerBase.queueStore.Push(ALERT_QUEUE, message);
#if DEBUG
            traceEntity.OutTime = System.DateTime.UtcNow;
            traceEntity.Duration = traceEntity.OutTime.Subtract(traceEntity.InTime);
            new AuditWorker().TraceDeviceTraffic(traceEntity);
#endif
        }

        public void InsertEmergencyqueueInfo(string emergencyQueueMessage)
        {
            CloudQueueMessage message = new CloudQueueMessage(emergencyQueueMessage);
            RepositoryManagerBase.queueStore.Create(EMERGENCY_QUEUE);
            RepositoryManagerBase.queueStore.Push(EMERGENCY_QUEUE, message);
        }

        public CloudQueueMessage GetQueueMessage()
        {
            return RepositoryManagerBase.queueStore.GetMessage(ALERT_QUEUE);
        }

        public void DeleteQueueMessage(CloudQueueMessage message)
        {

            RepositoryManagerBase.queueStore.DeleteMessage(ALERT_QUEUE, message);
        }

        public int? GetMessageCount()
        {
            return RepositoryManagerBase.queueStore.GetMessageCount(ALERT_QUEUE);
        }
    }
}
