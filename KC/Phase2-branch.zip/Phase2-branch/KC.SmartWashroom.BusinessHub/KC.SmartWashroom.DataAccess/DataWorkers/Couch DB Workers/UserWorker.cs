﻿using System;
using BusinessEntity = KC.SmartWashroom.BusinessEntities;

namespace KC.SmartWashroom.DataAccess.CouchDBWorkers
{
    using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
    using KC.SmartWashroom.Core.Helper;
    using KC.SmartWashroom.DataAccess.Skeleton;
    using System.Collections.Generic;

    public class UserWorker : IUserWorker
    {
        public DeviceDetail GetUserDetails(string deviceId)
        {
            throw new NotImplementedException();
        }

        public DeviceDetail GetErrorAdminDetails()
        {
            throw new NotImplementedException();
        }

        public ProcessResponse<KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert> SaveDeviceAlert(KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert deviceAlert)
        {
            throw new NotImplementedException();
        }

        public ProcessResponse<KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert> RemoveDeviceAlert(KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert deviceAlert)
        {
            throw new NotImplementedException();
        }

        public List<BusinessEntity.TenantApiEntities.Role> GetRoles()
        {
            throw new NotImplementedException();
        }

        public List<BusinessEntity.Property> GetProperties(int customerId)
        {
            throw new NotImplementedException();
        }

        public List<BusinessEntity.Building> GetBuildings(int customerId)
        {
            throw new NotImplementedException();
        }


        public BusinessEntity.TenantApiEntities.User GetUserDetails(int userId)
        {
            throw new NotImplementedException();
        }

        public System.Collections.Generic.List<UserEntity> GetContactsForCustomer(int customerID, int buildingId)
        {
            throw new NotImplementedException();
        }

        public ProcessResponse<BusinessEntity.TenantApiEntities.User> CreateUser(BusinessEntity.TenantApiEntities.User User)
        {
            throw new NotImplementedException();
        }

        public ProcessResponse<BusinessEntity.TenantApiEntities.User> UpdateUser(BusinessEntity.TenantApiEntities.User User)
        {
            throw new NotImplementedException();
        }

        public ProcessResponse<BusinessEntity.TenantApiEntities.User> DeleteUser(BusinessEntity.TenantApiEntities.User User)
        {
            throw new NotImplementedException();
        }


        public List<BusinessEntity.RolePermission> GetRolePermissions(short roleId)
        {
            throw new NotImplementedException();
        }

        public ProcessResponseForGateway SaveAccountInfo(string accountInfo)
        {
            throw new NotImplementedException();
        }

        public string GetUserContactInfo(string UserName)
        {
            throw new NotImplementedException();
        }
    }


}
