﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.DataAccess.CouchDBWorkers
{
    using KC.SmartWashroom.BusinessEntities;
    using KC.SmartWashroom.BusinessEntities.DashboardApiEntities;
    using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
    using KC.SmartWashroom.Core.Helper;
    using KC.SmartWashroom.DataAccess.Skeleton;

    public class PropertyWorker : IPropertyWorker
    {
        private string _errorDetail;

        string IPropertyWorker.ErrorDetail
        {
            get { return _errorDetail; }
            set { _errorDetail = value; }
        }

        public PropertyWorker()
        {
        }

        public void CreateProperty(Property property)
        {
            //Coding to create property from Store using couch DB Framework..
        }

        public Property GetProperty(int propertyID)
        {
            //Coding to retrive property from Store using couch DB Framework..
            return new BusinessEntities.Property(1, "Property1");
        }

        public ProcessResponse<Property> Create(Property property)
        {
            throw new NotImplementedException();
        }

        public ProcessResponse<Property> Update(Property property)
        {
            throw new NotImplementedException();
        }

        public ProcessResponse<Property> Delete(int propertyID)
        {
            throw new NotImplementedException();
        }

        public IList<PropertyAlert> GetAllProperties(int customerId,int UserId, int duration)
        {
            throw new NotImplementedException();
        }
        public string GetCustomerNameByID(int Id)
        {
            throw new NotImplementedException();
        }

        public List<Timezone> GetAllTimezones()
        {
            throw new NotImplementedException();
        }
    }
}
