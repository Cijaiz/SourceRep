﻿

namespace KC.SmartWashroom.DataAccess.DataWorkers
{
    using KC.SmartWashroom.BusinessEntities.DeviceUpdate;
    using KC.SmartWashroom.BusinessEntities.Linq;
    using KC.SmartWashroom.BusinessEntities.Search;
    using KC.SmartWashroom.DataAccess.Repository;
    using KC.SmartWashroom.DataAccess.Skeleton;
    using System.Collections.Generic;
    using System.Linq;

    public class DeviceMetadataWorker : IDeviceMetadataWorker
    {
        public DeviceMetadataWorker()
            : this(null)
        {

        }

        public DeviceMetadataWorker(string connectionString)
            : this(new DeviceMetadataRepository(connectionString), new ParameterMetadataRepository(connectionString))
        {

        }
        public DeviceMetadataWorker(IDataRepository<DeviceUpdateDetails> deviceDataRepository
            , IDataRepository<DeviceUpdateParameter> parameterDataRepository)
        {
            this.DeviceDataRepository = deviceDataRepository;
            this.ParameterDataRepository = parameterDataRepository;

        }

        public IEnumerable<DeviceUpdateParameter> GetDeviceParameters(DeviceSearchParameters searchParameters)
        {
            var parameters = default(IEnumerable<DeviceUpdateParameter>);

            if (this.ParameterDataRepository != null)
            {
                parameters = this.ParameterDataRepository.GetAll(searchParameters);

            }

            return parameters ?? Enumerable.Empty<DeviceUpdateParameter>();
        }

        public IEnumerable<DeviceUpdateDetails> GetDeviceDetailsWithParameters(DeviceSearchParameters searchParameters)
        {
            var parameterLookup = this.GetDeviceParameters(searchParameters)
                .CleanupAndGroupByDeviceType();

            var deviceCollection = this.GetDeviceDetails(searchParameters);

            foreach (var device in deviceCollection)
            {
                if (parameterLookup.ContainsKey(device.DeviceTypeId))
                {
                    var parameters = parameterLookup[device.DeviceTypeId];
                    foreach (var parameter in parameters)
                    {
                        var clone = parameter.Clone();
                        clone.Device = device;

                        // removing objects that are not relatd
                        for (int index = 0; index < clone.Values.Count; index++)
                        {
                            var value = clone.Values[index];

                            if (!(value.IsDefault // default value
                                || (value.IsCustomerOverride
                                    && value.CustomerId.HasValue && value.CustomerId.Value == device.CustomerId
                                    && string.IsNullOrWhiteSpace(value.DeviceId)) // customer overrride
                                || (value.IsDeviceOverride
                                    && value.CustomerId.HasValue && value.CustomerId.Value == device.CustomerId
                                    && value.DeviceId == device.DeviceId))) // device override
                            {
                                clone.Values.RemoveAt(index);
                                value.Parameter = null;
                                index--;
                            }

                        }

                        device.Parameters.Add(clone);
                    }
                }
                yield return device;
            }
            yield break;
        }

        public IEnumerable<DeviceUpdateDetails> GetDeviceDetails(DeviceSearchParameters searchParameters)
        {
            var devices = default(IEnumerable<DeviceUpdateDetails>);

            if (this.DeviceDataRepository != null)
            {
                devices = this.DeviceDataRepository.GetAll(searchParameters);
            }


            return devices ?? Enumerable.Empty<DeviceUpdateDetails>();
        }

        public void Dispose()
        {
            if (this.DeviceDataRepository != null)
            {
                this.DeviceDataRepository.Dispose();
                this.DeviceDataRepository = null;
            }

            if (this.ParameterDataRepository != null)
            {
                this.ParameterDataRepository.Dispose();
                this.ParameterDataRepository = null;
            }

        }

        public IDataRepository<DeviceUpdateDetails> DeviceDataRepository { get; set; }
        public IDataRepository<DeviceUpdateParameter> ParameterDataRepository { get; set; }
        
    }
}
