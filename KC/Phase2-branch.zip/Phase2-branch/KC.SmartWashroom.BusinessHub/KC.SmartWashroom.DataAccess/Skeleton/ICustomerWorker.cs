﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.Core.Helper;
using System;
using System.Collections.Generic;

namespace KC.SmartWashroom.DataAccess.Skeleton
{
    public interface ICustomerWorker
    {
        string ErrorDetail { get; set; }
        ProcessResponse CreateCustomer(string customerName, string Street, string buildingAddress, string City, string State, string Country, string Zip, int createdBy, DateTime createdOn);
        List<CustomerDetail> GetAllCustomers();
        CustomerDetail GetCustomer(int customerId);
        string GetCustomerName(int propertyId);
        ProcessResponse UpdateCustomer(CustomerDetail customerDetail);
        ProcessResponse DeleteCustomer(int customerIdToDelete);
        List<Countries> GetAllCountries();

        Dictionary<DeviceTypes, List<BusinessEntities.ReturnValueParameter>> GetDeviceParameters(int customerId);
        ProcessResponse<List<ReturnValueParameter>> UpsetReturnParameters(List<ReturnParameterResponse> returnValueParameters, int customerId);
        ProcessResponse DeleteDeviceParameterValues(List<Nullable<int>> paramterValueId);
        List<DeviceParameterValueEntity> GetCustermerLevelDeviceParameterValue(int customerId);
    }
}
