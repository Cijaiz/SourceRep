﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.DashboardApiEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.Core.Helper;
using System.Collections.Generic;

namespace KC.SmartWashroom.DataAccess.Skeleton
{
    public interface IPropertyWorker
    {
        string ErrorDetail { get; set; }
        void CreateProperty(Property property);
        Property GetProperty(int propertyID);
        ProcessResponse<Property> Create(Property property);

        ProcessResponse<Property> Delete(int propertyID);
        ProcessResponse<Property> Update(Property property);
        IList<PropertyAlert> GetAllProperties(int customerId, int userId, int duration);
        string GetCustomerNameByID(int Id);
        List<Timezone> GetAllTimezones();
    }
}
