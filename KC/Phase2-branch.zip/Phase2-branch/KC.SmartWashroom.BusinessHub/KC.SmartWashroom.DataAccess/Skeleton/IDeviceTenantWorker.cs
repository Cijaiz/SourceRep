﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.Core.Helper;
using System.Collections.Generic;

namespace KC.SmartWashroom.DataAccess.Skeleton
{
    public interface IDeviceTenantWorker
    {
        string ErrorDetail { get; set; }

        ProcessResponse<Device> Create(BusinessEntities.TenantApiEntities.Device device);
        ProcessResponse<Device> Update(BusinessEntities.TenantApiEntities.Device device);
        Device GetDevice(string deviceId);
        ProcessResponse Delete(string deviceId);
        List<DeviceTypes> GetDeviceTypes();
        List<RefillSize> GetRefillSize();
        Names GetNames(int washroomId);

        ReturnParameterResponse RetriveReturnParametersForDevice(string deviceId, int customerId, List<DeviceParameterValueEntity> customerParameterValues);

        ProcessResponse DeleteDeviceParameterValues(string deviceId, ReturnParameterDataTransfer dataTransfer);

        ProcessResponse<List<ReturnValueParameter>> DeviceUpsetReturnParameters(string deviceId, List<ReturnParameterResponse> returnValueParameters, int customerId);

        List<BusinessEntities.SearchDeviceDetailsEntity> GetDeviceDetails(string DeviceId);
        bool SaveToDeviceTypesCache();
        DeviceTypes GetDeviceTypesFromCache(string deviceType);
    }
}
