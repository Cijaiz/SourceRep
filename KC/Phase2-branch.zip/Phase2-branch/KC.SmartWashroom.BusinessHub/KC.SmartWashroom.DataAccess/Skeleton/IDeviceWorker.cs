﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.BusinessHubEntities;
using KC.SmartWashroom.Core.Enumerations;
using KC.SmartWashroom.Core.Helper;
using System.Collections.Generic;

namespace KC.SmartWashroom.DataAccess.Skeleton
{
    public interface IDeviceWorker
    {
        ProcessResponseForGateway SaveDeviceLog(DeviceLog deviceEntity);
        ProcessResponseForGateway SaveDeviceStatus(DeviceLog deviceEntity);
        ProcessResponseForGateway SaveDeviceAlert(string deviceAlerts);
        bool IsAlertExists(int customerId, string deviceId, string alertCode);
        bool IfAlertExists(string deviceID, string alertType);
        DeviceAssociation GetDeviceAssociation(string deviceId);
        IList<DeviceAlertGroupInfo> GetDeviceAlertTypes(string deviceType);

        List<DeviceResolutionDetail> GetAllDevicesForBuilding(int propertyId, int buildingId, int floorId, int washroomId);
        List<DeviceRefillDetail> GetAllSoapDevicesForBuilding(int buildingId);
        List<DeviceLog> GetAllDeviceLogsForDevice(string deviceId);

        string GetDeviceAlertCode(string alertName, string deviceType);
        void LogIncomingDeviceDetail(DeviceAuditLog entity);

        ProcessResponse ClearAllDeviceOverrides(List<int?> parameterIds, int customerId);

        DeviceSizeAndDispensedValue GetDeviceSizeandLastDispensedValue(int customerId, string deviceId, Enums.DeviceType type);

        List<BusinessEntities.AlertEngineEntities.DeviceAlert> CheckUnresponsive(int customerId, List<DeviceResolutionDetail> Alldevices);
        List<DeviceResolutionDetail> GetAlleHRTDevicesForUser(int userId, int roleLevel, int customerId);

        List<DeviceResolutionDetail> GetAllDevicesForUser(int userId, int roleLevel, int customerId, int buildingId);

        DeviceInformation GetDeviceAlertStatus(string deviceID);

        JRTParameters GetJRTDeviceStatus(int customerId, string deviceId);
        eHRTParameters GetEhrtDeviceStatus(int customerId, string deviceId);
        eSoapParameters GetEsoapDeviceStatus(int customerId, string deviceId);
        SRBParameters GetSRBDeviceStatus(int customerId, string deviceId);
        void DeleteDeviceStatus(string deviceId, int customerId);
        void DeleteAlertStatus(string deviceId, int customerId);
        ProcessResponseForGateway SaveDeviceForCache(string deviceId);
        IList<DeviceResolutionDetail> GetDeviceInfo(int propertyId, IList<string> deviceIdList);
    }
}
