﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.Core.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.DataAccess.Skeleton
{
    public interface IUserWorker
    {
        DeviceDetail GetUserDetails(string deviceId);

        List<UserEntity> GetContactsForCustomer(int customerID, int buildingId);

        DeviceDetail GetErrorAdminDetails();
        ProcessResponse<KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert> SaveDeviceAlert(KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert deviceAlert);
        ProcessResponse<KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert> RemoveDeviceAlert(KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert deviceAlert);

        List<Role> GetRoles();
        List<RolePermission> GetRolePermissions(Int16 roleId);
        List<Property> GetProperties(int customerId);
        List<Building> GetBuildings(int customerId);

        User GetUserDetails(int userId);
        ProcessResponse<User> CreateUser(User User);
        ProcessResponse<User> UpdateUser(User User);
        ProcessResponse<User> DeleteUser(User User);

        ProcessResponseForGateway SaveAccountInfo(string accountInfo);
        string GetUserContactInfo(string UserName);
    }
}
