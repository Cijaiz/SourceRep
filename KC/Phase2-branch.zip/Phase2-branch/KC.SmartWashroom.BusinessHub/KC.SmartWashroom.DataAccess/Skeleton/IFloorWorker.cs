﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.Core.Helper;
using System;
using System.Collections.Generic;

namespace KC.SmartWashroom.DataAccess.Skeleton
{
    public interface IFloorWorker
    {
        ProcessResponse<Floor> CreateFloorRange(List<Floor> floors);
        Floor GetFloorDetails(Int32 floorId);

        ProcessResponse<Floor> Delete(Int32 floorId, int? userId);
        ProcessResponse<Floor> Update(Floor floor);

        Names GetNames(Int32 buildingId);
        Floor GetFloorAlerts(Int32 floorId, Int32 buildingId, byte genderId, Int32 washroomId);
    }
}
