﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
using System;
using System.Collections.Generic;

namespace KC.SmartWashroom.DataAccess.Skeleton
{
    public interface ITableStorageHelper
    {
        List<AlertEntity> ReadAlertData(DateTime date, BusinessEntities.Property Property);

        List<eHRTEntityLog> EHRTData(DateTime date, BusinessEntities.Property Property);

        List<JRTEntityLog> JRTData(DateTime date, BusinessEntities.Property Property);

        List<SRBEntityLog> SRBData(DateTime date, BusinessEntities.Property Property);

        List<eSoapEntityLog> ESOAPData(DateTime date, BusinessEntities.Property Property);

        List<AlertEntity> GetBatteryResolvedAlertsForSRB(DateTime Date, BusinessEntities.Property Property);

        List<AlertEntity> GetBatteryResolvedAlertsForJRT(DateTime Date, BusinessEntities.Property Property);
    }
}
