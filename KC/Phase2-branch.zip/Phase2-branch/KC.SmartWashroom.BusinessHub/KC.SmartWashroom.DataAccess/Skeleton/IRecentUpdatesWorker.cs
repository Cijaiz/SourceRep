﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
using KC.SmartWashroom.BusinessEntities.BusinessHubEntities;
using System;
using System.Collections.Generic;

namespace KC.SmartWashroom.DataAccess.Skeleton
{
    public interface IRecentUpdatesWorker
    {
        ActivityResult FetchAllActivities(List<DeviceResolutionDetail> devices, int noOfRecentAlerts);
        ActivityResult FetchActivitiesLastDay(List<DeviceResolutionDetail> devices);
        List<DeviceAlertsResolutionDetail> FetchDeviceAlertsWithResolution(List<DeviceResolutionDetail> devices, int noOfRecentAlerts, SearchCriteria criteria);
        ActivityResult FetchAllActivitiesWithFilter(List<DeviceResolutionDetail> devices, string alertTypeCode, DateTime fromDate, DateTime toDate, int propertyId, int floorId, byte deviceTypeId, byte roomTypeId, int noOfRecentAlerts);

        IEnumerable<AlertStatusEntity> SearchRecent(SearchCriteria filter = null);
        List<DeviceAlertsResolutionDetail> GetDeviceAlertResolution(SearchCriteria searchCriteria);
    }
}
