﻿using KC.SmartWashroom.BusinessEntities.DashboardApiEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;

namespace KC.SmartWashroom.DataAccess.Skeleton
{
    public interface IBuildingWorker
    {
        BuildingEntity GetBuildingDetailsByPropertyId(int propertyID);
        List<Floor> GetFloorsByBuildingId(int Id);
        ProcessResponse<Building> CreateBuilding(Building building);
        ProcessResponse<Building> UpdateBuilding(Building building);
        ProcessResponse<Building> DeleteBuilding(Building building);
        List<Building> GetAllBuildings(int customerId, int userId, int roleLevel);

        Building GetBuildingDetails(int buildingId);
        Names GetNames(int propertyId);

        List<KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert> GetAlertDetailsByAlertType(byte alertTypeId, int floorId, byte genderId);
        List<KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert> GetAlertDetailsByAlertGroup(string alertGroupName, int floorId, byte genderId);
        
        List<Floor> GetFloors(int buildingId);
        KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert GetDeviceDetails(string deviceID);
        int GetCustomerId(int buildingId);
    }
}
