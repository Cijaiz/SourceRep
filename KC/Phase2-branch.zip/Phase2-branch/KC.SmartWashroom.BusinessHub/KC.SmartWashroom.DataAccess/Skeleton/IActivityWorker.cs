﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.BusinessHubEntities;
using KC.SmartWashroom.BusinessEntities.DashboardApiEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.Core.Helper;
using System;
using System.Collections.Generic;

namespace KC.SmartWashroom.DataAccess.Skeleton
{
    public interface IActivityWorker
    {
        ProcessResponse<Activity> CreateActivity(Activity activity);
        Activity GetActivity(int activity);

        BuildingEntity GetActivities(int customerId);
        BuildingEntity GetActivitiesByFilter(int customerId, string alertType, DateTime fromDate, DateTime toDate);

        List<string> GetAllAlertTypes();
        List<string> GetAlertTypesForDeviceType(byte deviceTypeId);

        List<DeviceTypes> GetAllDeviceTypes();
        List<Gender> GetAllRoomTypes();

        List<Property> GetAllProperties(int customerId);
        List<Building> GetAllBuildings(int customerId, int propertyId);
        List<Floor> GetAllFloors(int buildingId);

        int CountOutstandingDeviceAlerts(int userId, int roleLevel);
        //Not in use
        int CountOutstandingDeviceAlertsFilter(int customerId, string alertType, DateTime fromDate, DateTime toDate);

        int SumDispenseseHRTDevice(int customerId, List<DeviceResolutionDetail> Devices, int days);
        int SumEhrtDevices(SearchCriteria searchCriteria);
    }
}
