﻿using KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers;
using System;
using System.Collections.Generic;
using BusinessEntity = KC.SmartWashroom.BusinessEntities;

namespace KC.SmartWashroom.DataAccess.Skeleton
{
    public interface IAggregationWorker
    {
        //get all customer details
        List<Customer> GetCustomerDetails();

        //get all Properties details
        List<BusinessEntity.Property> GetAllProperties();

        //get property details
        BusinessEntity.Property GetPropertyDetails(int propertyId);

        //get customer detail by id
        Customer GetCustomerDetailsById(int CustomerId);

        //get all aggregation details for a particular property id
        AggregationStatu GetAggregationDetail(int PropertyId);

        //get all device data
        List<UsageMart> GetAllDevice(List<string> DeviceIds, DateTime Date);

        //get all device data for esoap, jrt and srb
        List<UsageMart> GetAllDeviceForJRTnSRBneSoap(List<BusinessEntity.Aggregation.DeviceWashroom> DeviceWashroomIds);

        //get all device data for ehrt
        List<UsageMart> GetAllDeviceForeHRT(List<BusinessEntity.Aggregation.DeviceWashroom> DeviceWashroomIds);

        //delete device logs for a particular day and customer
        void DeleteDeviceLogs(BusinessEntity.Property Property, DateTime Date);

        //bulk insert usage mart table data
        void BulkInsertDeviceLogs(List<UsageMart> DeviceLogs);

        //delete alert logs for a particular day and customer
        void DeleteAlertLogs(BusinessEntity.Property Property, DateTime Date);

        //builk insert alert logs table data
        void BulkInsertAlerts(List<AlertMart> Alerts);

        //insert success message for the customer and date
        void InsertSuccessMsg(DateTime Date, BusinessEntity.Property Property);
    }
}
