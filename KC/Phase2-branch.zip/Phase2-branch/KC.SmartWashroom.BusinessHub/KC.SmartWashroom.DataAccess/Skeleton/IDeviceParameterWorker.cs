﻿

/*
 * TODO: 
 * 1. This interface needs to be moved out to a common assembly (to support constructor injection)
 * 2. Aspired to call it as a repository
 
 */
namespace KC.SmartWashroom.DataAccess.Skeleton
{
    using KC.SmartWashroom.BusinessEntities.DeviceUpdate;
    using System;
    using System.Collections.Generic;

    /* Independent interface. No inheritance planned. */
    /// <summary>
    /// Data persistence abstraction for the device parameter
    /// "Kind" of a repository pattern!
    /// </summary>
    //[Obsolete("Please use the IDeviceMetadataWorker instead")]
    public interface IDeviceParameterWorker
    {
        /// <summary>
        /// Returns the device metadata based on the input criteria, when implemented
        /// </summary>
        /// <param name="deviceId">The id of the device, optional</param>
        /// <param name="deviceTypeName">The device type name, optional</param>
        /// <param name="deviceTypeId">The device type id, optional</param>
        /// <param name="customerId">The customer id, optional</param>
        /// <returns>Returns an enumerable of device metadata matching the input criteria</returns>
        /// <remarks>This is a heavy lifting query; aspire to use it judiciously</remarks>
        IEnumerable<DeviceUpdateDetails> GetDeviceDetails(string deviceId = "", string deviceTypeName = "", int deviceTypeId = 0, int customerId = 0);
        /// <summary>
        /// Sets the auto reset parameter values back to the store, when implemented
        /// </summary>
        /// <param name="parameters">The list of auto reset parameters</param>
        /// <returns>The count of values updated</returns>
        int OverwriteAutoResetParameterValues(IEnumerable<DeviceUpdateParameter> parameters);

        IEnumerable<DeviceUpdateDetails> RetrieveFromCache(string deviceId);

        DeviceUpdateDetails GetFromCache(string deviceId);

        bool SaveToCache(DeviceUpdateDetails obj);

        bool RemoveFromCache(string deviceId);
    }
}
