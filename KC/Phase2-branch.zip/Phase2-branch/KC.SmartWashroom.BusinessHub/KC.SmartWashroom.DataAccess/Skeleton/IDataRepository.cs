﻿/*
 * TODO: 
 * 1. This interface needs to be moved out to a common assembly (to support constructor injection)
*/


namespace KC.SmartWashroom.DataAccess.Skeleton
{
    using KC.SmartWashroom.Core;
    using System;
    using System.Collections.Generic;

    public interface IDataRepository<T> : IDisposable
     where T : class
    {
        IEnumerable<T> GetAll(IPropertyBag searchParameters);
    }
}
