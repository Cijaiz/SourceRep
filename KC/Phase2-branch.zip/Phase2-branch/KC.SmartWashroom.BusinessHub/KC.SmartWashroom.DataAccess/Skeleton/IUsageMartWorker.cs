﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.Core.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.DataAccess.Skeleton
{
    public interface IUsageMartWorker
    {
        List<ReportGenericEntity> GetTrafficDataWeekwise(ReportFilterEntity FilterValues);

        List<ReportGenericEntity> GetTrafficDataMonthWise(ReportFilterEntity FilterValues);

        List<ReportGenericEntity> GetProductUsageWeekwise(ReportFilterEntity FilterValues);

        List<ReportGenericEntity> GetProductUsageMonthwise(ReportFilterEntity FilterValues);

        List<ReportGenericEntity> GetProductSummaryData(ReportFilterEntity FilterValues);

        int GetRefillBeforeThreshold(ReportFilterEntity FilterValues);
      
    }
}
