﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.Core.Helper;
using System;
using System.Collections.Generic;

namespace KC.SmartWashroom.DataAccess.Skeleton
{
    public interface ISimulatorWorker
    {
        List<DeviceSimulator> FetchDevices();
        DateTime FetchDeviceLogTimeStamp(DeviceSimulator devicePrm, int CustomerId);

        List<string> FetchUpdateFixAlertForDevice(string DeviceId);
        DeviceSimulator FetchTempDeviceLog(DeviceSimulator devicePrm);

        ProcessResponse InsertTempDeviceLog(List<DeviceSimulator> Devices);
        ProcessResponse UpdateTempDeviceLog(List<DeviceSimulator> Devices);

        DateTime FetchTimeStampForAlert(string deviceId, string alertType);
        ProcessResponse InsertTimeStampForAlert(List<DeviceSimulator> Devices);

        ProcessResponse UpdateTimeStampForAlert(string DeviceId, string AlertCode);
        ProcessResponse DeleteTimeStampForAlert(string DeviceId, List<string> FixAlertCodes);

        bool CheckDeviceAlertFirstRaise(string deviceId, string alertType);
        void DeleteInactiveDevices();
    }
}
