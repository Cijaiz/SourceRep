﻿

namespace KC.SmartWashroom.DataAccess.Skeleton
{
    using KC.SmartWashroom.BusinessEntities.DeviceUpdate;
    using KC.SmartWashroom.BusinessEntities.Search;
    using System;
    using System.Collections.Generic;
    public interface IDeviceMetadataWorker : IDisposable
    {
        IEnumerable<DeviceUpdateParameter> GetDeviceParameters(DeviceSearchParameters searchParameters);
        IEnumerable<DeviceUpdateDetails> GetDeviceDetails(DeviceSearchParameters searchParameters);
        IEnumerable<DeviceUpdateDetails> GetDeviceDetailsWithParameters(DeviceSearchParameters searchParameters);
    }
}
