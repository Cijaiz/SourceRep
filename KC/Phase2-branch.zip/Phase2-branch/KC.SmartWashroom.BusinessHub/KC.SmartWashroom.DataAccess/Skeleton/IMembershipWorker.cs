﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.Core.Security.Authorization.Structure;
using System.Collections.Generic;
namespace KC.SmartWashroom.DataAccess.Skeleton
{
    public interface IMembershipWorker
    {
        ProcessResponse<UserContext> GetUserContext(string userName);
        KeyValuePair<string, string>? RetriveUserCredentials(string userName, string password);

        bool ResetUserCredentials(string userName, string newSaltedPassword, string salt);
        bool GenerateUserCredentials(string userName, string password, string passwordSalt);

        List<RolePermission> GetUserPermissions(int userId);

        bool ValidateUserName(string userName, ref string saltedPassword);
        bool ValidateCustomer(string userName);
        bool CreateFeature(RolePermission feature);
        List<BusinessEntities.RolePermission> GetFeatures();
        UserAssetEntity GetUserAssets(int userID);

        BusinessEntities.BusinessHubEntities.UserAccessAsserts GetAllUserAcessAsserts();

        int GetUserRoleLevel(string email);
    }
}
