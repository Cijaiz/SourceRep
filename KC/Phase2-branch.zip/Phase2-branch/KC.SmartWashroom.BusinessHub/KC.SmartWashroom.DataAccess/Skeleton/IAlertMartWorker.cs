﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.Core.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.DataAccess.Skeleton
{
    public interface IAlertMartWorker
    {
        List<ReportGenericEntity> GetAlertDataWeekwise(ReportFilterEntity FilterValues);

        List<ReportGenericEntity> GetAlertDataMonthwise(ReportFilterEntity FilterValues);

        List<ReportGenericEntity> GetAlertSummaryData(ReportFilterEntity FilterValues);

        StoryboardReportEntity GetStoryBoardData(ReportFilterEntity FilterValues);

    }
}
