﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.Core.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.DataAccess.Skeleton
{
    public interface IAzureSchedulerAuditWorker
    {
        ProcessResponse InsertUpdateJob(AzureSchedulerLog Scheduler);

        AzureSchedulerLog GetJob(int CustomerId);

        ProcessResponse DeleteJob(int CustomerId);
    }
}
