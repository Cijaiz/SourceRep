﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.Core.Helper;
using System.Collections.Generic;

namespace KC.SmartWashroom.DataAccess.Skeleton
{
    public interface IWashroomWorker
    {
        Washroom GetWashroomDetails(int washroomId);
        List<Gender> GetGenders();
        List<Wing> GetWings();
        List<Washroom> GetWashroomsByFloorId(int floorId);
        List<Washroom> GetWashroomsByFloorIdGroupedByGender(int floorId);
        List<DeviceStatus> GetDeviceStatusInWashrooms(int floorId, int washroomId);
        decimal GetDeviceRefillValue(string size, string DeviceType, out byte productUsageBuffer);
        decimal GetESoapShotSize(string size);

        ProcessResponse<Washroom> Create(Washroom washroom);
        ProcessResponse<Washroom> Update(Washroom washroom);
        ProcessResponse<Washroom> Delete(Washroom washroom);
        Names GetNames(int floorId);
        int GetCustomerId(int washroomId);
        IList<Washroom> GetWashrromsByPropertyAndGeneder(int propertyId, byte genderId);
    }
}
