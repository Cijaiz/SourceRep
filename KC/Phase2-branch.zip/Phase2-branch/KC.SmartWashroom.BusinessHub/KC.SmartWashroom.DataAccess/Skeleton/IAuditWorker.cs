﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.BusinessHubEntities;
using KC.SmartWashroom.Core.Helper;
using System.Collections.Generic;

namespace KC.SmartWashroom.DataAccess.Skeleton
{
    public interface IAuditWorker
    {
        ProcessResponse LogAuditActivity(Audit auditDetail);
        void TraceDeviceTraffic(DeviceTrafficTrace entity);
    }
}
