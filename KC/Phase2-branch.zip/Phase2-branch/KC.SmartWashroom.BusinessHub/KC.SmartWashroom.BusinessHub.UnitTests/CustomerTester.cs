﻿using KC.SmartWashroom.Business;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.Core.Helper;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;

namespace KC.SmartWashroom.BusinessHub.UnitTests
{
    [TestClass]
    public class CustomerTester
    {
        CustomerBusinessManager manager;

        [TestInitialize]
        public void Initialize()
        {
            if (manager == null)
            {
                manager = new CustomerBusinessManager();
            }
        }

        [TestMethod]
        public void TestGetResult()
        {
            var response = manager.GetDeviceParameters(1);
            Assert.IsTrue(response.Count > 0, "Failed...");
        }

        [TestMethod]
        public void TestUpsetReturnParameters()
        {
            System.Collections.Generic.Dictionary<DeviceTypes, List<ReturnValueParameter>> dictionary = new System.Collections.Generic.Dictionary<DeviceTypes, List<ReturnValueParameter>>();
            List<ReturnValueParameter> returnValueParameters = new List<ReturnValueParameter>();
            List<ReturnParameterResponse> returnResponseParameters = new List<ReturnParameterResponse>();
            ReturnValueParameter returnPrameter = new ReturnValueParameter();
            returnPrameter.Parameter = new DeviceParameterEntity();

            int customerId = 1;
            int upsetCustomerId = 2;

            //Pull values..
            var responses = manager.GetDeviceParameters(customerId);
            foreach (var ss in responses)
            {
                var list = ss.Value;
                foreach (var l in list)
                {
                    if (!l.ParameterValue.CustomerId.HasValue)
                    {
                        l.ParameterValue = new DeviceParameterValueEntity();
                    }
                    l.ParameterValue.Value = l.Parameter.DeviceParameterId.Equals(1) ? "150" : "1";
                    l.ParameterValue.CustomerId = upsetCustomerId;
                    l.ParameterValue.DeviceParameterValueId = l.Parameter.DeviceParameterId;
                }
                dictionary.Add(ss.Key, ss.Value);
                returnResponseParameters.Add(new ReturnParameterResponse() { deviceTypes = ss.Key, returnValueParameters = ss.Value });
                break;
            }

            var response = manager.UpsetReturnParameters(returnResponseParameters, upsetCustomerId);
            Assert.IsTrue(response.Status.Equals(ResponseStatus.Success), "Error Saving");
        }

        [TestMethod]
        public void deleteRecord()
        {
            List<int?> value = new List<int?>();
            value.Add(48);
            value.Add(47);

            var ss = manager.DeleteDeviceParameterValue(value,0);
        }
    }
}
