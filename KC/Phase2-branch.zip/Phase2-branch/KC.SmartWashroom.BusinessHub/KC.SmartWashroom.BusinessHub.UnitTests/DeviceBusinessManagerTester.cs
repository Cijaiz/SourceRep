﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using KC.SmartWashroom.Business;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.Helper;
using System.Collections.Generic;

namespace KC.SmartWashroom.BusinessHub.UnitTests
{
    [TestClass]
    public class DeviceBusinessManagerTester
    {
        DeviceBusinessManager manager;
        string deviceDetailJRT = "000000820202020,1.12,5.811,87,0,657";
        string deviceDetaileHRT = "000000B1F1W1D4,1.12,m,m,m,h,16777215,16777215,16777215,65535,65535,5.811,1193046,1,87";
        string deviceDetaileSoap = "0000078a20040bd140e,112,s,s,s,1193046,1193046,1193046,1193046,16777215,483,483,0,0,0,1193046,1193046,1193046,5,0";
        string gatewayDetail = "1234567890abcdef,104";

        //string deviceAlertJRT="000000820202020,J1,1,1.15,5.811,87,0,657";
        //string deviceAlerteHRT="000000020202020,H1,1,1.15,m,m,m,h,16777215,16777215,16777215,65535,65535,5.811,1193046,1,87";
        //string deviceAlerteSoap="000000720202020,S1,1,1.15,s,s,s,1193046,1193046,1193046,1193046,16777215,5.811,5.811,1193046,1193046,1193046,1193046";

        [TestInitialize]
        public void Initialize()
        {
            if (manager == null)
            {
                manager = new DeviceBusinessManager();
            }
        }

        #region DeviceLogTest
        [TestMethod]
        [ExpectedException(typeof(ApplicationException), "Invalid parameters")]
        public void ComposeDeviceLogInvalid()
        {
            string invalid = string.Empty;
            manager.ComposeDeviceLog(invalid, invalid);
        }

        [TestMethod]
        public void ComposeDeviceLogeSoapValid()
        {
            string deviceDetail = deviceDetaileSoap;
            Assert.IsTrue(manager.ComposeDeviceLog(deviceDetail, gatewayDetail));
        }

        [TestMethod]
        public void ComposeDeviceLogJRTValid()
        {
            string deviceDetail = deviceDetailJRT;
            Assert.IsTrue(manager.ComposeDeviceLog(deviceDetail, gatewayDetail));
        }

        [TestMethod]
        public void ComposeDeviceLogeHRTValid()
        {
            string deviceDetail = deviceDetaileHRT;
            Assert.IsTrue(manager.ComposeDeviceLog(deviceDetail, gatewayDetail));
        }

        [TestMethod]
        public void SaveDeviceLogJRTTest()
        {
            string expectedStatus = AlertEngineConstants.STATUS_SUCCESS;
            string deviceDetail = deviceDetailJRT;
            manager.ComposeDeviceLog(deviceDetail, gatewayDetail);

            ProcessResponseForGateway test = null;
            test = manager.SaveDeviceLog();
            Assert.AreEqual(expectedStatus, test.status);
        }

        [TestMethod]
        public void SaveDeviceLogeHRTTest()
        {
            string expectedStatus = AlertEngineConstants.STATUS_SUCCESS;
            string deviceDetail = deviceDetaileHRT;
            manager.ComposeDeviceLog(deviceDetail, gatewayDetail);

            ProcessResponseForGateway test = null;
            test = manager.SaveDeviceLog();
            Assert.AreEqual(expectedStatus, test.status);
        }

        [TestMethod]
        public void SaveDeviceLogeSoapTest()
        {
            string expectedStatus = AlertEngineConstants.STATUS_SUCCESS;
            string deviceDetail = deviceDetaileSoap;
            manager.ComposeDeviceLog(deviceDetail, gatewayDetail);

            ProcessResponseForGateway test = null;
            test = manager.SaveDeviceLog();
            Assert.AreEqual(expectedStatus, test.status);
        }

        #endregion


        #region DeviceAlertTest

        //[TestMethod]
        //[ExpectedException(typeof(ApplicationException), "Invalid parameters")]
        //public void ComposeDeviceAlertInvalid()
        //{
        //    string invalid = string.Empty;
        //    manager.ComposeDeviceAlert(invalid);
        //}

        //[TestMethod]
        //public void ComposeDeviceAlertInvalid()
        //{
        //    string expectedResult = "Invalid parameters";
        //    string invalid = string.Empty;
        //    try
        //    {
        //        manager.ComposeDeviceAlert(invalid);
        //        Assert.Fail("No exception thrown");

        //    }
        //    catch (ApplicationException ex)
        //    {
        //        Assert.AreEqual(expectedResult, ex.Message);

        //    }
        //    catch (Exception)
        //    {
        //        Assert.Fail("Wrong exception thrown");

        //    }
        //}

        //[TestMethod]
        //public void ComposeDeviceAlerteHRTValid()
        //{
        //    string deviceAlert = deviceAlerteHRT;
        //    Assert.IsTrue(manager.ComposeDeviceAlert(deviceAlert));
        //}

        // [TestMethod]
        //public void ComposeDeviceAlerteSoapValid()
        //{
        //    string deviceAlert = deviceAlerteSoap;
        //    Assert.IsTrue(manager.ComposeDeviceAlert(deviceAlert));
        //}

        // [TestMethod]
        //public void ComposeDeviceAlertJRTValid()
        //{
        //    string deviceAlert = deviceAlertJRT;
        //    Assert.IsTrue(manager.ComposeDeviceAlert(deviceAlert));
        //}

        //[TestMethod]
        //public void SaveDeviceAlertJRTTest()
        //{
        //    string expectedStatus = AlertEngineConstants.STATUS_SUCESS;
        //    string deviceAlert = deviceAlertJRT;
        //    manager.ComposeDeviceAlert(deviceAlert);

        //    ProcessResponseForGateway test = null;
        //    test = manager.SaveDeviceAlert();
        //    Assert.AreEqual(expectedStatus, test.status);
        //}

        //[TestMethod]
        //public void SaveDeviceAlerteHRTTest()
        //{
        //    string expectedStatus = AlertEngineConstants.STATUS_SUCESS;
        //    string deviceAlert = deviceAlerteHRT;
        //    manager.ComposeDeviceAlert(deviceAlert);

        //    ProcessResponseForGateway test = null;
        //    test = manager.SaveDeviceAlert();
        //    Assert.AreEqual(expectedStatus, test.status);
        //}

        //[TestMethod]
        //public void SaveDeviceAlerteSoapTest()
        //{
        //    string expectedStatus = AlertEngineConstants.STATUS_SUCESS;
        //    string deviceAlert = deviceAlerteSoap;
        //    manager.ComposeDeviceAlert(deviceAlert);

        //    ProcessResponseForGateway test = null;
        //    test = manager.SaveDeviceAlert();
        //    Assert.AreEqual(expectedStatus, test.status);
        //}

        #endregion

        [TestMethod]
        public void GetDeviceAlertStatus()
        {
            DeviceInformation response = manager.GetDeviceAlertStatus("B1F10W100D998");

            Assert.IsTrue(response != null, "Count Not Find any Entry in DB..");
        }

        [TestMethod]
        public void ClearAllDeviceOverrides()
        {
            var ss = new List<int?>() { 3 };
            manager.ClearAllDeviceOverrides(ss, 2);
        }

        [TestMethod]
        public void TestCheckAlertExist()
        {
            Assert.IsNotNull(manager.CheckAlertExist(1, "00001112c81c540cb8", "SR1"));
        }
    }
}

