﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using KC.SmartWashroom.Business;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.Helper;
using System.Collections.Generic;

namespace KC.SmartWashroom.BusinessHub.UnitTests
{
    [TestClass]
    public class MembershipTester
    {
        MembershipBusinessManager manager;


        [TestInitialize]
        public void Initialize()
        {
            if (manager == null)
            {
                manager = new MembershipBusinessManager();
            }
        }

        [TestMethod]
        [ExpectedException(typeof(ApplicationException), "Invalid parameters")]
        public void ValidateCustomer()
        {
            
           // bool isValid = manager.ValidateCustomer("admin@kcc.com");
            bool isValid = manager.ValidateCustomer("neelkcc@gmail.com");
           // bool isValid = manager.ValidateCustomer("neelkcc@gmail.com");
            
            Assert.IsTrue(isValid, "Valid customer.");
        }

        #region GetUserAssets
        [TestMethod]
        [ExpectedException(typeof(ApplicationException), "Invalid parameters")]
        public void GetUserAssets()
        {
            string invalid = string.Empty;
            var userAsset = manager.GetUserAssets(1);
            Assert.IsNotNull(userAsset, "Error retriving the user aserts..");
        }

        #endregion

    }
}

