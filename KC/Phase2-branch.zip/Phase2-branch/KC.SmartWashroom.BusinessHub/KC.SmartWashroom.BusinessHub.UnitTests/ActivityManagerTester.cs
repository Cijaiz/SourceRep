﻿using System;
using KC.SmartWashroom.Business;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using KC.SmartWashroom.BusinessEntities.BusinessHubEntities;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.Helper;
using System.Collections.Generic;

namespace KC.SmartWashroom.BusinessHub.UnitTests
{
    [TestClass]
    public class ActivityManagerTester
    {
        [TestMethod]
        public void TestGetActivities()
        {
            ActivityBusinessManager manager = new ActivityBusinessManager();
            int pageSize = 10;
            ActivityResult result = manager.GetActivities(new SearchCriteria() { PropertyId = 1, UserId = 1, CustomerId = 1, FromDate =DateTime.UtcNow.AddDays(-8), ToDate = DateTime.UtcNow, SearchByPartition = true, PageSize = pageSize });

            Assert.IsTrue(result.Activities.Count > 0);
        }

        [TestMethod]
        public void TestGetRecentActivities()
        {
            ActivityBusinessManager manager = new ActivityBusinessManager();
            int pageSize = 5;
            IList<DeviceAlertsResolutionDetail> resolutions = manager.GetRecentActivities(new SearchCriteria() { PropertyId = 1, UserId = 1,  FromDate = DateTime.UtcNow.AddDays(-2), ToDate = DateTime.UtcNow, SearchByPartition = true, PageSize = pageSize });

            Assert.IsTrue(resolutions.Count > 0);
        }
    }
}
