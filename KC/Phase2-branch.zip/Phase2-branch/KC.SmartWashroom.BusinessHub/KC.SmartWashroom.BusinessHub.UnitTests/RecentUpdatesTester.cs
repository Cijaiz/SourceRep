﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using KC.SmartWashroom.Business;
using KC.SmartWashroom.BusinessEntities;

namespace KC.SmartWashroom.BusinessHub.UnitTests
{
    [TestClass]
    public class RecentUpdatesTester
    {
        RecentUpdatesManager manager;

        [TestInitialize]
        public void Initialize()
        {
            if (manager == null)
            {
                manager = new RecentUpdatesManager();
            }
        }

        [TestMethod]
        public void TestGetDeviceAlertsForBuildingWithResolution()
        {
            var response = manager.FetchDeviceAlertsForBuildingWithResolution(1, 1, 0, 0);
            Assert.IsTrue(response.Count > 0, "Failed...");
        }
    }
}
