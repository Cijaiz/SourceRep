﻿using KC.SmartWashroom.Business;
using KC.SmartWashroom.BusinessEntities.DeviceUpdate;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace KC.SmartWashroom.BusinessHub.UnitTests
{
    [TestClass]
    public class CacheTester
    {
        DeviceUpdateValueManager manager = null;

        [TestInitialize]
        public void Initialize()
        {
            manager = new DeviceUpdateValueManager();
        }

        [TestMethod]
        public void SaveDeviceDetailTOCache()
        {
            var deviceDetails = manager.GetDeviceDetails("000000c006c122bf8a");
            manager.SaveToCache(deviceDetails.GetEnumerator().Current);
        }
    }
}
