﻿using KC.SmartWashroom.Business.Simulator;
using KC.SmartWashroom.Core.Helper;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessHub.UnitTests
{
    [TestClass]
    public class GatewayFeedManagerTester
    {
        GatewayFeedManager manager;

        [TestInitialize]
        public void Initialize()
        {
            if (manager == null)
            {
                manager = new GatewayFeedManager();
            }
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException), "No devices found")]
        public void FetchDevices()
        {
            manager.FetchDevices();
        }

        //[TestMethod]
        //[ExpectedException(typeof(ArgumentNullException), "No devices found")]
        //public void FetchDeviceLogsNoDevice()
        //{
        //    manager.FetchDeviceLogTimeStamp();
        //}

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException), "No devices found")]
        public void FetchDeviceLogs()
        {
            manager.FetchDevices();
            //manager.FetchDeviceLogTimeStamp();
            manager.FetchTempDeviceLogs();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException), "No devices found")]
        public void CreateDeviceSimulatorsNoDevice()
        {
            manager.CreateDeviceSimulators();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException), "No devices found")]
        public void CreateDeviceSimulators()
        {
            manager.FetchDevices();
            //manager.FetchDeviceLogTimeStamp();
            manager.FetchTempDeviceLogs();
            manager.CreateDeviceSimulators();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException), "Simulator not created")]
        public void SimulateDataNoSimulator()
        {
            manager.SimulateData();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException), "No devices found")]
        public void SimulateDataNoDevice()
        {
            manager.CreateDeviceSimulators();
            manager.SimulateData();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException), "No devices found")]
        public void SimulateData()
        {
            manager.FetchDevices();
            //manager.FetchDeviceLogTimeStamp();
            manager.FetchTempDeviceLogs();
            manager.CreateDeviceSimulators();
            manager.SimulateData();
        }


        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException), "Simulator not created")]
        public void PushNewDeviceDataFeedNoSimulator()
        {
            manager.SimulateData();
            manager.PushNewDeviceDataFeed();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException), "No devices found")]
        public void PushNewDeviceDataFeedNoDevice()
        {
            manager.CreateDeviceSimulators();
            manager.SimulateData();
            manager.PushNewDeviceDataFeed();
        }

        [TestMethod]
        public void PushNewDeviceDataFeedSuccess()
        {
            ProcessResponse test = null;
            manager.FetchDevices();
            //manager.FetchDeviceLogTimeStamp();
            manager.FetchTempDeviceLogs();
            manager.CreateDeviceSimulators();
            manager.SimulateData();
            test = manager.PushNewDeviceDataFeed();
            Assert.AreEqual<ResponseStatus>(ResponseStatus.Success, test.Status);
        }

        [TestMethod]
        public void PushNewDeviceDataFeedFailure()
        {
            ProcessResponse test = null;
            manager.FetchDevices();
            //manager.FetchDeviceLogTimeStamp();
            manager.FetchTempDeviceLogs();
            manager.CreateDeviceSimulators();
            manager.SimulateData();
            test = manager.PushNewDeviceDataFeed();
            Assert.AreEqual<ResponseStatus>(ResponseStatus.Failed, test.Status);
        }

        [TestMethod]
        public void PushNewDeviceDataFeedError()
        {
            ProcessResponse test = null;
            manager.FetchDevices();
            //manager.FetchDeviceLogTimeStamp();
            manager.FetchTempDeviceLogs();
            manager.CreateDeviceSimulators();
            manager.SimulateData();
            test = manager.PushNewDeviceDataFeed();
            Assert.AreEqual<ResponseStatus>(ResponseStatus.Error, test.Status);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException), "Simulator not created")]
        public void PushUpdatedDeviceDataFeedNoSimulator()
        {
            manager.SimulateData();
            manager.PushNewDeviceDataFeed();
            manager.PushUpdatedDeviceDataFeed();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException), "No devices found")]
        public void PushUpdatedDeviceDataFeedNoDevice()
        {
            manager.CreateDeviceSimulators();
            manager.SimulateData();
            manager.PushNewDeviceDataFeed();
            manager.PushUpdatedDeviceDataFeed();
        }

        [TestMethod]
        public void PushUpdatedDeviceDataFeedSuccess()
        {
            ProcessResponse test = null;
            manager.FetchDevices();
            //manager.FetchDeviceLogTimeStamp();
            manager.FetchTempDeviceLogs();
            manager.CreateDeviceSimulators();
            manager.SimulateData();
            manager.PushNewDeviceDataFeed();
            test = manager.PushUpdatedDeviceDataFeed();
            Assert.AreEqual<ResponseStatus>(ResponseStatus.Success, test.Status);
        }

        [TestMethod]
        public void PushUpdatedDeviceDataFeedFailure()
        {
            ProcessResponse test = null;
            manager.FetchDevices();
            //manager.FetchDeviceLogTimeStamp();
            manager.FetchTempDeviceLogs();
            manager.CreateDeviceSimulators();
            manager.SimulateData();
            manager.PushNewDeviceDataFeed();
            test = manager.PushUpdatedDeviceDataFeed();
            Assert.AreEqual<ResponseStatus>(ResponseStatus.Failed, test.Status);
        }

        [TestMethod]
        public void PushUpdatedDeviceDataFeedError()
        {
            ProcessResponse test = null;
            manager.FetchDevices();
            //manager.FetchDeviceLogTimeStamp();
            manager.FetchTempDeviceLogs();
            manager.CreateDeviceSimulators();
            manager.SimulateData();
            manager.PushNewDeviceDataFeed();
            test = manager.PushUpdatedDeviceDataFeed();
            Assert.AreEqual<ResponseStatus>(ResponseStatus.Error, test.Status);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException), "Simulator not created")]
        public void UpdateDeviceParameterNoSimulator()
        {
            manager.SimulateData();
            manager.UpdateDeviceParameter();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException), "No devices found")]
        public void UpdateDeviceParameterNoDevice()
        {
            manager.CreateDeviceSimulators();
            manager.SimulateData();
            manager.UpdateDeviceParameter();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException), "Simulator not created")]
        public void InsertTempDeviceLogNoSimulator()
        {
            manager.SimulateData();
            manager.PushNewDeviceDataFeed();
            manager.PushUpdatedDeviceDataFeed();
            manager.UpdateDeviceParameter();
            manager.InsertTempDeviceLog();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException), "No devices found")]
        public void InsertTempDeviceLogNoDevice()
        {
            manager.CreateDeviceSimulators();
            manager.SimulateData();
            manager.PushNewDeviceDataFeed();
            manager.PushUpdatedDeviceDataFeed();
            manager.UpdateDeviceParameter();
            manager.InsertTempDeviceLog();
        }

        [TestMethod]
        public void InsertTempDeviceLogSuccess()
        {
            ProcessResponse test = null;
            manager.FetchDevices();
            //manager.FetchDeviceLogTimeStamp();
            manager.FetchTempDeviceLogs();
            manager.CreateDeviceSimulators();
            manager.SimulateData();
            manager.PushNewDeviceDataFeed();
            manager.PushUpdatedDeviceDataFeed();
            manager.UpdateDeviceParameter();
            test = manager.InsertTempDeviceLog();
            Assert.AreEqual<ResponseStatus>(ResponseStatus.Success, test.Status);
        }

        [TestMethod]
        public void InsertTempDeviceLogFailure()
        {
            ProcessResponse test = null;
            manager.FetchDevices();
            //manager.FetchDeviceLogTimeStamp();
            manager.FetchTempDeviceLogs();
            manager.CreateDeviceSimulators();
            manager.SimulateData();
            manager.PushNewDeviceDataFeed();
            manager.PushUpdatedDeviceDataFeed();
            manager.UpdateDeviceParameter();
            test = manager.InsertTempDeviceLog();
            Assert.AreEqual<ResponseStatus>(ResponseStatus.Failed, test.Status);
        }

        [TestMethod]
        public void InsertTempDeviceLogError()
        {
            ProcessResponse test = null;
            manager.FetchDevices();
            //manager.FetchDeviceLogTimeStamp();
            manager.FetchTempDeviceLogs();
            manager.CreateDeviceSimulators();
            manager.SimulateData();
            manager.PushNewDeviceDataFeed();
            manager.PushUpdatedDeviceDataFeed();
            manager.UpdateDeviceParameter();
            test = manager.InsertTempDeviceLog();
            Assert.AreEqual<ResponseStatus>(ResponseStatus.Error, test.Status);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException), "Simulator not created")]
        public void UpdateTempDeviceLogNoSimulator()
        {
            manager.SimulateData();
            manager.PushNewDeviceDataFeed();
            manager.PushUpdatedDeviceDataFeed();
            manager.UpdateDeviceParameter();
            manager.InsertTempDeviceLog();
            manager.UpdateTempDeviceLog();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException), "No devices found")]
        public void UpdateTempDeviceLogNoDevice()
        {
            manager.CreateDeviceSimulators();
            manager.SimulateData();
            manager.PushNewDeviceDataFeed();
            manager.PushUpdatedDeviceDataFeed();
            manager.UpdateDeviceParameter();
            manager.InsertTempDeviceLog();
            manager.UpdateTempDeviceLog();
        }

        [TestMethod]
        public void UpdateTempDeviceLogSuccess()
        {
            ProcessResponse test = null;
            manager.FetchDevices();
            //manager.FetchDeviceLogTimeStamp();
            manager.FetchTempDeviceLogs();
            manager.CreateDeviceSimulators();
            manager.SimulateData();
            manager.PushNewDeviceDataFeed();
            manager.PushUpdatedDeviceDataFeed();
            manager.UpdateDeviceParameter();
            manager.InsertTempDeviceLog();
            test = manager.UpdateTempDeviceLog();
            Assert.AreEqual<ResponseStatus>(ResponseStatus.Success, test.Status);
        }

        [TestMethod]
        public void UpdateTempDeviceLogFailure()
        {
            ProcessResponse test = null;
            manager.FetchDevices();
            //manager.FetchDeviceLogTimeStamp();
            manager.FetchTempDeviceLogs();
            manager.CreateDeviceSimulators();
            manager.SimulateData();
            manager.PushNewDeviceDataFeed();
            manager.PushUpdatedDeviceDataFeed();
            manager.UpdateDeviceParameter();
            manager.InsertTempDeviceLog();
            test = manager.UpdateTempDeviceLog();
            Assert.AreEqual<ResponseStatus>(ResponseStatus.Failed, test.Status);
        }

        [TestMethod]
        public void UpdateTempDeviceLogError()
        {
            ProcessResponse test = null;
            manager.FetchDevices();
            //manager.FetchDeviceLogTimeStamp();
            manager.FetchTempDeviceLogs();
            manager.CreateDeviceSimulators();
            manager.SimulateData();
            manager.PushNewDeviceDataFeed();
            manager.PushUpdatedDeviceDataFeed();
            manager.UpdateDeviceParameter();
            manager.InsertTempDeviceLog();
            test = manager.UpdateTempDeviceLog();
            Assert.AreEqual<ResponseStatus>(ResponseStatus.Error, test.Status);
        }
    }
}
