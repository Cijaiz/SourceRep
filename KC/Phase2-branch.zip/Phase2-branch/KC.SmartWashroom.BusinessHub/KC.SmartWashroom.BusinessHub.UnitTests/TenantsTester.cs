﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using KC.SmartWashroom.Business;
using KC.SmartWashroom.BusinessEntities;
using System.Collections.Generic;

namespace KC.SmartWashroom.BusinessHub.UnitTests
{
    [TestClass]
    public class TenantsTester
    {
        TenantsBusinessManager manager;

        [TestInitialize]
        public void Initialize()
        {
            if (manager == null)
            {
                manager = new TenantsBusinessManager();
                //manager.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.PropertyWorker>();
            }
        }

        [TestMethod]
        public void TestGetUsersForDevice()
        {
            Assert.IsTrue(manager.GetUserDetails("000000002"));
            //  Assert.IsNotNull(manager.DeviceLog, "Failed to Return User Details");
        }

        public void TestPostDeviceAlert()
        {
            BusinessEntities.AlertEngineEntities.DeviceAlert deviceAlert = new BusinessEntities.AlertEngineEntities.DeviceAlert();
            manager.SaveDeviceAlert(new BusinessEntities.AlertEngineEntities.DeviceAlert { DeviceId = "000000020202020", AlertTypeId = 3, DateTime = DateTime.Now });
        }

        [TestMethod]
        public void TestGetContactsForCustomer()
        {
            var response = manager.GetContactsForCustomer(1,1009);
            Assert.IsTrue(response.Count > 0, "Failed...");
        }

        [TestMethod]
        public void TestErrorAdmin()
        {
            var response = manager.GetUserDetails(1, 1);
            //var userdetails = new List<UserDetail>();

            Assert.IsTrue(response == null, "Failed...");
        }
    }
}
