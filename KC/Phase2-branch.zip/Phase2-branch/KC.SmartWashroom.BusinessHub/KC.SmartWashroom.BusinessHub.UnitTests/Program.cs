﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using KC.SmartWashroom.Core.NotificationUtility;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.Core.Helper;

namespace HubTestBench
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("<<<<<<<<<<<<.... Business Hub Tester... >>>>>>>>>>>>>>>");

            WebClient client = new WebClient();

            ////string test12 = client.SafeWebClientProcessing("http://smartwashroom.cloudapp.net/api/tenants/GetValue?id=5");

            //string test = client.SafeWebClientProcessing("http://localhost:56853/api/tenants/GetValue?id=5");

            //string test1 = client.SafeWebClientProcessing(string.Format("{0}/{1}?userId={2}&userCount={3}",
            //    "http://localhost:56853/api/tenants",
            //    "GetValuesCount",
            //    1,
            //    2));

            //string response = client.WebClientPostRequest<UserFeedStatus>("http://localhost:56853/api/tenants/UpdateFeedStatus", new UserFeedStatus() { UserName = "CIJAI", Password = "Test" });
            //string response1 = client.WebClientPostRequest<UserFeedStatus>("http://localhost:56853/api/Devices/Post?deviceDetails=000000720202020,1.12,s,s,s,1193046,1193046,1193046,1193046,16777215,5.811,5.811,1193046,1193046", new UserFeedStatus() { UserName = "CIJAI", Password = "Test" });
            //string response1 = client.WebClientPostRequest<DeviceDetailParameter>("http://localhost:56853/api/Devices/Post", new DeviceDetailParameter() { deviceDetail = "000000720202020,1.12,s,s,s,1193046,1193046,1193046,1193046,16777215,5.811,5.811,1193046,1193046,1193046,1193046" });
            string response = client.WebClientPostRequest<AlertParameter>("http://localhost:56853/api/Alert/Post", new AlertParameter() { deviceAlerts = "000000820202020,J1,1,1.12,5.811,87,0,657" });

            ProcessResponseForGateway responseEntity = SerializationHelper.JsonDeserialize<ProcessResponseForGateway>(response);
            //ProcessResponse responseEntity = SerializationHelper.JsonDeserialize<ProcessResponse>(response1);
        }
    }
}
