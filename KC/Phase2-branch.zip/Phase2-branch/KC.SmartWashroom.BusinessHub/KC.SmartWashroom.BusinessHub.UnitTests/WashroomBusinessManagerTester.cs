﻿using KC.SmartWashroom.Business;
using KC.SmartWashroom.BusinessEntities.BusinessHubEntities;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessHub.UnitTests
{
    [TestClass]
    public class WashroomBusinessManagerTester
    {
        WashroomBusinessManager manager;

        [TestInitialize]
        public void Initialize()
        {
            if (manager == null)
            {
                manager = new WashroomBusinessManager();
            }
        }

        [TestMethod]
        public void GetDeviceSinceLastValue()
        {
            string deviceID = "000007c006c122bf5a";
            DeviceTenantManager deviceTenantManager = new DeviceTenantManager();
            var ss =deviceTenantManager.RetriveReturnParametersForDevice(deviceID, 1);

            DeviceBusinessManager deviceManager = new DeviceBusinessManager();
            var deviceType = ss.deviceTypes.DeviceName;

            DeviceAlertsResolutionDetail alertResolutionDetail = manager.GetDeviceLastDispensedValue(1, deviceID, deviceType);
            Assert.IsNotNull(alertResolutionDetail, "Failed to retrive the Device Last Didpsnesed value..");
        }
    }
}
