﻿using System;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using KC.SmartWashroom.Business;
using KC.SmartWashroom.BusinessEntities;
using System.Collections.Generic;
using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
using KC.SmartWashroom.Core.Helper;


namespace KC.SmartWashroom.BusinessHub.UnitTests
{
    [TestClass]
    public class PropertyTester
    {
        PropertyBusinessManager manager;
        BuildingBusinessManager buildingManager;
        WashroomBusinessManager washroomManager;
        FloorBusinessManager floorManager;
        [TestInitialize]
        public void Initialize()
        {
            if (manager == null)
            {
                manager = new PropertyBusinessManager();
            }
            if (buildingManager == null)
            {
                buildingManager = new BuildingBusinessManager();
            }

            if (washroomManager == null)
            {
                washroomManager = new WashroomBusinessManager();
            }
            if (floorManager == null)
            {
                floorManager = new FloorBusinessManager();
            }
        }

        [TestMethod]
        public void TestCreate()
        {
            Property property = new Property();
            property.AddressId = 1;
            property.IsCustomerAddress = true;
            property.Name = "Properytest";
            property.ImageUrl = "image.jpg";
            property.UserId = 1;
            Assert.IsNotNull(manager.Create(property));
        }

        [TestMethod]
        public void GetBuildingDetailsByPropertyId()
        {
            int propertyID = 1;
            Assert.IsNotNull(buildingManager.GetBuildingDetailsByPropertyId(propertyID,1,1));
        }

       [TestMethod]
       public void GetWashroomsByFloorId()
       {
           int floorId= 1;
           Floor floor = new Floor();
           

           floor = floorManager.GetFloorAlerts(1, 1,2,0,0);
           var floorWashrooms = floor.Alerts.GroupBy(x => new { x.WashroomId }).ToList();
           if (floorWashrooms != null)
           {
               if (floorWashrooms.Count > 0)
               {
                   var washrooms = washroomManager.GetWashroomsByFloorIdWithoutLog(floorId).Where(x => x.ID.Equals(floorWashrooms[0].Key.WashroomId)).GroupBy(x => new { x.ID, x.Name });
                   floor.WashroomSets = new List<KeyValuePair<KeyValuePair<string, Int32>, List<DeviceAlert>>>();
                   foreach (var item in washrooms.Select(x => x).ToList())
                   {
                       KeyValuePair<string, Int32> washroomPair = new KeyValuePair<string, Int32>(item.Key.Name, item.Key.ID);
                       KeyValuePair<KeyValuePair<string, Int32>, List<DeviceAlert>> floorPair = new KeyValuePair<KeyValuePair<string, Int32>, List<DeviceAlert>>(washroomPair, floor.Alerts.FindAll(x => x.WashroomId.Equals(item.Key.ID)));
                       floor.WashroomSets.Add(floorPair);
                   }
               }
               
           }
           

           
           Assert.IsNotNull(floor);
       }
 
        [TestMethod]
       public void GetDeviceStatusInWashrooms()
       {
           List<DeviceStatus> deviceStatuses = new List<DeviceStatus>();
           deviceStatuses = washroomManager.GetDeviceStatusInWashrooms(1,1);
           var deviceTypes = deviceStatuses.GroupBy(x => new { x.DeviceType });
           

           Assert.IsNotNull(deviceStatuses);
       }

        [TestMethod]
        public void GetAlertDetailsByAlertType()
        {
            
            Assert.IsNotNull(buildingManager.GetAlertDetailsByAlertType(1, 1, 1));
        }

        [TestMethod]
        public  void TestLocalTimeCOnversionBUlkData()
        {

            for (int i = 1; i <= 1000000;i++)
            {
                var inputDate = DateTime.UtcNow;
                inputDate = CommonHelper.GetLocalTime(inputDate, "Eastern Standard Time");
            }
        }
    }
}
