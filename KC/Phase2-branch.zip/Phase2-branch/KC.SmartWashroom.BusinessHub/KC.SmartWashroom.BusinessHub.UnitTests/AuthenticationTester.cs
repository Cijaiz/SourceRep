﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using KC.SmartWashroom.Business;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.Core.Security.Authorization.Structure;

namespace KC.SmartWashroom.BusinessHub.UnitTests
{
    [TestClass]
    public class AuthenticationTester
    {
        MembershipBusinessManager manager;

        [TestInitialize]
        public void Initialize()
        {
            manager = new MembershipBusinessManager();
        }

        [TestMethod]
        public void TestLoginUser()
        {
            string userName = "vijayananthan.jc@cognizant.com";
            string password = "00";

            ProcessResponse<UserContext> expectedResponse = new ProcessResponse<UserContext>() { Status = ResponseStatus.Success };
            var response = manager.LoginUser(userName, password);

            Assert.AreEqual(expectedResponse.Status, response.Status);
            Assert.IsNotNull(response.Object, "User Context is Empty..");
        }

        [TestMethod]
        public void TestResetLoginCredentials()
        {
            string userName = "vijayananthan.jc@cognizant.com";
            string oldPassword = "12345";
            string password = "00";

            ProcessResponse<UserContext> expectedResponse = new ProcessResponse<UserContext>() { Status = ResponseStatus.Success };
            var response = manager.ResetUserCredentials(userName, oldPassword, password);

            Assert.IsTrue(response);
        }

        [TestMethod]
        public void TestGenerateUserCredentials()
        {
            string userName = "admin@kcc.com";
            string password = "passme000";

            ProcessResponse<UserContext> expectedResponse = new ProcessResponse<UserContext>() { Status = ResponseStatus.Success };
            var response = manager.GenerateUserCredentials(userName, password);

            Assert.IsTrue(response);
        }
    }
}
