﻿using KC.SmartWashroom.Business;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.Core.Helper;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.BusinessHub.UnitTests
{
    [TestClass]
    public class DeviceTenantTester
    {
        DeviceTenantManager manager;
        [TestInitialize]
        public void Initialize()
        {
            if (manager == null)
            {
                manager = new DeviceTenantManager();
            }
        }

        [TestMethod]
        public void TestGetContactsForCustomer()
        {
            var response = manager.RetriveReturnParametersForDevice("000000465506dd2b36", 1);
            Assert.IsTrue(response != null, "Failed...");
        }

        [TestMethod]
        public void TestDeleteDeviceParameters()
        {

            BusinessEntities.ReturnParameterDataTransfer dataTransfer = new BusinessEntities.ReturnParameterDataTransfer();
            string deviceID = "0000078a20040bd140e";
            dataTransfer.customerId = 1;
            dataTransfer.ParamterValueIds.Add(72);
            dataTransfer.ParamterValueIds.Add(73);
            var response = manager.DeleteDeviceParameterValues(deviceID, dataTransfer);
            //RetriveReturnParametersForDevice("0000078a20040bd140e", 1);
            Assert.IsTrue(response != null, "Failed...");
        }


        [TestMethod]
        public void TestDeviceUpsetReturnParameters()
        {
            string deviceID = "0000078a20040bd140e";

            //Pull values..
            ReturnParameterResponse responses = new ReturnParameterResponse();
            ReturnParameterDataTransfer dataTransfer = new ReturnParameterDataTransfer();
            responses = manager.RetriveReturnParametersForDevice("0000078a20040bd140e", 1);
            foreach (var ss in responses.returnValueParameters)
            {
                if (!ss.ParameterValue.CustomerId.HasValue)
                {
                    ss.ParameterValue = new DeviceParameterValueEntity();
                }
                ss.ParameterValue.Value = ss.Parameter.DeviceParameterId.Equals(10) ? "1" : "320";
                ss.ParameterValue.CustomerId = 1;
                ss.ParameterValue.DeviceParameterValueId = ss.Parameter.DeviceParameterId;
            }

            dataTransfer.customerId = 1;
            List<ReturnParameterResponse> returnValueParameters = new List<ReturnParameterResponse>();
            returnValueParameters.Add(responses);
            var response = manager.DeviceUpsetReturnParameters(deviceID, returnValueParameters, dataTransfer.customerId);
            Assert.IsTrue(response.Status.Equals(ResponseStatus.Success), "Error Saving");
        }


    }
}
