﻿using KC.SmartWashroom.BusinessEntities.BusinessHubEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.DependencyInjector;
using KC.SmartWashroom.Core.Enumerations;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.DataAccess.Skeleton;
using System;
using System.Collections.Generic;
using BusinessEntity = KC.SmartWashroom.BusinessEntities;

namespace KC.SmartWashroom.Business
{
    public class WashroomBusinessManager : BusinessManagerBase<IWashroomWorker>
    {

        public void ManualInjection<T>()
        {
            this.dataWorker = (IWashroomWorker)Injector.Resolve<T>();
        }

        public BusinessEntity.Washroom GetWashroomDetails(int washroomId, int userId)
        {
            BusinessEntity.Washroom washroom = this.dataWorker.GetWashroomDetails(washroomId);
            Guard.IsNotNull(washroom, "Washroom details from database");

            AddParametersToAuditInformation("WashroomId", washroomId);
            BuildAuditInfo();
            AuditLog(userId, Core.Enumerations.Enums.AuditActivity.ViewWashroom);
            return washroom;
        }

        public List<BusinessEntity.Gender> GetGenders()
        {
            List<BusinessEntity.Gender> Genders = this.dataWorker.GetGenders();
            Guard.IsNotNull(Genders, "Genders from database");
            return Genders;
        }

        public List<BusinessEntity.Wing> GetWings()
        {
            List<BusinessEntity.Wing> Wings = this.dataWorker.GetWings();
            Guard.IsNotNull(Wings, "Wings from database");
            return Wings;
        }

        public ProcessResponse<BusinessEntity.Washroom> Create(BusinessEntity.Washroom washroom)
        {
            ProcessResponse<BusinessEntity.Washroom> response = new ProcessResponse<BusinessEntity.Washroom>();
            response = this.dataWorker.Create(washroom);

            AddParametersToAuditInformation("FloorLevel", washroom.FloorLevel);
            BuildAuditInfo();
            AuditLog(washroom.CreatedBy, Core.Enumerations.Enums.AuditActivity.CreateWashroom);
            return response;
        }

        public ProcessResponse<BusinessEntity.Washroom> Update(BusinessEntity.Washroom washroom)
        {
            ProcessResponse<BusinessEntity.Washroom> response = new ProcessResponse<BusinessEntity.Washroom>();
            response = this.dataWorker.Update(washroom);

            AddParametersToAuditInformation("WashroomName", washroom.Name);
            BuildAuditInfo();
            AuditLog(washroom.LastUpdatedBy != null ? Convert.ToInt32(washroom.LastUpdatedBy) : 0, Core.Enumerations.Enums.AuditActivity.EditWashroom);
            return response;
        }

        public ProcessResponse<BusinessEntity.Washroom> Delete(BusinessEntity.Washroom washroom)
        {
            ProcessResponse<BusinessEntity.Washroom> response = new ProcessResponse<BusinessEntity.Washroom>();
            response = this.dataWorker.Delete(washroom);

            AddParametersToAuditInformation("WashroomId", washroom.ID);
            BuildAuditInfo();
            AuditLog(washroom.LastUpdatedBy != null ? Convert.ToInt32(washroom.LastUpdatedBy) : 0, Core.Enumerations.Enums.AuditActivity.DeleteWashroom);
            return response;
        }

        public List<BusinessEntity.Washroom> GetWashroomsByFloorId(string propertyName, string buildingName, string floorLevel, string washroomName, int floorId, int userId)
        {
            Guard.IsNotNull(userId, "userID");

            #region Audit log
            base.AddParametersToAuditInformation("PropertyName", propertyName);
            base.AddParametersToAuditInformation("BuildingName", buildingName);
            base.AddParametersToAuditInformation("FloorLevel", floorLevel);
            base.AddParametersToAuditInformation("WashroomName", washroomName);
            base.BuildAuditInfo();

            base.AuditInformation.AuditActivityType = Core.Enumerations.Enums.AuditActivity.WashroomView;
            base.AuditInformation.PerformedBy = userId.ToString();
            base.AuditInformation.AuditInfo = base.FinalAuditInformation;
            base.TraceAuditInformation();

            #endregion
            return this.dataWorker.GetWashroomsByFloorId(floorId);
        }
        public List<BusinessEntity.Washroom> GetWashroomsByFloorIdWithoutLog(int floorId)
        {
            return this.dataWorker.GetWashroomsByFloorId(floorId);
        }
        public List<BusinessEntity.Washroom> GetWashroomsByFloorIdGroupedByGender(int floorId)
        {
            return this.dataWorker.GetWashroomsByFloorIdGroupedByGender(floorId);

        }
        public IList<BusinessEntity.Washroom> GetWashrromsByPropertyAndGeneder(int propertyId, byte genderId)
        {
            return this.dataWorker.GetWashrromsByPropertyAndGeneder(propertyId, genderId);
        }
        public decimal GetDeviceRefillValue(string size, string DeviceType)
        {
            byte productUsageBuffer = 0;
            return this.dataWorker.GetDeviceRefillValue(size, DeviceType, out productUsageBuffer);
        }
        public DeviceAlertsResolutionDetail GetDeviceLastDispensedValue(int customerId, string deviceId, string deviceType)
        {
            byte productUsageBuffer = 0;
            DeviceAlertsResolutionDetail alertResolutionDetail = null;
            DeviceBusinessManager deviceManager = new DeviceBusinessManager();

            //var thresholdValuesString = CommonHelper.GetConfigSetting(AlertEngineConstants.THRESHOLD_VALUES);
            //var thresholdValue = SerializationHelper.JsonDeserialize<ThresholdValue>(thresholdValuesString);

            deviceManager.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Table_Workers.DeviceWorker>();
            var SizeandDispensed = deviceManager.GetDeviceSizeandLastDispensedValue(customerId, deviceId);

            if (SizeandDispensed == null || string.IsNullOrEmpty(SizeandDispensed.DeviceSize))
                return alertResolutionDetail;

            string deviceSize = SizeandDispensed.DeviceSize;
            decimal deviceSinceLastDispensed = SizeandDispensed.DeviceSinceLastDispensed;

            decimal deviceRefillValue = this.dataWorker.GetDeviceRefillValue(deviceSize, deviceType, out productUsageBuffer);
            decimal ProductThresholdValue = this.dataWorker.GetESoapShotSize(SizeandDispensed.ShotSize); //ProductThresholdValue; Retrival from DB..

            alertResolutionDetail = new DeviceAlertsResolutionDetail();
            alertResolutionDetail.DeviceId = deviceId;
            alertResolutionDetail.DeviceType = deviceType;
            alertResolutionDetail.CustomerID = customerId;

            alertResolutionDetail.RefillSize = deviceSize;
            alertResolutionDetail.IsRefillHappened = true;
            alertResolutionDetail.NoOfDispensesSinceLastRefill = deviceSinceLastDispensed;

            alertResolutionDetail.RefillPercentage = (int)CommonHelper.CalculateDevicePercentageLevel(deviceType, deviceSinceLastDispensed,
                                                                                                        deviceRefillValue,
                                                                                                        ProductThresholdValue,
                                                                                                        productUsageBuffer);
            return alertResolutionDetail;
        }

        public List<BusinessEntity.DeviceStatus> GetDeviceStatusInWashrooms(int floorId, int washroomId)
        {
            byte productUsageBuffer = 0;
            DeviceBusinessManager deviceManager = new DeviceBusinessManager();
            List<BusinessEntity.DeviceStatus> deviceStatuses = new List<BusinessEntity.DeviceStatus>();

            deviceStatuses = this.dataWorker.GetDeviceStatusInWashrooms(floorId, washroomId);
            int customerId = this.dataWorker.GetCustomerId(washroomId);

            //var thresholdValuesString = CommonHelper.GetConfigSetting(AlertEngineConstants.THRESHOLD_VALUES);
            //var thresholdValue = SerializationHelper.JsonDeserialize<ThresholdValue>(thresholdValuesString);

            //decimal ProductThresholdValue = Convert.ToDecimal(thresholdValue.ProductRefillValue.ToString());
            //decimal LowBatteryThresholdValue = Convert.ToDecimal(thresholdValue.LowBatteryThresholdValue.ToString());
            foreach (var item in deviceStatuses)
            {
                deviceManager.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Table_Workers.DeviceWorker>();
                var SizeandDispensed = deviceManager.GetDeviceSizeandLastDispensedValue(customerId, item.DeviceId);
                if (SizeandDispensed != null)
                {
                    item.DeviceLastDispensed = SizeandDispensed.DeviceSinceLastDispensed;
                    item.CurrentBatteryVoltage = SizeandDispensed.CurrentBatteryVoltage;
                    item.DeviceSize = SizeandDispensed.DeviceSize;

                    decimal DeviceRefillValue = this.dataWorker.GetDeviceRefillValue(item.DeviceSize, item.DeviceType, out productUsageBuffer);

                    item.DeviceRefillValue = DeviceRefillValue;
                    item.ProductThresholdValue = this.dataWorker.GetESoapShotSize(SizeandDispensed.ShotSize); //ProductThresholdValue; Retrival from DB..
                    item.MinBatteryVoltage = item.MinBatteryVoltage; //LowBatteryThresholdValue; Retrival from DB..
                    item.PercentageLevel = CommonHelper.CalculateDevicePercentageLevel(item.DeviceType,
                                                                                        item.DeviceLastDispensed,
                                                                                        item.DeviceRefillValue,
                                                                                        item.ProductThresholdValue,
                                                                                        item.ProductUsageBuffer.Value); //ProductThresholdValue);

                    if (item.MinBatteryVoltage != 0)
                    {
                        //Formulat Reference. Battery Percentage = (1 - (MaxVOltage - Current VOltage) / (MaxVoltage - MinVOltage)) * 100
                        decimal batteryPercentage = ((1 - (item.MaxBatteryVoltage - (decimal)item.CurrentBatteryVoltage) / (item.MaxBatteryVoltage - item.MinBatteryVoltage)) * 100);
                        item.LowBatteryPercentageLevel = (batteryPercentage < 0) ? 0 : ((batteryPercentage > 100) ? 100 : batteryPercentage);
                    }
                }
            }
            return deviceStatuses;
        }

        public Names GetNames(int floorId)
        {
            Guard.IsNotNull(floorId, "floorId");
            return this.dataWorker.GetNames(floorId);
        }

        private void AuditLog(int userId, Core.Enumerations.Enums.AuditActivity activity)
        {

            base.AuditInformation.AuditActivityType = activity;
            base.AuditInformation.PerformedBy = userId.ToString();
            base.AuditInformation.AuditInfo = base.FinalAuditInformation;
            base.TraceAuditInformation();

        }
    }
}
