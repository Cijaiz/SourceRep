﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.Enumerations;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.DataAccess.Skeleton;
using System;
using System.Collections.Generic;

namespace KC.SmartWashroom.Business
{
    public class CustomerBusinessManager : BusinessManagerBase<ICustomerWorker>
    {
        public string ErrorDetail { get; private set; }

        public ProcessResponse SaveCustomer(CustomerDetail customerDetail)
        {
            Guard.IsNotNull(customerDetail, "Customer");
            SaveActivityInLog(Enums.AuditActivity.CreateCustomer, customerDetail.UserId, Enums.ActivityLogNames.CustomerName, customerDetail.CustomerName);
            return this.dataWorker.CreateCustomer(customerDetail.CustomerName, customerDetail.Street, customerDetail.BuildingAddress, customerDetail.City, customerDetail.State, customerDetail.Country, customerDetail.Pincode, customerDetail.CreatedBy, customerDetail.CreatedDate);
        }

        public List<CustomerDetail> GetAllCustomers(int userId)
        {
            SaveActivityInLog(Enums.AuditActivity.GetallCustomer, userId, Enums.ActivityLogNames.AllCustomers, "(allcustomers)");
            List<CustomerDetail> customerDetails = new List<CustomerDetail>();
            customerDetails = this.dataWorker.GetAllCustomers();
            if (customerDetails.Equals(null))
                ErrorDetail = this.dataWorker.ErrorDetail;

            return customerDetails;
        }

        public CustomerDetail GetCustomer(int customerId, int userId)
        {
            SaveActivityInLog(Enums.AuditActivity.ViewCustomer, userId, Enums.ActivityLogNames.CustomerId, customerId.ToString());
            Guard.IsNotNull(customerId, "Customer");
            CustomerDetail customerDetail = new CustomerDetail();
            customerDetail = this.dataWorker.GetCustomer(customerId);
            if (customerDetail.Equals(null))
                ErrorDetail = this.dataWorker.ErrorDetail;

            return customerDetail;
        }

        public string GetCustomerName(int propertyId)
        {
            Guard.IsNotNull(propertyId, "Customer");
            return this.dataWorker.GetCustomerName(propertyId);
        }

        public ProcessResponse UpdateCustomer(CustomerDetail customerDetail)
        {
            Guard.IsNotNull(customerDetail, "Customer");
            SaveActivityInLog(Enums.AuditActivity.EditCustomer, customerDetail.UserId, Enums.ActivityLogNames.CustomerName, customerDetail.CustomerName);
            return this.dataWorker.UpdateCustomer(customerDetail);
        }

        public ProcessResponse DeleteCustomer(int customerIdToDelete, int userId)
        {
            Guard.IsNotNull(customerIdToDelete, "CustomerId");
            SaveActivityInLog(Enums.AuditActivity.DeleteCustomer, userId, Enums.ActivityLogNames.CustomerId, customerIdToDelete.ToString());
            return this.dataWorker.DeleteCustomer(customerIdToDelete);
        }

        public List<Countries> GetAllCountries()
        {
            List<Countries> countries = new List<Countries>();
            countries = this.dataWorker.GetAllCountries();
            if (countries.Equals(null))
                ErrorDetail = this.dataWorker.ErrorDetail;
            return countries;
        }

        private void SaveActivityInLog(Enums.AuditActivity activity, int userId, Enums.ActivityLogNames activityName, string Name)
        {
            base.AddParametersToAuditInformation(activityName.ToString(), Name);
            base.BuildAuditInfo();

            base.AuditInformation.AuditActivityType = activity;
            base.AuditInformation.PerformedBy = userId.ToString();
            base.AuditInformation.AuditInfo = base.FinalAuditInformation;
            base.TraceAuditInformation();
        }

        public Dictionary<DeviceTypes, List<BusinessEntities.ReturnValueParameter>> GetDeviceParameters(int customerId)
        {
            Dictionary<DeviceTypes, List<BusinessEntities.ReturnValueParameter>> parameters = new Dictionary<DeviceTypes, List<BusinessEntities.ReturnValueParameter>>();
            parameters = this.dataWorker.GetDeviceParameters(customerId);
            if (parameters.Equals(null))
                ErrorDetail = this.dataWorker.ErrorDetail;
            return parameters;
        }

        public ProcessResponse<List<ReturnValueParameter>> UpsetReturnParameters(List<ReturnParameterResponse> returnValueParameters, int customerId)
        {
            ProcessResponse<List<ReturnValueParameter>> response = new ProcessResponse<List<ReturnValueParameter>>();
            DeviceBusinessManager deviceBM = new DeviceBusinessManager();
            response = this.dataWorker.UpsetReturnParameters(returnValueParameters, customerId);
            if (response.Status == ResponseStatus.Success)
                deviceBM.SendMessageForCustomerLevelReset(customerId);
            return response;
        }

        public ProcessResponse DeleteDeviceParameterValue(List<Nullable<int>> paramterValueId, int customerId)
        {
            ProcessResponse response = new ProcessResponse();
            DeviceBusinessManager deviceBM = new DeviceBusinessManager();
            response = this.dataWorker.DeleteDeviceParameterValues(paramterValueId);
            if (response.Status == ResponseStatus.Success)
                deviceBM.SendMessageForCustomerLevelReset(customerId);
            return response;
        }

        public List<DeviceParameterValueEntity> GetCustermerLevelDeviceParameterValue(int customerId)
        {
            return this.dataWorker.GetCustermerLevelDeviceParameterValue(customerId);
        }
        
    }
}
