﻿

namespace KC.SmartWashroom.Business
{
    using KC.SmartWashroom.Business.Contracts;
    using KC.SmartWashroom.BusinessEntities.DeviceUpdate;
    using KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers;
    using KC.SmartWashroom.DataAccess.Skeleton;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    /*Note: Subclassing is avoided by design*/

    /// <summary>
    /// The data provider device manager
    /// </summary>
    //[Obsolete("Please use the DeviceMetadataManager instead")]
    public class DeviceUpdateValueManager : IDeviceUpdateValueManager, IDisposable
    {
        /* TODO: Move the interface outside as a common assembly and to refer it everywhere.
         */
        /// <summary>
        /// Constructor; designed for DI and unit test
        /// </summary>
        /// <param name="parameterStore"></param>

        public DeviceUpdateValueManager(IDeviceParameterWorker parameterStore = null)
        {
            this.ParameterStore = parameterStore ?? new DeviceParameterWorker();
        }


        /// <summary>
        /// The persistence store
        /// </summary>
        protected virtual IDeviceParameterWorker ParameterStore { get; set; }

        /// <summary>
        /// Dispose
        /// </summary>
        public void Dispose()
        {

            if (this.ParameterStore is IDisposable)
            {
                var disposable = this.ParameterStore as IDisposable;
                disposable.Dispose();
            }
            this.Dispose(true);
        }

        /// <summary>
        /// Dispose override
        /// </summary>
        /// <param name="isDisposing">override parameter</param>
        protected virtual void Dispose(bool isDisposing)
        {
            // do nothing :)
        }

        /// <summary>
        /// Gets the device parameters from the persistence store
        /// </summary>
        /// <param name="deviceId">The unique device identifier</param>
        /// <returns>An enumerable of the device parameters</returns>
        public IEnumerable<DeviceUpdateDetails> GetDeviceDetails(string deviceId)
        {
            var deviceParameters = default(IEnumerable<DeviceUpdateDetails>);

            if (!string.IsNullOrWhiteSpace(deviceId))
            {
                // getter friendly property reference
                var store = this.ParameterStore;

                if (store != null)
                {
                    deviceParameters = store.GetDeviceDetails(deviceId: deviceId);
                }

            }

            return deviceParameters ?? Enumerable.Empty<DeviceUpdateDetails>();
        }

        public IEnumerable<DeviceUpdateDetails> RetrieveFromCache(string deviceId)
        {
            IEnumerable<DeviceUpdateDetails> deviceUpdateDetails = null;

            if (!string.IsNullOrWhiteSpace(deviceId))
            {
                // getter friendly property reference
                var store = this.ParameterStore;

                if (store != null)
                {
                    deviceUpdateDetails = store.RetrieveFromCache(deviceId);
                }

            }

            return deviceUpdateDetails;
        }
        /// <summary>
        /// Sets the auto reset parameter values back to the store
        /// </summary>
        /// <param name="parameters">The list of auto reset parameters</param>
        /// <returns>The number of records affected</returns>
        public int SetAutoResetParameterValues(IEnumerable<DeviceUpdateParameter> parameters)
        {
            int recordsAffected = 0;
            if (parameters != null)
            {
                var store = this.ParameterStore;

                if (store != null)
                {
                    recordsAffected = store.OverwriteAutoResetParameterValues(parameters);
                }

            }

            return recordsAffected;
        }

        public bool SaveToCache(DeviceUpdateDetails d)
        {
            try
            {
                this.ParameterStore.SaveToCache(d);
                return true;
            }
            catch (Exception ex)
            {
                KC.SmartWashroom.Core.Log.Logger.Error(string.Format("DeviceUpdateValueManager.SaveToCache(deviceid {0}): An error occurred", d.DeviceId), ex);
                //throw new ApplicationException("An error occurred while saving device to cahce", ex);
                return false;
            }
        }

        public DeviceUpdateDetails GetFromCache(string deviceId)
        {
            DeviceUpdateDetails obj = null;

            try
            {
                obj = this.ParameterStore.GetFromCache(deviceId);
                return obj;
            }
            catch (Exception ex)
            {
                KC.SmartWashroom.Core.Log.Logger.Error(string.Format("DeviceUpdateValueManager.GetFromCache(deviceid {0}): An error occurred", deviceId), ex);
                throw new ApplicationException("Error occurred when getting device from cache", ex);
                //throw;
            }
        }

        public bool RemoveFromCache(string deviceId = "")
        {
            try
            {
                this.ParameterStore.RemoveFromCache(deviceId);
                return true;
            }
            catch (Exception ex)
            {
                KC.SmartWashroom.Core.Log.Logger.Error(string.Format("DeviceUpdateValueManager.RemoveFromCache(deviceid {0}): An error occurred", deviceId), ex);
                //throw new ApplicationException("An error occurred while saving device to cahce", ex);
                return false;
            }
        }
    }
}
