﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.BusinessHubEntities;
using KC.SmartWashroom.BusinessEntities.DashboardApiEntities;
using KC.SmartWashroom.Core.DependencyInjector;
using KC.SmartWashroom.Core.Helper;
using TableWorkers = KC.SmartWashroom.DataAccess.DataWorkers.Table_Workers;
using EntityWorkers = KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers;
using KC.SmartWashroom.DataAccess.Skeleton;
using System;
using System.Collections.Generic;
using System.Linq;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.Core.Constants;

namespace KC.SmartWashroom.Business
{
    public class ActivityBusinessManager : BusinessManagerBase<IActivityWorker>
    {
        public void ManualInjection<T>()
        {
            this.dataWorker = (IActivityWorker)Injector.Resolve<T>();
        }

        public ProcessResponse<Activity> CreateActivity(Activity activity)
        {
            this.ManualInjection<EntityWorkers.ActivityWorker>();
            return this.dataWorker.CreateActivity(activity);
        }

        public Activity GetActivity(int activityId)
        {
            this.ManualInjection<EntityWorkers.ActivityWorker>();
            return this.dataWorker.GetActivity(activityId);
        }

        public BuildingEntity GetActivities(int customerId, int userId)
        {
            this.ManualInjection<EntityWorkers.ActivityWorker>();
            BuildingEntity buildingEnt = new BuildingEntity();
            buildingEnt = this.dataWorker.GetActivities(customerId);
            SetFloorSets(buildingEnt);
            SetDeviceAlertType(buildingEnt);
            return buildingEnt;
        }

        public BuildingEntity GetActivitiesByFilter(int customerId, int userId, string alertType, DateTime fromDate, DateTime toDate)
        {
            this.ManualInjection<EntityWorkers.ActivityWorker>();
            BuildingEntity buildingEnt = new BuildingEntity();
            buildingEnt = this.dataWorker.GetActivitiesByFilter(customerId, alertType, fromDate, toDate);
            SetFloorSets(buildingEnt);
            SetDeviceAlertType(buildingEnt);
            return buildingEnt;
        }
        public IList<DeviceAlertsResolutionDetail> GetRecentActivities(SearchCriteria searchCriteria)
        {
            if(searchCriteria.CustomerId<=0)
            {
                PropertyBusinessManager manager = new PropertyBusinessManager();
                Property property = manager.GetProperty(searchCriteria.PropertyId, searchCriteria.UserId);
                searchCriteria.CustomerId = property.CustomerId;
            }
            return PrepareAlertResolutions(searchCriteria);
        }
        public ActivityResult GetActivities(SearchCriteria searchCriteria)
        {
            ActivityResult activityResult = new ActivityResult();
            if (searchCriteria.WashroomGenderId > 0)
            {
                FillWashroomList(searchCriteria);
            }
            IList<DeviceAlertsResolutionDetail> alertResolutions = PrepareAlertResolutions(searchCriteria);
            activityResult.Activities = alertResolutions.ToList();

            SearchCriteria statsSearchCriteria = new SearchCriteria();
            CommonHelper.ShallowCopy(statsSearchCriteria, searchCriteria);
            PrepareDailyStatsInfo(statsSearchCriteria, activityResult);

            activityResult.NextPartitionKey = searchCriteria.NextPartitionKey;
            activityResult.NextRowKey = searchCriteria.NextRowKey;
            AuditLog(searchCriteria.UserId, KC.SmartWashroom.Core.Enumerations.Enums.AuditActivity.GetAllActivities);
            return activityResult;
        }
        private int GetTrafficCount(SearchCriteria searchCriteria)
        {
            this.ManualInjection<EntityWorkers.ActivityWorker>();
            int count = this.dataWorker.SumEhrtDevices(searchCriteria);
            return count > 0 ? count / 2 : 0;
        }
        private IList<DeviceAlertsResolutionDetail> PrepareAlertResolutions(SearchCriteria searchCriteria)
        {
            RecentUpdatesManager recentUpdatesManager = new RecentUpdatesManager();
            IList<DeviceAlertsResolutionDetail> alertResolutions = recentUpdatesManager.SearchActivities(searchCriteria);
            if (alertResolutions != null && alertResolutions.Count > 0)
            {
                DeviceBusinessManager deviceManager = new DeviceBusinessManager();
                IList<DeviceResolutionDetail> deviceDetails = deviceManager.GetDeviceInfo(searchCriteria.PropertyId, alertResolutions.Select(item => item.DeviceId).Distinct().ToList());
                if (deviceDetails != null && deviceDetails.Count > 0)
                {
                    FilleDeviceInfo(alertResolutions, deviceDetails);
                }
            }
            return alertResolutions;

        }
        private void PrepareDailyStatsInfo(SearchCriteria searchCriteria, ActivityResult activityResult)
        {
            searchCriteria.NextPartitionKey = null;
            searchCriteria.NextRowKey = null;
            searchCriteria.FromDate = DateTime.UtcNow.AddHours(CommonConstants.LAST_STATS_DURATION);
            searchCriteria.ResolutionOnly = false;
            searchCriteria.ToDate = DateTime.UtcNow;
            searchCriteria.PageSize = 1000;

            RecentUpdatesManager recentUpdatesManager = new RecentUpdatesManager();
            List<DeviceAlertsResolutionDetail> alertResolutions = recentUpdatesManager.SearchActivities(searchCriteria);
            if (alertResolutions != null && alertResolutions.Count>0)
            {
                int resolutionTimeinMins = 0;
                int resolutionCount = 0;
                int alertCount = 0;
                alertResolutions.ForEach(item => 
                    {
                        if(string.IsNullOrEmpty(item.AlertResolvedOn))
                        {
                            alertCount++;
                        }
                        else
                        {
                             resolutionCount++;
                             resolutionTimeinMins = resolutionTimeinMins + item.ResolutionTimeSpanMinutes;
                        }
                    });
                if (resolutionTimeinMins > 0)
                {
                    activityResult.AverageResponseTime = resolutionTimeinMins / resolutionCount;
                }
                activityResult.TotalResolvedAlertsCount = resolutionCount;
                activityResult.TotalAlertsCount= alertCount;
            }
            activityResult.TrafficUsage = GetTrafficCount(searchCriteria);
            
        }
        private void FilleDeviceInfo(IList<DeviceAlertsResolutionDetail> alertResolutions, IList<DeviceResolutionDetail> deviceDetails)
        {
            foreach (DeviceAlertsResolutionDetail resolutionInfo in alertResolutions)
            {
                var device = deviceDetails
                    .Where(d => string.Equals(d.DeviceID, resolutionInfo.DeviceId, StringComparison.OrdinalIgnoreCase))
                    .FirstOrDefault();
                if (device != null)
                {
                    resolutionInfo.Floor = device.Floor;
                    resolutionInfo.PropertyName = device.PropertyName;
                    resolutionInfo.BuildingName = device.Building;
                    resolutionInfo.Wing = device.Wing;
                    resolutionInfo.WashroomGender = device.WashroomGender;
                    resolutionInfo.DeviceName = device.DeviceName;
                    resolutionInfo.DeviceType = device.DeviceType;
                    resolutionInfo.LocalTimeZone = device.LocalTimeZone;
                }
            }
        }
        private void FillWashroomList(SearchCriteria searchCriteria)
        {
            WashroomBusinessManager manager = new WashroomBusinessManager();
            IList<Washroom> washroomList = manager.GetWashrromsByPropertyAndGeneder(searchCriteria.PropertyId, searchCriteria.WashroomGenderId);
            if (washroomList != null && washroomList.Count > 0)
            {
                searchCriteria.WashroomList = washroomList.Select(item => item.ID).ToList<int>();
            }
            else
            {
                searchCriteria.WashroomList = new List<int>() { 0 };
            }

        }
        public List<string> GetAllAlertTypes()
        {
            this.ManualInjection<EntityWorkers.ActivityWorker>();
            return this.dataWorker.GetAllAlertTypes();
        }

        public List<string> GetAlertTypesForDeviceType(byte deviceTypeId)
        {
            this.ManualInjection<EntityWorkers.ActivityWorker>();
            return this.dataWorker.GetAlertTypesForDeviceType(deviceTypeId);
        }


        public List<DeviceTypes> GetAllDeviceTypes()
        {
            this.ManualInjection<EntityWorkers.ActivityWorker>();
            return this.dataWorker.GetAllDeviceTypes();
        }

        public List<Gender> GetAllRoomTypes()
        {
            this.ManualInjection<EntityWorkers.ActivityWorker>();
            return this.dataWorker.GetAllRoomTypes();
        }

        public List<Property> GetAllProperties(int customerId)
        {
            this.ManualInjection<EntityWorkers.ActivityWorker>();
            return this.dataWorker.GetAllProperties(customerId);
        }

        public List<Building> GetAllBuildings(int customerId, int propertyId)
        {
            this.ManualInjection<EntityWorkers.ActivityWorker>();
            return this.dataWorker.GetAllBuildings(customerId, propertyId);
        }

        public List<Floor> GetAllFloors(int buildingId)
        {
            this.ManualInjection<EntityWorkers.ActivityWorker>();
            return this.dataWorker.GetAllFloors(buildingId);
        }

        public int CountOutstandingDeviceAlerts(int customerId, int userId, string customerName)
        {
            int Count = 0;
            //Count of alerts call Property manager
            PropertyBusinessManager propMgr = new PropertyBusinessManager();
            List<PropertyAlert> props = (List<PropertyAlert>)propMgr.GetAllProperties(customerId, userId, customerName, 24);
            props.ForEach(o => Count = Count + o.AlertCount);
            AuditLog(userId, KC.SmartWashroom.Core.Enumerations.Enums.AuditActivity.CountOutstandingAlerts);
            return Count;
        }

        public int CountOutstandingDeviceAlertsFilter(int customerId, string alertTypeCode, DateTime fromDate, DateTime toDate)
        {
            this.ManualInjection<EntityWorkers.ActivityWorker>();
            return this.dataWorker.CountOutstandingDeviceAlertsFilter(customerId, alertTypeCode, fromDate, toDate);
        }

        public int CountDispenseseHRTDevices(int customerId, int userId, int roleLevel, int days)
        {
            int Count = 0;
            //Retrive device related details from device manager..
            DeviceBusinessManager deviceManager = new DeviceBusinessManager();
            //List<DeviceResolutionDetail> devices = deviceManager.FetcheHRTDevicesForUser(userId, roleLevel, customerId);
            //this.ManualInjection<ActivityWorker>();
            //Count = this.dataWorker.SumDispenseseHRTDevice(customerId, devices, days);
            this.ManualInjection<EntityWorkers.ActivityWorker>();
            //Count = this.dataWorker.SumEhrtDevices(customerId, roleLevel, userId);
            AuditLog(userId, KC.SmartWashroom.Core.Enumerations.Enums.AuditActivity.CountDispenseseHRTDevices);
            return Count;
        }

        private void SetFloorSets(BuildingEntity buildingEntity)
        {
            buildingEntity.buildings.ForEach(b => b.floorSets = (from flr in b.floors
                                                                 where flr.Alerts.Count() > 0
                                                                 select new FloorSet
                                                                 {
                                                                     PropertyId = b.PropertyId,
                                                                     CustomerId = b.CustomerId,
                                                                     PropertyName = b.PropertyName,
                                                                     FloorWithAlert = flr
                                                                 }).ToList<FloorSet>());

            buildingEntity.buildings.ForEach(b => b.floorSets.Add((from flr in b.floors
                                                                   where flr.Alerts.Count() == 0
                                                                   select new FloorSet
                                                                   {
                                                                       PropertyId = b.PropertyId,
                                                                       CustomerId = b.CustomerId,
                                                                       PropertyName = b.PropertyName,
                                                                       FloorsWithoutAlert = b.floors.FindAll(o => o.Alerts.Count() == 0)
                                                                   }).FirstOrDefault<FloorSet>()));

            //Remove Null floorset entries created
            buildingEntity.buildings.ForEach(b => b.floorSets.RemoveAll(o => o == null));
        }

        private void SetDeviceAlertType(BuildingEntity buildingEntity)
        {
            buildingEntity.buildings.ForEach(b => b.floors.ForEach(f => f.Alerts.ForEach(a => a.AlertTypeName = CommonHelper.GetDeviceAlertType(a.AlertType).Value)));
        }

        private void AuditLog(int userId, KC.SmartWashroom.Core.Enumerations.Enums.AuditActivity audit)
        {
            AuditInformation.AuditActivityType = audit;
            AuditInformation.PerformedBy = userId.ToString();
            TraceAuditInformation();
        }
    }
}
