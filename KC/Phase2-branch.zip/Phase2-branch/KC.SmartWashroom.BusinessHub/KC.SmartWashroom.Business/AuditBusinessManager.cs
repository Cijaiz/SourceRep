﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.DependencyInjector;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.Core.Log;
using KC.SmartWashroom.DataAccess.Skeleton;
using System;

namespace KC.SmartWashroom.Business
{
    public class AuditBusinessManager : BusinessManagerBase<IAuditWorker>
    {
        public ProcessResponse TraceAuditInformation(Audit auditDetail)
        {
            if (CommonHelper.GetConfigSetting("EnableAuditLog").Equals("true", System.StringComparison.OrdinalIgnoreCase))
            {
                return this.dataWorker.LogAuditActivity(auditDetail);
            }
            else
            {
                return new ProcessResponse()
                {
                    Message = "Sucess",
                    Status = ResponseStatus.Success
                };
            }
        }
        public DeviceTrafficTrace CreateDeviceTrafficTrace(string section, string deviceId)
        {
            return new DeviceTrafficTrace()
            {
                DeviceId = deviceId,
                Section = section,
                InTime = DateTime.UtcNow
            };
        }
        public void TraceDeviceTraffic(DeviceTrafficTrace trace)
        {
            try
            {
                string enableTraceLog = CommonHelper.GetConfigSetting("EnableTraceLog") ?? "true";
                if (enableTraceLog.Equals("true", System.StringComparison.OrdinalIgnoreCase))
                {
                    Guard.IsNotNull(trace, "trace");
                    trace.OutTime = DateTime.UtcNow;
                    trace.PartitionKey = DateTime.UtcNow.ToString(CommonConstants.PARTITION_DATE_FORMAT);
                    trace.Duration = trace.OutTime.Subtract(trace.InTime);
                    this.dataWorker.TraceDeviceTraffic(trace);
                }
            }
            catch(Exception exp)
            {
                Logger.Error(exp.ToString());
            }
        }

    }
}
