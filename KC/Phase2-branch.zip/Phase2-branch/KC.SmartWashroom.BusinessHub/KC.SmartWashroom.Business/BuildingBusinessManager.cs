﻿using KC.SmartWashroom.Core.DependencyInjector;
using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
using KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers;
using KC.SmartWashroom.DataAccess.Skeleton;
using System.Collections.Generic;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.BusinessEntities.DashboardApiEntities;
using BusinessEntity = KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.BusinessEntities.BusinessHubEntities;
using System;

namespace KC.SmartWashroom.Business
{
    public class BuildingBusinessManager : BusinessManagerBase<IBuildingWorker>
    {
        public void ManualInjection<T>()
        {
            this.dataWorker = (IBuildingWorker)Injector.Resolve<T>();
        }

        public BuildingEntity GetBuildingDetailsByPropertyId(int buildingId, int propertyID, int userId)
        {
            Guard.IsNotNull(propertyID, "Property");
            Guard.IsNotNull(userId, "userId");
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.BuildingWorker>();
            BuildingEntity response = this.dataWorker.GetBuildingDetailsByPropertyId(propertyID);

            #region Audit log

            base.AddParametersToAuditInformation("PropertyName", response.PropertyName);
            base.AddParametersToAuditInformation("BuildingName", buildingId != 0 ? response.buildings.Find(x => x.ID.Equals(buildingId)).Name :
                                            ((response.buildings.Count > 0) ? response.buildings[0].Name : string.Empty));
            base.BuildAuditInfo();
            base.AuditInformation.AuditActivityType = Core.Enumerations.Enums.AuditActivity.BuildingView;
            base.AuditInformation.PerformedBy = userId.ToString();
            base.AuditInformation.AuditInfo = base.FinalAuditInformation;
            base.TraceAuditInformation();

            #endregion

            return response;
        }
        public List<BusinessEntities.Floor> GetFloorsByBuildingId(int ID)
        {
            Guard.IsNotNull(ID, "ID");
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.BuildingWorker>();
            List<BusinessEntities.Floor> response = this.dataWorker.GetFloorsByBuildingId(ID);
            return response;
        }


        public ProcessResponse<BusinessEntity.Building> CreateBuilding(BusinessEntity.Building building)
        {
            ProcessResponse<BusinessEntity.Building> response = new ProcessResponse<BusinessEntity.Building>();
            response = this.dataWorker.CreateBuilding(building);

            AddParametersToAuditInformation("PropertyName", building.PropertyName);
            BuildAuditInfo();
            AuditLog(building.CreatedBy, Core.Enumerations.Enums.AuditActivity.CreateBuilding);

            return response;
        }

        public ProcessResponse<BusinessEntity.Building> DeleteBuilding(BusinessEntity.Building building)
        {
            ProcessResponse<BusinessEntity.Building> response = new ProcessResponse<BusinessEntity.Building>();
            response = this.dataWorker.DeleteBuilding(building);

            AddParametersToAuditInformation("BuildingId", building.ID);
            BuildAuditInfo();
            AuditLog((building.LastUpdatedBy != null ? Convert.ToInt32(building.LastUpdatedBy) : 0), Core.Enumerations.Enums.AuditActivity.DeleteBuilding);
            return response;
        }

        public ProcessResponse<BusinessEntity.Building> UpdateBuilding(BusinessEntity.Building building)
        {
            ProcessResponse<BusinessEntity.Building> response = new ProcessResponse<BusinessEntity.Building>();
            response = this.dataWorker.UpdateBuilding(building);

            AddParametersToAuditInformation("BuildingName", building.Name);
            BuildAuditInfo();
            AuditLog((building.LastUpdatedBy != null ? Convert.ToInt32(building.LastUpdatedBy) : 0), Core.Enumerations.Enums.AuditActivity.EditBuilding);
            return response;
        }

        public BusinessEntity.Building GetBuildingDetails(int buildingId, int userId)
        {
            BusinessEntity.Building building = this.dataWorker.GetBuildingDetails(buildingId);
            Guard.IsNotNull(building, "Building details from database");

            AddParametersToAuditInformation("BuildingId", buildingId);
            BuildAuditInfo();
            AuditLog(userId, Core.Enumerations.Enums.AuditActivity.ViewBuilding);
            return building;
        }

        public List<KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert> GetAlertDetailsByAlertType(byte alertTypeId, int floorId, byte genderId)
        {

            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.BuildingWorker>();
            List<KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert> response = this.dataWorker.GetAlertDetailsByAlertType(alertTypeId, floorId, genderId);
            return response;
        }

        public List<KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert> GetAlertDetailsByAlertGroup(string alertGroupName, int floorId, byte genderId)
        {

            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.BuildingWorker>();
            List<KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert> response = this.dataWorker.GetAlertDetailsByAlertGroup(alertGroupName, floorId, genderId);
            return response;
        }

        public List<BusinessEntity.Floor> GetFloors(int buildingId)
        {
            return this.dataWorker.GetFloors(buildingId);
        }

        public Names GetNames(int propertyId)
        {
            Guard.IsNotNull(propertyId, "propertyId");
            return this.dataWorker.GetNames(propertyId);
        }

        public List<KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert> GetUnresponsiveDevices(int propertyId, int buildingId, int floorId, int washroomId)
        {
            int customerId = this.dataWorker.GetCustomerId(buildingId);
            DeviceBusinessManager deviceManager = new DeviceBusinessManager();

            List<DeviceResolutionDetail> devicesForBuilding = new List<DeviceResolutionDetail>();

            deviceManager.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.DeviceWorker>();
            devicesForBuilding = deviceManager.FetchDevicesForBuilding(propertyId, buildingId, floorId, washroomId);


            deviceManager.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Table_Workers.DeviceWorker>();
            var unresponsiveDevices = deviceManager.CheckUnresponsive(customerId, devicesForBuilding);

            return unresponsiveDevices;
        }

        public List<BusinessEntity.Building> GetAllBuildings(int customerId, int userId, int roleLevel)
        {
            return this.dataWorker.GetAllBuildings(customerId,userId,roleLevel);
        }

        private void AuditLog(int userId, Core.Enumerations.Enums.AuditActivity activity)
        {

            base.AuditInformation.AuditActivityType = activity;
            base.AuditInformation.PerformedBy = userId.ToString();
            base.AuditInformation.AuditInfo = base.FinalAuditInformation;
            base.TraceAuditInformation();

        }
    }
}
