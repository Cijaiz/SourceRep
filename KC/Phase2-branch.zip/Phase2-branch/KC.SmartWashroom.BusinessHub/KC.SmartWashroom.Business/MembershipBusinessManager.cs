﻿using System.Collections.Generic;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.Core.Security.Authorization.Structure;
using KC.SmartWashroom.DataAccess.Skeleton;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.Core.Enumerations;

namespace KC.SmartWashroom.Business
{
    public class MembershipBusinessManager : BusinessManagerBase<IMembershipWorker>
    {
        const string AUTH_FAIL = "AUTH_FAIL";
        const string AUTH_FAIL_CLEANER = "AUTH_FAIL_CLEANER";
        public ProcessResponse<UserContext> LoginUser(string userName, string password)
        {
            Guard.IsNotBlank(userName, "UserName");
            Guard.IsNotBlank(password, "Password");

            ProcessResponse<UserContext> response = new ProcessResponse<UserContext>() { Status = ResponseStatus.Failed, Message = AUTH_FAIL };

            //Actual Validation...
            string originalPasswordSalt = string.Empty;
            //Check for User Role with Cleaner role
            int RoleLevel = this.dataWorker.GetUserRoleLevel(userName);
            if (RoleLevel == (int)Enums.RoleLevelType.Cleaner)
            {
                response.Message = AUTH_FAIL_CLEANER;
                return response;
            }
            if (!this.ValidateLoginCredentials(userName, password, ref originalPasswordSalt))
                return response;

            response.Status = ResponseStatus.Success;
            response.Object = this.GetUserContextWithPermission(userName);
            if (response.Object == null)
            {
                response.Status = ResponseStatus.Failed;
                return response;
            }
            response.Message = string.Format("User {0} is successfully Authenticated..", userName);
            return response;
        }

        public bool ResetUserCredentials(string userName, string oldPassword, string newPassword)
        {
            string originalPasswordSalt = string.Empty;
            string newSaltedPassword = string.Empty;
            bool isPasswordReset = false;

            if (this.ValidateLoginCredentials(userName, oldPassword, ref originalPasswordSalt))
                if (!string.IsNullOrEmpty(originalPasswordSalt))
                    newSaltedPassword = CryptoHelper.HashData(originalPasswordSalt, newPassword);
                else
                {
                    originalPasswordSalt = CryptoHelper.GenerateSalt();
                    newSaltedPassword = CryptoHelper.HashData(originalPasswordSalt, newPassword);
                }

            if (!string.IsNullOrEmpty(newSaltedPassword))
                isPasswordReset = this.dataWorker.ResetUserCredentials(userName, newSaltedPassword, originalPasswordSalt);

            return isPasswordReset;
        }

        public bool GenerateUserCredentials(string userName, string password)
        {
            string passwordSalt = string.Empty;
            string saltedPassword = string.Empty;

            passwordSalt = CryptoHelper.GenerateSalt();
            saltedPassword = CryptoHelper.HashData(passwordSalt, password);
            return this.dataWorker.GenerateUserCredentials(userName, saltedPassword, passwordSalt);
        }

        public bool ValidateUserName(string userName, ref string saltedPassword)
        {
            return this.dataWorker.ValidateUserName(userName, ref saltedPassword);
        }
        public bool ValidateCustomer(string userName)
        {
            return this.dataWorker.ValidateCustomer(userName);
        }
        
        public List<RolePermission> GetUserPermissions(int userId)
        {
            return this.dataWorker.GetUserPermissions(userId);
        }

        private UserContext GetUserContextWithPermission(string userEmail)
        {
            Guard.IsNotNull(userEmail, "UserEmail");
            UserContext userDetailWithPermission = null;

            ProcessResponse<UserContext> response = this.dataWorker.GetUserContext(userEmail);
            if (response.Status == Core.Helper.ResponseStatus.Success)
            {
                userDetailWithPermission = new UserContext();
                userDetailWithPermission = response.Object;
            }
            return userDetailWithPermission;
        }

        private bool ValidateLoginCredentials(string userName, string password, ref string originalPasswordSalt)
        {
            bool isValid = false;
            originalPasswordSalt = string.Empty;
            KeyValuePair<string, string>? originalPasswordSaltPair = null;

            //Retrive the Original Password for Validation along with the Salt..
            originalPasswordSaltPair = this.dataWorker.RetriveUserCredentials(userName, password);
            if (!originalPasswordSaltPair.HasValue || string.IsNullOrEmpty(originalPasswordSaltPair.Value.Key)
                                                || string.IsNullOrEmpty(originalPasswordSaltPair.Value.Value))
                return isValid;

            //Generate SaltedPassword for Excat Comparision..
            string inputPasswordSalted = CryptoHelper.HashData(originalPasswordSaltPair.Value.Value, password);

            //Dont read the password instead compare directly for high security.. so that even code does not knows the password..
            if (string.Equals(inputPasswordSalted, originalPasswordSaltPair.Value.Key))
                isValid = true;

            originalPasswordSalt = originalPasswordSaltPair.Value.Key;
            return isValid;
        }

        public bool CreateFeatureForUserAuthorization(BusinessEntities.RolePermission newFeature)
        {
            return this.dataWorker.CreateFeature(newFeature);
        }

        public List<RolePermission> GetAuthorizationFeatures()
        {
            return this.dataWorker.GetFeatures();
        }

        public UserAssetEntity GetUserAssets(int userID)
        {
            return this.dataWorker.GetUserAssets(userID);
        }

        public BusinessEntities.BusinessHubEntities.UserAccessAsserts GetAllUserAsserts()
        {
            return this.dataWorker.GetAllUserAcessAsserts();
        }
    }
}
