﻿using KC.SmartWashroom.BusinessEntities.DeviceUpdate;
using KC.SmartWashroom.BusinessEntities.Search;
using KC.SmartWashroom.Core.Log;
using KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.Business
{
    public class CacheManager : IDisposable
    {
        private string _dbConnectionString = null;
        private KC.SmartWashroom.Business.Contracts.IDeviceMetadataManager _metadataMgr = null;
        private KC.SmartWashroom.Business.Contracts.IDeviceUpdateValueManager _deviceUpdateValueMgr = null;

        public CacheManager()
        {
            if (string.IsNullOrEmpty(this._dbConnectionString))
                this._dbConnectionString = EntityRepositoryManager.connectionString;

            _metadataMgr = new KC.SmartWashroom.Business.DeviceMetadataManager(new KC.SmartWashroom.DataAccess.DataWorkers.DeviceMetadataWorker(_dbConnectionString));
            _deviceUpdateValueMgr = new KC.SmartWashroom.Business.DeviceUpdateValueManager();
        }

        public CacheManager(string dbConnStr = null)
        {
            _dbConnectionString = dbConnStr;
            _metadataMgr = new KC.SmartWashroom.Business.DeviceMetadataManager(new KC.SmartWashroom.DataAccess.DataWorkers.DeviceMetadataWorker(_dbConnectionString));
            _deviceUpdateValueMgr = new KC.SmartWashroom.Business.DeviceUpdateValueManager();
        }

        public KC.SmartWashroom.Business.Contracts.IDeviceUpdateValueManager GetDeviceUpdateValueManager()
        {
            return _deviceUpdateValueMgr;
        }

        public DeviceUpdateDetails GetFromCache(string deviceId)
        {
            return _deviceUpdateValueMgr.GetFromCache(deviceId);
        }

        /// <summary>
        /// Fetches device details from database and updates it in cache
        /// </summary>
        /// <param name="deviceId">If specified, updates only that device. If not specified, updates all the devices</param>
        public void RefreshCache(string deviceId = null)
        {
            try
            {
                DeviceSearchParameters searchParameters = new DeviceSearchParameters();

                if (!string.IsNullOrWhiteSpace(deviceId))
                {
                    searchParameters.DeviceId = deviceId;
                    Logger.Debug("Device id is specified, search will be only for device {0}", deviceId);
                }

                Logger.Debug("Getting list of all devices");
                List<DeviceUpdateDetails> lst = _metadataMgr.GetDeviceDetails(searchParameters).ToList<DeviceUpdateDetails>();
                Logger.Debug("Received list of all devices, count is {0}", lst.Count);

                int count = lst.Count;
                int processed = 0;

                Logger.Debug("Looping through devices to add to cache");
                if (lst.Count > 0)
                {
                    foreach (DeviceUpdateDetails d in lst)
                    {
                        Logger.Debug("Adding to cache: Device ID {0}", d.DeviceId);
                        bool success = _deviceUpdateValueMgr.SaveToCache(d);
                        if (success)
                            Logger.Debug("Added to cache:  Device ID {0}", d.DeviceId);
                        else
                            Logger.Error("Business.CacheManager.RefreshCache: An error occurred while addeding to cache:  Device ID {0}", d.DeviceId);

                        processed++;
                        Logger.Debug("Processed {0} of {1} records", processed, count);
                    }
                    //lst.Clear();
                    //lst = null;
                }
                //Remove inactive devices from cache
                if (string.IsNullOrWhiteSpace(deviceId))
                {
                    //Remove all inactive devices if they exist
                    _deviceUpdateValueMgr.RemoveFromCache();
                }
                else
                {
                    //Remove only the single device if it does not exist
                    //List would not have received any entries if it has been removed or doesn't exist
                    if (lst.Count == 0)
                    {
                        _deviceUpdateValueMgr.RemoveFromCache(deviceId);
                    }
                }
                lst.Clear();
                lst = null;
            }
            catch (Exception ex)
            {
                Logger.Error("An error occurred while refreshing cache", ex);
                //throw;
            }
        }

        public DeviceUpdateDetails GetFromDatabase(string deviceId)
        {
            try
            {
                DeviceSearchParameters searchParameters = new DeviceSearchParameters();

                if (!string.IsNullOrWhiteSpace(deviceId))
                {
                    searchParameters.DeviceId = deviceId;
                    Logger.Debug("GetFromDatabase: Searching for device {0} in detabase", deviceId);
                }

                List<DeviceUpdateDetails> lst = _metadataMgr.GetDeviceDetails(searchParameters).ToList<DeviceUpdateDetails>();
                if (lst.Count > 0)
                {
                    Logger.Debug("GetFromDatabase: Found details for {0}, returning", deviceId);
                    return lst[0];
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                Logger.Error(String.Format("GetFromDatabase: An error occurred while getting device details from database for {0}", deviceId), ex);
                return null;
                //throw;
            }
        }

        public void RefreshCacheForAutoReset(int customerId)
        {
            try
            {
                DeviceSearchParameters searchParameters = new DeviceSearchParameters();

                searchParameters.CustomerId = customerId;
                Logger.Debug("Customer id is specified, search will be only for customer {0}", customerId);

                Logger.Debug("Getting list of all devices");
                List<DeviceUpdateDetails> lst = _metadataMgr.GetDeviceDetails(searchParameters).ToList<DeviceUpdateDetails>();
                Logger.Debug("Received list of all devices, count is {0}", lst.Count);

                int count = lst.Count;
                int processed = 0;

                Logger.Debug("Looping through devices to add/refresh to cache");
                if (lst.Count > 0)
                {
                    foreach (DeviceUpdateDetails d in lst)
                    {
                        Logger.Debug("Adding to cache: Device ID {0}", d.DeviceId);
                        bool success = _deviceUpdateValueMgr.SaveToCache(d);
                        if (success)
                            Logger.Debug("Added to cache:  Device ID {0}", d.DeviceId);
                        else
                            Logger.Error("Business.CacheManager.RefreshCache: An error occurred while addeding to cache:  Device ID {0}", d.DeviceId);

                        processed++;
                        Logger.Debug("Processed {0} of {1} records", processed, count);
                    }
                    lst.Clear();
                    lst = null;
                }
            }
            catch (Exception ex)
            {
                Logger.Error("An error occurred while refreshing cache", ex);
                //throw;
            }
        }


        public void Dispose()
        {
            _dbConnectionString = null;
            _deviceUpdateValueMgr = null;
            if (_metadataMgr != null)
            {
                _metadataMgr.Dispose();
                _metadataMgr = null;
            }
        }
    }
}
