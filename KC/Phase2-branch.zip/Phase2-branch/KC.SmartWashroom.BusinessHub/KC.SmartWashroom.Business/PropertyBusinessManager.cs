﻿using KC.SmartWashroom.BusinessEntities.DashboardApiEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.Core.DependencyInjector;
using KC.SmartWashroom.Core.Enumerations;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.DataAccess.Skeleton;
using System.Collections.Generic;
namespace KC.SmartWashroom.Business
{
    public class PropertyBusinessManager : BusinessManagerBase<IPropertyWorker>
    {
        public string ErrorDetail { get; private set; }

        public void ManualInjection<T>()
        {
            this.dataWorker = (IPropertyWorker)Injector.Resolve<T>();
        }

        public ProcessResponse<BusinessEntities.Property> Create(BusinessEntities.Property propertyEntity)
        {
            Guard.IsNotNull(propertyEntity, "Property");
            SaveActivityInLog(Enums.AuditActivity.CreateProperty, propertyEntity.UserId, Enums.ActivityLogNames.PropertyName, propertyEntity.PropertyName);
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.PropertyWorker>();
            ProcessResponse<BusinessEntities.Property> response = this.dataWorker.Create(propertyEntity);
            return response;
        }

        public ProcessResponse<BusinessEntities.Property> Update(BusinessEntities.Property propertyEntity)
        {
            Guard.IsNotNull(propertyEntity, "Property");
            SaveActivityInLog(Enums.AuditActivity.EditProperty, propertyEntity.UserId, Enums.ActivityLogNames.PropertyName, propertyEntity.PropertyName);
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.PropertyWorker>();
            ProcessResponse<BusinessEntities.Property> response = this.dataWorker.Update(propertyEntity);
            return response;
        }

        public ProcessResponse<BusinessEntities.Property> Delete(int propertyID, int userID)
        {
            Guard.IsNotNull(propertyID, "Property");
            SaveActivityInLog(Enums.AuditActivity.DeleteProperty, userID, Enums.ActivityLogNames.PropertyId, propertyID.ToString());
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.PropertyWorker>();
            ProcessResponse<BusinessEntities.Property> response = this.dataWorker.Delete(propertyID);
            return response;
        }

        public IList<PropertyAlert> GetAllProperties(int customerId, int userId, string customerName, int duration)
        {
            Guard.IsNotNull(userId, "userID");
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.PropertyWorker>();
            IList<PropertyAlert> response = this.dataWorker.GetAllProperties(customerId, userId, duration);

            #region Audit log
            base.AddParametersToAuditInformation("CustomerName", customerName); // GetCustomerNameByID(customerId));
            base.BuildAuditInfo();
            base.AuditInformation.AuditActivityType = Core.Enumerations.Enums.AuditActivity.PropertyView;
            base.AuditInformation.PerformedBy = userId.ToString();
            base.AuditInformation.AuditInfo = base.FinalAuditInformation;
            base.TraceAuditInformation();

            #endregion

            return response;
        }

        public string GetCustomerNameByID(int Id)
        {
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.PropertyWorker>();
            string response = this.dataWorker.GetCustomerNameByID(Id);
            return response;
        }

        public BusinessEntities.Property GetProperty(int propertyID, int userID)
        {
            Guard.IsNotNull(propertyID, "Property");
            SaveActivityInLog(Enums.AuditActivity.ViewProperty, userID, Enums.ActivityLogNames.PropertyId, propertyID.ToString());
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.PropertyWorker>();
            BusinessEntities.Property response = this.dataWorker.GetProperty(propertyID);
            return response;
        }

        private void SaveActivityInLog(Enums.AuditActivity activity, int userId, Enums.ActivityLogNames activityName, string Name)
        {
            base.AddParametersToAuditInformation(activityName.ToString(), Name);
            base.BuildAuditInfo();

            base.AuditInformation.AuditActivityType = activity;
            base.AuditInformation.PerformedBy = userId.ToString();
            base.AuditInformation.AuditInfo = base.FinalAuditInformation;
            base.TraceAuditInformation();
        }

        public List<Timezone> GetAllTimezones()
        {
            List<Timezone> timezones = new List<Timezone>();
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.PropertyWorker>();
            timezones = this.dataWorker.GetAllTimezones();
            if (timezones.Equals(null))
                ErrorDetail = this.dataWorker.ErrorDetail;
            return timezones;
        }

    }
}
