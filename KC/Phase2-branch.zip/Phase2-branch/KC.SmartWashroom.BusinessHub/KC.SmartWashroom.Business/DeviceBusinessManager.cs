﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.BusinessHubEntities;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.DependencyInjector;
using KC.SmartWashroom.Core.Enumerations;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers;
using KC.SmartWashroom.DataAccess.Skeleton;
using KC.SmartWashroom.Core.NotificationUtility;
using System;
using System.Collections.Generic;
using System.Collections;
using System.Net;
using System.Linq;
using KC.SmartWashroom.Core.Log;
using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;

namespace KC.SmartWashroom.Business
{
    public class DeviceBusinessManager : BusinessManagerBase<IDeviceWorker>
    {
        public DeviceLog DeviceLog { get; private set; }
        public DeviceAlertInfo DeviceAlertInfo { get; private set; }

        public BusinessEntities.DeviceUpdate.DeviceUpdateDetails DeviceUpdateDetails { private get; set; }
        List<DeviceAlertInfo> deviceAlerts = new List<DeviceAlertInfo>();

        private string alertcode;


        public void ManualInjection<T>()
        {
            this.dataWorker = (IDeviceWorker)Injector.Resolve<T>();
        }

        public bool ComposeDeviceLog(string deviceLogDetail, string gatewayDetail)
        {
            string[] deviceDetails = deviceLogDetail.Split(',');
            string[] gatewayDetails = gatewayDetail.Split(',');
            if (deviceDetails.Length.Equals(0) || string.IsNullOrEmpty(deviceDetails[0]))
            {
                throw new ApplicationException("Invalid parameters");
            }
            PrepareDeviceLog(deviceDetails, gatewayDetails);
            return true;
        }

        public DeviceAssociation GetDeviceAssociation(string deviceId)
        {
            this.ManualInjection<DeviceWorker>();

            DeviceAssociation deviceAssociation = this.dataWorker.GetDeviceAssociation(deviceId);

            return deviceAssociation;
        }
        public ProcessResponseForGateway SaveDeviceLog()
        {
            Guard.IsNotNull(DeviceLog, "Compose Device Log");

            ProcessResponseForGateway response = this.dataWorker.SaveDeviceLog(DeviceLog);

            response = this.dataWorker.SaveDeviceStatus(DeviceLog);
#if DEBUG
            AuditBusinessManager auditManager = new AuditBusinessManager();
            DeviceTrafficTrace traceEntity = auditManager.CreateDeviceTrafficTrace("SaveDeviceAlerts", DeviceLog.DeviceId);
#endif
            if (response.status.Equals(AlertEngineConstants.STATUS_SUCCESS))
            {
                foreach (DeviceAlertInfo DeviceAlertInfo in deviceAlerts)
                {
                    response = SaveDeviceAlert(DeviceAlertInfo);
                }

            }
            else
            {
                //If device log fails, still store the alert info in Queue, but send the device alert failure;
                foreach (DeviceAlertInfo DeviceAlertInfo in deviceAlerts)
                {
                    SaveDeviceAlert(DeviceAlertInfo);
                }

            }
#if DEBUG
            auditManager.TraceDeviceTraffic(traceEntity);
#endif
            return response;
        }

        public ProcessResponseForGateway SaveDeviceAlert(DeviceAlertInfo deviceAlertInfo)
        {
#if DEBUG
            AuditBusinessManager auditManager = new AuditBusinessManager();
            DeviceTrafficTrace traceEntity = auditManager.CreateDeviceTrafficTrace("SaveDeviceAlert called for device {0}", deviceAlertInfo.DeviceID);
#endif
            Guard.IsNotNull(deviceAlertInfo, "Alert Info");
            ProcessResponseForGateway response = new ProcessResponseForGateway();

            if (deviceAlertInfo.SharedEmailAddresses != null || deviceAlertInfo.SharedMobileNumbers != null)
            {
                ProcessDeviceAlerts(deviceAlertInfo);
            }
            else
            {
                this.dataWorker.SaveDeviceAlert(SerializationHelper.JsonSerialize(deviceAlertInfo));
            }

            response.status = AlertEngineConstants.STATUS_SUCCESS;
#if DEBUG
            auditManager.TraceDeviceTraffic(traceEntity);
#endif
            return response;
        }

        private void ProcessDeviceAlerts(DeviceAlertInfo deviceAlertInfo)
        {
#if DEBUG
            AuditBusinessManager auditManager = new AuditBusinessManager();
            DeviceTrafficTrace traceEntity = auditManager.CreateDeviceTrafficTrace("ProcessDeviceAlerts called for device {0}", deviceAlertInfo.DeviceID);
#endif
            //Retrive all users tagged for the incomming device..
            TenantsBusinessManager teannts = new TenantsBusinessManager();
            teannts.GetUserDetails(deviceAlertInfo.DeviceID);
            List<UserEntity> usersForDevice = teannts.DeviceLog.UserDetails;
            List<UserEntity> sharedUserEmails = new List<UserEntity>();
            if (deviceAlertInfo.SharedEmailAddresses != null && deviceAlertInfo.SharedEmailAddresses.Count > 0)
            {
                //Now join the related users with the shared users with the email address linking..
                sharedUserEmails = (from user in usersForDevice
                                    join sharedUserEmail in deviceAlertInfo.SharedEmailAddresses
                                    on user.Email equals sharedUserEmail
                                    select user).ToList();
            }

            //Clear the SharedEmailAddresses so that it will be null in the queue message in case of pushing message for SharedMobileNumbers
            if (deviceAlertInfo.SharedEmailAddresses != null && deviceAlertInfo.SharedEmailAddresses.Count > 0)
            {
                deviceAlertInfo.SharedEmailAddresses.Clear();
            }

            //Push queue message only when threr are mobile numbers available..
            if (deviceAlertInfo.SharedMobileNumbers != null && deviceAlertInfo.SharedMobileNumbers.Count > 0)
            {
                this.dataWorker.SaveDeviceAlert(SerializationHelper.JsonSerialize(deviceAlertInfo));

                //Once the sms alerts are sent Now clear all the mobiles and do an 
                //iterative post for all emails based on cleaner or no cleaner decision..
                deviceAlertInfo.SharedMobileNumbers.Clear();
            }

            //clear emails so that we can process it sequentially by sending first the queue message for all mobiles alone....
            foreach (UserEntity user in sharedUserEmails)
            {
                if (deviceAlertInfo.SharedEmailAddresses.Count > 0)
                    deviceAlertInfo.SharedEmailAddresses.Clear();

                deviceAlertInfo.SharedEmailAddresses.Add(user.Email);
                deviceAlertInfo.IsAlertForCleaner = user.RoleLevel.Equals((int)Enums.RoleLevelType.Cleaner) ? true : false;

                //POst as indivudial Messages to Queue for Processing Cleaners and Non cleaners....
                this.dataWorker.SaveDeviceAlert(SerializationHelper.JsonSerialize(deviceAlertInfo));
            }
#if DEBUG
            auditManager.TraceDeviceTraffic(traceEntity);
#endif
        }
        public IList<DeviceAlertGroupInfo> GetDeviceAlertTypes(string deviceType)
        {
            this.ManualInjection<DeviceWorker>();
            return this.dataWorker.GetDeviceAlertTypes(deviceType);
        }
        public string GetDeviceAlertCode(string alertName, string deviceType)
        {
            this.ManualInjection<DeviceWorker>();
            return this.dataWorker.GetDeviceAlertCode(alertName, deviceType);
        }

        public bool IfAlertExists(string deviceID, string alertcode)
        {
            this.ManualInjection<DeviceWorker>();
            return this.dataWorker.IfAlertExists(deviceID, alertcode);
        }

        public void LogIncomingDeviceDetail(DeviceAuditLog entity)
        {
            Guard.IsNotNull(entity, "entity");
            this.dataWorker.LogIncomingDeviceDetail(entity);
        }

        public List<DeviceResolutionDetail> FetchDevicesForBuilding(int propertyId, int buildingId, int floorId, int washroomId)
        {
            this.ManualInjection<DeviceWorker>();
            return this.dataWorker.GetAllDevicesForBuilding(propertyId, buildingId, floorId, washroomId);
        }
        public IList<DeviceResolutionDetail> GetDeviceInfo(int propertyId, IList<string> deviceIdList)
        {
            this.ManualInjection<DeviceWorker>();
            return this.dataWorker.GetDeviceInfo(propertyId, deviceIdList);
        }
        public List<DeviceResolutionDetail> FetchDevicesForUser(int userId, int roleLevel, int customerId, int buildingId)
        {
            this.ManualInjection<DeviceWorker>();
            return this.dataWorker.GetAllDevicesForUser(userId, roleLevel, customerId, buildingId);
        }

        public List<DeviceResolutionDetail> FetcheHRTDevicesForUser(int userId, int roleLevel, int customerId)
        {
            this.ManualInjection<DeviceWorker>();
            return this.dataWorker.GetAlleHRTDevicesForUser(userId, roleLevel, customerId);
        }

        public List<DeviceRefillDetail> FetchSoapDevicesForBuilding(int buildingId)
        {
            this.ManualInjection<DeviceWorker>();
            return this.dataWorker.GetAllSoapDevicesForBuilding(buildingId);
        }

        public List<DeviceLog> GetAllDeviceLogsForDevice(string deviceId)
        {
            return this.dataWorker.GetAllDeviceLogsForDevice(deviceId);
        }

        public string GeteHRTRefillSize(string deviceId)
        {
            this.ManualInjection<DeviceWorker>();
            var deviceSpecificPreference = this.dataWorker.GetDeviceSizeandLastDispensedValue(0, deviceId, Enums.DeviceType.eHRT);
            return deviceSpecificPreference.DeviceSize;
        }
        public DeviceSizeAndDispensedValue GetDeviceSizeandLastDispensedValue(int customerId, string deviceId)
        {
            var deviceSizeDispensedValue = new DeviceSizeAndDispensedValue();
            Enums.DeviceType deviceType = GetDeviceType(deviceId);

            switch (deviceType)
            {
                //For EHRT devices the refill size is configured at the Device Level by the Users so manual inject and get the device specific data from SQL Azure..
                case Enums.DeviceType.eHRT:

                    deviceSizeDispensedValue = this.dataWorker.GetDeviceSizeandLastDispensedValue(customerId, deviceId, deviceType);
                    if (deviceSizeDispensedValue != null)
                    {
                        //Manual Inject to pick up the Device Size alone from the SQL Azure..
                        this.ManualInjection<DeviceWorker>();
                        var deviceSpecificPreference = this.dataWorker.GetDeviceSizeandLastDispensedValue(customerId, deviceId, deviceType);

                        if (deviceSpecificPreference != null)
                            deviceSizeDispensedValue.DeviceSize = deviceSpecificPreference.DeviceSize;
                    }
                    break;
                default:
                    deviceSizeDispensedValue = this.dataWorker.GetDeviceSizeandLastDispensedValue(customerId, deviceId, deviceType);
                    break;
            }
            return deviceSizeDispensedValue;
        }

        public List<BusinessEntities.AlertEngineEntities.DeviceAlert> CheckUnresponsive(int customerId, List<DeviceResolutionDetail> Alldevices)
        {
            return this.dataWorker.CheckUnresponsive(customerId, Alldevices);
        }

        public DeviceInformation GetDeviceAlertStatus(string deviceID)
        {
            this.ManualInjection<DeviceWorker>();

            return this.dataWorker.GetDeviceAlertStatus(deviceID);
        }

        public ProcessResponse ClearAllDeviceOverrides(List<int?> parameterIds, int customerId)
        {
            ProcessResponse response = new ProcessResponse();
            this.ManualInjection<DeviceWorker>();
            response = this.dataWorker.ClearAllDeviceOverrides(parameterIds, customerId);
            if (response.Status == ResponseStatus.Success)
                SendMessageForCustomerLevelReset(customerId);
            return response;
        }

        public bool CheckAlertExist(int customerId, string deviceID, string alertcode)
        {
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Table_Workers.DeviceWorker>();
            return this.dataWorker.IsAlertExists(customerId, deviceID, alertcode);
        }

        public void DeleteDeviceStatus(string deviceID, int customerId)
        {
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Table_Workers.DeviceWorker>();
            this.dataWorker.DeleteDeviceStatus(deviceID, customerId);
        }

        public void DeleteAlertStatus(string deviceID, int customerId)
        {
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Table_Workers.DeviceWorker>();
            this.dataWorker.DeleteAlertStatus(deviceID, customerId);
        }

        public void SaveDeviceToQueueForCache(string deviceId, bool IsDatabaseRefresh)
        {
#if DEBUG
            AuditBusinessManager mgr = new AuditBusinessManager();
            DeviceTrafficTrace trace = mgr.CreateDeviceTrafficTrace("BM.SaveDeviceToQueueForCache", deviceId);
#endif
            DeviceAlertInfo device = new DeviceAlertInfo();
            device.DeviceID = deviceId;
            if (IsDatabaseRefresh)
                device.AlertType = AlertEngineConstants.API_DATABASE_UPDATE;
            else
                device.AlertType = AlertEngineConstants.API_CACHE_REFRESH;
            device.IsAlert = 1;
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Table_Workers.DeviceWorker>();
            this.dataWorker.SaveDeviceForCache(SerializationHelper.JsonSerialize(device));
#if DEBUG
            mgr.TraceDeviceTraffic(trace);
#endif
        }

        public void SendMessageForCustomerLevelReset(int customerId)
        {
            DeviceAlertInfo device = new DeviceAlertInfo();
            device.DeviceID = customerId.ToString();
            device.AlertType = AlertEngineConstants.API_CACHE_CUSTOMER_OVERRIDE_REFRESH;
            device.IsAlert = 1;
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Table_Workers.DeviceWorker>();
            this.dataWorker.SaveDeviceForCache(SerializationHelper.JsonSerialize(device));
        }

        #region Private methods
        private Enums.DeviceType GetDeviceType(string Macid)
        {
            if (Macid.StartsWith(CommonConstants.JRT_DEVICE))
                return Enums.DeviceType.JRT;
            else if (Macid.StartsWith(CommonConstants.SRB_DEVICE))
                return Enums.DeviceType.SRB;
            else if (Macid.StartsWith(CommonConstants.ESOAP_DEVICE))
                return Enums.DeviceType.eSoap;
            else if (Macid.StartsWith(CommonConstants.EHRT_DEVICE))
                return Enums.DeviceType.eHRT;
            else
                throw new ApplicationException("Device Cannot be Identified");
        }

        private void PrepareDeviceLog(string[] deviceDetails, string[] gatewayDetails)
        {

            dynamic deviceParameter = null;
            string deviceId = deviceDetails[0];
            Enums.DeviceType deviceType = GetDeviceType(deviceId);

            DeviceLog = new DeviceLog();
            DeviceLog.DeviceId = deviceId;
            DeviceLog.DeviceType = (int)deviceType;
            DeviceLog.Timestamp = DateTime.UtcNow;

            //DeviceAssociation deviceAssociation = this.GetDeviceAssociation(deviceId); Performance Fix: This is being replaced from the incomming Property DeviceDetails.

            if (DeviceUpdateDetails != null) //&& DeviceDetails.IsDeviceActive) TODO: Unable to find the wiring component for this in DeviceDetails Entity..
            {
                DeviceLog.CustomerId = DeviceUpdateDetails.CustomerId;
                DeviceLog.PropertyId = DeviceUpdateDetails.PropertyId;
                DeviceLog.BuildingId = DeviceUpdateDetails.BuildingId;

                DeviceLog.FloorLevel = DeviceUpdateDetails.FloorLevel;
                DeviceLog.FloorId = DeviceUpdateDetails.FloorId;
                DeviceLog.WashroomId = DeviceUpdateDetails.RestroomId;
            }
            else
            {
                throw new ApplicationException(string.Format("Deivce Id {0} not registered or inactive", deviceId));
            }
            switch (deviceType)
            {
                case Enums.DeviceType.JRT:
                    deviceParameter = AssignJRTParameters(DeviceUpdateDetails.CustomerId, deviceDetails, deviceId);
                    break;
                case Enums.DeviceType.SRB:
                    deviceParameter = AssignSRBParameters(DeviceUpdateDetails.CustomerId, deviceDetails, deviceId);
                    break;
                case Enums.DeviceType.eSoap:
                    deviceParameter = AssigneSoapParameters(DeviceUpdateDetails.CustomerId, deviceDetails, deviceId);
                    break;
                case Enums.DeviceType.eHRT:
                    deviceParameter = AssigneHRTParameters(DeviceUpdateDetails.CustomerId, deviceDetails, deviceId);
                    break;
                default:
                    break;
            }
            //DeviceLog.DeviceParameter = deviceParameter;
            DeviceLog.Parameter = deviceParameter;
            if (gatewayDetails != null && gatewayDetails.Length >= 2 && !string.IsNullOrEmpty(gatewayDetails[0]) && !string.IsNullOrEmpty(gatewayDetails[1]))
            {
                DeviceLog.GatewayId = gatewayDetails[0];
                DeviceLog.GatewayFirmwareVersion = (int.Parse(gatewayDetails[1]) / 100.0).ToString();
            }
            else
            {
                throw new ApplicationException("Invalid parameters");
            }

        }
        private decimal GetBatteryScaleFactor(Enums.DeviceType deviceType, bool Iscached = false)
        {
            DeviceTenantManager manager = new DeviceTenantManager();
            if (Iscached)
                return manager.GetDeviceTypesFromCache(deviceType.ToString()).BatteryScaleFactor;
            else
                return manager.GetDeviceTypes().Where(dt => dt.DbDeviceType == deviceType.ToString()).FirstOrDefault().BatteryScaleFactor;
        }
        private JRTParameters AssignJRTParameters(int customerId, string[] JrtLog, string deviceID)
        {
            JRTParameters jrtParameters = new JRTParameters();

            decimal scaleFactor = GetBatteryScaleFactor(Enums.DeviceType.JRT, true);
            if (JrtLog.Length < 11)
            {
                throw new ApplicationException("Invalid parameters");
            }

            try
            {
                IList<DeviceAlertGroupInfo> alertGroupInfoList = this.GetDeviceAlertTypes(Enums.DeviceType.JRT.ToString());

                jrtParameters.SoftwareVersion = decimal.Parse(JrtLog[(int)Enums.JRTParams.SoftwareVersion]) / 100;
                jrtParameters.BatteryVoltage = decimal.Parse(JrtLog[(int)Enums.JRTParams.BatteryVoltage]) * scaleFactor;
                jrtParameters.PaperRollRemainingPercent = decimal.Parse(JrtLog[(int)Enums.JRTParams.PaperRollRemainingPercent]);

                if (!string.IsNullOrEmpty(JrtLog[(int)Enums.JRTParams.LowBatteryAlert]))
                {
                    alertcode = GetCode(Enums.Alerts.LowBatteryAlert.ToString(), alertGroupInfoList);
                    jrtParameters.LowBatteryAlert = (JrtLog[(int)Enums.JRTParams.LowBatteryAlert].Equals("1"));
                    CheckAlert(customerId, deviceID, alertcode, jrtParameters.LowBatteryAlert);
                }
                jrtParameters.PlaceHolder1 = (JrtLog[(int)Enums.JRTParams.PlaceHolder1].Equals("1"));

                if (!string.IsNullOrEmpty(JrtLog[(int)Enums.JRTParams.LowPaperAlert]))
                {
                    alertcode = GetCode(Enums.Alerts.LowPaperAlert.ToString(), alertGroupInfoList);
                    jrtParameters.LowPaperAlert = (JrtLog[(int)Enums.JRTParams.LowPaperAlert].Equals("1"));
                    CheckAlert(customerId, deviceID, alertcode, jrtParameters.LowPaperAlert);
                }

                jrtParameters.PlaceHolder2 = (JrtLog[(int)Enums.JRTParams.PlaceHolder2].Equals("1"));
                jrtParameters.TotalRollsDispensed = int.Parse(JrtLog[(int)Enums.JRTParams.TotalRollsDispensed]);
                jrtParameters.UpdateIntervalInMinutes = int.Parse(JrtLog[(int)Enums.JRTParams.UpdateIntervalInMinutes]);
                jrtParameters.Reset = JrtLog[(int)Enums.JRTParams.Reset].Equals("1");

                SetJrtDeviceStatus(jrtParameters, deviceID, customerId, alertGroupInfoList);

            }
            catch
            {
                throw new ApplicationException("Invalid parameters");
            }

            return jrtParameters;
        }


        private SRBParameters AssignSRBParameters(int customerId, string[] SRBLog, string deviceID)
        {
            SRBParameters srbParameters = new SRBParameters();
            decimal scaleFactor = GetBatteryScaleFactor(Enums.DeviceType.SRB, true);
            if (SRBLog.Length < 9)
            {
                throw new ApplicationException("Invalid parameters");
            }
            try
            {
                IList<DeviceAlertGroupInfo> alertGroupInfoList = this.GetDeviceAlertTypes(Enums.DeviceType.SRB.ToString());
                srbParameters.SoftwareVersion = decimal.Parse(SRBLog[(int)Enums.SRBParams.SoftwareVersion]) / 100;
                srbParameters.BatteryVoltage = decimal.Parse(SRBLog[(int)Enums.SRBParams.BatteryVoltage]) * scaleFactor;
                srbParameters.PaperRollRemainingPercent = decimal.Parse(SRBLog[(int)Enums.SRBParams.PaperRollRemainingPercent]);

                if (!string.IsNullOrEmpty(SRBLog[(int)Enums.SRBParams.LowBatteryAlert]))
                {
                    alertcode = GetCode(Enums.Alerts.LowBatteryAlert.ToString(), alertGroupInfoList);
                    srbParameters.LowBatteryAlert = (SRBLog[(int)Enums.SRBParams.LowBatteryAlert].Equals("1"));
                    CheckAlert(customerId, deviceID, alertcode, srbParameters.LowBatteryAlert);
                }

                if (!string.IsNullOrEmpty(SRBLog[(int)Enums.SRBParams.LowPaperAlert]))
                {
                    alertcode = GetCode(Enums.Alerts.LowPaperAlert.ToString(), alertGroupInfoList);
                    srbParameters.LowPaperAlert = (SRBLog[(int)Enums.SRBParams.LowPaperAlert].Equals("1"));
                    CheckAlert(customerId, deviceID, alertcode, srbParameters.LowPaperAlert);
                }

                srbParameters.TotalRollsDispensed = int.Parse(SRBLog[(int)Enums.SRBParams.TotalRollsDispensed]) * 2;
                srbParameters.UpdateIntervalInMinutes = int.Parse(SRBLog[(int)Enums.SRBParams.UpdateIntervalInMinutes]);
                srbParameters.Reset = SRBLog[(int)Enums.SRBParams.Reset].Equals("1");

                SetSrbDeviceStatus(srbParameters, deviceID, customerId, alertGroupInfoList);
            }
            catch
            {
                throw new ApplicationException("Invalid parameters");
            }


            return srbParameters;
        }
        private eHRTParameters AssigneHRTParameters(int customerId, string[] eHRTLog, string deviceID)
        {
            eHRTParameters ehrtParameters = new eHRTParameters();
            decimal scaleFactor = GetBatteryScaleFactor(Enums.DeviceType.eHRT, true);
            if (eHRTLog.Length < 24)
            {
                throw new ApplicationException("Invalid parameters");
            }

            try
            {
                IList<DeviceAlertGroupInfo> alertGroupInfoList = this.GetDeviceAlertTypes(Enums.DeviceType.eHRT.ToString());
                ehrtParameters.SoftwareVersion = decimal.Parse(eHRTLog[(int)Enums.eHRTParams.SoftwareVersion]) / 100;
                ehrtParameters.Sensitivity = char.Parse(eHRTLog[(int)Enums.eHRTParams.Sensitivity]);
                ehrtParameters.DispenseLength = char.Parse(eHRTLog[(int)Enums.eHRTParams.DispenseLength]);

                ehrtParameters.DispenserDelay = char.Parse(eHRTLog[(int)Enums.eHRTParams.DispenserDelay]);
                ehrtParameters.DispenseMode = char.Parse(eHRTLog[(int)Enums.eHRTParams.DispenseMode]);
                ehrtParameters.TotalDispenseCount = int.Parse(eHRTLog[(int)Enums.eHRTParams.TotalDispenseCount]);

                ehrtParameters.DispensesWithLastBattery = int.Parse(eHRTLog[(int)Enums.eHRTParams.DispensesWithLastBattery]);
                ehrtParameters.DispensesWithCurrentBattery = int.Parse(eHRTLog[(int)Enums.eHRTParams.DispensesWithCurrentBattery]);
                ehrtParameters.NumberOfBatteryChanges = int.Parse(eHRTLog[(int)Enums.eHRTParams.NumberOfBatteryChanges]);

                ehrtParameters.VoltageLastBatteryChange = decimal.Parse(eHRTLog[(int)Enums.eHRTParams.VoltageLastBatteryChange]) * scaleFactor;
                ehrtParameters.CurrentBatteryVoltage = decimal.Parse(eHRTLog[(int)Enums.eHRTParams.CurrentBatteryVoltage]) * scaleFactor;
                if (!string.IsNullOrEmpty(eHRTLog[(int)Enums.eHRTParams.LowPaperAlert]))
                {
                    alertcode = GetCode(Enums.Alerts.LowPaperAlert.ToString(), alertGroupInfoList);
                    ehrtParameters.LowPaperAlert = (eHRTLog[(int)Enums.eHRTParams.LowPaperAlert].Equals("1"));
                    CheckAlert(customerId, deviceID, alertcode, ehrtParameters.LowPaperAlert);
                }

                if (!string.IsNullOrEmpty(eHRTLog[(int)Enums.eHRTParams.LowBatteryAlert]))
                {
                    alertcode = GetCode(Enums.Alerts.LowBatteryAlert.ToString(), alertGroupInfoList);
                    ehrtParameters.LowBatteryAlert = (eHRTLog[(int)Enums.eHRTParams.LowBatteryAlert].Equals("1"));
                    CheckAlert(customerId, deviceID, alertcode, ehrtParameters.LowBatteryAlert);
                }
                if (!string.IsNullOrEmpty(eHRTLog[(int)Enums.eHRTParams.PaperJamAlert]))
                {
                    alertcode = GetCode(Enums.Alerts.PaperJamAlert.ToString(), alertGroupInfoList);
                    ehrtParameters.PaperJamAlert = (eHRTLog[(int)Enums.eHRTParams.PaperJamAlert].Equals("1"));
                    CheckAlert(customerId, deviceID, alertcode, ehrtParameters.PaperJamAlert);
                }

                ehrtParameters.PaperDispensedSinceLastRefill = int.Parse(eHRTLog[(int)Enums.eHRTParams.PaperDispensedSinceLastRefill]);
                if (!string.IsNullOrEmpty(eHRTLog[(int)Enums.eHRTParams.Reset]))
                    ehrtParameters.Reset = (eHRTLog[(int)Enums.eHRTParams.Reset].Equals("1"));

                if (!string.IsNullOrEmpty(eHRTLog[(int)Enums.eHRTParams.PlaceHolder]))
                    ehrtParameters.PlaceHolder = (eHRTLog[(int)Enums.eHRTParams.PlaceHolder].Equals("1"));

                ehrtParameters.TrashEmptyPercent = int.Parse(eHRTLog[(int)Enums.eHRTParams.TrashEmptyPercent]);
                if (!string.IsNullOrEmpty(eHRTLog[(int)Enums.eHRTParams.TrashFullAlert]))
                {
                    alertcode = GetCode(Enums.Alerts.TrashFullAlert.ToString(), alertGroupInfoList);
                    ehrtParameters.TrashFullAlert = (eHRTLog[(int)Enums.eHRTParams.TrashFullAlert].Equals("1"));
                    CheckAlert(customerId, deviceID, alertcode, ehrtParameters.TrashFullAlert);
                }
                ehrtParameters.UpdateInterval = int.Parse(eHRTLog[(int)Enums.eHRTParams.UpdateInterval]);
                ehrtParameters.TotalRollsDispensed = int.Parse(eHRTLog[(int)Enums.eHRTParams.TotalRollsDispensed]);

                ehrtParameters.DelayEnabled = eHRTLog[(int)Enums.eHRTParams.DelayEnabled].Equals("1");
                ehrtParameters.DelayValue = int.Parse(eHRTLog[(int)Enums.eHRTParams.DelayValue]);

                SetEhrtDeviceStatus(ehrtParameters, deviceID, customerId, alertGroupInfoList);
            }
            catch
            {
                throw new ApplicationException("Invalid parameters");
            }

            return ehrtParameters;
        }

        private eSoapParameters AssigneSoapParameters(int customerId, string[] eSoapLog, string deviceID)
        {
            eSoapParameters esoapParameters = new eSoapParameters();
            decimal scaleFactor = GetBatteryScaleFactor(Enums.DeviceType.eSoap, true);
            if (eSoapLog.Length < 21)
            {
                throw new ApplicationException("Invalid parameters");
            }

            try
            {
                IList<DeviceAlertGroupInfo> alertGroupInfoList = this.GetDeviceAlertTypes(Enums.DeviceType.eSoap.ToString());
                esoapParameters.SoftwareVersion = decimal.Parse(eSoapLog[(int)Enums.eSOAPParams.SoftwareVersion]) / 100;
                esoapParameters.Shot = char.Parse(eSoapLog[(int)Enums.eSOAPParams.Shot]);
                esoapParameters.Range = char.Parse(eSoapLog[(int)Enums.eSOAPParams.Range]);

                esoapParameters.RefillSize = char.Parse(eSoapLog[(int)Enums.eSOAPParams.RefillSize]);
                esoapParameters.CleanModeSinceBatteryChange = int.Parse(eSoapLog[(int)Enums.eSOAPParams.CleanModeSinceBatteryChange]);
                esoapParameters.TotalDispenseSinceConstruction = int.Parse(eSoapLog[(int)Enums.eSOAPParams.TotalDispenseSinceConstruction]);

                esoapParameters.DispenseDuringLastBattery = int.Parse(eSoapLog[(int)Enums.eSOAPParams.DispenseDuringLastBattery]);
                esoapParameters.DispenseSinceLastBatteryChange = int.Parse(eSoapLog[(int)Enums.eSOAPParams.DispenseSinceLastBatteryChange]);
                esoapParameters.NumberOfBatteryChanges = int.Parse(eSoapLog[(int)Enums.eSOAPParams.NumberOfBatteryChanges]);

                esoapParameters.VoltageAtLastBatteryChange = decimal.Parse(eSoapLog[(int)Enums.eSOAPParams.VoltageAtLastBatteryChange]) * scaleFactor;
                esoapParameters.CurrentBatteryVoltage = decimal.Parse(eSoapLog[(int)Enums.eSOAPParams.CurrentBatteryVoltage]) * scaleFactor;
                if (!string.IsNullOrEmpty(eSoapLog[(int)Enums.eSOAPParams.LowSoapAlert]))
                {
                    alertcode = GetCode(Enums.Alerts.LowSoapAlert.ToString(), alertGroupInfoList);
                    esoapParameters.LowSoapAlert = (eSoapLog[(int)Enums.eSOAPParams.LowSoapAlert].Equals("1"));
                    CheckAlert(customerId, deviceID, alertcode, esoapParameters.LowSoapAlert);
                }

                if (!string.IsNullOrEmpty(eSoapLog[(int)Enums.eSOAPParams.LowBatteryAlert]))
                {
                    alertcode = GetCode(Enums.Alerts.LowBatteryAlert.ToString(), alertGroupInfoList);
                    esoapParameters.LowBatteryAlert = (eSoapLog[(int)Enums.eSOAPParams.LowBatteryAlert].Equals("1"));
                    CheckAlert(customerId, deviceID, alertcode, esoapParameters.LowBatteryAlert);
                }

                if (!string.IsNullOrEmpty(eSoapLog[(int)Enums.eSOAPParams.MotorOverCurrentAlert]))
                {
                    alertcode = GetCode(Enums.Alerts.MotorOvercurrentAlert.ToString(), alertGroupInfoList);
                    esoapParameters.MotorOverCurrentAlert = (eSoapLog[(int)Enums.eSOAPParams.MotorOverCurrentAlert].Equals("1"));
                    CheckAlert(customerId, deviceID, alertcode, esoapParameters.MotorOverCurrentAlert);
                }

                esoapParameters.TotalRefillsSinceConstruction = int.Parse(eSoapLog[(int)Enums.eSOAPParams.TotalRefillsSinceConstruction]);
                esoapParameters.RefillsduringLastBattery = int.Parse(eSoapLog[(int)Enums.eSOAPParams.RefillsduringLastBattery]);
                esoapParameters.RefillsSinceBatteryChange = int.Parse(eSoapLog[(int)Enums.eSOAPParams.RefillsSinceBatteryChange]);

                esoapParameters.NoOfDispensesSinceLastRefill = int.Parse(eSoapLog[(int)Enums.eSOAPParams.NoOfDispensesSinceLastRefill]);
                esoapParameters.UpdateInterval = int.Parse(eSoapLog[(int)Enums.eSOAPParams.UpdateInterval]);
                esoapParameters.Reset = (eSoapLog[(int)Enums.eSOAPParams.Reset].Equals("1"));

                SetEsoapDeviceStatus(esoapParameters, deviceID, customerId, alertGroupInfoList);
            }
            catch
            {
                throw new ApplicationException("Invalid parameters");
            }


            return esoapParameters;
        }

        private void ComposeAlert(string deviceId, string alertType, Int16 isAlert)
        {
            DeviceAlertInfo = new DeviceAlertInfo();
            DeviceAlertInfo.DeviceID = deviceId;
            DeviceAlertInfo.AlertType = alertType;
            DeviceAlertInfo.IsAlert = isAlert;

            deviceAlerts.Add(DeviceAlertInfo);
        }

        private string GetCode(string alertName, IList<DeviceAlertGroupInfo> alertGroupInfoList)
        {
            return (from alertGroup in alertGroupInfoList
                    where alertGroup.AlertGroup.Equals(alertName, StringComparison.OrdinalIgnoreCase)
                    select alertGroup.AlertType).First();

        }

        private void CheckAlert(int customerId, string deviceID, string alertCode, bool isAlert)
        {
            if (isAlert)
            {
                if (!CheckAlertExist(customerId, deviceID, alertCode))
                {
                    ComposeAlert(deviceID, alertCode, 1);
                }
            }
            else
            {
                if (CheckAlertExist(customerId, deviceID, alertCode))
                {
                    ComposeAlert(deviceID, alertCode, 0);
                }
            }

        }

        private string[] ParseDeviceLogData(string[] deviceAlertDetails)
        {
            string[] deviceLogDetails = new string[deviceAlertDetails.Length - 2];
            Array.Copy(deviceAlertDetails, 3, deviceLogDetails, 1, deviceAlertDetails.Length - 3);
            deviceLogDetails[0] = deviceAlertDetails[0];
            return deviceLogDetails;
        }

        #region GetDeviceStatus

        private JRTParameters SetJrtDeviceStatus(JRTParameters jrtParameters, string deviceId, int customerId, IList<DeviceAlertGroupInfo> alertGroupInfoList)
        {
            JRTParameters deviceBatteryAndPaperPrevious = this.dataWorker.GetJRTDeviceStatus(customerId, deviceId);
            if (jrtParameters.BatteryVoltage > deviceBatteryAndPaperPrevious.BatteryVoltage)
            {
                alertcode = GetCode(Enums.Alerts.LowBatteryAlert.ToString(), alertGroupInfoList);
                if (!CheckAlertExist(customerId, deviceId, alertcode))
                {
                    jrtParameters.RefilledBatteryBeforeThreshold = 1;
                }
            }

            if (jrtParameters.PaperRollRemainingPercent > deviceBatteryAndPaperPrevious.PaperRollRemainingPercent)
            {
                alertcode = GetCode(Enums.Alerts.LowPaperAlert.ToString(), alertGroupInfoList);
                if (!CheckAlertExist(customerId, deviceId, alertcode))
                {
                    jrtParameters.RefilledTissueBeforeThreshold = 1;
                }
            }

            return jrtParameters;
        }

        private eHRTParameters SetEhrtDeviceStatus(eHRTParameters ehrtParameters, string deviceId, int customerId, IList<DeviceAlertGroupInfo> alertGroupInfoList)
        {
            eHRTParameters deviceBatteryAndPaperPrevious = this.dataWorker.GetEhrtDeviceStatus(customerId, deviceId);
            if (ehrtParameters.CurrentBatteryVoltage > deviceBatteryAndPaperPrevious.CurrentBatteryVoltage)
            {
                alertcode = GetCode(Enums.Alerts.LowBatteryAlert.ToString(), alertGroupInfoList);
                if (!CheckAlertExist(customerId, deviceId, alertcode))
                {
                    ehrtParameters.RefilledBatteryBeforeThreshold = 1;
                }
            }

            if (ehrtParameters.PaperDispensedSinceLastRefill < deviceBatteryAndPaperPrevious.PaperDispensedSinceLastRefill)
            {
                alertcode = GetCode(Enums.Alerts.LowPaperAlert.ToString(), alertGroupInfoList);
                if (!CheckAlertExist(customerId, deviceId, alertcode))
                {
                    ehrtParameters.RefilledTowelBeforeThreshold = 1;
                }
            }

            return ehrtParameters;
        }

        private eSoapParameters SetEsoapDeviceStatus(eSoapParameters eSoapParameters, string deviceId, int customerId, IList<DeviceAlertGroupInfo> alertGroupInfoList)
        {
            eSoapParameters deviceBatteryAndPaperPrevious = this.dataWorker.GetEsoapDeviceStatus(customerId, deviceId);
            if (eSoapParameters.CurrentBatteryVoltage > deviceBatteryAndPaperPrevious.CurrentBatteryVoltage)
            {
                alertcode = GetCode(Enums.Alerts.LowBatteryAlert.ToString(), alertGroupInfoList);
                if (!CheckAlertExist(customerId, deviceId, alertcode))
                {
                    eSoapParameters.RefilledBatteryBeforeThreshold = 1;
                }
            }

            if (eSoapParameters.NoOfDispensesSinceLastRefill < deviceBatteryAndPaperPrevious.NoOfDispensesSinceLastRefill)
            {
                alertcode = GetCode(Enums.Alerts.LowSoapAlert.ToString(), alertGroupInfoList);
                if (!CheckAlertExist(customerId, deviceId, alertcode))
                {
                    eSoapParameters.RefilledSoapBeforeThreshold = 1;
                }
            }

            return eSoapParameters;
        }

        private SRBParameters SetSrbDeviceStatus(SRBParameters srbParameters, string deviceId, int customerId, IList<DeviceAlertGroupInfo> alertGroupInfoList)
        {
            SRBParameters deviceBatteryAndPaperPrevious = this.dataWorker.GetSRBDeviceStatus(customerId, deviceId);
            if (srbParameters.BatteryVoltage > deviceBatteryAndPaperPrevious.BatteryVoltage)
            {
                alertcode = GetCode(Enums.Alerts.LowBatteryAlert.ToString(), alertGroupInfoList);
                if (!CheckAlertExist(customerId, deviceId, alertcode))
                {
                    srbParameters.RefilledBatteryBeforeThreshold = 1;
                }
            }

            if (srbParameters.PaperRollRemainingPercent > deviceBatteryAndPaperPrevious.PaperRollRemainingPercent)
            {
                alertcode = GetCode(Enums.Alerts.LowPaperAlert.ToString(), alertGroupInfoList);
                if (!CheckAlertExist(customerId, deviceId, alertcode))
                {
                    srbParameters.RefilledTissueBeforeThreshold = 1;
                }
            }

            return srbParameters;
        }

        #endregion


        #endregion
    }
}
