﻿using KC.SmartWashroom.Core.DependencyInjector;
using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
using KC.SmartWashroom.DataAccess.DataWorkers.Table_Workers;
using KC.SmartWashroom.DataAccess.Skeleton;
using System.Collections.Generic;
using KC.SmartWashroom.Core.Helper;
using BusinessEntity = KC.SmartWashroom.BusinessEntities;
using System;
using System.Linq;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.Core.Constants;
using System.Collections.ObjectModel;
using KC.SmartWashroom.Core.Enumerations;

namespace KC.SmartWashroom.Business
{
    public class TenantsBusinessManager : BusinessManagerBase<IUserWorker>
    {
        public void ManualInjection<T>()
        {
            this.dataWorker = (IUserWorker)Injector.Resolve<T>();
        }

        public DeviceDetail DeviceLog { get; private set; }

        public bool GetUserDetails(string deviceId)
        {
            bool isSuccess = false;
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.UserWorker>();
            DeviceLog = this.dataWorker.GetUserDetails(deviceId);

            //Access Check..
            FilterAndRefreshUsersWithValidAccess(deviceId);

            if (DeviceLog != null)
                isSuccess = true;

            return isSuccess;
        }

        private void FilterAndRefreshUsersWithValidAccess(string deviceId)
        {
            //Retrive Device Location..
            DeviceBusinessManager deviceManager = new DeviceBusinessManager();
            var deviceAssociation = deviceManager.GetDeviceAssociation(deviceId);

            //Now filter users who has access to the specific buildings alone..
            MembershipBusinessManager memberShipManager = new MembershipBusinessManager();

            //Retrive..
            BusinessEntities.BusinessHubEntities.UserAccessAsserts alluserAccessAsserts = memberShipManager.GetAllUserAsserts();

            //Filteration..
            var validUserAccessBuildings = new List<UserEntity>();
            var validUserAccessPropertys = new List<UserEntity>();
            var validCustomerAdmins = new List<UserEntity>();

            validUserAccessBuildings = (from userDetail in DeviceLog.UserDetails

                                        join allbuildingUserId in alluserAccessAsserts.UserAccessBuildings
                                        on userDetail.ID equals allbuildingUserId.UserId

                                        where allbuildingUserId.AssertId.Equals(deviceAssociation.BuildingId)
                                        where (userDetail.RoleLevel.Equals((int)Enums.RoleLevelType.BuildingAdmin)
                                                || userDetail.RoleLevel.Equals((int)Enums.RoleLevelType.Cleaner))
                                        select userDetail).ToList();

            validUserAccessPropertys = (from userDetail in DeviceLog.UserDetails

                                        join allpropertyUserId in alluserAccessAsserts.UserAccessProperties
                                        on userDetail.ID equals allpropertyUserId.UserId

                                        where allpropertyUserId.AssertId.Equals(deviceAssociation.PropertyId)
                                        where (userDetail.RoleLevel.Equals((int)Enums.RoleLevelType.PropertyAdmin)
                                                || userDetail.RoleLevel.Equals((int)Enums.RoleLevelType.Cleaner))
                                        select userDetail).ToList();

            // Added customer role level to the valid userdetails list.

            validCustomerAdmins = DeviceLog.UserDetails.Where(user => user.RoleLevel.Equals((int)Enums.RoleLevelType.CustomerAdmin)).ToList();

            //REfresh the fetched users based on the access filter check..
            DeviceLog.UserDetails.Clear();

            //Load users who actually have building and property acccess
            DeviceLog.UserDetails.AddRange(validUserAccessBuildings);
            DeviceLog.UserDetails.AddRange(validUserAccessPropertys);
            DeviceLog.UserDetails.AddRange(validCustomerAdmins);
        }

        public bool GetErrorAdminDetails()
        {
            bool isSuccess = false;
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.UserWorker>();
            DeviceLog = this.dataWorker.GetErrorAdminDetails();
            if (DeviceLog != null)
                isSuccess = true;

            return isSuccess;
        }

        public List<UserEntity> GetContactsForCustomer(int customerID, int buildingId)
        {
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.UserWorker>();
            return this.dataWorker.GetContactsForCustomer(customerID, buildingId);
        }

        public ProcessResponse<KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert> SaveDeviceAlert(KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert deviceAlert)
        {
            Guard.IsNotNull(deviceAlert, "Device Alert");
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.UserWorker>();
            ProcessResponse<KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert> response = this.dataWorker.SaveDeviceAlert(deviceAlert);
            return response;
        }

        public ProcessResponse<KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert> RemoveDeviceAlert(KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert deviceAlert)
        {
            Guard.IsNotNull(deviceAlert, "Device Alert");
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.UserWorker>();
            ProcessResponse<KC.SmartWashroom.BusinessEntities.AlertEngineEntities.DeviceAlert> response = this.dataWorker.RemoveDeviceAlert(deviceAlert);
            return response;

        }

        public List<BusinessEntity.TenantApiEntities.Role> GetRoles()
        {
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.UserWorker>();
            List<BusinessEntity.TenantApiEntities.Role> roles = this.dataWorker.GetRoles();
            Guard.IsNotNull(roles, "Roles from database");
            return roles;
        }

        public List<BusinessEntity.RolePermission> GetRolePermissions(short roleId)
        {
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.UserWorker>();
            return this.dataWorker.GetRolePermissions(roleId);
        }

        public List<BusinessEntity.Property> GetProperties(int customerId)
        {
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.UserWorker>();
            List<BusinessEntity.Property> properties = this.dataWorker.GetProperties(customerId);
            Guard.IsNotNull(properties, "Properties from database");
            return properties;
        }

        public List<BusinessEntity.Building> GetBuildings(int customerId)
        {
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.UserWorker>();
            List<BusinessEntity.Building> buildings = this.dataWorker.GetBuildings(customerId);
            Guard.IsNotNull(buildings, "Buildings from database");
            return buildings;
        }

        public BusinessEntity.TenantApiEntities.User GetUserDetails(int userId, int performedBy)
        {
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.UserWorker>();
            BusinessEntity.TenantApiEntities.User userDetail = this.dataWorker.GetUserDetails(userId);
            //Guard.IsNotNull(userDetail, "User details from database");

            AddParametersToAuditInformation("UserId", userId);
            BuildAuditInfo();
            AuditLog(performedBy, Core.Enumerations.Enums.AuditActivity.ViewUser);

            return userDetail;
        }

        public ProcessResponse<BusinessEntity.TenantApiEntities.User> CreateUser(BusinessEntity.TenantApiEntities.User User)
        {
            ProcessResponse<BusinessEntity.TenantApiEntities.User> response = new ProcessResponse<BusinessEntity.TenantApiEntities.User>();
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.UserWorker>();
            response = this.dataWorker.CreateUser(User);

            if (response.Status == ResponseStatus.Success)
            {
                if (User.RoleLevel != (int)Enums.RoleLevelType.Cleaner)
                    if (GeneratePassword(User))
                        SavePasswordToQueue(User, true);
            }

            AddParametersToAuditInformation("CustomerName", User.CustomerName);
            BuildAuditInfo();
            AuditLog(User.UpdatedBy, Core.Enumerations.Enums.AuditActivity.CreateUser);

            return response;
        }

        public ProcessResponse<BusinessEntity.TenantApiEntities.User> UpdateUser(BusinessEntity.TenantApiEntities.User User)
        {
            ProcessResponse<BusinessEntity.TenantApiEntities.User> response = new ProcessResponse<BusinessEntity.TenantApiEntities.User>();
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.UserWorker>();
            response = this.dataWorker.UpdateUser(User);

            //Defect fix for no password reset on user update...
            //if (response.Status == ResponseStatus.Success)
            //{
            //    if (GeneratePassword(User))
            //        SavePasswordToQueue(User, true);
            //}

            AddParametersToAuditInformation("CustomerName", User.CustomerName);
            AddParametersToAuditInformation("UserName", User.FirstName + " " + User.LastName);
            BuildAuditInfo();
            AuditLog(User.UpdatedBy, Core.Enumerations.Enums.AuditActivity.EditUser);

            return response;
        }

        public ProcessResponse<BusinessEntity.TenantApiEntities.User> DeleteUser(BusinessEntity.TenantApiEntities.User User)
        {
            ProcessResponse<BusinessEntity.TenantApiEntities.User> response = new ProcessResponse<BusinessEntity.TenantApiEntities.User>();
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.UserWorker>();
            response = this.dataWorker.DeleteUser(User);

            AddParametersToAuditInformation("UserId", User.UserId);
            BuildAuditInfo();
            AuditLog(User.UpdatedBy, Core.Enumerations.Enums.AuditActivity.DeleteUser);

            return response;
        }

        public string GetUserContactInfo(string UserName)
        {
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.UserWorker>();
            return this.dataWorker.GetUserContactInfo(UserName);
        }

        public bool SavePasswordToQueue(BusinessEntity.TenantApiEntities.User User, bool create)
        {
            UserAccountInformation accountInfo = new UserAccountInformation();
            DeviceAlertInfo alertInfo = new DeviceAlertInfo();
            bool isPasswordSetSucess = false;

            accountInfo.Password = User.Password;

            ProcessResponseForGateway response = new ProcessResponseForGateway();
            List<string> email = new List<string>();
            List<string> mobile = new List<string>();

            email.Add(User.Email);
            mobile.Add(User.Mobile);

            alertInfo.IsAlert = 1;
            alertInfo.BatteryRemaining = 0;
            alertInfo.SharedEmailAddresses = email;

            if (User.Mobile != null)
                alertInfo.SharedMobileNumbers = mobile;
            else
                alertInfo.SharedMobileNumbers = null;
            alertInfo.SharedUsers = null;

            if (create)
            {
                alertInfo.DeviceID = AlertEngineConstants.USER_CREATION_TEMPLATECODE;
                alertInfo.AlertType = AlertEngineConstants.USER_CREATION_TEMPLATECODE;
            }
            else
            {
                alertInfo.DeviceID = AlertEngineConstants.USER_FORGOTPASSWORD_TEMPLATECODE;
                alertInfo.AlertType = AlertEngineConstants.USER_FORGOTPASSWORD_TEMPLATECODE;
            }
            alertInfo.MessageContent = SerializationHelper.JsonSerialize<UserAccountInformation>(accountInfo);

            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Table_Workers.UserWorker>();

            string deviceAlertInfo = SerializationHelper.JsonSerialize<DeviceAlertInfo>(alertInfo);
            response = this.dataWorker.SaveAccountInfo(deviceAlertInfo);

            if (response.status == AlertEngineConstants.STATUS_SUCCESS)
                isPasswordSetSucess = true;

            return isPasswordSetSucess;
        }

        private bool GeneratePassword(BusinessEntity.TenantApiEntities.User User)
        {
            MembershipBusinessManager memberBM = new MembershipBusinessManager();
            bool isPasswordGenerated = memberBM.GenerateUserCredentials(User.Email, User.Password);
            return isPasswordGenerated;
        }

        private void AuditLog(int userId, Core.Enumerations.Enums.AuditActivity activity)
        {

            base.AuditInformation.AuditActivityType = activity;
            base.AuditInformation.PerformedBy = userId.ToString();
            base.AuditInformation.AuditInfo = base.FinalAuditInformation;
            base.TraceAuditInformation();

        }
    }
}
