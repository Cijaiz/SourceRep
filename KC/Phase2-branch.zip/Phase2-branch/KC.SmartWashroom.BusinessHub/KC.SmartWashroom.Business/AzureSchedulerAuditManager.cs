﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.Core.DependencyInjector;
using KC.SmartWashroom.Core.Enumerations;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.DataAccess.Skeleton;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.Business
{
    public class AzureSchedulerAuditManager : BusinessManagerBase<IAzureSchedulerAuditWorker>
    {
        public void ManualInjection<T>()
        {
            this.dataWorker = (IAzureSchedulerAuditWorker)Injector.Resolve<T>();
        }

        public ProcessResponse InsertJob(AzureSchedulerLog Scheduler)
        {
            Guard.IsNotNull(Scheduler, "Scheduler");
            return this.dataWorker.InsertUpdateJob(Scheduler);
        }

        public AzureSchedulerLog GetJob(int PropertyId)
        {
            Guard.IsNotNull(PropertyId, "PropertyId");
            return this.dataWorker.GetJob(PropertyId);
        }

        public ProcessResponse DeleteJob(int PropertyId)
        {
            Guard.IsNotNull(PropertyId, "PropertyId");
            return this.dataWorker.DeleteJob(PropertyId);
        }
    }
}
