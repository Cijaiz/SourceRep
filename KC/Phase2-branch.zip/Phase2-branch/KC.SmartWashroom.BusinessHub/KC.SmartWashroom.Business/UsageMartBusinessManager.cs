﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.Core.DependencyInjector;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.DataAccess.Skeleton;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.Business
{
    public class UsageMartBusinessManager : BusinessManagerBase<IUsageMartWorker>
    {
        public void ManualInjection<T>()
        {
            this.dataWorker = (IUsageMartWorker)Injector.Resolve<T>();
        }

        public List<ReportGenericEntity> GetTrafficDataWeekwise(ReportFilterEntity FilterValues)
        {
            Guard.IsNotNull(FilterValues, "ReportFilterEntity");
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.UsageMartWorker>();
            List<ReportGenericEntity> response = new List<ReportGenericEntity>();
            response = this.dataWorker.GetTrafficDataWeekwise(FilterValues);
            return response;
        }

        public List<ReportGenericEntity> GetTrafficDataMonthWise(ReportFilterEntity FilterValues)
        {
            Guard.IsNotNull(FilterValues, "ReportFilterEntity");
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.UsageMartWorker>();
            List<ReportGenericEntity> response = new List<ReportGenericEntity>();
            response = this.dataWorker.GetTrafficDataMonthWise(FilterValues);
            return response;
        }


        public List<ReportGenericEntity> GetProductUsageWeekwise(ReportFilterEntity FilterValues)
        {
            Guard.IsNotNull(FilterValues, "ReportFilterEntity");
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.UsageMartWorker>();
            List<ReportGenericEntity> response = new List<ReportGenericEntity>();
            response = this.dataWorker.GetProductUsageWeekwise(FilterValues);
            return response;
        }

        public List<ReportGenericEntity> GetProductUsageMonthwise(ReportFilterEntity FilterValues)
        {
            Guard.IsNotNull(FilterValues, "ReportFilterEntity");
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.UsageMartWorker>();
            List<ReportGenericEntity> response = new List<ReportGenericEntity>();
            response = this.dataWorker.GetProductUsageMonthwise(FilterValues);
            return response;
        }
        
        public List<ReportGenericEntity> GetProductSummaryData(ReportFilterEntity FilterValues)
        {
            Guard.IsNotNull(FilterValues, "ReportFilterEntity");
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.UsageMartWorker>();
            List<ReportGenericEntity> response = new List<ReportGenericEntity>();
            response = this.dataWorker.GetProductSummaryData(FilterValues);
            return response;
        }

        public int GetRefillBeforeThreshold(ReportFilterEntity FilterValues)
        {
            Guard.IsNotNull(FilterValues, "ReportFilterEntity");
            this.ManualInjection<KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers.UsageMartWorker>();
            int Refill = 0;
            Refill = this.dataWorker.GetRefillBeforeThreshold(FilterValues);
            return Refill;
        }
    }
}
