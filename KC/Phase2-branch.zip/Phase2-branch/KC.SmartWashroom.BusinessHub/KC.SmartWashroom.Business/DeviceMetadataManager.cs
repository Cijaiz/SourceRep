﻿
namespace KC.SmartWashroom.Business
{
    using KC.SmartWashroom.Business.Contracts;
    using KC.SmartWashroom.BusinessEntities.DeviceUpdate;
    using KC.SmartWashroom.BusinessEntities.Search;
    using KC.SmartWashroom.DataAccess.DataWorkers;
    using KC.SmartWashroom.DataAccess.Skeleton;
    using System.Collections.Generic;

    public class DeviceMetadataManager : IDeviceMetadataManager
    {
        public DeviceMetadataManager(IDeviceMetadataWorker metadataWorker = null)
        {
            this.MetadataWorker = metadataWorker ?? new DeviceMetadataWorker();
        }

        public IEnumerable<DeviceUpdateDetails> GetDeviceDetails(DeviceSearchParameters searchParameters)
        {
            return this.MetadataWorker.GetDeviceDetailsWithParameters(searchParameters);
        }



        public void Dispose()
        {
            if (this.MetadataWorker != null)
            {
                this.MetadataWorker.Dispose();
                this.MetadataWorker = null;
            }
        }

        public IDeviceMetadataWorker MetadataWorker { get; set; }
    }
}
