﻿
// Aspired to move out along with other contracts
namespace KC.SmartWashroom.Business.Contracts
{
    using KC.SmartWashroom.BusinessEntities.DeviceUpdate;
    using KC.SmartWashroom.BusinessEntities.Search;
    using System;
    using System.Collections.Generic;

    public interface IDeviceMetadataManager : IDisposable
    {
        IEnumerable<DeviceUpdateDetails> GetDeviceDetails(DeviceSearchParameters searchParameters);
    }
}
