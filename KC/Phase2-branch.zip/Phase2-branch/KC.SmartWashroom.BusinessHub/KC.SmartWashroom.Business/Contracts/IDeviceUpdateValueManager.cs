﻿/*TODO: Interface for decoupling and unit testing. To be moved to an external assembly*/


namespace KC.SmartWashroom.Business.Contracts
{
    using KC.SmartWashroom.BusinessEntities.DeviceUpdate;
    using System;
    using System.Collections.Generic;
    /// <summary>
    /// Abstraction for the business class for the device parameter value management
    /// This component must be built to operate with the parameter value store
    /// </summary>
    //[Obsolete("Please use the IDeviceMetadataManager instead")]
    public interface IDeviceUpdateValueManager
    {
        /// <summary>
        /// Returns an enumerable of device metadata for the given device id, when implemented
        /// </summary>
        /// <param name="deviceId">The unique device identifier</param>
        /// <returns>An enumerable of the device metadata when implemented</returns>
        IEnumerable<DeviceUpdateDetails> GetDeviceDetails(string deviceId);

        /// <summary>
        /// Sets the auto reset parameter values back to the store
        /// </summary>
        /// <param name="parameters">The list of auto reset parameters</param>
        /// <returns>The number of records affected</returns>
        int SetAutoResetParameterValues(IEnumerable<DeviceUpdateParameter> autoResetParameters);

        IEnumerable<DeviceUpdateDetails> RetrieveFromCache(string deviceId);

        bool SaveToCache(DeviceUpdateDetails device);

        DeviceUpdateDetails GetFromCache(string deviceId);

        bool RemoveFromCache(string deviceId = "");
    }
}
