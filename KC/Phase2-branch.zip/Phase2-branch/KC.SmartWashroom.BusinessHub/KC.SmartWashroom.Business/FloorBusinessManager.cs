﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.Core.DependencyInjector;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.DataAccess.Skeleton;
using System.Collections.Generic;
using BusinessEntity = KC.SmartWashroom.BusinessEntities;
using System.Linq;
using System;

namespace KC.SmartWashroom.Business
{
    public class FloorBusinessManager : BusinessManagerBase<IFloorWorker>
    {
        public void ManualInjection<T>()
        {
            this.dataWorker = (IFloorWorker)Injector.Resolve<T>();
        }

        public ProcessResponse<BusinessEntity.Floor> CreateFloorRange(List<BusinessEntity.Floor> floors)
        {
            ProcessResponse<BusinessEntity.Floor> response = new ProcessResponse<Floor>();
            response = this.dataWorker.CreateFloorRange(floors);

            AddParametersToAuditInformation("BuildingName", floors.Count > 0 ? floors.FirstOrDefault().BuildingName : string.Empty);
            BuildAuditInfo();
            AuditLog(floors.Count > 0 ? floors.FirstOrDefault().CreatedBy : 0, Core.Enumerations.Enums.AuditActivity.CreateFloor);
            return response;
        }

        public BusinessEntity.Floor GetFloorDetails(int floorId, int userId)
        {
            BusinessEntity.Floor floor = this.dataWorker.GetFloorDetails(floorId);
            Guard.IsNotNull(floor, "Floor details from database");

            AddParametersToAuditInformation("FloorId", floorId);
            BuildAuditInfo();
            AuditLog(userId, Core.Enumerations.Enums.AuditActivity.ViewFloor);
            return floor;
        }

        public ProcessResponse<BusinessEntity.Floor> Delete(Int32 floorId,int userId)
        {
            ProcessResponse<BusinessEntity.Floor> response = new ProcessResponse<Floor>();
            response = this.dataWorker.Delete(floorId, userId);

            AddParametersToAuditInformation("FloorId", floorId);
            BuildAuditInfo();
            AuditLog(userId, Core.Enumerations.Enums.AuditActivity.DeleteFloor);
            return response;
        }

        public Names GetNames(int buildingId)
        {
            Guard.IsNotNull(buildingId, "buildingId");
            return this.dataWorker.GetNames(buildingId);
        }

        public ProcessResponse<BusinessEntity.Floor> Update(BusinessEntity.Floor floor)
        {
            ProcessResponse<BusinessEntity.Floor> response = new ProcessResponse<Floor>();
            response = this.dataWorker.Update(floor);

            AddParametersToAuditInformation("FloorLevel", floor.FloorLevel);
            BuildAuditInfo();
            AuditLog(floor.LastUpdatedBy != null ? Convert.ToInt32(floor.LastUpdatedBy) : 0, Core.Enumerations.Enums.AuditActivity.EditFloor);
            return response;
        }

        public BusinessEntity.Floor GetFloorAlerts(int floorId, int buildingId, byte genderId, int washroomId, int userId)
        {
            BusinessEntity.Floor floor = new Floor();
            floor = this.dataWorker.GetFloorAlerts(floorId, buildingId, genderId, washroomId);
            if (genderId == 0 && washroomId == 0)
            {
                Guard.IsNotNull(userId, "userID");
                #region Audit log
                base.AddParametersToAuditInformation("PropertyName", floor.PropertyName);
                base.AddParametersToAuditInformation("BuildingName", floor.BuildingName);
                base.AddParametersToAuditInformation("FloorLevel", floor.FloorLevel);
                base.BuildAuditInfo();

                base.AuditInformation.AuditActivityType = Core.Enumerations.Enums.AuditActivity.FloorView;
                base.AuditInformation.PerformedBy = userId.ToString();
                base.AuditInformation.AuditInfo = base.FinalAuditInformation;
                base.TraceAuditInformation();

                #endregion
            }


            return floor;
        }

        private void AuditLog(int userId, Core.Enumerations.Enums.AuditActivity activity)
        {

            base.AuditInformation.AuditActivityType = activity;
            base.AuditInformation.PerformedBy = userId.ToString();
            base.AuditInformation.AuditInfo = base.FinalAuditInformation;
            base.TraceAuditInformation();

        }


    }
}
