﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.Simulator;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.Core.Log;
using KC.SmartWashroom.Core.NotificationUtility;
using KC.SmartWashroom.DataAccess.Skeleton;
using KC.SmartWashroom.Core.Constants;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;

namespace KC.SmartWashroom.Business.Simulator
{
    public class GatewayFeedManager : BusinessManagerBase<ISimulatorWorker>
    {
        private int timeDiffLastlog = Convert.ToInt32(CommonHelper.GetConfigSetting("TimeDifferenceInMinutes"));


        const string GATEWAY_DETAIL = "1234567890abcdef,104";
        private string username = CommonHelper.GetConfigSetting("APIUserName");
        private string password = CommonHelper.GetConfigSetting("APIPassword");

        private int ResendAlertDuration = Convert.ToInt32(CommonHelper.GetConfigSetting("ResendAlertDurationInMinutes"));

        private List<IDeviceSimulator> DeviceSimulators;
        private List<DeviceSimulator> Devices { get; set; }

        public GatewayFeedManager()
        {
            DeviceSimulators = new List<IDeviceSimulator>();
        }

        #region Public methods
        public void FetchDevices()
        {
            Devices = this.dataWorker.FetchDevices();
            if (Devices != null)
            {
                RemoveJunkDevices();
            }
        }

        public void DeleteInactiveDevices()
        {
            this.dataWorker.DeleteInactiveDevices();
        }

        public DateTime FetchDeviceStatusTimeStamp(DeviceSimulator Device)
        {
            DeviceBusinessManager manager = new DeviceBusinessManager();
            DeviceAssociation deviceAssociation = manager.GetDeviceAssociation(Device.DeviceID);

            return this.dataWorker.FetchDeviceLogTimeStamp(Device, deviceAssociation.CustomerId);
        }

        public void FetchTempDeviceLogs()
        {
            Guard.IsNotNull(this.Devices, "DevicesFromSql");
            foreach (DeviceSimulator Device in this.Devices)
            {
                DeviceSimulator TempDevice = new DeviceSimulator();
                TempDevice = this.dataWorker.FetchTempDeviceLog(Device);
                Device.IsNewDevice = TempDevice.IsNewDevice;
                Device.DeviceParameter = TempDevice.DeviceParameter;
            }
        }

        public void CreateDeviceSimulators()
        {
            Guard.IsNotNull(this.Devices, "DevicesFromSql");
            foreach (DeviceSimulator device in this.Devices)
            {
                //Call specific device simulator to update parameters
                //Check for Device Type
                switch (device.Type.ToUpper())
                {
                    //Case JRT Type
                    case CommonConstants.JRT:
                        IDeviceSimulator jrtSimulator;
                        if (device.IsNewDevice)
                        {
                            jrtSimulator = new JRTSimulator(device.DeviceID);
                        }
                        else
                        {
                            jrtSimulator = new JRTSimulator(device.DeviceParameter, device.DeviceID);
                        }
                        this.DeviceSimulators.Add(jrtSimulator);
                        break;
                    case CommonConstants.SRB:
                        IDeviceSimulator srbSimulator;
                        if (device.IsNewDevice)
                        {
                            srbSimulator = new SRBSimulator(device.DeviceID);
                        }
                        else
                        {
                            srbSimulator = new SRBSimulator(device.DeviceParameter, device.DeviceID);
                        }
                        this.DeviceSimulators.Add(srbSimulator);
                        break;
                    //Case eHRT Type
                    case CommonConstants.eHRT:
                        IDeviceSimulator eHRTSimulator;
                        if (device.IsNewDevice)
                        {
                            eHRTSimulator = new eHRTSimulator(device.DeviceID);
                        }
                        else
                        {
                            eHRTSimulator = new eHRTSimulator(device.DeviceParameter, device.DeviceID);
                        }
                        this.DeviceSimulators.Add(eHRTSimulator);
                        break;
                    //Case eSoap Type
                    case CommonConstants.eSoap:
                        IDeviceSimulator eSoapSimulator;
                        if (device.IsNewDevice)
                        {
                            eSoapSimulator = new eSoapSimulator(device.DeviceID);
                        }
                        else
                        {
                            eSoapSimulator = new eSoapSimulator(device.DeviceParameter, device.DeviceID);
                        }
                        this.DeviceSimulators.Add(eSoapSimulator);
                        break;
                    default:
                        break;
                }
            }
        }

        public void SimulateData()
        {
            foreach (DeviceSimulator device in this.Devices)
            {
                try
                {
                    Guard.IsNotNull(this.DeviceSimulators.Find(o => o.DeviceId == device.DeviceID), "DeviceSimulatorObject");
                    if (device.IsNewDevice)
                    {
                        DeviceSimulators.Find(o => o.DeviceId == device.DeviceID).SimulateInitialDeviceData(device);
                    }
                    else
                    {
                        List<string> FixAlertCodes = new List<string>();
                        FixAlertCodes = UpdateFixAlertForDevice(device);
                        DeviceSimulators.Find(o => o.DeviceId == device.DeviceID).SimulateDeviceData(device, FixAlertCodes);
                        if (FixAlertCodes != null && FixAlertCodes.Count > 0)
                        {
                            device.DeviceParameter = DeviceSimulators.Find(s => s.DeviceId == device.DeviceID).CreateAPIRequestBody(device);
                            PushResolvedAlertDataFeed(new DeviceDetailParameter() { deviceDetail = device.DeviceParameter });
                        }
                    }
                }
                catch (Exception exp)
                {
                    Logger.Error(string.Format("Simulate Failed for - {0}. Exception: {1}", device.DeviceID, exp.ToString()));
                }
            }
        }

        public void CreateRequestBody()
        {
            this.Devices.ForEach(o => o.DeviceParameter = this.DeviceSimulators.Find(s => s.DeviceId == o.DeviceID).CreateAPIRequestBody(o));
        }

        public void InsertRaisedAlertTimeStamp()
        {
            //Set the alerts raised in respective device
            this.Devices.ForEach(o => this.DeviceSimulators.Find(s => s.DeviceId == o.DeviceID).SetRaisedAlerts(o));
            //Check for new alerts and call API
            PushNewAlertDataFeed();
            //Set the time log for raised alerts
            this.dataWorker.InsertTimeStampForAlert(this.Devices);
        }

        public ProcessResponse PushNewDeviceDataFeed()
        {
            List<DeviceDetailParameter> NewDeviceFeeds = new List<DeviceDetailParameter>();

            NewDeviceFeeds = (from device in this.Devices
                              where device.IsNewDevice == true
                              select new DeviceDetailParameter { deviceDetail = device.DeviceParameter }).ToList();
            return BulkDeviceDataUpdate(NewDeviceFeeds);
        }

        public ProcessResponse PushUpdatedDeviceDataFeed()
        {
            List<DeviceDetailParameter> UpdatedDeviceFeeds = new List<DeviceDetailParameter>();

            UpdatedDeviceFeeds = (from device in this.Devices
                                  where device.IsNewDevice == false && this.CheckDeviceLogUpdateRequired(device) == true
                                  select new DeviceDetailParameter { deviceDetail = device.DeviceParameter }).ToList();

            return BulkDeviceDataUpdate(UpdatedDeviceFeeds);
        }

        public ProcessResponse PushResolvedAlertDataFeed(DeviceDetailParameter deviceDetailParam)
        {
            List<DeviceDetailParameter> UpdatedDeviceFeeds = new List<DeviceDetailParameter>();

            UpdatedDeviceFeeds.Add(deviceDetailParam);
            if (deviceDetailParam != null && deviceDetailParam.deviceDetail != null)
            {
                Logger.Debug(string.Format("Alert Resolved - {0}", deviceDetailParam.deviceDetail));
            }
            return BulkDeviceDataUpdate(UpdatedDeviceFeeds);
        }
        public ProcessResponse PushNewAlertDataFeed()
        {
            List<DeviceDetailParameter> AlertFeeds = new List<DeviceDetailParameter>();
            AlertFeeds = (from device in this.Devices
                          from alert in device.Alerts
                          where device.Alerts.Count() >= 1 && device.IsNewDevice == false && this.CheckAlertRaisedFirstTime(device.DeviceID, alert.AlertCode) == true
                          select device.DeviceParameter).Distinct().Select(deviceParam => new DeviceDetailParameter { deviceDetail = deviceParam }).ToList();
            if (AlertFeeds != null && AlertFeeds.Count > 0)
            {
                foreach (DeviceDetailParameter param in AlertFeeds)
                {
                    Logger.Debug("Alert raised - Device param : {0}", param.deviceDetail);
                }
            }
            return BulkDeviceDataUpdate(AlertFeeds);
        }

        public ProcessResponse PushAlertDataFeed()
        {
            List<DeviceDetailParameter> AlertFeeds = new List<DeviceDetailParameter>();
            AlertFeeds = (from device in this.Devices
                          from alert in device.Alerts
                          where device.Alerts.Count() >= 1 && device.IsNewDevice == false && this.CheckAlertLogUpdateRequired(device.DeviceID, alert.AlertCode) == true
                          select device.DeviceParameter).Distinct().Select(deviceParam => new DeviceDetailParameter { deviceDetail = deviceParam }).ToList();
            if (AlertFeeds != null && AlertFeeds.Count > 0)
            {
                foreach (DeviceDetailParameter param in AlertFeeds)
                {
                    Logger.Debug("Alert resend - Device param : {0}", param.deviceDetail);
                }
            }
            return BulkDeviceDataUpdate(AlertFeeds);
        }

        public void UpdateDeviceParameter()
        {
            //Update the device parameter with json format of parameter data
            this.Devices.ForEach(o => o.DeviceParameter = this.DeviceSimulators.Find(a => a.DeviceId == o.DeviceID).GetJSONDeviceParameters());
        }

        public ProcessResponse InsertTempDeviceLog()
        {
            //Call Data layer
            return this.dataWorker.InsertTempDeviceLog(this.Devices.FindAll(o => o.IsNewDevice == true));
        }

        public ProcessResponse UpdateTempDeviceLog()
        {
            //Call Data layer
            return this.dataWorker.UpdateTempDeviceLog(this.Devices.FindAll(o => o.IsNewDevice == false));
        }

        public void GatewayFeeder()
        {
            //Use ProcessResponse
            List<ProcessResponseForGateway> allResponses = new List<ProcessResponseForGateway>();
            DeleteInactiveDevices();
            FetchDevices();
            if (Devices != null)
            {
                FetchTempDeviceLogs();
                CreateDeviceSimulators();

                SimulateData();
                CreateRequestBody();
                InsertRaisedAlertTimeStamp();
                PushNewDeviceDataFeed();
                PushUpdatedDeviceDataFeed();
                PushAlertDataFeed();
                //Call UpdateParameter method to update device parameters with json format of device parameter values
                UpdateDeviceParameter();
                //Insert/Update data in temp table
                InsertTempDeviceLog();

                UpdateTempDeviceLog();
            }
            else
            {
                Logger.Debug("No active devices for simulation");
            }
        }
        #endregion

        #region Private methods
        private ProcessResponse BulkDeviceDataUpdate(List<DeviceDetailParameter> devicesDetails)
        {
            List<ProcessResponse> apiResponses = new List<ProcessResponse>();
            ProcessResponse Response = new ProcessResponse() { Status = ResponseStatus.Success };
            string response = string.Empty;
            if (devicesDetails.Count > 0)
            {
                WebClient client = new WebClient();
                //Set authentication header token
                client.SetDeviceAuthenticationHeaderToken(CommonHelper.GetConfigSetting("AuthHeaderToken"));
                foreach (DeviceDetailParameter deviceDetail in devicesDetails)
                {
                    try
                    {
                        deviceDetail.gatewayDetail = GATEWAY_DETAIL;
                        response = client.WebClientPostRequest<DeviceDetailParameter>(CommonHelper.GetConfigSetting("PushSimulatorDataUrl") + "Devices/Post", deviceDetail);
                        if (!string.IsNullOrEmpty(response))
                        {
                            Response = SerializationHelper.JsonDeserialize<ProcessResponse>(response);
                        }
                        apiResponses.Add(Response);
                    }
                    catch (Exception exp)
                    {
                        if (deviceDetail != null && !string.IsNullOrEmpty(deviceDetail.deviceDetail))
                        {
                            string[] deviceFields = deviceDetail.deviceDetail.Split(',');
                            if (deviceFields != null && deviceFields.Count() > 0 && !string.IsNullOrEmpty(deviceFields[0]))
                            {
                                Logger.Error(string.Format("API Send Failed for - {0}. Exception: {1}", deviceFields[0], exp.ToString()));
                            }
                            else
                            {
                                Logger.Error(exp.ToString());
                            }
                        }
                        else
                        {
                            Logger.Error(exp.ToString());
                        }
                    }
                }
                if ( apiResponses!=null && apiResponses.Count>0 &&
                    apiResponses.Find(o => (o != null) && (o.Status == ResponseStatus.Failed || o.Status == ResponseStatus.Error)) != null)
                {
                    Response.Status = ResponseStatus.Failed;
                }
            }
            return Response;
        }

        private List<string> UpdateFixAlertForDevice(DeviceSimulator device)
        {
            List<string> FixAlertCodes = new List<string>();
            //Check the list of alerts for the device
            FixAlertCodes = this.dataWorker.FetchUpdateFixAlertForDevice(device.DeviceID);
            //Delete the alerts which are fixed from RaisedAlerts table 
            if (FixAlertCodes.Count() > 0)
            {
                this.dataWorker.DeleteTimeStampForAlert(device.DeviceID, FixAlertCodes);
            }
            return FixAlertCodes;
        }

        private bool CheckDeviceLogUpdateRequired(DeviceSimulator device)
        {
            //Get the Timestamp of the device
            DateTime deviceTimeStamp = FetchDeviceStatusTimeStamp(device);
            //Check the timespan difference with current time and last device log time
            TimeSpan timeDiff = DateTime.UtcNow.Subtract(deviceTimeStamp);

            if (timeDiff.TotalMinutes > timeDiffLastlog)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private bool CheckAlertLogUpdateRequired(string deviceId, string alertType)
        {
            DateTime LastAlertLogged;
            //Get the last log time for the alert
            LastAlertLogged = this.dataWorker.FetchTimeStampForAlert(deviceId, alertType);
            //Check if the difference between current time and last log alert time is more than the Resend Alert time
            TimeSpan timeDiff = DateTime.UtcNow.Subtract(LastAlertLogged);
            if (ResendAlertDuration == 0)
            {
                return false;
            }
            else if (timeDiff.TotalMinutes > ResendAlertDuration)
            {
                //Update the timestamp
                this.dataWorker.UpdateTimeStampForAlert(deviceId, alertType);
                return true;
            }
            return false;
        }

        private bool CheckAlertRaisedFirstTime(string deviceId, string alertType)
        {
            return this.dataWorker.CheckDeviceAlertFirstRaise(deviceId, alertType);
        }

        private void RemoveJunkDevices()
        {
            Devices.RemoveAll(o => !o.Type.Equals(GetDeviceType(o.DeviceID), StringComparison.OrdinalIgnoreCase));
        }

        private string GetDeviceType(string Macid)
        {
            if (Macid.StartsWith(CommonConstants.JRT_DEVICE))
                return CommonConstants.JRT;
            else if (Macid.StartsWith(CommonConstants.SRB_DEVICE))
                return CommonConstants.SRB;
            else if (Macid.StartsWith(CommonConstants.ESOAP_DEVICE))
                return CommonConstants.eSoap;
            else if (Macid.StartsWith(CommonConstants.EHRT_DEVICE))
                return CommonConstants.eHRT;
            else
                return string.Empty;
        }
        #endregion
    }
}

