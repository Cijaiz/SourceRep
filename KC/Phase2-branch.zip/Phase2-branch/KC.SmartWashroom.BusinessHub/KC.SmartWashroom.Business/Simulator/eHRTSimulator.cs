﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.Simulator;
using KC.SmartWashroom.Core.Enumerations;
using KC.SmartWashroom.Core.Helper;
using System;
using System.Collections.Generic;
using System.Configuration;

namespace KC.SmartWashroom.Business.Simulator
{
    class eHRTSimulator : IDeviceSimulator
    {
        eHRTParameters eHRTPrms;
        string _deviceId;
        bool _hasAlert;
        private const string H2LowBatteryKey = "H2LowBatteryThreshold";
        private const string H4LowPaperKey = "H4LowPaperThreshold";
        private const string H5TrashFullKey = "H5TrashFullThreshold";
        private const string MaxPaperDispenseKey = "eHRTMaxPaperDispense";
        
        Dictionary<string, string> ThresholdValues = SerializationHelper.JsonDeserialize<Dictionary<string, string>>(CommonHelper.GetConfigSetting("ThresholdValues"));

        const int MAX_POSSIBLE_BATTERY_VOLTAGE = 582;
        const int MIN_POSSIBLE_BATTERY_VOLTAGE = 485;

        decimal H2Threshold = 0;
        int H4Threshold = 0;
        int H5Threshold = 0;
        int MaxPaperDispenses = 0;

        int LowRandomNumber { get { return Convert.ToInt32(CommonHelper.GetConfigSetting("LowRandomNumber")); } }
        int HighRandomNumber { get { return Convert.ToInt32(CommonHelper.GetConfigSetting("HighRandomNumber")); } }

        public string DeviceId
        {
            get { return _deviceId; }
            set { _deviceId = value; }
        }

        public bool HasAlert
        {
            get { return _hasAlert; }
            set { _hasAlert = value; }
        }

        public eHRTSimulator(string devicePrmData, string deviceId)
        {
            _deviceId = deviceId;
            _hasAlert = false;
            eHRTPrms = SerializationHelper.Deserialize<eHRTParameters>(devicePrmData);
            SetThresholdValues(deviceId);
        }

        public eHRTSimulator(string deviceId)
        {
            _deviceId = deviceId;
            _hasAlert = false;
            eHRTPrms = new eHRTParameters();
            SetThresholdValues(deviceId);
        }
        private int GetRefillValue(string deviceId)
        {
            int refillValue = 0;
            DeviceBusinessManager deviceBusinessManager = new DeviceBusinessManager();
            string refillSize = deviceBusinessManager.GeteHRTRefillSize(deviceId);
            WashroomBusinessManager washroomBusinessManager = new WashroomBusinessManager();
            refillValue = (int)washroomBusinessManager.GetDeviceRefillValue(refillSize, Enums.DeviceType.eHRT.ToString().ToUpper());
            return refillValue;
        }

        private void SetThresholdValues(string deviceId)
        {
            Guard.IsNotNull(ThresholdValues[H2LowBatteryKey], "Threshold Value for Low Battery of hrt device type");
            Guard.IsNotBlank(ThresholdValues[H2LowBatteryKey], "Threshold Value for Low Battery of hrt device type");
            Guard.IsNotNull(ThresholdValues[H4LowPaperKey], "Threshold Value for Low Paper of hrt device type");
            Guard.IsNotBlank(ThresholdValues[H4LowPaperKey], "Threshold Value for Low Paper of hrt device type");
            Guard.IsNotNull(ThresholdValues[H5TrashFullKey], "Threshold Value for Trash Full of hrt device type");
            Guard.IsNotBlank(ThresholdValues[H5TrashFullKey], "Threshold Value for Trash Full of hrt device type");
            Guard.IsNotNull(ThresholdValues[MaxPaperDispenseKey], "Maximum Value for paper dispense of hrt device type");
            Guard.IsNotBlank(ThresholdValues[MaxPaperDispenseKey], "Maximum Value for paper dispense of hrt device type");
            H2Threshold = Convert.ToDecimal(ThresholdValues[H2LowBatteryKey].ToString());
            //H4Threshold = Convert.ToInt32(ThresholdValues[H4LowPaperKey].ToString());
            H5Threshold = Convert.ToInt32(ThresholdValues[H5TrashFullKey].ToString());
            //MaxPaperDispenses = Convert.ToInt32(ThresholdValues[MaxPaperDispenseKey].ToString());
            MaxPaperDispenses = GetRefillValue(deviceId);
            H4Threshold = (int)(MaxPaperDispenses * 0.8);


        }

        public void SimulateInitialDeviceData(DeviceSimulator dsEntity)
        {
            eHRTPrms.SoftwareVersion = 101M;
            eHRTPrms.Sensitivity = 'L';
            eHRTPrms.DispenseLength = 'S';
            eHRTPrms.DispenserDelay = 'S';
            eHRTPrms.DispenseMode = 'H';
            eHRTPrms.TotalDispenseCount = 0;
            eHRTPrms.DispensesWithLastBattery = 0;
            eHRTPrms.DispensesWithCurrentBattery = 0;
            eHRTPrms.NumberOfBatteryChanges = 0;
            eHRTPrms.VoltageLastBatteryChange = 0;
            eHRTPrms.CurrentBatteryVoltage = MAX_POSSIBLE_BATTERY_VOLTAGE;
            eHRTPrms.PaperDispensedSinceLastRefill = 0;
            eHRTPrms.Reset = false;
            eHRTPrms.TrashEmptyPercent = 100;
            eHRTPrms.TotalRollsDispensed = 0;

            //new Parameters
            eHRTPrms.DelayEnabled = false;
            eHRTPrms.DelayValue = 32562;
        }

        public void SimulateDeviceData(DeviceSimulator dsEntity, List<string> FixAlertCodes)
        {
            //Update eHRT parameters by that much %
            eHRTPrms.CurrentBatteryVoltage = (int)(eHRTPrms.CurrentBatteryVoltage - ((MAX_POSSIBLE_BATTERY_VOLTAGE - MIN_POSSIBLE_BATTERY_VOLTAGE) * (CommonHelper.GetRandomNumber(LowRandomNumber, HighRandomNumber) / 100.0M)));
            eHRTPrms.CurrentBatteryVoltage = (eHRTPrms.CurrentBatteryVoltage <= MIN_POSSIBLE_BATTERY_VOLTAGE) ? MIN_POSSIBLE_BATTERY_VOLTAGE : eHRTPrms.CurrentBatteryVoltage;

            int randomValDispense = CommonHelper.GetRandomNumber(LowRandomNumber, HighRandomNumber);
            eHRTPrms.TotalDispenseCount = (eHRTPrms.PaperDispensedSinceLastRefill == MaxPaperDispenses) ? eHRTPrms.TotalDispenseCount : eHRTPrms.TotalDispenseCount + randomValDispense;
            eHRTPrms.PaperDispensedSinceLastRefill = eHRTPrms.PaperDispensedSinceLastRefill + randomValDispense;
            eHRTPrms.PaperDispensedSinceLastRefill = (eHRTPrms.PaperDispensedSinceLastRefill > MaxPaperDispenses) ? MaxPaperDispenses : eHRTPrms.PaperDispensedSinceLastRefill;

            eHRTPrms.DispensesWithCurrentBattery = (eHRTPrms.PaperDispensedSinceLastRefill == MaxPaperDispenses) ? eHRTPrms.DispensesWithCurrentBattery : eHRTPrms.DispensesWithCurrentBattery + CommonHelper.GetRandomNumber(LowRandomNumber, HighRandomNumber);
            eHRTPrms.TrashEmptyPercent = eHRTPrms.TrashEmptyPercent - CommonHelper.GetRandomNumber(LowRandomNumber, HighRandomNumber);
            eHRTPrms.TrashEmptyPercent = (eHRTPrms.TrashEmptyPercent <= 0) ? 0 : eHRTPrms.TrashEmptyPercent;
            UpdateDeviceAlertParameters(FixAlertCodes);
        }

        public string CreateAPIRequestBody(DeviceSimulator dsEntity)
        {
            return dsEntity.DeviceID + "," + eHRTPrms.SoftwareVersion + "," + eHRTPrms.Sensitivity + "," + eHRTPrms.DispenseLength + "," + eHRTPrms.DispenserDelay + "," +
                eHRTPrms.DispenseMode + "," + eHRTPrms.TotalDispenseCount + "," + eHRTPrms.DispensesWithLastBattery + "," + eHRTPrms.DispensesWithCurrentBattery + "," +
                eHRTPrms.NumberOfBatteryChanges + "," + eHRTPrms.VoltageLastBatteryChange + "," + (int)eHRTPrms.CurrentBatteryVoltage + "," + (eHRTPrms.LowPaperAlert ? "1" : "0") + "," +
                (eHRTPrms.LowBatteryAlert ? "1" : "0") + "," + 0 + "," + eHRTPrms.PaperDispensedSinceLastRefill + "," + (eHRTPrms.Reset ? "1" : "0") + "," +
                0 + "," + eHRTPrms.TrashEmptyPercent + "," + (eHRTPrms.TrashFullAlert ? "1" : "0") + "," + 0 + "," + eHRTPrms.TotalRollsDispensed + "," + (eHRTPrms.DelayEnabled ? "1" : "0") + "," + eHRTPrms.DelayValue;
        }

        public void SetRaisedAlerts(DeviceSimulator dsEntity)
        {
            if (eHRTPrms.LowBatteryAlert)
            {
                AlertSimulator alert = new AlertSimulator();
                alert.AlertCode = "H2";
                dsEntity.Alerts.Add(alert);
            }
            if (eHRTPrms.LowPaperAlert)
            {
                AlertSimulator alert = new AlertSimulator();
                alert.AlertCode = "H4";
                dsEntity.Alerts.Add(alert);
            }
            if (eHRTPrms.TrashFullAlert)
            {
                AlertSimulator alert = new AlertSimulator();
                alert.AlertCode = "H5";
                dsEntity.Alerts.Add(alert);
            }
        }

        public string GetJSONDeviceParameters()
        {
            return SerializationHelper.JsonSerialize(eHRTPrms);
        }

        private void UpdateDeviceAlertParameters(List<string> alertCodes)
        {
            if (alertCodes != null)
            {
                //Low battery alert
                if (eHRTPrms.CurrentBatteryVoltage <= H2Threshold && alertCodes.Contains("H2"))
                {
                    eHRTPrms.NumberOfBatteryChanges++;
                    eHRTPrms.DispensesWithLastBattery = eHRTPrms.DispensesWithCurrentBattery;
                    eHRTPrms.DispensesWithCurrentBattery = 0;
                    eHRTPrms.VoltageLastBatteryChange = Convert.ToInt32(eHRTPrms.CurrentBatteryVoltage);
                    eHRTPrms.CurrentBatteryVoltage = MAX_POSSIBLE_BATTERY_VOLTAGE;
                    eHRTPrms.LowBatteryAlert = false;
                    this.HasAlert = false;
                }
                //Low paper alert
                if (eHRTPrms.PaperDispensedSinceLastRefill >= H4Threshold && alertCodes.Contains("H4"))
                {
                    eHRTPrms.PaperDispensedSinceLastRefill = 0;
                    eHRTPrms.TotalRollsDispensed++;
                    eHRTPrms.LowPaperAlert = false;
                    this.HasAlert = false;
                }
                //Trash full alert
                if (eHRTPrms.TrashEmptyPercent <= H5Threshold && alertCodes.Contains("H5"))
                {
                    eHRTPrms.TrashEmptyPercent = 100;
                    eHRTPrms.TrashFullAlert = false;
                    this.HasAlert = false;
                }
            }
            if (eHRTPrms.CurrentBatteryVoltage <= H2Threshold)
            {
                eHRTPrms.LowBatteryAlert = true;
                this.HasAlert = true;
            }
            if (eHRTPrms.PaperDispensedSinceLastRefill >= H4Threshold)
            {
                eHRTPrms.LowPaperAlert = true;
                this.HasAlert = true;
            }
            if (eHRTPrms.TrashEmptyPercent <= H5Threshold)
            {
                eHRTPrms.TrashFullAlert = false;//Making it false as Trash Full alert is not in scope
                this.HasAlert = true;
            }
        }
    }
}
