﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.Simulator;
using System.Collections.Generic;

namespace KC.SmartWashroom.Business.Simulator
{
    public interface IDeviceSimulator
    {
        string DeviceId { get; set; }
        bool HasAlert { get; set; }

        void SimulateInitialDeviceData(DeviceSimulator dsEntity);
        void SimulateDeviceData(DeviceSimulator dsEntity, List<string> FixAlertCodes);

        string GetJSONDeviceParameters();
        string CreateAPIRequestBody(DeviceSimulator dsEntity);

        void SetRaisedAlerts(DeviceSimulator dsEntity);        
    }
}
