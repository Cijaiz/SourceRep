﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.Simulator;
using KC.SmartWashroom.Core.Helper;
using System;
using System.Collections.Generic;
using System.Configuration;

namespace KC.SmartWashroom.Business.Simulator
{
    class eSoapSimulator : IDeviceSimulator
    {
        eSoapParameters eSoapPrms;
        string _deviceId;
        bool _hasAlert;
        private const string S1LowSoapKey = "S1LowSoapThreshold";
        private const string S2LowBatteryKey = "S2LowBatteryThreshold";
        private const string S4VeryLowSoapKey = "S4VeryLowSoapThreshold";
        private const string MaxSoapDispenseKey = "eSOAPMaxSoapDispense";

        Dictionary<string, string> ThresholdValues = SerializationHelper.JsonDeserialize<Dictionary<string, string>>(CommonHelper.GetConfigSetting("ThresholdValues"));

        const int MAX_POSSIBLE_BATTERY_VOLTAGE = 582;
        const int MIN_POSSIBLE_BATTERY_VOLTAGE = 427;
        int S1Threshold = 0;
        decimal S2Threshold = 0;
        //int S4Threshold = 0;
        int MaxSoapDispenses = 0;

        int LowRandomNumber { get { return Convert.ToInt32(CommonHelper.GetConfigSetting("LowRandomNumber")); } }
        int HighRandomNumber { get { return Convert.ToInt32(CommonHelper.GetConfigSetting("HighRandomNumber")); } }

        public string DeviceId
        {
            get { return _deviceId; }
            set { _deviceId = value; }
        }

        public bool HasAlert
        {
            get { return _hasAlert; }
            set { _hasAlert = value; }
        }

        public eSoapSimulator(string devicePrmData, string deviceId)
        {
            _deviceId = deviceId;
            _hasAlert = false;
            eSoapPrms = SerializationHelper.Deserialize<eSoapParameters>(devicePrmData);
            SetThresholdValues();
        }

        public eSoapSimulator(string deviceId)
        {
            _deviceId = deviceId;
            _hasAlert = false;
            eSoapPrms = new eSoapParameters();
            SetThresholdValues();
        }

        private void SetThresholdValues()
        {
            Guard.IsNotNull(ThresholdValues[S1LowSoapKey], "Threshold Value for Low Soap of eSoap device type");
            Guard.IsNotBlank(ThresholdValues[S1LowSoapKey], "Threshold Value for Low Soap of eSoap device type");
            Guard.IsNotNull(ThresholdValues[S2LowBatteryKey], "Threshold Value for Low Battery of eSoap device type");
            Guard.IsNotBlank(ThresholdValues[S2LowBatteryKey], "Threshold Value for Low Battery of eSoap device type");
            Guard.IsNotNull(ThresholdValues[S4VeryLowSoapKey], "Threshold Value for Very Low Soap of eSoap device type");
            Guard.IsNotBlank(ThresholdValues[S4VeryLowSoapKey], "Threshold Value for Very Low Soap of eSoap device type");
            Guard.IsNotNull(ThresholdValues[MaxSoapDispenseKey], "Maximum Value for soap dispense of eSoap device type");
            Guard.IsNotBlank(ThresholdValues[MaxSoapDispenseKey], "Maximum Value for soap dispense of eSoap device type");
            S1Threshold = Convert.ToInt32(ThresholdValues[S1LowSoapKey].ToString());
            S2Threshold = Convert.ToDecimal(ThresholdValues[S2LowBatteryKey].ToString());
            //S4Threshold = Convert.ToInt32(ThresholdValues[S4VeryLowSoapKey].ToString());
            MaxSoapDispenses = Convert.ToInt32(ThresholdValues[MaxSoapDispenseKey].ToString());
        }

        public void SimulateInitialDeviceData(DeviceSimulator dsEntity)
        {
            eSoapPrms.SoftwareVersion = 101M;
            eSoapPrms.Shot = 'S';
            eSoapPrms.Range = 'S';
            eSoapPrms.RefillSize = 'S';
            eSoapPrms.CleanModeSinceBatteryChange = 0;
            eSoapPrms.TotalDispenseSinceConstruction = 0;
            eSoapPrms.DispenseDuringLastBattery = 0;
            eSoapPrms.DispenseSinceLastBatteryChange = 0;
            eSoapPrms.NumberOfBatteryChanges = 0;
            eSoapPrms.VoltageAtLastBatteryChange = 0;
            eSoapPrms.CurrentBatteryVoltage = MAX_POSSIBLE_BATTERY_VOLTAGE;
            eSoapPrms.TotalRefillsSinceConstruction = 0;
            eSoapPrms.RefillsduringLastBattery = 0;
            eSoapPrms.RefillsSinceBatteryChange = 0;
            eSoapPrms.NoOfDispensesSinceLastRefill = 0;

            // New Parameters
            eSoapPrms.UpdateInterval = 2;
            eSoapPrms.Reset = false;

        }

        public void SimulateDeviceData(DeviceSimulator dsEntity, List<string> FixAlertCodes)
        {
            //Update eSoap parameters by that much %       
            int randomValDispense = CommonHelper.GetRandomNumber(LowRandomNumber, HighRandomNumber);
            eSoapPrms.TotalDispenseSinceConstruction = (eSoapPrms.NoOfDispensesSinceLastRefill == MaxSoapDispenses) ? eSoapPrms.TotalDispenseSinceConstruction : eSoapPrms.TotalDispenseSinceConstruction + randomValDispense;
            eSoapPrms.NoOfDispensesSinceLastRefill = eSoapPrms.NoOfDispensesSinceLastRefill + randomValDispense;
            eSoapPrms.NoOfDispensesSinceLastRefill = (eSoapPrms.NoOfDispensesSinceLastRefill > MaxSoapDispenses) ? MaxSoapDispenses : eSoapPrms.NoOfDispensesSinceLastRefill;
            eSoapPrms.DispenseSinceLastBatteryChange = (eSoapPrms.NoOfDispensesSinceLastRefill == MaxSoapDispenses) ? eSoapPrms.DispenseSinceLastBatteryChange : eSoapPrms.DispenseSinceLastBatteryChange + CommonHelper.GetRandomNumber(LowRandomNumber, HighRandomNumber);
            eSoapPrms.CurrentBatteryVoltage = (int)(eSoapPrms.CurrentBatteryVoltage - ((MAX_POSSIBLE_BATTERY_VOLTAGE - MIN_POSSIBLE_BATTERY_VOLTAGE) * (CommonHelper.GetRandomNumber(LowRandomNumber, HighRandomNumber) / 100.0M)));
            eSoapPrms.CurrentBatteryVoltage = (eSoapPrms.CurrentBatteryVoltage <= MIN_POSSIBLE_BATTERY_VOLTAGE) ? MIN_POSSIBLE_BATTERY_VOLTAGE : eSoapPrms.CurrentBatteryVoltage;
            UpdateDeviceAlertParameters(FixAlertCodes);
        }

        public string CreateAPIRequestBody(DeviceSimulator dsEntity)
        {
            return dsEntity.DeviceID + "," + eSoapPrms.SoftwareVersion + "," + eSoapPrms.Shot + "," + eSoapPrms.Range + "," + eSoapPrms.RefillSize + "," +
                eSoapPrms.CleanModeSinceBatteryChange + "," + eSoapPrms.TotalDispenseSinceConstruction + "," + eSoapPrms.DispenseDuringLastBattery + "," +
                eSoapPrms.DispenseSinceLastBatteryChange + "," + eSoapPrms.NumberOfBatteryChanges + "," + eSoapPrms.VoltageAtLastBatteryChange + "," +
                (int) eSoapPrms.CurrentBatteryVoltage + "," + (eSoapPrms.LowSoapAlert ? 1 : 0) + "," + (eSoapPrms.LowBatteryAlert ? 1 : 0) + "," + 0 + "," +
                eSoapPrms.TotalRefillsSinceConstruction + "," + eSoapPrms.RefillsduringLastBattery + "," + eSoapPrms.RefillsSinceBatteryChange + "," +
                eSoapPrms.NoOfDispensesSinceLastRefill + "," + eSoapPrms.UpdateInterval + "," +(eSoapPrms.Reset ? 1 : 0) ;
               
        }

        public string GetJSONDeviceParameters()
        {
            return SerializationHelper.JsonSerialize(eSoapPrms);
        }

        public void SetRaisedAlerts(DeviceSimulator dsEntity)
        {
            if (eSoapPrms.LowSoapAlert)
            {
                AlertSimulator alert = new AlertSimulator();
                alert.AlertCode = "S1";
                dsEntity.Alerts.Add(alert);
            }
            if (eSoapPrms.LowBatteryAlert)
            {
                AlertSimulator alert = new AlertSimulator();
                alert.AlertCode = "S2";
                dsEntity.Alerts.Add(alert);
            }
            //if (eSoapPrms.VeryLowSoapAlert)
            //{
            //    AlertSimulator alert = new AlertSimulator();
            //    alert.AlertCode = "S4";
            //    dsEntity.Alerts.Add(alert);
            //}
            }

        private void UpdateDeviceAlertParameters(List<string> alertCodes)
        {
            if (alertCodes != null)
            {
                //Low soap alert
                if (eSoapPrms.NoOfDispensesSinceLastRefill >= S1Threshold && alertCodes.Contains("S1"))
                {
                    eSoapPrms.NoOfDispensesSinceLastRefill = 0;
                    eSoapPrms.TotalRefillsSinceConstruction++;
                    eSoapPrms.RefillsSinceBatteryChange++;
                    eSoapPrms.LowSoapAlert = false;
                    //eSoapPrms.VeryLowSoapAlert = false;
                    this.HasAlert = false;
                }
                //Low battery alert
                if (eSoapPrms.CurrentBatteryVoltage <= S2Threshold && alertCodes.Contains("S2"))
                {
                    eSoapPrms.DispenseDuringLastBattery = eSoapPrms.DispenseSinceLastBatteryChange;
                    eSoapPrms.DispenseSinceLastBatteryChange = 0;
                    eSoapPrms.NumberOfBatteryChanges++;
                    eSoapPrms.VoltageAtLastBatteryChange = eSoapPrms.CurrentBatteryVoltage;
                    eSoapPrms.CurrentBatteryVoltage = MAX_POSSIBLE_BATTERY_VOLTAGE;
                    eSoapPrms.RefillsduringLastBattery = eSoapPrms.RefillsSinceBatteryChange;
                    eSoapPrms.RefillsSinceBatteryChange = 0;
                    eSoapPrms.LowBatteryAlert = false;
                    this.HasAlert = false;
                }
                //Very Low Soap Alert
                //if (eSoapPrms.NoOfDispensesSinceLastRefill >= S4Threshold && alertCodes.Contains("S4"))
                //{
                //    eSoapPrms.TotalDispenseSinceConstruction = eSoapPrms.TotalDispenseSinceConstruction + eSoapPrms.NoOfDispensesSinceLastRefill;
                //    eSoapPrms.NoOfDispensesSinceLastRefill = 0;
                //    eSoapPrms.TotalRefillsSinceConstruction++;
                //    eSoapPrms.RefillsSinceBatteryChange++;
                //    eSoapPrms.LowSoapAlert = false;
                //    //eSoapPrms.VeryLowSoapAlert = false;
                //    this.HasAlert = false;
                //}
            }
            if (eSoapPrms.NoOfDispensesSinceLastRefill >= S1Threshold)
            {
                eSoapPrms.LowSoapAlert = true;
                this.HasAlert = true;
            }
            if (eSoapPrms.CurrentBatteryVoltage <= S2Threshold)
            {
                eSoapPrms.LowBatteryAlert = true;
                this.HasAlert = true;
            }
            //if (eSoapPrms.NoOfDispensesSinceLastRefill >= S4Threshold)
            //{
            //    //eSoapPrms.VeryLowSoapAlert = true;
            //    this.HasAlert = true;
            //}
        }
    }
}
