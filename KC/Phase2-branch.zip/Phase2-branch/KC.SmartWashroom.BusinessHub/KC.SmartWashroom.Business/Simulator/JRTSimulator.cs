﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.Simulator;
using KC.SmartWashroom.Core.Helper;
using System;
using System.Collections.Generic;
using System.Configuration;

namespace KC.SmartWashroom.Business.Simulator
{
    class JRTSimulator : IDeviceSimulator
    {
        JRTParameters jrtPrms;
        string _deviceId;
        bool _hasAlert;
        private const string J1LowBatteryKey = "J1LowBatteryThreshold";
        private const string J3LowPaperKey = "J3LowPaperThreshold";

        Dictionary<string, string> ThresholdValues = SerializationHelper.JsonDeserialize<Dictionary<string, string>>(CommonHelper.GetConfigSetting("ThresholdValues"));

        decimal J1Threshold = 0;
        int J3Threshold = 0;
        const int MAX_POSSIBLE_BATTERY_VOLTAGE = 755;
        const int MIN_POSSIBLE_BATTERY_VOLTAGE = 554;

        int LowRandomNumber { get { return Convert.ToInt32(CommonHelper.GetConfigSetting("LowRandomNumber")); } }
        int HighRandomNumber { get { return Convert.ToInt32(CommonHelper.GetConfigSetting("HighRandomNumber")); } }

        public string DeviceId
        {
            get { return _deviceId; }
            set { _deviceId = value; }
        }

        public bool HasAlert
        {
            get { return _hasAlert; }
            set { _hasAlert = value; }
        }

        public JRTSimulator(string devicePrmData, string deviceId)
        {
            _deviceId = deviceId;
            _hasAlert = false;
            jrtPrms = SerializationHelper.Deserialize<JRTParameters>(devicePrmData);
            SetThresholdValues();
        }

        public JRTSimulator(string deviceId)
        {
            _deviceId = deviceId;
            _hasAlert = false;
            jrtPrms = new JRTParameters();
            SetThresholdValues();
        }

        private void SetThresholdValues()
        {
            Guard.IsNotNull(ThresholdValues[J1LowBatteryKey], "Threshold Value for Low Battery of jrt device type");
            Guard.IsNotBlank(ThresholdValues[J1LowBatteryKey], "Threshold Value for Low Battery of jrt device type");
            Guard.IsNotNull(ThresholdValues[J3LowPaperKey], "Threshold Value for Low Paper of jrt device type");
            Guard.IsNotBlank(ThresholdValues[J3LowPaperKey], "Threshold Value for Low Paper of jrt device type");
            J1Threshold = Convert.ToDecimal(ThresholdValues[J1LowBatteryKey].ToString());
            J3Threshold = Convert.ToInt32(ThresholdValues[J3LowPaperKey].ToString());
        }

        public void SimulateInitialDeviceData(DeviceSimulator dsEntity)
        {
            jrtPrms.SoftwareVersion = 101;
            jrtPrms.BatteryVoltage = MAX_POSSIBLE_BATTERY_VOLTAGE;
            jrtPrms.PaperRollRemainingPercent = 100;
            jrtPrms.TotalRollsDispensed = 0;
        }

        public void SimulateDeviceData(DeviceSimulator dsEntity, List<string> FixAlertCodes)
        {
            //Update JRT parameters by that much %
            jrtPrms.BatteryVoltage = (int)(jrtPrms.BatteryVoltage - ((MAX_POSSIBLE_BATTERY_VOLTAGE - MIN_POSSIBLE_BATTERY_VOLTAGE) * (CommonHelper.GetRandomNumber(LowRandomNumber, HighRandomNumber) / 100.0M)));
            jrtPrms.BatteryVoltage = (jrtPrms.BatteryVoltage <= MIN_POSSIBLE_BATTERY_VOLTAGE) ? MIN_POSSIBLE_BATTERY_VOLTAGE : jrtPrms.BatteryVoltage;
            jrtPrms.PaperRollRemainingPercent = jrtPrms.PaperRollRemainingPercent - CommonHelper.GetRandomNumber(LowRandomNumber, HighRandomNumber);
            jrtPrms.PaperRollRemainingPercent = (jrtPrms.PaperRollRemainingPercent <= 0) ? 0 : jrtPrms.PaperRollRemainingPercent;
            //jrtPrms.TotalRollsDispensed = (jrtPrms.PaperRollRemainingPercent == 0) ? jrtPrms.TotalRollsDispensed : jrtPrms.TotalRollsDispensed + CommonHelper.GetRandomNumber(LowRandomNumber, HighRandomNumber);
            UpdateDeviceAlertParameters(FixAlertCodes);
        }

        public string CreateAPIRequestBody(DeviceSimulator dsEntity)
        {
            return dsEntity.DeviceID + "," + jrtPrms.SoftwareVersion + "," + (int)jrtPrms.BatteryVoltage + "," + jrtPrms.PaperRollRemainingPercent + "," +
                (jrtPrms.LowBatteryAlert ? "1" : "0") + "," + 0 + "," + (jrtPrms.LowPaperAlert ? "1" : "0") + "," + 0 + "," +
                jrtPrms.TotalRollsDispensed + "," + jrtPrms.UpdateIntervalInMinutes + "," + (jrtPrms.Reset ? "1" : "0");
        }

        public string GetJSONDeviceParameters()
        {
            return SerializationHelper.JsonSerialize(jrtPrms);
        }

        public void SetRaisedAlerts(DeviceSimulator dsEntity)
        {
            if (jrtPrms.LowBatteryAlert)
            {
                AlertSimulator alert = new AlertSimulator();
                alert.AlertCode = "J1";
                dsEntity.Alerts.Add(alert);
            }
            if (jrtPrms.LowPaperAlert)
            {
                AlertSimulator alert = new AlertSimulator();
                alert.AlertCode = "J3";
                dsEntity.Alerts.Add(alert);
            }

        }

        private void UpdateDeviceAlertParameters(List<string> alertCodes)
        {
            if (alertCodes != null)
            {
                //Low battery alert
                if (jrtPrms.BatteryVoltage <= J1Threshold && alertCodes.Contains("J1"))
                {
                    jrtPrms.BatteryVoltage = MAX_POSSIBLE_BATTERY_VOLTAGE;
                    jrtPrms.LowBatteryAlert = false;
                    this.HasAlert = false;
                }
                //Low paper alert
                if (jrtPrms.PaperRollRemainingPercent <= J3Threshold && alertCodes.Contains("J3"))
                {
                    jrtPrms.PaperRollRemainingPercent = 100;
                    jrtPrms.TotalRollsDispensed++;
                    jrtPrms.LowPaperAlert = false;
                    this.HasAlert = false;
                }
            }
            if (jrtPrms.BatteryVoltage <= J1Threshold)
            {
                jrtPrms.LowBatteryAlert = true;
                this.HasAlert = true;
            }
            if (jrtPrms.PaperRollRemainingPercent <= J3Threshold)
            {
                jrtPrms.LowPaperAlert = true;
                this.HasAlert = true;
            }
        }
    }
}
