﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
using KC.SmartWashroom.BusinessEntities.BusinessHubEntities;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.DependencyInjector;
using KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers;
using KC.SmartWashroom.DataAccess.Skeleton;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.Business
{
    public class RecentUpdatesManager : BusinessManagerBase<IRecentUpdatesWorker>
    {
        public void ManualInjection<T>()
        {
            this.dataWorker = (IRecentUpdatesWorker)Injector.Resolve<T>();
        }

        public List<DeviceAlertsResolutionDetail> FetchDeviceAlertsForBuildingWithResolution(int propertyId, int buildingId, int floorId, int washroomId)
        {
            //REtrive device related details from device manager..
            DeviceBusinessManager deviceManager = new DeviceBusinessManager();

            List<DeviceResolutionDetail> devices = deviceManager.FetchDevicesForBuilding(propertyId, buildingId, floorId, washroomId);

            buildingId = floorId > 0 ? 0 : buildingId;
            floorId = washroomId > 0 ? 0 : floorId;

            var top5For30DaysWithPartition = new SearchCriteria()
            {
                ToDate = DateTime.UtcNow.Date,
                FromDate = DateTime.UtcNow.Date.AddMonths(-1),
                PropertyId = propertyId,
                BuildingList = buildingId>0? new List<int>() { buildingId }:null,
                FloorId = floorId,
                
                WashroomList = washroomId > 0 ? new List<int>() { washroomId }:null
            };

            var deviceAlerts = this.dataWorker.FetchDeviceAlertsWithResolution(devices, CommonConstants.RECENTUPDATES_ALERTS_COUNT, top5For30DaysWithPartition);

            return deviceAlerts;
        }
        public List<DeviceAlertsResolutionDetail> SearchActivities(SearchCriteria criteria)
        {
            return this.dataWorker.GetDeviceAlertResolution(criteria);
        }

        public ActivityResult FetchAllActivities(int customerId, int userId, int noOfRecentAlerts, int roleLevel)
        {
            int buildingId = 0;
            ActivityResult activityResult = new ActivityResult();
            List<DeviceAlertsResolutionDetail> AlertResoltions = new List<DeviceAlertsResolutionDetail>();
            //Retrive device related details from device manager..
            DeviceBusinessManager deviceManager = new DeviceBusinessManager();
            //Building Id 0 for fetching all the devices
            List<DeviceResolutionDetail> devices = deviceManager.FetchDevicesForUser(userId, roleLevel, customerId, buildingId);
            activityResult = this.dataWorker.FetchAllActivities(devices, noOfRecentAlerts);
            AuditLog(userId, KC.SmartWashroom.Core.Enumerations.Enums.AuditActivity.GetAllActivities);
            return activityResult;
        }
        public ActivityResult FetchActivitiesLastDay(int customerId, int userId, int roleLevel)
        {
            int buildingId = 0;
            ActivityResult activityResult = new ActivityResult();
            List<DeviceAlertsResolutionDetail> AlertResoltions = new List<DeviceAlertsResolutionDetail>();
            //Retrive device related details from device manager..
            DeviceBusinessManager deviceManager = new DeviceBusinessManager();
            //Building Id 0 for fetching all the devices
            List<DeviceResolutionDetail> devices = deviceManager.FetchDevicesForUser(userId, roleLevel, customerId, buildingId);
            activityResult = this.dataWorker.FetchActivitiesLastDay(devices);
            AuditLog(userId, KC.SmartWashroom.Core.Enumerations.Enums.AuditActivity.GetAllActivities);
            return activityResult;
        }

        public ActivityResult FetchAllActivitiesWithFilter(int customerId, int userId, string alertTypeCode, DateTime fromDate, DateTime toDate, int propertyId, int buildingId, int floorId, byte deviceTypeId, byte roomTypeId, int noOfRecentAlerts, int roleLevel)
        {
            ActivityResult activityResult = new ActivityResult();
            List<DeviceAlertsResolutionDetail> AlertResoltions = new List<DeviceAlertsResolutionDetail>();
            //Retrive device related details from device manager..
            DeviceBusinessManager deviceManager = new DeviceBusinessManager();
            List<DeviceResolutionDetail> devices = deviceManager.FetchDevicesForUser(userId, roleLevel, customerId, buildingId);
            activityResult = this.dataWorker.FetchAllActivitiesWithFilter(devices, alertTypeCode, fromDate, toDate, propertyId, floorId, deviceTypeId, roomTypeId, noOfRecentAlerts);
            AuditLog(userId, KC.SmartWashroom.Core.Enumerations.Enums.AuditActivity.GetFilteredActivities);
            return activityResult;
        }

        private void AuditLog(int userId, KC.SmartWashroom.Core.Enumerations.Enums.AuditActivity audit)
        {
            AuditInformation.AuditActivityType = audit;
            AuditInformation.PerformedBy = userId.ToString();
            TraceAuditInformation();
        }
    }
}
