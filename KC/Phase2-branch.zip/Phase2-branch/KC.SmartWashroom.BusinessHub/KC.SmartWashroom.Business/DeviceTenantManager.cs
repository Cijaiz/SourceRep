﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.TenantApiEntities;
using KC.SmartWashroom.Core.Enumerations;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.DataAccess.Skeleton;
using System.Collections.Generic;

namespace KC.SmartWashroom.Business
{
    public class DeviceTenantManager : BusinessManagerBase<IDeviceTenantWorker>
    {
        public string ErrorDetail { get; private set; }

        public ProcessResponse<Device> Create(Device device)
        {
            Guard.IsNotNull(device, "Device");
            ProcessResponse<Device> response = new ProcessResponse<Device>();
            SaveActivityInLog(Enums.AuditActivity.CreateDevice, device.UserId, Enums.ActivityLogNames.DeviceName, device.Name);
            response= this.dataWorker.Create(device);
            if (response.Status == ResponseStatus.Success)
                SaveDeviceToQueueForCache(device.ID);
            return response;
        }

        public ProcessResponse<Device> Update(Device device)
        {
            Guard.IsNotNull(device, "Device");
            SaveActivityInLog(Enums.AuditActivity.EditDevice, device.UserId, Enums.ActivityLogNames.DeviceName, device.Name);
            ProcessResponse<Device> response = new ProcessResponse<Device>();
            response=this.dataWorker.Update(device);
            if (response.Status == ResponseStatus.Success)
                SaveDeviceToQueueForCache(device.ID);
            return response;
        }

        public Device GetDevice(string deviceId, int userId)
        {
            Guard.IsNotNull(deviceId, "DeviceId");
            SaveActivityInLog(Enums.AuditActivity.ViewDevice, userId, Enums.ActivityLogNames.DeviceId, deviceId.ToString());
            Device device = new Device();
            device = this.dataWorker.GetDevice(deviceId);
            if (device.Equals(null))
                ErrorDetail = this.dataWorker.ErrorDetail;

            return device;
        }

        public ReturnParameterResponse RetriveReturnParametersForDevice(string deviceId, int customerId)
        {
            //retrive the customer level overrides
            CustomerBusinessManager manager = new CustomerBusinessManager();
            List<DeviceParameterValueEntity> customerParameterValues = manager.GetCustermerLevelDeviceParameterValue(customerId);

            return this.dataWorker.RetriveReturnParametersForDevice(deviceId, customerId, customerParameterValues);
        }

        public ProcessResponse Delete(string deviceId, int userId)
        {
            Guard.IsNotNull(deviceId, "DeviceId");
            SaveActivityInLog(Enums.AuditActivity.DeleteDevice, userId, Enums.ActivityLogNames.DeviceId, deviceId.ToString());
            DeviceBusinessManager deviceBM = new DeviceBusinessManager();
            //Get the customer Id from the deviceid
            DeviceAssociation da = new DeviceAssociation();
            da = deviceBM.GetDeviceAssociation(deviceId);
            ProcessResponse response = this.dataWorker.Delete(deviceId);
            //Delete DeviceStatus and AlertStatus storage table data

            deviceBM.DeleteDeviceStatus(deviceId, da.CustomerId);
            deviceBM.DeleteAlertStatus(deviceId, da.CustomerId);

            if (response.Status == ResponseStatus.Success)
                SaveDeviceToQueueForCache(deviceId);

            return response;
        }

        public List<DeviceTypes> GetDeviceTypes()
        {
            List<DeviceTypes> deviceTypes = new List<DeviceTypes>();
            deviceTypes = this.dataWorker.GetDeviceTypes();
            if (deviceTypes.Equals(null))
                ErrorDetail = this.dataWorker.ErrorDetail;
            return deviceTypes;
        }

        public DeviceTypes GetDeviceTypesFromCache(string deviceType)
        {
            return this.dataWorker.GetDeviceTypesFromCache(deviceType);
        }
        public bool SaveToDeviceTypesCache()
        {
           return this.dataWorker.SaveToDeviceTypesCache();
        }


        public List<RefillSize> GetRefillSize()
        {
            List<RefillSize> refillSize = new List<RefillSize>();
            refillSize = this.dataWorker.GetRefillSize();
            if (refillSize.Equals(null))
                ErrorDetail = this.dataWorker.ErrorDetail;
            return refillSize;
        }

        public Names GetNames(int washroomId)
        {
            Guard.IsNotNull(washroomId, "washroomId");
            return this.dataWorker.GetNames(washroomId);
        }

        private void SaveActivityInLog(Enums.AuditActivity activity, int userId, Enums.ActivityLogNames activityName, string Name)
        {
            base.AddParametersToAuditInformation(activityName.ToString(), Name);
            base.BuildAuditInfo();

            base.AuditInformation.AuditActivityType = activity;
            base.AuditInformation.PerformedBy = userId.ToString();
            base.AuditInformation.AuditInfo = base.FinalAuditInformation;
            base.TraceAuditInformation();
        }

        public ProcessResponse DeleteDeviceParameterValues(string deviceId, ReturnParameterDataTransfer dataTransfer)
        {
            Guard.IsNotNull(dataTransfer, "DeviceParameter");
            // SaveActivityInLog(Enums.AuditActivity.DeleteDevice, dataTransfer.customerId, Enums.ActivityLogNames.DeviceId,deviceId.ToString());
            ProcessResponse response = this.dataWorker.DeleteDeviceParameterValues(deviceId, dataTransfer);
            return response;
        }

        public ProcessResponse<List<ReturnValueParameter>> DeviceUpsetReturnParameters(string deviceId, List<ReturnParameterResponse> returnValueParameters, int customerId)
        {
            return this.dataWorker.DeviceUpsetReturnParameters(deviceId, returnValueParameters, customerId);
        }

        public List<BusinessEntities.SearchDeviceDetailsEntity> GetDeviceDetails(string DeviceId)
        {
            Guard.IsNotNull(DeviceId, "DeviceId");
            return this.dataWorker.GetDeviceDetails(DeviceId);
        }

        private void SaveDeviceToQueueForCache(string deviceId)
        {
             DeviceBusinessManager deviceBM = new DeviceBusinessManager();
             deviceBM.SaveDeviceToQueueForCache(deviceId, false);
        }
    }
}
