﻿
namespace KC.SmartWashroom.Business
{
    using KC.SmartWashroom.BusinessEntities;
    using KC.SmartWashroom.BusinessEntities.BusinessHubEntities;
    using KC.SmartWashroom.Core.Constants;
    using KC.SmartWashroom.Core.DependencyInjector;
    using KC.SmartWashroom.Core.Helper;
    using KC.SmartWashroom.Core.Log;
    using KC.SmartWashroom.Core.NotificationUtility;
    using Microsoft.Practices.Unity;
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Text;

    public class BusinessManagerBase<T>
    {
        private AuditBusinessManager auditManager = null;

        [Dependency]
        internal T dataWorker { get; set; }
        protected Audit AuditInformation { get; set; }
         
        public BusinessManagerBase()
        {
            BusinessHubUrl = CommonHelper.GetConfigSetting(AlertEngineConstants.BUSINESS_HUB_URL);
            
            this.dataWorker = Injector.Resolve<T>();

            if (this.AuditInformation == null)
                this.AuditInformation = new Audit();
        }

        #region Rest Client Configuration
        private readonly string BusinessHubUrl;
       
        private WebClient webClient;
        
          

        private static string APIUserName = string.Empty;
        private static string APIPassword = string.Empty;
        private static Dictionary<string, string> validHubCredentials;

        public string FinalBusinessHubUrl { get; private set; }
        public string FinalAuditInformation { get; private set; }

        protected List<KeyValuePair<string, object>> QueryParameters;
        protected List<KeyValuePair<string, object>> AuditInfoParameters;
        protected string HubSerializedResponse = string.Empty;
        protected dynamic inputdata = string.Empty;

        protected void BuildBusinessHubUrl(string controllerName, string ActionName)
        {
            StringBuilder queryStringBuilder = new StringBuilder();
            if (this.QueryParameters != null)
            {
                foreach (KeyValuePair<string, object> keyvalue in this.QueryParameters)
                {
                    queryStringBuilder.Append(keyvalue.Key);
                    queryStringBuilder.Append("=");
                    queryStringBuilder.Append(keyvalue.Value);
                    queryStringBuilder.Append("&");
                }
                queryStringBuilder.Remove(queryStringBuilder.Length - 1, 1);
            }

            if (queryStringBuilder.Length > 0)
                this.FinalBusinessHubUrl = string.Format("{0}{1}/{2}?{3}", BusinessHubUrl, controllerName, ActionName, queryStringBuilder.ToString());
            else
                this.FinalBusinessHubUrl = string.Format("{0}{1}/{2}", BusinessHubUrl, controllerName, ActionName);
        }

        protected void BuildAuditInfo()
        {
            StringBuilder queryStringBuilder = new StringBuilder();
            if (this.AuditInfoParameters != null)
            {
                foreach (KeyValuePair<string, object> keyvalue in this.AuditInfoParameters)
                {
                    queryStringBuilder.Append(keyvalue.Key);
                    queryStringBuilder.Append(":");
                    queryStringBuilder.Append(keyvalue.Value);
                    queryStringBuilder.Append(" ");
                }
                queryStringBuilder.Remove(queryStringBuilder.Length - 1, 1);
            }

            if (queryStringBuilder.Length > 0)
                this.FinalAuditInformation = queryStringBuilder.ToString();
            else
                this.FinalAuditInformation = null;
        }
        protected void PerformBusinessHUbRestCall()
        {
            Guard.IsNotNull(this.FinalBusinessHubUrl, "Hub URL");

            HubSerializedResponse = RestWebClient.SafeWebClientProcessing(this.FinalBusinessHubUrl);
        }

        protected void ResetQueryParameters()
        {
            this.QueryParameters = null;
        }

        private static bool LoadHubCredentials()
        {
            bool isCredentialsLoaded = true;

            if (validHubCredentials == null)
            {
                try
                {
                    validHubCredentials = new Dictionary<string, string>();

                    string serializedHubCredentials = CommonHelper.GetConfigSetting(CommonConstants.AUTHENTICATIONCREDENTIALS);
                    validHubCredentials = SerializationHelper.JsonDeserialize<Dictionary<string, string>>(serializedHubCredentials);

                    if (validHubCredentials != null && validHubCredentials.Count > 1)
                    {
                        if (!validHubCredentials.TryGetValue(CommonConstants.HUB_USERNAME, out APIUserName))
                            throw new InvalidOperationException("Unable to Set Hub APIUserName Credentials From the Configurations...");

                        if (!validHubCredentials.TryGetValue(CommonConstants.HUB_USERPASSWORD, out APIPassword))
                            throw new InvalidOperationException("Unable to Set Hub APIPassword Credentials From the Configurations...");
                    }
                }
                catch (Exception credentialException)
                {
                    Logger.Error(credentialException.Message);
                    isCredentialsLoaded = false;
                }
            }
            return isCredentialsLoaded;
        }

        public WebClient RestWebClient
        {
            get
            {
                if (webClient == null)
                {
                    webClient = new WebClient();

                    if (!LoadHubCredentials())
                        throw new InvalidOperationException("Unable to Load Hub Credentials From the Configurations...");

                    //Set Authentication / Authorization Headers..
                    SetAuthenticationHeaderToken();
                }

                return webClient;
            }
        }

        //Query Parameters added for REST CALL.. & will be added automatically during call.....
        public void AddParametersToWebClientCall(string key, object value)
        {
            if (QueryParameters == null)
                QueryParameters = new List<KeyValuePair<string, object>>();

            QueryParameters.Add(new KeyValuePair<string, object>(key, value));
        }

        public void SetAuthenticationHeaderToken()
        {
            if (!LoadHubCredentials())
                throw new InvalidOperationException("Unable to Load Hub Credentials From the Configurations...");

            Guard.IsNotBlank(APIPassword, "API Password");
            Guard.IsNotBlank(APIUserName, "API UserName");

            if (webClient != null)
                webClient.SetAuthenticationHeaderToken(APIUserName, APIPassword);
        }
        #endregion

        public ProcessResponse TraceAuditInformation()
        {
            Guard.IsNotNull(AuditInformation, "Audit Information");

            if (auditManager == null)
                auditManager = new AuditBusinessManager();

            return auditManager.TraceAuditInformation(AuditInformation);
        }

        public void AddParametersToAuditInformation(string key, object value)
        {
            if (AuditInfoParameters == null)
                AuditInfoParameters = new List<KeyValuePair<string, object>>();

            AuditInfoParameters.Add(new KeyValuePair<string, object>(key, value));
        }

        

      

    }
}
