using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Threading;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.Diagnostics;
using Microsoft.WindowsAzure.ServiceRuntime;
using Microsoft.WindowsAzure.Storage;
using KC.SmartWashroom.Aggregation;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.Core.Log;

namespace KC.SmartWashroom.AggregateWorker
{
    public class WorkerRole : RoleEntryPoint
    {
        public override void Run()
        {
            // This is a sample worker implementation. Replace with your logic.
            Trace.TraceInformation("KC.SmartWashroom.AggregateWorker entry point called");

            TimeSpan start = new TimeSpan(int.Parse(CommonHelper.GetConfigSetting("StartHour")), 0, 0);
            TimeSpan end = new TimeSpan(int.Parse(CommonHelper.GetConfigSetting("EndHour")), 0, 0);
            while (true)
            {
                
                //Trace.TraceInformation("Working");

                //TimeSpan current = DateTime.UtcNow.TimeOfDay;
                //if ((current > start) && (current < end))
                //{
                //ReportAggregation ReportAggregate = new ReportAggregation();

                //ReportAggregate.Aggregation();

                //Thread.Sleep(3600000);
                //}                

                RunAggregationEngine();
                Thread.Sleep(36000);

            }
        }

        public static void RunAggregationEngine()
                {
            Logger.Warning("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<Start the Aggregation Engine Processing>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
                ReportAggregation ReportAggregate = new ReportAggregation();

            ReportAggregate.AggregationEngine();

            //Thread.Sleep(36000);
        }

        public override bool OnStart()
        {
            // Set the maximum number of concurrent connections 
            ServicePointManager.DefaultConnectionLimit = 12;

            // For information on handling configuration changes
            // see the MSDN topic at http://go.microsoft.com/fwlink/?LinkId=166357.

            return base.OnStart();
        }
    }
}
