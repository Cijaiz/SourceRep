﻿using KC.SmartWashroom.Aggregation.Interface;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
using KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers;
using KC.SmartWashroom.DataAccess.DataWorkers.Table_Workers;
using KC.SmartWashroom.DataAccess.Skeleton;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using BusinessEntity = KC.SmartWashroom.BusinessEntities;

namespace KC.SmartWashroom.Aggregation.Implementation
{
    public class SRBAggregate : ISRBAggregate
    {
        public List<UsageMart> ProcessSRB(DateTime date, BusinessEntity.Property Property)
        {
            List<UsageMart> DeviceLogs = new List<UsageMart>();
            List<SRBEntityLog> SRBEntities = new List<SRBEntityLog>();

            //read data from table storage for a particulart customer and partition
            ITableStorageHelper TableStoreHelper = new TableStorageHelper();
            SRBEntities = TableStoreHelper.SRBData(date, Property);

            //get battery resolved alert from the alert logs table for a particular customer
            List<AlertEntity> AlertList = new List<AlertEntity>();
            AlertList = TableStoreHelper.GetBatteryResolvedAlertsForSRB(date, Property);

            //Aggregate eHRT Device Logs
            if (SRBEntities.Count != 0)
                DeviceLogs = AggregateSRBLogs(date, SRBEntities, AlertList);

            return DeviceLogs;
        }


        private static List<UsageMart> AggregateSRBLogs(DateTime date, List<SRBEntityLog> SRBEntities, List<AlertEntity> AlertList)
        {
            List<UsageMart> DeviceLogs = new List<UsageMart>();

            var SRBTemp = (from SRB in SRBEntities
                           group SRB by new
                           {
                               SRB.DeviceId,
                               SRB.CustomerId,
                               SRB.PropertyId,
                               SRB.BuildingId,
                               SRB.FloorId,
                               SRB.FloorLevel,
                               SRB.WashroomId,
                               SRB.DeviceType
                           } into grp
                           let maxof = grp.Max(e => e.TotalRollsDispensed)
                           from SRB in grp
                           where SRB.TotalRollsDispensed == maxof
                           select new
                           {
                               SRB.DeviceId,
                               SRB.CustomerId,
                               SRB.PropertyId,
                               SRB.BuildingId,
                               SRB.FloorId,
                               SRB.FloorLevel,
                               SRB.WashroomId,
                               SRB.DeviceType,
                               SRB.TotalRollsDispensed
                           }).Distinct().ToList();

            var SRBRefill = SRBEntities.GroupBy(g => g.DeviceId)
                .Select(ehrt => new
                {
                    DeviceId = ehrt.First().DeviceId,
                    BatteryRefill = ehrt.Sum(s => s.RefilledBatteryBeforeThreshold),
                    TowelRefill = ehrt.Sum(s1 => s1.RefilledTissueBeforeThreshold)
                }).ToList();

            List<BusinessEntity.Aggregation.DeviceWashroom> DeviceWashroomIds = new List<BusinessEntity.Aggregation.DeviceWashroom>();
            DeviceWashroomIds = (from dl in SRBTemp
                                 select new BusinessEntity.Aggregation.DeviceWashroom { DeviceId = dl.DeviceId, WashroomId = dl.WashroomId.ToString() }).Distinct().ToList();

            //get the devicelogs for previous day
            IAggregationWorker SqlHelper = new AggregationWorker();
            List<UsageMart> DeviceList = new List<UsageMart>();
            DeviceList = SqlHelper.GetAllDeviceForJRTnSRBneSoap(DeviceWashroomIds);
            //DeviceList = SqlHelper.GetAllDevice(DeviceIds, date);

            //aggregate
            DateTimeFormatInfo dfi = DateTimeFormatInfo.CurrentInfo;
            Calendar cal = dfi.Calendar;
            foreach (var SRB in SRBTemp)
            {
                UsageMart deviceEnt = new UsageMart();
                deviceEnt.CustomerId = SRB.CustomerId.ToString();
                deviceEnt.PropertyId = SRB.PropertyId.ToString();
                deviceEnt.BuildingId = SRB.BuildingId.ToString();
                deviceEnt.FloorId = SRB.FloorId.ToString();
                deviceEnt.FloorName = SRB.FloorLevel.ToString();
                deviceEnt.WashRoomId = SRB.WashroomId.ToString();
                deviceEnt.DeviceId = SRB.DeviceId;
                deviceEnt.DeviceType = SRB.DeviceType.ToString();
                deviceEnt.UsageDate = date;
                deviceEnt.UsageDay = date.Day;
                deviceEnt.UsageDayOfWeek = date.ToString("ddd");
                deviceEnt.UsageWeek = cal.GetWeekOfYear(date, dfi.CalendarWeekRule, dfi.FirstDayOfWeek);
                deviceEnt.UsageMonth = date.ToString("MMM");
                deviceEnt.UsageYear = date.Year;
                deviceEnt.TotalUsed = Convert.ToInt32(SRB.TotalRollsDispensed);
                int totalUsedYesterday = (from d in DeviceList
                                          where d != null && d.DeviceId == deviceEnt.DeviceId
                                          select d.TotalUsed).FirstOrDefault();

                //if (totalUsedYesterday != null)
                //{
                if (totalUsedYesterday == 0)
                    deviceEnt.CountOfUsage = Convert.ToInt32(SRB.TotalRollsDispensed);
                else
                    deviceEnt.CountOfUsage = Convert.ToInt32(SRB.TotalRollsDispensed) < totalUsedYesterday ? Convert.ToInt32(SRB.TotalRollsDispensed) : (Convert.ToInt32(SRB.TotalRollsDispensed)) - totalUsedYesterday;
                //}
                //else
                //{
                //    deviceEnt.CountOfUsage = Convert.ToInt32(SRB.TotalRollsDispensed);
                //}

                var batteryChange = (from a in AlertList
                                     where SRB.DeviceId == a.DeviceId & a.IsAlert == 0
                                     select a).ToList();
                if (batteryChange.Count != 0)
                    deviceEnt.CountOfBattery = batteryChange.Count;
                else
                    deviceEnt.CountOfBattery = 0;

                deviceEnt.TotalBatteryChange = 0;
                //deviceEnt.CountOfBattery = 0;
                deviceEnt.TotalPaperTowel = 0;
                deviceEnt.CountOfPaperUsed = 0;
                deviceEnt.DispenserSize = "None";

                var refill = (from re in SRBRefill
                              where re.DeviceId == SRB.DeviceId
                              select re).FirstOrDefault();
                if (refill != null)
                {
                    deviceEnt.BatteryRefillBeforeThres = refill.BatteryRefill;
                    deviceEnt.TowelRefillBeforeThres = refill.TowelRefill;
                }
                else
                {
                    deviceEnt.BatteryRefillBeforeThres = 0;
                    deviceEnt.TowelRefillBeforeThres = 0;
                }

                DeviceLogs.Add(deviceEnt);
            }

            return DeviceLogs;
        }

    }
}
