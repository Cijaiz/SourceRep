﻿using KC.SmartWashroom.Aggregation.Interface;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers;
using KC.SmartWashroom.DataAccess.DataWorkers.Table_Workers;
using KC.SmartWashroom.DataAccess.Skeleton;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using BusinessEntity = KC.SmartWashroom.BusinessEntities;

namespace KC.SmartWashroom.Aggregation.Implementation
{
    public class ESOAPAggregate : IESOAPAggregate
    {
        public List<UsageMart> ProcesseSOAP(DateTime date, BusinessEntities.Property Property)
        {
            List<UsageMart> DeviceLogs = new List<UsageMart>();
            List<eSoapEntityLog> eSoapEntities = new List<eSoapEntityLog>();

            //read data from table storage for a particulart customer and partition
            ITableStorageHelper TableStoreHelper = new TableStorageHelper();
            eSoapEntities = TableStoreHelper.ESOAPData(date, Property);

            //Aggregate eHRT Device Logs
            if (eSoapEntities.Count != 0)
                DeviceLogs = AggregateeSoapLogs(date, eSoapEntities);

            return DeviceLogs;
        }


        private static List<UsageMart> AggregateeSoapLogs(DateTime date, List<eSoapEntityLog> eSoapEntities)
        {
            List<UsageMart> DeviceLogs = new List<UsageMart>();

            var eSoapTemp = (from eSoap in eSoapEntities
                             group eSoap by new
                             {
                                 eSoap.DeviceId,
                                 eSoap.CustomerId,
                                 eSoap.PropertyId,
                                 eSoap.BuildingId,
                                 eSoap.FloorId,
                                 eSoap.FloorLevel,
                                 eSoap.WashroomId,
                                 eSoap.DeviceType
                                 //,eSoap.RefillSize
                             } into grp
                             let maxof = grp.Max(e => e.TotalRefillsSinceConstruction)
                             from eSoap in grp
                             where eSoap.TotalRefillsSinceConstruction == maxof
                             group eSoap by new
                             {
                                 eSoap.DeviceId,
                                 eSoap.CustomerId,
                                 eSoap.PropertyId,
                                 eSoap.BuildingId,
                                 eSoap.FloorId,
                                 eSoap.FloorLevel,
                                 eSoap.WashroomId,
                                 eSoap.DeviceType
                             } into grp1
                             let maxBattery = grp1.Max(b => b.NumberOfBatteryChanges)
                             from esoap1 in grp1
                             where esoap1.NumberOfBatteryChanges == maxBattery
                             select new
                             {
                                 esoap1.DeviceId,
                                 esoap1.CustomerId,
                                 esoap1.PropertyId,
                                 esoap1.BuildingId,
                                 esoap1.FloorId,
                                 esoap1.FloorLevel,
                                 esoap1.WashroomId,
                                 esoap1.DeviceType,
                                 esoap1.TotalRefillsSinceConstruction,
                                 esoap1.RefillSize,
                                 esoap1.NumberOfBatteryChanges
                             }).Distinct().ToList();

            var eSoapRefill = eSoapEntities.GroupBy(g => g.DeviceId)
                .Select(ehrt => new
                {
                    DeviceId = ehrt.First().DeviceId,
                    BatteryRefill = ehrt.Sum(s => s.RefilledBatteryBeforeThreshold),
                    TowelRefill = ehrt.Sum(s1 => s1.RefilledSoapBeforeThreshold)
                }).ToList();

            List<BusinessEntity.Aggregation.DeviceWashroom> DeviceWashroomIds = new List<BusinessEntity.Aggregation.DeviceWashroom>();
            DeviceWashroomIds = (from dl in eSoapTemp
                                 select new BusinessEntity.Aggregation.DeviceWashroom { DeviceId = dl.DeviceId, WashroomId = dl.WashroomId.ToString() }).Distinct().ToList();

            //get the devicelogs for previous day
            IAggregationWorker SqlHelper = new AggregationWorker();
            List<UsageMart> DeviceList = new List<UsageMart>();
            DeviceList = SqlHelper.GetAllDeviceForJRTnSRBneSoap(DeviceWashroomIds);
            //DeviceList = SqlHelper.GetAllDevice(DeviceIds, date);

            //aggregate
            DateTimeFormatInfo dfi = DateTimeFormatInfo.CurrentInfo;
            Calendar cal = dfi.Calendar;
            foreach (var eSoap in eSoapTemp)
            {
                UsageMart deviceEnt = new UsageMart();
                deviceEnt.CustomerId = eSoap.CustomerId.ToString();
                deviceEnt.PropertyId = eSoap.PropertyId.ToString();
                deviceEnt.BuildingId = eSoap.BuildingId.ToString();
                deviceEnt.FloorId = eSoap.FloorId.ToString();
                deviceEnt.FloorName = eSoap.FloorLevel.ToString();
                deviceEnt.WashRoomId = eSoap.WashroomId.ToString();
                deviceEnt.DeviceId = eSoap.DeviceId;
                deviceEnt.DeviceType = eSoap.DeviceType.ToString();
                deviceEnt.UsageDate = date;
                deviceEnt.UsageDay = date.Day;
                deviceEnt.UsageDayOfWeek = date.ToString("ddd");
                deviceEnt.UsageWeek = cal.GetWeekOfYear(date, dfi.CalendarWeekRule, dfi.FirstDayOfWeek);
                deviceEnt.UsageMonth = date.ToString("MMM");
                deviceEnt.UsageYear = date.Year;
                deviceEnt.TotalUsed = Convert.ToInt32(eSoap.TotalRefillsSinceConstruction);
                deviceEnt.TotalBatteryChange = Convert.ToInt32(eSoap.NumberOfBatteryChanges);
                var totalUsedYesterday = (from d in DeviceList
                                          where d != null && d.DeviceId == deviceEnt.DeviceId
                                          select new { d.TotalUsed, d.TotalBatteryChange }).FirstOrDefault();
                if (totalUsedYesterday != null)
                {
                    if (totalUsedYesterday.TotalUsed == 0)
                        deviceEnt.CountOfUsage = Convert.ToInt32(eSoap.TotalRefillsSinceConstruction);
                    else
                        deviceEnt.CountOfUsage = Convert.ToInt32(eSoap.TotalRefillsSinceConstruction) < totalUsedYesterday.TotalUsed ? Convert.ToInt32(eSoap.TotalRefillsSinceConstruction) : (Convert.ToInt32(eSoap.TotalRefillsSinceConstruction)) - totalUsedYesterday.TotalUsed;

                    if (totalUsedYesterday.TotalBatteryChange == 0)
                        deviceEnt.CountOfBattery = Convert.ToInt32(eSoap.NumberOfBatteryChanges);
                    else
                        deviceEnt.CountOfBattery = Convert.ToInt32(eSoap.NumberOfBatteryChanges) < totalUsedYesterday.TotalBatteryChange ? Convert.ToInt32(eSoap.NumberOfBatteryChanges) : (Convert.ToInt32(eSoap.NumberOfBatteryChanges)) - totalUsedYesterday.TotalBatteryChange;
                }
                else
                {
                    deviceEnt.CountOfUsage = Convert.ToInt32(eSoap.TotalRefillsSinceConstruction);
                    deviceEnt.CountOfBattery = Convert.ToInt32(eSoap.NumberOfBatteryChanges);
                }

                deviceEnt.TotalPaperTowel = 0;
                deviceEnt.CountOfPaperUsed = 0;
                deviceEnt.DispenserSize = eSoap.RefillSize;

                var refill = (from re in eSoapRefill
                              where re.DeviceId == eSoap.DeviceId
                              select re).FirstOrDefault();
                if (refill != null)
                {
                    deviceEnt.BatteryRefillBeforeThres = refill.BatteryRefill;
                    deviceEnt.TowelRefillBeforeThres = refill.TowelRefill;
                }
                else
                {
                    deviceEnt.BatteryRefillBeforeThres = 0;
                    deviceEnt.TowelRefillBeforeThres = 0;
                }

                DeviceLogs.Add(deviceEnt);
            }

            return DeviceLogs;
        }

    }
}
