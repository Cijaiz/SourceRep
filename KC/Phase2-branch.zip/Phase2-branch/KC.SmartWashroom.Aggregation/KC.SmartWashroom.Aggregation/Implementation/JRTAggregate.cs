﻿using KC.SmartWashroom.Aggregation.Interface;
using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
using KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers;
using KC.SmartWashroom.DataAccess.DataWorkers.Table_Workers;
using KC.SmartWashroom.DataAccess.Skeleton;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using BusinessEntity = KC.SmartWashroom.BusinessEntities;

namespace KC.SmartWashroom.Aggregation.Implementation
{
    public class JRTAggregate : IJRTAggregate
    {
        public List<UsageMart> ProcessJRT(DateTime date, BusinessEntity.Property Property)
        {
            List<UsageMart> DeviceLogs = new List<UsageMart>();
            List<JRTEntityLog> JRTEntities = new List<JRTEntityLog>();

            //read data from table storage for a particulart customer and partition
            ITableStorageHelper TableStoreHelper = new TableStorageHelper();
            JRTEntities = TableStoreHelper.JRTData(date, Property);

            //get battery resolved alert from the alert logs table for a particular customer
            List<AlertEntity> AlertList = new List<AlertEntity>();
            AlertList = TableStoreHelper.GetBatteryResolvedAlertsForJRT(date, Property);

            //Aggregate eHRT Device Logs
            if (JRTEntities.Count != 0)
                DeviceLogs = AggregateJRTLogs(date, JRTEntities, AlertList);

            return DeviceLogs;
        }


        private static List<UsageMart> AggregateJRTLogs(DateTime date, List<JRTEntityLog> JRTEntities, List<AlertEntity> AlertList)
        {
            List<UsageMart> DeviceLogs = new List<UsageMart>();

            var JRTTemp = (from JRT in JRTEntities
                           group JRT by new
                           {
                               JRT.DeviceId,
                               JRT.CustomerId,
                               JRT.PropertyId,
                               JRT.BuildingId,
                               JRT.FloorId,
                               JRT.FloorLevel,
                               JRT.WashroomId,
                               JRT.DeviceType
                           } into grp
                           let maxof = grp.Max(e => e.TotalRollsDispensed)
                           from JRT in grp
                           where JRT.TotalRollsDispensed == maxof
                           select new
                           {
                               JRT.DeviceId,
                               JRT.CustomerId,
                               JRT.PropertyId,
                               JRT.BuildingId,
                               JRT.FloorId,
                               JRT.FloorLevel,
                               JRT.WashroomId,
                               JRT.DeviceType,
                               JRT.TotalRollsDispensed
                           }).Distinct().ToList();

            var JRTRefill = JRTEntities.GroupBy(g => g.DeviceId)
                .Select(ehrt => new
                {
                    DeviceId = ehrt.First().DeviceId,
                    BatteryRefill = ehrt.Sum(s => s.RefilledBatteryBeforeThreshold),
                    TowelRefill = ehrt.Sum(s1 => s1.RefilledTissueBeforeThreshold)
                }).ToList();

            List<BusinessEntity.Aggregation.DeviceWashroom> DeviceWashroomIds = new List<BusinessEntity.Aggregation.DeviceWashroom>();
            DeviceWashroomIds = (from dl in JRTTemp
                                 select new BusinessEntity.Aggregation.DeviceWashroom { DeviceId = dl.DeviceId, WashroomId = dl.WashroomId.ToString() }).Distinct().ToList();

            //get the devicelogs for previous day
            IAggregationWorker SqlHelper = new AggregationWorker();
            List<UsageMart> DeviceList = new List<UsageMart>();
            DeviceList = SqlHelper.GetAllDeviceForJRTnSRBneSoap(DeviceWashroomIds);
            //DeviceList = SqlHelper.GetAllDevice(DeviceIds, date);

            //aggregate
            DateTimeFormatInfo dfi = DateTimeFormatInfo.CurrentInfo;
            Calendar cal = dfi.Calendar;
            foreach (var JRT in JRTTemp)
            {
                UsageMart deviceEnt = new UsageMart();
                deviceEnt.CustomerId = JRT.CustomerId.ToString();
                deviceEnt.PropertyId = JRT.PropertyId.ToString();
                deviceEnt.BuildingId = JRT.BuildingId.ToString();
                deviceEnt.FloorId = JRT.FloorId.ToString();
                deviceEnt.FloorName = JRT.FloorLevel.ToString();
                deviceEnt.WashRoomId = JRT.WashroomId.ToString();
                deviceEnt.DeviceId = JRT.DeviceId;
                deviceEnt.DeviceType = JRT.DeviceType.ToString();
                deviceEnt.UsageDate = date;
                deviceEnt.UsageDay = date.Day;
                deviceEnt.UsageDayOfWeek = date.ToString("ddd");
                deviceEnt.UsageWeek = cal.GetWeekOfYear(date, dfi.CalendarWeekRule, dfi.FirstDayOfWeek);
                deviceEnt.UsageMonth = date.ToString("MMM");
                deviceEnt.UsageYear = date.Year;
                deviceEnt.TotalUsed = Convert.ToInt32(JRT.TotalRollsDispensed);
                int totalUsedYesterday = (from d in DeviceList
                                          where d != null && d.DeviceId == deviceEnt.DeviceId
                                          select d.TotalUsed).FirstOrDefault();

                //if (totalUsedYesterday != null)
                //{
                if (totalUsedYesterday == 0)
                    deviceEnt.CountOfUsage = Convert.ToInt32(JRT.TotalRollsDispensed);
                else
                    deviceEnt.CountOfUsage = Convert.ToInt32(JRT.TotalRollsDispensed) < totalUsedYesterday ? Convert.ToInt32(JRT.TotalRollsDispensed) : (Convert.ToInt32(JRT.TotalRollsDispensed)) - totalUsedYesterday;
                //}
                //else
                //{
                //    deviceEnt.CountOfUsage = Convert.ToInt32(JRT.TotalRollsDispensed);
                //}

                var batteryChange = (from a in AlertList
                                     where JRT.DeviceId == a.DeviceId & a.IsAlert == 0
                                     select a).ToList();
                if (batteryChange.Count != 0)
                    deviceEnt.CountOfBattery = batteryChange.Count;
                else
                    deviceEnt.CountOfBattery = 0;

                deviceEnt.TotalBatteryChange = 0;
                //deviceEnt.CountOfBattery = 0;
                deviceEnt.TotalPaperTowel = 0;
                deviceEnt.CountOfPaperUsed = 0;
                deviceEnt.DispenserSize = "None";

                var refill = (from re in JRTRefill
                              where re.DeviceId == JRT.DeviceId
                              select re).FirstOrDefault();
                if (refill != null)
                {
                    deviceEnt.BatteryRefillBeforeThres = refill.BatteryRefill;
                    deviceEnt.TowelRefillBeforeThres = refill.TowelRefill;
                }
                else
                {
                    deviceEnt.BatteryRefillBeforeThres = 0;
                    deviceEnt.TowelRefillBeforeThres = 0;
                }

                DeviceLogs.Add(deviceEnt);
            }

            return DeviceLogs;
        }

    }
}
