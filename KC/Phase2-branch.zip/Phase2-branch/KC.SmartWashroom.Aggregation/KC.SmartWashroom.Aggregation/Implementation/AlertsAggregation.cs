﻿using KC.SmartWashroom.Aggregation.Interface;
using KC.SmartWashroom.BusinessEntities.AlertEngineEntities;
using KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers;
using KC.SmartWashroom.DataAccess.DataWorkers.Table_Workers;
using KC.SmartWashroom.DataAccess.Skeleton;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace KC.SmartWashroom.Aggregation.Implementation
{
    public class AlertsAggregation : IAlertsAggregation
    {
        public List<AlertMart> Aggregate(DateTime date, BusinessEntities.Property Property)
        {
            ITableStorageHelper TableHelper = new TableStorageHelper();
            List<AlertEntity> AlertEntityList = new List<AlertEntity>();

            //read all the alerts for a particular customer for a particular date
            AlertEntityList = TableHelper.ReadAlertData(date, Property);
            List<AlertMart> AlertList = new List<AlertMart>();
            //group the alerts based on the meta data
            if (AlertEntityList.Count != 0)
                AlertList = AggregateAlerts(AlertEntityList, date);

            return AlertList;
        }

        //group the alerts based on the meta data
        private static List<AlertMart> AggregateAlerts(List<AlertEntity> AlertEntityList, DateTime date)
        {
            List<AlertMart> AlertList = new List<AlertMart>();
            DateTimeFormatInfo dfi = DateTimeFormatInfo.CurrentInfo;
            Calendar cal = dfi.Calendar;
            var Alerts = (from Alert in AlertEntityList
                          group Alert by new
                          {
                              Alert.CustomerID,
                              Alert.PropertyID,
                              Alert.BuildingId,
                              Alert.FloorId,
                              Alert.FloorLevel,
                              Alert.WashroomId,
                              Alert.DeviceId,
                              Alert.DeviceType,
                              Alert.AlertType
                          } into grp
                          select new
                          {
                              grp.Key.CustomerID,
                              grp.Key.PropertyID,
                              grp.Key.BuildingId,
                              grp.Key.FloorId,
                              grp.Key.FloorLevel,
                              grp.Key.WashroomId,
                              grp.Key.DeviceId,
                              grp.Key.DeviceType,
                              grp.Key.AlertType,
                              CountOfAlert = grp.Sum(g => g.IsAlert)
                          }).ToList();

            foreach (var Alt in Alerts)
            {
                AlertMart Alert = new AlertMart();

                Alert.AlertDate = date;
                Alert.AlertDay = date.Day;
                Alert.AlertMonth = date.ToString("MMM");
                Alert.AlertDayOfWeek = date.ToString("ddd");
                Alert.AlertWeek = cal.GetWeekOfYear(date, dfi.CalendarWeekRule, dfi.FirstDayOfWeek);
                Alert.AlertYear = date.Year;
                Alert.CustomerId = Alt.CustomerID.ToString();
                Alert.PropertyId = Alt.PropertyID.ToString();
                Alert.BuildingId = Alt.BuildingId.ToString();
                Alert.FloorId = Alt.FloorId.ToString();
                Alert.FloorName = Alt.FloorLevel.ToString();
                Alert.WashRoomId = Alt.WashroomId.ToString();
                Alert.DeviceId = Alt.DeviceId;
                Alert.DeviceType = Alt.DeviceType.ToString();
                Alert.AlertType = Alt.AlertType;
                Alert.CountOfAlert = Alt.CountOfAlert;

                AlertList.Add(Alert);
            }

            return AlertList;
        }

    }
}
