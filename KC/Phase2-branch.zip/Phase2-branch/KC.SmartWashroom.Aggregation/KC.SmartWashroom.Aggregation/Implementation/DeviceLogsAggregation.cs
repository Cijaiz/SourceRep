﻿using KC.SmartWashroom.Aggregation.Interface;
using KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers;
using System;
using System.Collections.Generic;
using System.Linq;

namespace KC.SmartWashroom.Aggregation.Implementation
{
    public class DeviceLogsAggregation : IDeviceLogsAggregation
    {
        public List<UsageMart> Aggregate(DateTime Date, BusinessEntities.Property Property)
        {
            List<UsageMart> DeviceLogs = new List<UsageMart>();

            //Aggregate eHRT device logs
            IeHRTAggregate eHRTAgg = new eHRTAggregate();
            List<UsageMart> eHRTlogs = new List<UsageMart>();
            eHRTlogs = eHRTAgg.ProcesseHRT(Date, Property);
            if (eHRTlogs.Count() != 0)
            {
                DeviceLogs.AddRange(eHRTlogs);
            }

            //Aggregate JRT Device Logs
            IJRTAggregate JRTAgg = new JRTAggregate();
            List<UsageMart> JRTlogs = new List<UsageMart>();
            JRTlogs = JRTAgg.ProcessJRT(Date, Property);
            if (JRTlogs.Count() != 0)
            {
                DeviceLogs.AddRange(JRTlogs);
            }

            //Aggregate SRB Device Logs
            ISRBAggregate SRBAgg = new SRBAggregate();
            List<UsageMart> SRBlogs = new List<UsageMart>();
            SRBlogs = SRBAgg.ProcessSRB(Date, Property);
            if (SRBlogs.Count() != 0)
            {
                DeviceLogs.AddRange(SRBlogs);
            }

            //Aggregate eSoap Device logs
            IESOAPAggregate eSoapAgg = new ESOAPAggregate();
            List<UsageMart> eSoaplogs = new List<UsageMart>();
            eSoaplogs = eSoapAgg.ProcesseSOAP(Date, Property);
            if (eSoaplogs.Count() != 0)
            {
                DeviceLogs.AddRange(eSoaplogs);
            }

            return DeviceLogs;
        }
    }
}
