﻿using KC.SmartWashroom.Aggregation.Implementation;
using KC.SmartWashroom.Aggregation.Interface;
using BusinessEntity = KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.Helper;
using KC.SmartWashroom.Core.NotificationUtility;
using KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers;
using KC.SmartWashroom.DataAccess.Skeleton;
using Microsoft.WindowsAzure.Storage.Queue;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml.Serialization;
using KC.SmartWashroom.Core.Log;

namespace KC.SmartWashroom.Aggregation
{
    public class ReportAggregation
    {
        private static IAggregationWorker SQLHelper = null;

        public ReportAggregation()
        {
            SQLHelper = new AggregationWorker();
        }

        public void Aggregation()
        {
            //List<Customer> CustomerDetails = new List<Customer>();
            //CustomerDetails = SQLHelper.GetCustomerDetails();

            List<BusinessEntity.Property> Properties = new List<BusinessEntity.Property>();
            Properties = SQLHelper.GetAllProperties();

            if (Properties.Count != 0)
            {
                //Run the aggregation for each customer
                foreach (var Prop in Properties)
                {
                    //check when the aggregation ran last for the particular customer
                    AggregationStatu Status = new AggregationStatu();
                    Status = SQLHelper.GetAggregationDetail(Prop.ID);

                    if (Status != null)
                    {
                        //calculate range for which the aggregation needs to run
                        DateTime checkIn = Status.ProcessedDate.AddDays(1);
                        DateTime checkOut = DateTime.UtcNow.Date;

                        TimeSpan span = checkOut - checkIn;
                        List<DateTime> range = new List<DateTime>();
                        for (int day = 0; day <= span.Days; day++)
                        {
                            range.Add(checkIn.AddDays(day));
                        }

                        //check if the dates to be processed is null
                        if (range.Count != 0)
                        {
                            foreach (var date in range)
                            {
                                CommonAggregation(date, Prop);
                            }
                        }
                    }
                    else
                    {
                        DateTime Date = DateTime.UtcNow.AddDays(-1);
                        CommonAggregation(Date, Prop);
                    }
                }
            }
        }



        public void AggregationEngine()
        {
            try
            {
                string queueName = CommonHelper.GetConfigSetting(AggregationConstants.SchedulerQueue);
                AzureHelper.AzureConnectionString = CommonHelper.GetConfigSetting(AggregationConstants.StorageConnectionString);
                AzureHelper.CreateQueueIfNotExists(queueName);
                int MessageCount = AzureHelper.GetQueueMessagesCount(queueName);
                BusinessEntity.Property Property = new BusinessEntity.Property();

                if (MessageCount != 0)
                {
                    CloudQueueMessage retrievedMessage = AzureHelper.DownloadSingleMessagesFromQueue(queueName);

                    if (retrievedMessage != null)
                    {
                        XmlSerializer dcs = new XmlSerializer(typeof(BusinessEntity.StorageQueueMessage));
                        BusinessEntity.StorageQueueMessage message = null;
                        using (MemoryStream xmlstream = new MemoryStream(Encoding.Unicode.GetBytes(retrievedMessage.AsString)))
                        {
                            message = (BusinessEntity.StorageQueueMessage)dcs.Deserialize(xmlstream);
                        }

                        string PropertyId = message.Message.ToString();
                        int i;
                        if (Int32.TryParse(PropertyId, out i))
                        {
                            //Customer CustomerDetail = new Customer();
                            //CustomerDetail.ID = Convert.ToInt32(PropertyId);

                            //check when the aggregation ran last for the particular customer
                            AggregationStatu Status = new AggregationStatu();
                            Status = SQLHelper.GetAggregationDetail(Convert.ToInt32(PropertyId));
                            //Customer Cus = new Customer();
                            //Cus = SQLHelper.GetCustomerDetailsById(Convert.ToInt32(PropertyId));

                            //Get Property details
                            Property = SQLHelper.GetPropertyDetails(Convert.ToInt32(PropertyId));
                            if (Status != null && Property != null)
                            {
                                //calculate range for which the aggregation needs to run
                                DateTime checkIn = Status.ProcessedDate;
                                DateTime checkOut = DateTime.UtcNow.Date;

                                TimeSpan span = checkOut - checkIn;
                                List<DateTime> range = new List<DateTime>();
                                for (int day = 0; day <= span.Days; day++)
                                {
                                    range.Add(checkIn.AddDays(day));
                                }

                                //check if the dates to be processed is null
                                if (range.Count != 0)
                                {
                                    foreach (var date in range)
                                    {
                                        CommonAggregation(date, Property);
                                    }
                                }
                            }
                            else
                            {
                                if (Property != null && Property.ID != 0)
                                {
                                    DateTime Date = DateTime.UtcNow.AddDays(-1);
                                    CommonAggregation(Date, Property);
                                }
                                else
                                {
                                    Logger.Debug("Property is null or Property Id is 0");
                                }
                            }

                            //Process the message in less than 15 mins, and then delete the message
                            AzureHelper.DeleteQueueMessage(queueName, retrievedMessage);
                        }
                    }
                }
            }
            catch (Exception exp)
            {
                Logger.Error(exp.ToString());
            }
        }


        public static void CommonAggregation(DateTime Date, BusinessEntity.Property Property)
        {

            //aggregate DeviceLogs
            List<UsageMart> DeviceLogs = new List<UsageMart>();
            IDeviceLogsAggregation DeviceLogsAggregation = new DeviceLogsAggregation();

            //Delete device logs data for the particular date and customer
            SQLHelper.DeleteDeviceLogs(Property, Date);

            //Delete alert data for the particular date and customer
            SQLHelper.DeleteAlertLogs(Property, Date);

            DeviceLogs = DeviceLogsAggregation.Aggregate(Date, Property);

            //check if the devicelogs are null
            if (DeviceLogs.Count != 0)
            {
                //bulk insert data into usage mart table
                SQLHelper.BulkInsertDeviceLogs(DeviceLogs);
            }

            //Aggreagte Alerts
            IAlertsAggregation AlertAgg = new AlertsAggregation();
            List<AlertMart> AlertLogs = new List<AlertMart>();
            AlertLogs = AlertAgg.Aggregate(Date, Property);

            //check if the alert are null
            if (AlertLogs.Count != 0)
            {
                //bulkInsert Alerts
                SQLHelper.BulkInsertAlerts(AlertLogs);
            }

            DateTime CurrentDate = DateTime.UtcNow.Date;
            //update status table with success
            if (!CurrentDate.Equals(Date))
                SQLHelper.InsertSuccessMsg(Date, Property);
        }

    }
}
