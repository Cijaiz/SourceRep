﻿using KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers;
using System;
using System.Collections.Generic;

namespace KC.SmartWashroom.Aggregation.Interface
{
    public interface ISRBAggregate
    {
        List<UsageMart> ProcessSRB(DateTime date, BusinessEntities.Property Property);
    }
}
