﻿using KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers;
using System;
using System.Collections.Generic;

namespace KC.SmartWashroom.Aggregation.Interface
{
    public interface IeHRTAggregate
    {
        List<UsageMart> ProcesseHRT(DateTime date, BusinessEntities.Property Property);
    }
}
