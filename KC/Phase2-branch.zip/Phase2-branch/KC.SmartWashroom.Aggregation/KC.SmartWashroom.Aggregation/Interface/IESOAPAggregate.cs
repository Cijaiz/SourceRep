﻿using KC.SmartWashroom.DataAccess.DataWorkers.Entity_Workers;
using System;
using System.Collections.Generic;

namespace KC.SmartWashroom.Aggregation.Interface
{
    public interface IESOAPAggregate
    {
        List<UsageMart> ProcesseSOAP(DateTime date, BusinessEntities.Property Property);
    }
}
