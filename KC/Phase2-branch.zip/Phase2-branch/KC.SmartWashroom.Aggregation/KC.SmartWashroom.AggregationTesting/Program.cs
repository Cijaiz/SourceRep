﻿using KC.SmartWashroom.Aggregation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KC.SmartWashroom.AggregationTesting
{
    class Program
    {
        static void Main(string[] args)
        {
            ReportAggregation ReportAggregate = new ReportAggregation();
            ReportAggregate.Aggregation();
        }
    }
}
