﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KC.SmartWashroom.Reports.ReportHelper
{
    public class BasicChart
    {
        public string Id {get; set;}
        public string Title {get; set;}
        public string ChartName {get; set;}
        public List<string> Series {get; set;}
        public string CategoryAxis {get; set;}
        public string SecondaryAxis { get; set; }        
        public string XAxisName {get; set;}
        public string YAxisName {get; set;}       
    }
}