﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KC.SmartWashroom.Reports.ReportHelper
{
    public static class GenericExtensions
    {

        public static List<string> ToStringList(this IEnumerable<object> items, bool distinct = false, bool sorted = false)
        {
            List<string> stringItems = new List<string>();

            foreach (object item in items)
            {
                stringItems.Add(item.ToString());
            }

            if (distinct == true)
            {
                stringItems = stringItems.Distinct().ToList();
            }

            if (sorted == true)
            {
                stringItems = stringItems.OrderBy(s => s).ToList();
            }

            return stringItems;
        }

    }
}