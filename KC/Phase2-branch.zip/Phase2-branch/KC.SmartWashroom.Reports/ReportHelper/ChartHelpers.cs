﻿using KC.SmartWashroom.BusinessEntities;
using KC.SmartWashroom.Core.Constants;
using KC.SmartWashroom.Core.Localization;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;

namespace KC.SmartWashroom.Reports.ReportHelper
{
    public class ChartHelpers
    {

        public StringBuilder BuildChartHtml(List<ReportGenericEntity> data, BasicChart Chart)
        {
            //var chartType = "line";
            var chartType = Chart.ChartName;
            int count = 0;
            string templateContent = ReadTemplate(chartType);

            List<string> categoryAxisValues = data.Select(d => "\"" + d[Chart.CategoryAxis] + "\"").ToStringList(true);

            string categoryAxisData = string.Join(",", categoryAxisValues.ToArray());



            string seriesData = BuildSeriesData(data, data.Select(d => d[Chart.CategoryAxis]).ToStringList(true), Chart);
           

            //Check if it is a bar or line chart
            //For line chart X axis is count of Category Axis values
            //For bar X axis is Units Consumed
            if (Chart.ChartName == "line")
            {
                count = categoryAxisValues.Count;
            }
            else
            {
                //Check for CategoryAxis
                if (Chart.CategoryAxis == TrafficChartConstants.SecondaryAxisSupplyWeekAndMonth)
                {
                    string val = (from d in data
                                  orderby d[TrafficChartConstants.YAxisProductUsage] descending
                                  select d[TrafficChartConstants.YAxisProductUsage]).FirstOrDefault().ToString();
                    Int32.TryParse(val, out count);
                }
                else
                {
                    string val = (from d in data
                                  orderby d[AlertChartConstants.YAxis] descending
                                  select d[AlertChartConstants.YAxis]).FirstOrDefault().ToString();
                    Int32.TryParse(val, out count);
                }

            }

            //getting diaplayname for axis 
            StringBuilder chartContent = new StringBuilder();

            chartContent.Append(System.Web.HttpUtility.HtmlDecode(PopulateChartHtml(templateContent, seriesData,
                 categoryAxisData, Chart, count)));

            return chartContent;
        }


        private static string PopulateChartHtml(string templateContent, string seriesData, string categoryAxisData, BasicChart Chart, int dataCount)
        {
            int newGuidHash = Guid.NewGuid().GetHashCode();
            string newId = newGuidHash >= 0 ? newGuidHash.ToString() : (newGuidHash * -1).ToString();
            string name = string.Format("Chart{0}", newId);

            templateContent = templateContent.Replace(ChartConstants.NAME, name);
            templateContent = templateContent.Replace(ChartConstants.CHART_TITLE, Chart.Title);
            templateContent = templateContent.Replace(ChartConstants.DATA_SERIES, seriesData);
            templateContent = templateContent.Replace(ChartConstants.VALUE_AXIS_TITLE, ResourceLocalization.LoadString(Chart.YAxisName));
            templateContent = templateContent.Replace(ChartConstants.CATEGORY_AXIS_DATA, categoryAxisData);
            templateContent = templateContent.Replace(ChartConstants.CATEGORY_AXIS_TITLE, ResourceLocalization.LoadString(Chart.XAxisName));
            templateContent = templateContent.Replace(ChartConstants.BAR_CHART_AXIS, Chart.CategoryAxis);
            templateContent = templateContent.Replace(ChartConstants.AXIS_DATA_COUNT, dataCount.ToString());

            return templateContent;
        }

        private static string BuildSeriesData(List<ReportGenericEntity> data, List<string> categoryAxisData, BasicChart chart)
        {
            StringBuilder seriesBuilder = new StringBuilder();
            //List<string> appliedColors = new List<string>();
            List<object> seriesData = default(List<object>);

            List<string> secondaryAxisData = data.Select(d => d[chart.SecondaryAxis]).ToStringList(true);

            List<ReportGenericEntity> data1 = new List<ReportGenericEntity>();
            secondaryAxisData.ForEach(sad =>
                {
                    categoryAxisData.ForEach(cad =>
                    {
                        List<ReportGenericEntity> ent = data.Where(d => d[chart.CategoryAxis].ToString() == cad.ToString() &&
                                                                  d[chart.SecondaryAxis].ToString() == sad).ToList();
                        int sum = ent.Sum(d => Convert.ToInt32(d[chart.Series[0]]));
                        ReportGenericEntity newEntity = new ReportGenericEntity();
                        newEntity[chart.CategoryAxis] = cad;
                        newEntity[chart.SecondaryAxis] = sad;
                        newEntity[chart.Series[0]] = sum;
                        data1.Add(newEntity);
                    });
                });

            if (chart.ChartName.Contains("line"))
            {
                if (chart.SecondaryAxis != null)
                {
                    secondaryAxisData.ForEach(sad =>
                    {
                        seriesData = new List<object>();

                        categoryAxisData.ForEach(pad =>
                        {
                            ReportGenericEntity entity = data1.Where(d => d[chart.CategoryAxis].ToString() == pad.ToString() &&
                                                                  d[chart.SecondaryAxis].ToString() == sad).FirstOrDefault();

                            seriesData.Add(entity != null ? entity[chart.Series[0]] : 0);
                        });

                        seriesBuilder.Append(CreateSeries(string.Format("{0} : {1}", chart.SecondaryAxis, sad), sad, seriesData, chart.ChartName, true));

                        seriesBuilder.AppendLine(",");

                    });
                }
            }
            else
            {
                if (chart.CategoryAxis != null)
                {
                    categoryAxisData.ForEach(pad =>
                        {
                            seriesData = new List<object>();
                            secondaryAxisData.ForEach(sad =>
                                {
                                    ReportGenericEntity entity = data1.Where(d => d[chart.SecondaryAxis].ToString() == sad.ToString() &&
                                        d[chart.CategoryAxis].ToString() == pad).FirstOrDefault();

                                    seriesData.Add(entity != null ? entity[chart.Series[0]] : 0);
                                });

                            seriesBuilder.Append(CreateSeriesForBar(chart.CategoryAxis, pad, seriesData, chart.ChartName, true));

                            seriesBuilder.AppendLine(",");
                        });
                }
            }

            return seriesBuilder.ToString().TrimEnd(new char[] { ',' });
        }


        private static string CreateSeries(string seriesName, string categoryName, List<object> data, string type, bool stack = true)
        {
            StringBuilder seriesBuilder = new StringBuilder();

            seriesBuilder.Append("{");
            seriesBuilder.Append(string.Format("type:\"{0}\",", type));
            seriesBuilder.Append(string.Format("data:[{0}],", string.Join(",", data.ToArray())));

            switch (categoryName)
            {
                case TrafficChartConstants.eHRTName: seriesBuilder.Append(string.Format("color:\"{0}\",", ChartColourConstants.eHRT));
                    break;
                case TrafficChartConstants.JRTName: seriesBuilder.Append(string.Format("color:\"{0}\",", ChartColourConstants.JRT));
                    break;
                case TrafficChartConstants.eSoapName: seriesBuilder.Append(string.Format("color:\"{0}\",", ChartColourConstants.eSoap));
                    break;
                case TrafficChartConstants.SRBName: seriesBuilder.Append(string.Format("color:\"{0}\",", ChartColourConstants.SRB));
                    break;
                case AlertChartConstants.LowPaper: seriesBuilder.Append(string.Format("color:\"{0}\",", ChartColourConstants.LowPaper));
                    break;
                case AlertChartConstants.LowBattery: seriesBuilder.Append(string.Format("color:\"{0}\",", ChartColourConstants.LowBattery));
                    break;
                case AlertChartConstants.PaperJam: seriesBuilder.Append(string.Format("color:\"{0}\",", ChartColourConstants.PaperJam));
                    break;
                case AlertChartConstants.LowSoap: seriesBuilder.Append(string.Format("color:\"{0}\",", ChartColourConstants.LowSoap));
                    break;
                default:
                    seriesBuilder.Append(string.Format("color:\"{0}\",", ChartColourConstants.Others));
                    break;
            }
            seriesBuilder.Append("stack:false,");

            seriesBuilder.Append(string.Format("name:\"{0}\"", ResourceLocalization.LoadString(seriesName.Substring(seriesName.IndexOf(':') + 1).Trim())));

            seriesBuilder.Append("}");

            return seriesBuilder.ToString().TrimEnd(new char[] { ',' });
        }

        private static string CreateSeriesForBar(string seriesName, string categoryName, List<object> data, string type, bool stack = true)
        {
            StringBuilder seriesBuilder = new StringBuilder();

            seriesBuilder.Append("{ ");
            string units = GetUnits(categoryName);

            seriesBuilder.Append(string.Format(" \"{0}\" : \"{1}{2}\" , ", seriesName, ResourceLocalization.LoadString(categoryName.Trim()), units));
            seriesBuilder.Append(string.Format(" \"value\" : {0} , ", string.Join(",", data.ToArray())));
            //seriesBuilder.Append(" \"userColor\": \"#ffd600\" ");
            switch (categoryName)
            {
                case TrafficChartConstants.eHRTName: seriesBuilder.Append(string.Format(" \"userColor\": \"{0}\" ", ChartColourConstants.eHRT));
                    break;
                case TrafficChartConstants.JRTName: seriesBuilder.Append(string.Format(" \"userColor\": \"{0}\" ", ChartColourConstants.JRT));
                    break;
                case TrafficChartConstants.eSoapName: seriesBuilder.Append(string.Format(" \"userColor\": \"{0}\" ", ChartColourConstants.eSoap));
                    break;
                case TrafficChartConstants.SRBName: seriesBuilder.Append(string.Format(" \"userColor\": \"{0}\" ", ChartColourConstants.SRB));
                    break;
                case TrafficChartConstants.Batteries: seriesBuilder.Append(string.Format(" \"userColor\": \"{0}\" ", ChartColourConstants.Batteries));
                    break;
                case AlertChartConstants.LowPaper: seriesBuilder.Append(string.Format(" \"userColor\": \"{0}\" ", ChartColourConstants.LowPaper));
                    break;
                case AlertChartConstants.LowBattery: seriesBuilder.Append(string.Format(" \"userColor\": \"{0}\" ", ChartColourConstants.LowBattery));
                    break;
                case AlertChartConstants.PaperJam: seriesBuilder.Append(string.Format(" \"userColor\": \"{0}\" ", ChartColourConstants.PaperJam));
                    break;
                case AlertChartConstants.LowSoap: seriesBuilder.Append(string.Format(" \"userColor\": \"{0}\" ", ChartColourConstants.LowSoap));
                    break;
                default:
                    seriesBuilder.Append(string.Format(" \"userColor\": \"{0}\" ", ChartColourConstants.Others));
                    break;
            }

            seriesBuilder.Append(" }");

            return seriesBuilder.ToString().TrimEnd(new char[] { ',' });
        }

        private static string GetUnits(string categoryData)
        {
            string unit = string.Empty;

            switch (categoryData)
            {
                case TrafficChartConstants.eHRTName: unit = TrafficChartConstants.Rolls;
                    break;
                case TrafficChartConstants.JRTName: unit = TrafficChartConstants.Rolls;
                    break;
                case TrafficChartConstants.SRBName: unit = TrafficChartConstants.Rolls;
                    break;
                case TrafficChartConstants.eSoapName: unit = TrafficChartConstants.Bottles;
                    break;
                case TrafficChartConstants.Batteries: unit = TrafficChartConstants.Numbers;
                    break;
                default:
                    break;
            }

            return ResourceLocalization.LoadString(unit);
        }

        private static string ReadTemplate(string chartType)
        {
            string result = string.Empty;

            string path = string.Format("~/ChartTemplate/{0}Chart.template", chartType);
            using (StreamReader streamReader = File.OpenText(HttpContext.Current.Server.MapPath(path)))
            {
                result = streamReader.ReadToEnd();
            }

            return result;
        }

    }
}