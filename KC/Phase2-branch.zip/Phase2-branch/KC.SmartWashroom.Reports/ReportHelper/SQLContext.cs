﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KC.SmartWashroom.Reports.ReportHelper
{
    public class SQLContext
    {
        public IEnumerable<GenericEntity> ReadData()
        {
            string query = "select AlertDayOfWeek,DeviceType,sum(countofalert) as CountOfAlert from alertmart group by AlertDayOfWeek,DeviceType";

            return ReadData(query);
        }

        public IEnumerable<GenericEntity> ReadData(string query)
        {
            SQLHelper helper = new SQLHelper();
            foreach (var item in helper.ReadData(query))
            {
                yield return item;
            }
        }
    }
}