﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KC.SmartWashroom.Reports.ReportHelper
{
    public class ChartContent
    {
        public string ChartHTML { get; set; }
    }
}