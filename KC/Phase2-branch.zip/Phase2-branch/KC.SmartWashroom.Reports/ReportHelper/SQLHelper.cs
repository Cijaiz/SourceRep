﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace KC.SmartWashroom.Reports.ReportHelper
{
    public class SQLHelper
    {
        public IEnumerable<GenericEntity> ReadData(string query)
        {
            using (SqlConnection con = new SqlConnection("Server=pxhl6h2q56.database.windows.net,1433;Database=KCReports;User Id=sa-1;Password=password-1;"))
            {
                con.Open();
                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = con;
                    command.CommandText = query;

                    using (var dataReader = command.ExecuteReader())
                    {
                        while (dataReader.Read())
                        {
                            GenericEntity newEntity = new GenericEntity();

                            int fieldCount = dataReader.FieldCount;
                            for (int i = 0; i < fieldCount; i++)
                            {
                                newEntity[dataReader.GetName(i)] = dataReader.GetValue(i);
                            }

                            yield return newEntity;
                        }
                    }
                }
            }
            yield break;

        }
       
    }
}