﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KC.SmartWashroom.Reports.ReportHelper
{
    public class ChartConstants
    {
        public const string NAME = "{NAME}";
        public const string CHART_TITLE = "{CHART_TITLE}";
        public const string DATA_SERIES = "{DATA_SERIES}";
        public const string VALUE_AXIS_TITLE = "{VALUE_AXIS_TITLE}";
        public const string CATEGORY_AXIS_DATA = "{CATEGORY_AXIS_DATA}";
        public const string CATEGORY_AXIS_TITLE = "{CATEGORY_AXIS_TITLE}";
        public const string BAR_CHART_AXIS = "{BAR_CHART_AXIS}";
        public const string AXIS_DATA_COUNT = "{DATACOUNT}";
        public const string CHART_TYPE = "{CHARTTYPE}";
    }
}